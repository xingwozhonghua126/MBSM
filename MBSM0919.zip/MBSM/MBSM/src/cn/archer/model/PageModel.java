package cn.archer.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PageModel<Selebith> {
    //结果集  

    private List<Selebith> list;

    //查询记录数  
    private int totalRecords;

    //每页多少条数据  
    private int pageSize;

    //第几页  
    private int pageNo;

    public PageModel(List<Selebith> list) {
        this.list = list;
        if (list == null) {
            this.totalRecords = 0;
        } else {
            this.totalRecords = list.size();
        }
        this.pageSize = 12;
    }

    /**
     * 总页数
     *
     * @return
     */
    public int getTotalPages() {
        return (totalRecords + pageSize - 1) / pageSize;
    }
    
    
    public void fanzhuan() {
        Collections.reverse(list);
    }
    /**
     * 取得首页
     *
     * @return
     */
    public int getTopPageNo() {
        return 1;
    }

    /**
     * 上一页
     *
     * @return
     */
    public int getPreviousPageNo() {
        if (pageNo <= 1) {
            return 1;
        }
        return pageNo - 1;
    }

    /**
     * 下一页
     *
     * @return
     */
    public int getNextPageNo() {
        if (pageNo >= getBottomPageNo()) {
            return getBottomPageNo();
        }
        return pageNo + 1;
    }

    /**
     * 取得尾页
     *
     * @return
     */
    public int getBottomPageNo() {
        return getTotalPages();
    }

    /**
     * 返回当前页list
     *
     * @return
     */
    public List<Selebith> getNoList() {
        List<Selebith> Nolist = new ArrayList<>();
        for (int index = (pageNo - 1) * pageSize; index < list.size(); index++) {
            if (index == pageNo * pageSize) {
                break;
            }
            Nolist.add(list.get(index));
        }
        return Nolist;
    }

    public List<Selebith> getList() {
        return list;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public int getPageSize() {
        return pageSize;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    /**
     * 返回当前页记录数起始编号
     *
     * @return
     */
    public int getPageNoRecordBegin() {
        if (pageNo == 0) {
            return 0;
        } else {
            return (pageNo - 1) * getPageSize();
        }
    }

    /**
     * 返回当前页记录数结束编号
     *
     * @return
     */
    public int getPageNoRecordEnd() {
        if (getPageNo() != getBottomPageNo()) {
            return pageNo * getPageSize();
        } else {
            return getTotalRecords();
        }
    }
}
