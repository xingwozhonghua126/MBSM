package cn.archer.model;


import cn.archer.mapper.plus.YzMapperPlus;
import cn.archer.pojo.FourTest;
import java.util.ArrayList;
import java.util.List;

public class YzFourtestPageModel {

    //Dao映射 
    private YzMapperPlus yzMapperPlus;

    //当前页面 
    private List<FourTest> Nolist;

    //查询记录数  
    private int totalRecords;

    //每页多少条数据  
    private int pageSize;

    //第几页  
    private int pageNo;
    
    public YzFourtestPageModel(int pageSize, YzMapperPlus yzMapperPlus) {
        this.yzMapperPlus = yzMapperPlus;
        this.pageSize = pageSize;
        this.Nolist = new ArrayList<>();
        this.pageNo = 1;
    }

        public void reset(int totalRecords)
    {
        this.totalRecords = totalRecords;
    }
 
    /**
     * 总页数
     *
     * @return
     */
    public int getTotalPages() {
        return (totalRecords + pageSize - 1) / pageSize;
    }

    /**
     * 取得首页
     *
     * @return
     */
    public int getTopPageNo() {
        return 1;
    }

    /**
     * 上一页
     *
     * @return
     */
    public int getPreviousPageNo() {
        if (pageNo <= 1) {
            return 1;
        }
        return pageNo -= 1;
    }

    /**
     * 下一页
     *
     * @return
     */
    public int getNextPageNo() {
        if (pageNo >= getBottomPageNo()) {
            return getBottomPageNo();
        }
        return pageNo += 1;
    }

    /**
     * 取得尾页
     *
     * @return
     */
    public int getBottomPageNo() {
        return getTotalPages();
    }

    /**
     * 返回当前页list
     *
     * @return
     */
    public List<FourTest> getNoList() {
        if (pageNo != getBottomPageNo()) {
            Nolist = (List<FourTest>) yzMapperPlus.selectAllfourtestBypage(getPageSize(), (pageNo - 1) * pageSize);
        } else {
            Nolist = (List<FourTest>) yzMapperPlus.selectAllfourtestBypage(getTotalRecords() - (pageNo - 1) * pageSize, (pageNo - 1) * pageSize);
        }
        return Nolist;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public int getPageSize() {
        return pageSize;
    }

    /**
     * 设置取得当前页
     *
     * @return
     */
    public int getPageNo() {
        return pageNo;
    }

    /**
     * 设置当前页
     *
     * @param pageNo
     */
    public void setPageNo(int pageNo) {
        if (pageNo > getBottomPageNo()) {
            this.pageNo = getTotalPages();
        } else if (pageNo < getTopPageNo()) {
            this.pageNo = getTopPageNo();
        } else {
            this.pageNo = pageNo;
        }
    }

    /**
     * 返回当前页记录数起始编号
     *
     * @return
     */
    public int getPageNoRecordBegin() {
        if (pageNo == 0) {
            return 0;
        } else {
            return (pageNo - 1) * getPageSize();
        }
    }

    /**
     * 返回当前页记录数结束编号
     *
     * @return
     */
    public int getPageNoRecordEnd() {
        if (getPageNo() != getBottomPageNo()) {
            return pageNo * getPageSize();
        } else {
            return getTotalRecords();
        }
    }
}
