package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.employeeIdtoNameSmap;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import cn.archer.mapper.BoarMapper;
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Childbirth;
import static cn.archer.utils.MyStaticMethod.setJTableRow;
import cn.archer.utils.MybatisUtil;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author Administrator
 */
public class FemaleBoarApp extends javax.swing.JDialog {

    private String formid0;
    private String zt;

    /**
     * Creates new form FormApp
     */
    public FemaleBoarApp(String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.setTitle("当前种母猪业绩信息");
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        List<Breeding> breedingtemp;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper mapper = sqlSession.getMapper(BoarMapper.class);
            breedingtemp = mapper.selectAllPZ(farmid0);
            sqlSession.close();
        }

        List<String> BreedingEmployee = new ArrayList<>();
        List<String> BreedingPzzt = new ArrayList<>();
        List<String> BreedingFance = new ArrayList<>();

        for (int i = 0; i < breedingtemp.size(); i++) {
            BreedingEmployee.add(employeeIdtoNameSmap.get(breedingtemp.get(i).getEmployeeid()));

            if (breedingtemp.get(i).getPzzt().equals("1")) {
                BreedingPzzt.add("检验");
            }
            if (breedingtemp.get(i).getPzzt().equals("2")) {
                BreedingPzzt.add("妊娠");
            }
            if (breedingtemp.get(i).getPzzt().equals("3")) {
                BreedingPzzt.add("返情");
            }

            BreedingFance.add(fenceIdtoNameSmap.get(breedingtemp.get(i).getFenceid()));

        }

        Object[][] tableModel01 = new Object[breedingtemp.size()][6];
        for (int j = 0; j < breedingtemp.size(); j++) {
            tableModel01[j][0] = breedingtemp.get(j).getId();
            tableModel01[j][1] = breedingtemp.get(j).getR_animal();
            tableModel01[j][2] = breedingtemp.get(j).getPzrq();
            tableModel01[j][3] = BreedingEmployee.get(j);
            tableModel01[j][4] = BreedingPzzt.get(j);
            tableModel01[j][5] = BreedingFance.get(j);
        }

        String[] tableHead01 = new String[]{"流水编号", "个体编号", "配种日期", "负责人  ", "配种状态 ", "所在栏舍  "};
        jTable1.setModel(new javax.swing.table.DefaultTableModel(tableModel01, tableHead01));
        setJTableRow(jTable1);
        //-----------------------------------------------------------------------------------

        List<Childbirth> childbirthtemp;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper mapper = sqlSession.getMapper(BoarMapper.class);
            childbirthtemp = mapper.selectAllFM(farmid0);
            sqlSession.close();
        }
        Object[][] tableModel02 = new Object[childbirthtemp.size()][7];
        for (int j = 0; j < childbirthtemp.size(); j++) {
            switch (childbirthtemp.get(j).getZt()) {
                case "1":
                    childbirthtemp.get(j).setZt("分娩状态");
                    break;
                case "2":
                    childbirthtemp.get(j).setZt("断奶状态");
                    break;
                case "3":
                    childbirthtemp.get(j).setZt("未知状态");
                    break;
            }

            tableModel02[j][0] = childbirthtemp.get(j).getId();
            tableModel02[j][1] = childbirthtemp.get(j).getR_animal();
            tableModel02[j][2] = childbirthtemp.get(j).getCzrq();
            tableModel02[j][3] = childbirthtemp.get(j).getZt();
            tableModel02[j][4] = employeeIdtoNameSmap.get(childbirthtemp.get(j).getFwemployeeid());
            tableModel02[j][5] = fenceIdtoNameSmap.get(childbirthtemp.get(j).getFenceid());
            tableModel02[j][6] = fenceIdtoNameSmap.get(childbirthtemp.get(j).getFwfenceid());
        }

        String[] tableHead02 = new String[]{"流水编号", "个体编号", "分娩日期", "当前状态", "负责人 ", "妊娠栏舍", "分娩栏舍"};
        jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel02, tableHead02));
        setJTableRow(jTable2);
        //----------------------------------------------------------------------------------

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper mapper = sqlSession.getMapper(BoarMapper.class);
            childbirthtemp = mapper.selectAllDM(farmid0);
            sqlSession.close();
        }
        Object[][] tableModel03 = new Object[childbirthtemp.size()][8];
        for (int j = 0; j < childbirthtemp.size(); j++) {
            tableModel03[j][0] = childbirthtemp.get(j).getId();
            tableModel03[j][1] = childbirthtemp.get(j).getR_animal();
            tableModel03[j][2] = childbirthtemp.get(j).getTc();
            tableModel03[j][3] = childbirthtemp.get(j).getDnrq();
            tableModel03[j][4] = childbirthtemp.get(j).getDnts();
            tableModel03[j][5] = childbirthtemp.get(j).getDnwz();
            tableModel03[j][6] = fenceIdtoNameSmap.get(childbirthtemp.get(j).getOutfenceid());
            tableModel03[j][7] = employeeIdtoNameSmap.get(childbirthtemp.get(j).getEmployeeid());
        }

        String[] tableHead03 = new String[]{"流水编号", "个体编号", "当前胎次", "断奶日期", "断奶头数 ", "断奶窝重", "断奶后栏舍", "负责人"};
        jTable3.setModel(new javax.swing.table.DefaultTableModel(tableModel03, tableHead03));
        setJTableRow(jTable3);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jDesktopPane4 = new javax.swing.JDesktopPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jDesktopPane5 = new javax.swing.JDesktopPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jDesktopPane3 = new javax.swing.JDesktopPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton8 = new javax.swing.JButton();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(305, 353));

        jLabel1.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel1.setText("当前种母猪业绩信息");

        jTabbedPane1.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jTabbedPane1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTabbedPane1FocusGained(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("楷体", 0, 14)); // NOI18N
        jTable1.setForeground(new java.awt.Color(0, 51, 102));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable1.getTableHeader().setResizingAllowed(false);
        jScrollPane1.setViewportView(jTable1);

        jDesktopPane4.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane4Layout = new javax.swing.GroupLayout(jDesktopPane4);
        jDesktopPane4.setLayout(jDesktopPane4Layout);
        jDesktopPane4Layout.setHorizontalGroup(
            jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE)
        );
        jDesktopPane4Layout.setVerticalGroup(
            jDesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("配种状态", jDesktopPane4);

        jTable2.setFont(new java.awt.Font("楷体", 0, 14)); // NOI18N
        jTable2.setForeground(new java.awt.Color(0, 51, 102));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable2.getTableHeader().setResizingAllowed(false);
        jScrollPane2.setViewportView(jTable2);

        jDesktopPane5.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane5Layout = new javax.swing.GroupLayout(jDesktopPane5);
        jDesktopPane5.setLayout(jDesktopPane5Layout);
        jDesktopPane5Layout.setHorizontalGroup(
            jDesktopPane5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE)
        );
        jDesktopPane5Layout.setVerticalGroup(
            jDesktopPane5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("分娩状态", jDesktopPane5);

        jTable3.setFont(new java.awt.Font("楷体", 0, 14)); // NOI18N
        jTable3.setForeground(new java.awt.Color(0, 51, 102));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable3.getTableHeader().setResizingAllowed(false);
        jScrollPane3.setViewportView(jTable3);

        jDesktopPane3.setLayer(jScrollPane3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane3Layout = new javax.swing.GroupLayout(jDesktopPane3);
        jDesktopPane3.setLayout(jDesktopPane3Layout);
        jDesktopPane3Layout.setHorizontalGroup(
            jDesktopPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE)
        );
        jDesktopPane3Layout.setVerticalGroup(
            jDesktopPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("断奶状态", jDesktopPane3);

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/详细信息L.png"))); // NOI18N
        jButton8.setText("详细信息");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(782, 782, 782)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(144, 144, 144))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(432, 432, 432)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1014, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton8)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1034, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 612, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

        //配种状态
        if (jTabbedPane1.getSelectedIndex() == 0) {
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            int selectedRow = jTable1.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null,
                        "请选择您要查看的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String farmid = (String) model.getValueAt(selectedRow, 0);
            BreedingApp breedingApp = new BreedingApp(farmid, this, true, 1);
            breedingApp.setVisible(true);
        }
        //分娩状态
        if (jTabbedPane1.getSelectedIndex() == 1) {
            DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
            int selectedRow = jTable2.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null,
                        "请选择您要查看的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String farmid = (String) model.getValueAt(selectedRow, 0);
            ChildbirthApp childbirthApp = new ChildbirthApp(farmid, this, true);
            childbirthApp.setVisible(true);
        }
        //妊娠状态
        if (jTabbedPane1.getSelectedIndex() == 2) {
            DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
            int selectedRow = jTable3.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null,
                        "请选择您要查看的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String farmid = (String) model.getValueAt(selectedRow, 0);
            WeaningApp weaningApp = new WeaningApp(farmid, this, true);
            weaningApp.setVisible(true);

        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jTabbedPane1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTabbedPane1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jTabbedPane1FocusGained

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton8;
    private static javax.swing.JDesktopPane jDesktopPane3;
    private static javax.swing.JDesktopPane jDesktopPane4;
    private static javax.swing.JDesktopPane jDesktopPane5;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    // End of variables declaration//GEN-END:variables
}
