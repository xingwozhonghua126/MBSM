package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.FourTestpage;
import static cn.archer.app.MainApp.employeeIdtoNameSmap;
import static cn.archer.app.MainApp.employeeJSThingsShow;
import static cn.archer.app.MainApp.employeeJSThingsmap;
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeeThingsmap;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.fenceNametoIdSmap;
import static cn.archer.app.MainApp.fourTestMapperPlus;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.swintypeIdtoNameSmap;
import static cn.archer.app.MainApp.swintypeNametoIdSmap;
import cn.archer.mapper.DesignbaseMapper;
import cn.archer.mapper.EmployeeMapper;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.FourTestMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.mapper.SwintypeMapper;
import cn.archer.mapper.plus.FourTestMapperPlus;
import cn.archer.model.FourTestPageModel;
import cn.archer.pojo.Designbase;
import cn.archer.pojo.Employee;
import cn.archer.pojo.Fence;
import cn.archer.pojo.FourTest;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.ShengZYF;
import cn.archer.pojo.Swintype;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import cn.archer.utils.DateChooserJButtonJDialog;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author Administrator
 */
public class FourTestApp extends javax.swing.JDialog {

    private VarietiesDataPlus varietiesDataPlus;
    private String flagua;
    private String formid0;
    private List<Piggery> piggery;

    /**
     * Creates new form FormApp
     */
    public FourTestApp(VarietiesDataPlus varietiesDataPlus, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        flagua = "add";
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("后备猪4月龄登记");
        jLabel00.setText("后备猪4月龄登记");//录入，登记，更改,详情
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        jTextField2.setText(dateFormater.format(date));
        jTextField12.setText("0");
        jTextField15.setText("0");
        jTextField23.setText("0");
        jTextField5.setText("0");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsShow));

        SwintypeMapper swintypeMapper = sqlSession.getMapper(SwintypeMapper.class);
        List<Swintype> swintype = swintypeMapper.selectAll();
        String typeName[] = new String[4];
        for (int i = 0; i < swintype.size(); i++) {
            if (swintype.get(i).getTypename().equals("后备猪")) {
                typeName[0] = swintype.get(i).getTypename();
            } else if (swintype.get(i).getTypename().equals("生长育肥猪")) {
                typeName[1] = swintype.get(i).getTypename();
            } else if (swintype.get(i).getTypename().equals("销售")) {
                typeName[2] = swintype.get(i).getTypename();
            } else if (swintype.get(i).getTypename().equals("死亡")) {
                typeName[3] = swintype.get(i).getTypename();
            }
        }

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(typeName));
        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel47.setText(designbase1.getTypename());
        jLabel48.setText(designbase2.getTypename());
        jLabel49.setText(designbase3.getTypename());
        sqlSession.close();
        jTextField30.setEnabled(false);
    }

    public FourTestApp(VarietiesDataPlus varietiesDataPlus, String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "upp";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("后备猪4月龄更改");
        jLabel00.setText("后备猪4月龄更改");//录入，登记，更改,详情
        jButton7.setEnabled(false);
        jButton6.setText("确认更改");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
        List<FourTest> fourTest = fourTestMapper.selectAll();
        FourTest tTest = null;
        for (int i = 0; i < fourTest.size(); i++) {
            if (fourTest.get(i).getR_animal().equals(farmid0)) {
                tTest = fourTest.get(i);
            }

        }

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsmap.get(tTest.getEmployeeid())));//负责人
        jTextField1.setEnabled(false);
        jTextField1.setText(tTest.getR_animal());//主键，个体编号
        jTextField2.setText(tTest.getCdrq());//测定日期
        jComboBox3.setEnabled(false);
        jComboBox3.addItem(tTest.getZsex().equals("1") ? "母" : "公");//性别

        jComboBox6.setEnabled(false);
        jComboBox6.addItem(fenceIdtoNameSmap.get(tTest.getFenceid()));//栏代码还可以关联到舍所在舍栏
        jTextField5.setText(String.valueOf(tTest.getWeight()));//体重

        jTextField10.setText(tTest.getFxrts());//腹线乳头数
        jTextField11.setText(tTest.getFxqxrt());//腹线有无缺陷乳头
        jTextField12.setText(String.valueOf(tTest.getFxzhpf()));//腹线综合评分
        jTextField13.setText(tTest.getYwss());//有无损伤
        jTextField14.setText(tTest.getSfgx());//是否过小
        jTextField15.setText(String.valueOf(tTest.getYgzhpf()));//有过综合评分
        jTextField16.setText(tTest.getZtzsfgx());//趾是否过小
        jTextField17.setText(tTest.getZtfgjsfhl());//跗关节是否合理
        jTextField18.setText(tTest.getZtszywssyz());//四肢有无损伤、肿胀
        jTextField19.setText(String.valueOf(tTest.getZtzhpf()));//肢体综合评分
        jTextField20.setText(tTest.getTxqhqgc());//前和后躯宽广
        jTextField21.setText(tTest.getTxhtcqs());//后臀长且深
        jTextField22.setText(tTest.getTxlgxz());//肋骨形状
        jTextField23.setText(String.valueOf(tTest.getTxzhpf()));//前后肋综合评分
        jTextField24.setText(tTest.getQjyl());//强健有力
        jTextField25.setText(tTest.getJpz());//寄生虫、皮肤和整体状态
        jTextField26.setText(tTest.getQtyd());//其它要点
        jTextField31.setText(tTest.getBz1());//其它要点
        jTextField32.setText(tTest.getBz2());//其它要点
        jTextField33.setText(tTest.getBz3());//其它要点

        String bL = tTest.getBltt();//保留 (K) 死亡 (C)
        if (bL.equals("K")) {
            jComboBox27.removeAllItems();
            jComboBox27.addItem("保留(K)");
            jComboBox27.addItem("死亡(C)");
        } else {
            jComboBox27.removeAllItems();
            jComboBox27.addItem("死亡(C)");
            jComboBox27.addItem("保留(K)");
        }
        jTextField28.setText(tTest.getBlbfb()); //保留百分比:
        PiggeryMapper piggeryMapper = sqlSession.getMapper(PiggeryMapper.class);
        jComboBox7.addItem(swintypeIdtoNameSmap.get(tTest.getCdzt()));//1后备 2死亡 3销售4生长育肥
        jComboBox7.setEnabled(false);
        jComboBox8.removeAllItems();
        jComboBox8.addItem(piggeryMapper.selectByFenceId(tTest.getOutfenceid()));
        jComboBox8.setEnabled(false);
        sqlSession.commit();
        jComboBox9.removeAllItems();
        jComboBox9.addItem(fenceIdtoNameSmap.get(tTest.getOutfenceid()));//不符合标注后备所去栏舍
        jComboBox9.setEnabled(false);

        jTextField29.setText(tTest.getBz());//备注
        jTextField30.setText(tTest.getJg());//价格
        sqlSession.commit();
        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel47.setText(designbase1.getTypename());
        jLabel48.setText(designbase2.getTypename());
        jLabel49.setText(designbase3.getTypename());

        sqlSession.close();

    }

    public FourTestApp(String farmid0, java.awt.Frame parent, boolean modal, int j) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("后备猪4月龄情详情");
        jLabel00.setText("后备猪4月龄详情");//录入，登记，更改,详情
        jButton6.setText("确认更改");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
        List<FourTest> fourTest = fourTestMapper.selectAll();
        FourTest tTest = null;
        for (int i = 0; i < fourTest.size(); i++) {
            if (fourTest.get(i).getR_animal().equals(farmid0)) {
                tTest = fourTest.get(i);
            }

        }

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsmap.get(tTest.getEmployeeid())));//负责人

        jTextField1.setText(tTest.getR_animal());//主键，个体编号
        jTextField2.setText(tTest.getCdrq());//测定日期
        jComboBox3.addItem(tTest.getZsex().equals("1") ? "母" : "公");//性别
        jComboBox6.addItem(fenceIdtoNameSmap.get(tTest.getFenceid()));//栏代码还可以关联到舍所在舍栏
        jTextField5.setText(String.valueOf(tTest.getWeight()));//体重

        jTextField10.setText(tTest.getFxrts());//腹线乳头数
        jTextField11.setText(tTest.getFxqxrt());//腹线有无缺陷乳头
        jTextField12.setText(String.valueOf(tTest.getFxzhpf()));//腹线综合评分
        jTextField13.setText(tTest.getYwss());//有无损伤
        jTextField14.setText(tTest.getSfgx());//是否过小
        jTextField15.setText(String.valueOf(tTest.getYgzhpf()));//有过综合评分
        jTextField16.setText(tTest.getZtzsfgx());//趾是否过小
        jTextField17.setText(tTest.getZtfgjsfhl());//跗关节是否合理
        jTextField18.setText(tTest.getZtszywssyz());//四肢有无损伤、肿胀
        jTextField19.setText(String.valueOf(tTest.getZtzhpf()));//肢体综合评分
        jTextField20.setText(tTest.getTxqhqgc());//前和后躯宽广
        jTextField21.setText(tTest.getTxhtcqs());//后臀长且深
        jTextField22.setText(tTest.getTxlgxz());//肋骨形状
        jTextField23.setText(String.valueOf(tTest.getTxzhpf()));//前后肋综合评分
        jTextField24.setText(tTest.getQjyl());//强健有力
        jTextField25.setText(tTest.getJpz());//寄生虫、皮肤和整体状态
        jTextField26.setText(tTest.getQtyd());//其它要点
        jTextField31.setText(tTest.getBz1());//其它要点
        jTextField32.setText(tTest.getBz2());//其它要点
        jTextField33.setText(tTest.getBz3());//其它要点

        String bL = tTest.getBltt();//保留 (K) 死亡 (C)
        if (bL.equals("K")) {
            jComboBox27.removeAllItems();
            jComboBox27.addItem("保留(K)");
            jComboBox27.addItem("死亡(C)");
        } else {
            jComboBox27.removeAllItems();
            jComboBox27.addItem("死亡(C)");
            jComboBox27.addItem("保留(K)");
        }
        jTextField28.setText(tTest.getBlbfb()); //保留百分比:
        PiggeryMapper piggeryMapper = sqlSession.getMapper(PiggeryMapper.class);
        jComboBox7.addItem(swintypeIdtoNameSmap.get(tTest.getCdzt()));//1后备 2死亡 3销售4生长育肥
        jComboBox8.removeAllItems();
        jComboBox8.addItem(piggeryMapper.selectByFenceId(tTest.getOutfenceid()));
        sqlSession.commit();
        jComboBox9.removeAllItems();
        jComboBox9.addItem(fenceIdtoNameSmap.get(tTest.getOutfenceid()));//不符合标注后备所去栏舍
        jTextField29.setText(tTest.getBz());//备注
        jTextField30.setText(tTest.getJg());//价格
        sqlSession.commit();
        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel47.setText(designbase1.getTypename());
        jLabel48.setText(designbase2.getTypename());
        jLabel49.setText(designbase3.getTypename());

        sqlSession.close();

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jComboBox3.setEnabled(false);
        jComboBox4.setEnabled(false);
        jTextField5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jTextField11.setEnabled(false);
        jTextField12.setEnabled(false);
        jTextField13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jTextField16.setEnabled(false);
        jTextField17.setEnabled(false);
        jTextField18.setEnabled(false);
        jTextField19.setEnabled(false);
        jTextField20.setEnabled(false);
        jTextField21.setEnabled(false);
        jTextField22.setEnabled(false);
        jTextField23.setEnabled(false);
        jTextField24.setEnabled(false);
        jTextField25.setEnabled(false);
        jTextField26.setEnabled(false);
        jComboBox27.setEnabled(false);
        jTextField28.setEnabled(false);
        jTextField29.setEnabled(false);
        jTextField30.setEnabled(false);
        jTextField31.setEnabled(false);
        jTextField32.setEnabled(false);
        jTextField33.setEnabled(false);
        jButton02.setEnabled(false);

    }

    public FourTestApp(String farmid0, javax.swing.JDialog parent, boolean modal, int j) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("后备猪4月龄情详情");
        jLabel00.setText("后备猪4月龄详情");//录入，登记，更改,详情
        jButton6.setText("确认更改");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
        List<FourTest> fourTest = fourTestMapper.selectAll();
        FourTest tTest = null;
        for (int i = 0; i < fourTest.size(); i++) {
            if (fourTest.get(i).getR_animal().equals(farmid0)) {
                tTest = fourTest.get(i);
            }

        }

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsmap.get(tTest.getEmployeeid())));//负责人

        jTextField1.setText(tTest.getR_animal());//主键，个体编号
        jTextField2.setText(tTest.getCdrq());//测定日期
        jComboBox3.addItem(tTest.getZsex().equals("1") ? "母" : "公");//性别
        jComboBox6.addItem(fenceIdtoNameSmap.get(tTest.getFenceid()));//栏代码还可以关联到舍所在舍栏
        jTextField5.setText(String.valueOf(tTest.getWeight()));//体重

        jTextField10.setText(tTest.getFxrts());//腹线乳头数
        jTextField11.setText(tTest.getFxqxrt());//腹线有无缺陷乳头
        jTextField12.setText(String.valueOf(tTest.getFxzhpf()));//腹线综合评分
        jTextField13.setText(tTest.getYwss());//有无损伤
        jTextField14.setText(tTest.getSfgx());//是否过小
        jTextField15.setText(String.valueOf(tTest.getYgzhpf()));//有过综合评分
        jTextField16.setText(tTest.getZtzsfgx());//趾是否过小
        jTextField17.setText(tTest.getZtfgjsfhl());//跗关节是否合理
        jTextField18.setText(tTest.getZtszywssyz());//四肢有无损伤、肿胀
        jTextField19.setText(String.valueOf(tTest.getZtzhpf()));//肢体综合评分
        jTextField20.setText(tTest.getTxqhqgc());//前和后躯宽广
        jTextField21.setText(tTest.getTxhtcqs());//后臀长且深
        jTextField22.setText(tTest.getTxlgxz());//肋骨形状
        jTextField23.setText(String.valueOf(tTest.getTxzhpf()));//前后肋综合评分
        jTextField24.setText(tTest.getQjyl());//强健有力
        jTextField25.setText(tTest.getJpz());//寄生虫、皮肤和整体状态
        jTextField26.setText(tTest.getQtyd());//其它要点
        jTextField31.setText(tTest.getBz1());//其它要点
        jTextField32.setText(tTest.getBz2());//其它要点
        jTextField33.setText(tTest.getBz3());//其它要点

        String bL = tTest.getBltt();//保留 (K) 死亡 (C)
        if (bL.equals("K")) {
            jComboBox27.removeAllItems();
            jComboBox27.addItem("保留(K)");
            jComboBox27.addItem("死亡(C)");
        } else {
            jComboBox27.removeAllItems();
            jComboBox27.addItem("死亡(C)");
            jComboBox27.addItem("保留(K)");
        }
        jTextField28.setText(tTest.getBlbfb()); //保留百分比:
        PiggeryMapper piggeryMapper = sqlSession.getMapper(PiggeryMapper.class);
        jComboBox7.addItem(swintypeIdtoNameSmap.get(tTest.getCdzt()));//1后备 2死亡 3销售4生长育肥
        jComboBox8.removeAllItems();
        jComboBox8.addItem(piggeryMapper.selectByFenceId(tTest.getOutfenceid()));
        sqlSession.commit();
        jComboBox9.removeAllItems();
        jComboBox9.addItem(fenceIdtoNameSmap.get(tTest.getOutfenceid()));//不符合标注后备所去栏舍
        jTextField29.setText(tTest.getBz());//备注
        jTextField30.setText(tTest.getJg());//价格
        sqlSession.commit();
        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel47.setText(designbase1.getTypename());
        jLabel48.setText(designbase2.getTypename());
        jLabel49.setText(designbase3.getTypename());

        sqlSession.close();

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jComboBox3.setEnabled(false);
        jComboBox4.setEnabled(false);
        jTextField5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jTextField11.setEnabled(false);
        jTextField12.setEnabled(false);
        jTextField13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jTextField16.setEnabled(false);
        jTextField17.setEnabled(false);
        jTextField18.setEnabled(false);
        jTextField19.setEnabled(false);
        jTextField20.setEnabled(false);
        jTextField21.setEnabled(false);
        jTextField22.setEnabled(false);
        jTextField23.setEnabled(false);
        jTextField24.setEnabled(false);
        jTextField25.setEnabled(false);
        jTextField26.setEnabled(false);
        jComboBox27.setEnabled(false);
        jTextField28.setEnabled(false);
        jTextField29.setEnabled(false);
        jTextField30.setEnabled(false);
        jTextField31.setEnabled(false);
        jTextField32.setEnabled(false);
        jTextField33.setEnabled(false);
        jButton02.setEnabled(false);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jLabel05 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jTextField20 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jTextField21 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField22 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jTextField23 = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jTextField24 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTextField25 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jTextField26 = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jTextField28 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jTextField29 = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton02 =  new DateChooserJButtonJDialog (jTextField2);
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        jComboBox8 = new javax.swing.JComboBox<>();
        jComboBox9 = new javax.swing.JComboBox<>();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox27 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel00 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jTextField30 = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jTextField31 = new javax.swing.JTextField();
        jTextField32 = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        jTextField33 = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel05.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel05.setText("个体编号：");
        jLabel05.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel05MouseEntered(evt);
            }
        });

        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel12.setText("负 责 人：");

        jTextField5.setText("0");
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel25.setText("体    重：");

        jLabel26.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel26.setText("测定日期：");

        jLabel33.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel33.setText("所在舍栏：");

        jLabel34.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel34.setText("性    别：");

        jTextField10.setText("0");

        jLabel28.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel28.setText("腹线乳头数 ：");

        jTextField11.setText("无");
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel36.setText("腹线有无缺陷乳头：");

        jLabel7.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel7.setText("综合评分：");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel7MouseEntered(evt);
            }
        });

        jTextField12.setText("0");
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel8.setText("有无损伤：");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel8MouseEntered(evt);
            }
        });

        jTextField13.setText("无");
        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel37.setText("是否过小：");

        jTextField14.setText("否");

        jLabel38.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel38.setText("综合评分：");

        jTextField15.setText("0");

        jLabel9.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel9.setText("趾是否过小：");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel9MouseEntered(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel27.setText("跗关节是否合理：");

        jLabel35.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel35.setText("四肢有无损伤：");

        jTextField18.setText("无");

        jTextField17.setText("是");

        jTextField16.setText("否");
        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel10.setText("综合评分：");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel10MouseEntered(evt);
            }
        });

        jTextField19.setText("0");
        jTextField19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField19ActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel29.setText("前和后躯宽广：");

        jTextField20.setText("0");

        jLabel39.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel39.setText("后臀长且深：");

        jTextField21.setText("0");

        jLabel11.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel11.setText("肋骨形状：");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel11MouseEntered(evt);
            }
        });

        jTextField22.setText("0");
        jTextField22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField22ActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel30.setText("综合评分：");

        jTextField23.setText("0");

        jLabel40.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel40.setText("强健有力：");

        jTextField24.setText("0");

        jLabel13.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel13.setText("寄生虫皮肤和整体状态：");
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel13MouseEntered(evt);
            }
        });

        jTextField25.setText("0");
        jTextField25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField25ActionPerformed(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel31.setText("其它要点：");

        jTextField26.setText("0");

        jLabel41.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel41.setText("保留或死亡：");

        jLabel14.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel14.setText("登记状态：");
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel14MouseEntered(evt);
            }
        });

        jLabel32.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel32.setText("所去猪舍：");

        jLabel42.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel42.setText("保留百分比：");

        jTextField28.setText("0");

        jLabel43.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel43.setText("所去栏位：");

        jTextField29.setText("0");
        jTextField29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField29ActionPerformed(evt);
            }
        });

        jLabel44.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel44.setText("备    注：");

        jButton6.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton6.setText("连续提交");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/refues.png"))); // NOI18N
        jButton7.setText("重新输入");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton8.setText("退出输入");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("*");

        jTextField2.setEditable(false);
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jButton02.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton02.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton02ActionPerformed(evt);
            }
        });

        jComboBox3.setEnabled(false);
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jComboBox6.setEnabled(false);

        jComboBox8.setEnabled(false);
        jComboBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox8ActionPerformed(evt);
            }
        });

        jComboBox9.setEnabled(false);

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "后备猪", "生长育肥猪", "销售", "淘汰" }));
        jComboBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox7ActionPerformed(evt);
            }
        });

        jComboBox27.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "保留(K)", "死亡(C)" }));
        jComboBox27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox27ActionPerformed(evt);
            }
        });

        jLabel00.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel00.setText("后备猪4月龄登记");

        jLabel45.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel45.setText("销售价格：");

        jTextField30.setEnabled(false);
        jTextField30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField30ActionPerformed(evt);
            }
        });

        jLabel64.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(204, 0, 0));
        jLabel64.setText("KG");

        jLabel46.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 0, 0));
        jLabel46.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息处理");

        jLabel47.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel47.setText("备   注1：");

        jTextField31.setText("0");
        jTextField31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField31ActionPerformed(evt);
            }
        });

        jTextField32.setText("0");
        jTextField32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField32ActionPerformed(evt);
            }
        });

        jLabel48.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel48.setText("备   注2：");

        jTextField33.setText("0");
        jTextField33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField33ActionPerformed(evt);
            }
        });

        jLabel49.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel49.setText("备   注3：");

        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 0));
        jLabel3.setText("*");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(357, 357, 357)
                .addComponent(jLabel00)
                .addGap(358, 358, 358))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel05)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField1))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBox7, 0, 141, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel28)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField10)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel46, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jTextField28))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel9)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jTextField25))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel10)
                                        .addComponent(jLabel11))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTextField19)
                                        .addComponent(jTextField22)))))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField32, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField29)))
                                .addGap(64, 64, 64)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField33))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel29)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField20))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel31)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField26))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel30)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField23))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel36)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField11, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel25)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel64))
                                            .addComponent(jTextField14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel27)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel32)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(64, 64, 64))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel26)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton02, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel3)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel40)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField24))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel35)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField18))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel39)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel41)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBox27, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel33, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTextField12, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                                            .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jComboBox6, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jComboBox9, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(220, 220, 220)
                        .addComponent(jButton6)
                        .addGap(31, 31, 31)
                        .addComponent(jButton7)
                        .addGap(31, 31, 31)
                        .addComponent(jButton8)))
                .addGap(25, 25, 25))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel00)
                .addGap(30, 30, 30)
                .addComponent(jLabel46)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel05, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField1)
                                .addComponent(jLabel2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jButton02, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addGap(2, 2, 2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField15)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel64)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField14)
                                    .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField16)
                        .addComponent(jTextField17)
                        .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField22)
                        .addComponent(jTextField23)
                        .addComponent(jTextField24)
                        .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField25)
                        .addComponent(jTextField26)
                        .addComponent(jComboBox27))
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField30)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField28)
                        .addComponent(jTextField29))
                    .addComponent(jLabel45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel42, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField31)
                    .addComponent(jTextField32)
                    .addComponent(jTextField33)
                    .addComponent(jLabel47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel48, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel49, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton8)
                        .addComponent(jButton7))
                    .addComponent(jButton6))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jLabel05MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel05MouseEntered
        // TODO add your handling code here:

    }//GEN-LAST:event_jLabel05MouseEntered

    private void jLabel7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseEntered

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jLabel8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseEntered

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jLabel9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseEntered

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jLabel10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel10MouseEntered

    private void jTextField19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField19ActionPerformed

    private void jLabel11MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseEntered

    private void jTextField22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField22ActionPerformed

    private void jLabel13MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel13MouseEntered

    private void jTextField25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField25ActionPerformed

    private void jLabel14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel14MouseEntered

    private void jTextField29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField29ActionPerformed

    private void jButton02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton02ActionPerformed

    }//GEN-LAST:event_jButton02ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        jTextField2.setText(dateFormater.format(date));
        jTextField12.setText("0");
        jTextField15.setText("0");
        jTextField23.setText("0");
        jTextField5.setText("0");
        SqlSession sqlSession = MybatisUtil.getSqlSession();

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsShow));

        SwintypeMapper swintypeMapper = sqlSession.getMapper(SwintypeMapper.class);
        List<Swintype> swintype = swintypeMapper.selectAll();
        String typeName[] = new String[4];
        for (int i = 0; i < swintype.size(); i++) {
            if (swintype.get(i).getTypename().equals("后备猪")) {
                typeName[0] = swintype.get(i).getTypename();
            } else if (swintype.get(i).getTypename().equals("生长育肥猪")) {
                typeName[1] = swintype.get(i).getTypename();
            } else if (swintype.get(i).getTypename().equals("销售")) {
                typeName[2] = swintype.get(i).getTypename();
            } else if (swintype.get(i).getTypename().equals("死亡")) {
                typeName[3] = swintype.get(i).getTypename();
            }
        }

        jComboBox7.removeAllItems();
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(typeName));

        sqlSession.close();

        jTextField1.setText("");
        jComboBox3.removeAllItems();
        jComboBox6.removeAllItems();
        jComboBox8.removeAllItems();
        jComboBox9.removeAllItems();
        jTextField10.setText("0");
        jTextField11.setText("无");
        jTextField13.setText("无");
        jTextField14.setText("无");
        jTextField16.setText("否");
        jTextField17.setText("是");
        jTextField18.setText("无");
        jTextField19.setText("0");
        jTextField20.setText("0");
        jTextField21.setText("0");
        jTextField22.setText("0");
        jTextField24.setText("0");
        jTextField25.setText("0");
        jTextField26.setText("0");
        jTextField28.setText("");
        jTextField29.setText("");
        jComboBox27.removeAllItems();
        jComboBox27.addItem("保留(K)");
        jComboBox27.addItem("死亡(C)");

    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        JTable jTable1 = varietiesDataPlus.getjTable1();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        String number = jTextField1.getText();
        if (number.length() != 15 && number.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加母猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Selebith selebith = mapper0.selectById("%" + number);
        if (selebith == null) {
            JOptionPane.showMessageDialog(null, "您添加个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getR_curmark().equals("4") != true) {
            JOptionPane.showMessageDialog(null, "当前不是后备猪", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在
        if (flagua.equals("add")) {
            String type = JComboBoxString(jComboBox7);
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            List<FourTest> tw = fourTestMapper.selectAll();
            for (int i = 0; i < tw.size(); i++) {
                if (tw.get(i).getR_animal().equals(selebith.getR_animal())) {
                    JOptionPane.showMessageDialog(null, "添加失败！已存在相同主键", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    sqlSession.close();
                    return;
                }
            }

            sqlSession.commit();
            if (selebith != null) {
                String two = selebith.getIftwo();
                if (two != null) {
                    if (type.equals("后备猪") && two.equals("1") && selebith.getIffour().equals("0")) {
                        FourTestMapper fourTest = sqlSession.getMapper(FourTestMapper.class);
                        FourTest tTest = new FourTest();
                        tTest.setR_animal(selebith.getR_animal());//主键，个体编号
                        tTest.setCdrq(jTextField2.getText());//测定日期
                        tTest.setZsex(JComboBoxString(jComboBox3).equals("母") ? "1" : "0");//性别
                        tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
                        tTest.setWeight(Double.parseDouble(jTextField5.getText()));//体重
                        tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                        tTest.setFxrts(jTextField10.getText());//腹线乳头数
                        tTest.setFxqxrt(jTextField11.getText());//腹线有无缺陷乳头
                        tTest.setFxzhpf(Integer.parseInt(jTextField12.getText()));//腹线综合评分
                        tTest.setYwss(jTextField13.getText());//有无损伤
                        tTest.setSfgx(jTextField14.getText());//是否过小
                        tTest.setYgzhpf(Integer.parseInt(jTextField15.getText()));//有过综合评分
                        tTest.setZtzsfgx(jTextField16.getText());//趾是否过小
                        tTest.setZtfgjsfhl(jTextField17.getText());//跗关节是否合理
                        tTest.setZtszywssyz(jTextField18.getText());//四肢有无损伤、肿胀
                        tTest.setZtzhpf(Integer.parseInt(jTextField19.getText()));//肢体综合评分
                        tTest.setTxqhqgc(jTextField20.getText());//前和后躯宽广
                        tTest.setTxhtcqs(jTextField21.getText());//后臀长且深
                        tTest.setTxlgxz(jTextField22.getText());//肋骨形状
                        tTest.setTxzhpf(Integer.parseInt(jTextField23.getText()));//前后肋综合评分
                        tTest.setQjyl(jTextField24.getText());//强健有力
                        tTest.setJpz(jTextField25.getText());//寄生虫、皮肤和整体状态
                        tTest.setQtyd(jTextField26.getText());//其它要点
                        String bL = JComboBoxString(jComboBox27);
                        String bLiu = null;
                        if (bL.equals("保留(K)")) {
                            bLiu = "K";
                        }
                        if (bL.equals("死亡(C)")) {
                            bLiu = "C";
                        }
                        tTest.setBltt(bLiu);//保留 (K) 死亡 (C)
                        tTest.setBlbfb(jTextField28.getText()); //保留百分比:
                        tTest.setOutfenceid(null);//不符合标注后备所去栏舍
                        tTest.setCdzt(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备 2死亡 3销售4生长育肥
                        tTest.setBz(jTextField29.getText());//备注
                        tTest.setBz1(jTextField31.getText());//备注
                        tTest.setBz2(jTextField32.getText());//备注
                        tTest.setBz3(jTextField33.getText());//备注
                        int i = fourTest.insert(tTest);//
                        sqlSession.commit();
                        SelebithMapper twoU = sqlSession.getMapper(SelebithMapper.class);
                        twoU.updateFour(selebith.getR_animal());
                        sqlSession.commit();
                        sqlSession.close();
                        JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                        Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
                        model.addRow(rowInsert);
                        jTable1.setModel(model);
                        varietiesDataPlus.validate();
                        FourTestMapperPlus fourTestMapperPlus = new FourTestMapperPlus();
                        MainApp.fourTestPageModel = new FourTestPageModel(14, fourTestMapperPlus.SelectCount(), fourTestMapperPlus, false);
                        MainApp.FourTestpage(MainApp.fourTestPageModel.getBottomPageNo());
                    }
                }
                if (type.equals("死亡") || type.equals("销售")) {
                    FourTestMapper fourTest = sqlSession.getMapper(FourTestMapper.class);
                    FourTest tTest = new FourTest();
                    tTest.setR_animal(selebith.getR_animal());//主键，个体编号
                    tTest.setCdrq(jTextField2.getText());//测定日期
                    tTest.setZsex("母".equals(JComboBoxString(jComboBox3)) ? "1" : "0");//性别
                    tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
                    tTest.setWeight(Double.parseDouble(jTextField5.getText()));//体重
                    tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                    tTest.setFxrts(jTextField10.getText());//腹线乳头数
                    tTest.setFxqxrt(jTextField11.getText());//腹线有无缺陷乳头
                    tTest.setFxzhpf(Integer.parseInt(jTextField12.getText()));//腹线综合评分
                    tTest.setYwss(jTextField13.getText());//有无损伤
                    tTest.setSfgx(jTextField14.getText());//是否过小
                    tTest.setYgzhpf(Integer.parseInt(jTextField15.getText()));//有过综合评分
                    tTest.setZtzsfgx(jTextField16.getText());//趾是否过小
                    tTest.setZtfgjsfhl(jTextField17.getText());//跗关节是否合理
                    tTest.setZtszywssyz(jTextField18.getText());//四肢有无损伤、肿胀
                    tTest.setZtzhpf(Integer.parseInt(jTextField19.getText()));//肢体综合评分
                    tTest.setTxqhqgc(jTextField20.getText());//前和后躯宽广
                    tTest.setTxhtcqs(jTextField21.getText());//后臀长且深
                    tTest.setTxlgxz(jTextField22.getText());//肋骨形状
                    tTest.setTxzhpf(Integer.parseInt(jTextField23.getText()));//前后肋综合评分
                    tTest.setQjyl(jTextField24.getText());//强健有力
                    tTest.setJpz(jTextField25.getText());//寄生虫、皮肤和整体状态
                    tTest.setQtyd(jTextField26.getText());//其它要点
                    String bL = JComboBoxString(jComboBox27);
                    String bLiu = null;
                    if (bL.equals("保留(K)")) {
                        bLiu = "K";
                    }
                    if (bL.equals("死亡(C)")) {
                        bLiu = "C";
                    }
                    tTest.setBltt(bLiu);//保留 (K) 死亡 (C)
                    tTest.setBlbfb(jTextField28.getText()); //保留百分比:
                    tTest.setOutfenceid(null);//不符合标注后备所去栏舍
                    tTest.setCdzt(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备 2死亡 3销售4生长育肥
                    tTest.setBz(jTextField29.getText());//备注
                    tTest.setBz1(jTextField31.getText());//备注
                    tTest.setBz2(jTextField32.getText());//备注
                    tTest.setBz3(jTextField33.getText());//备注
                    if (type.equals("销售")) {
                        tTest.setJg(jTextField30.getText());//价格
                    }
                    int i = fourTest.insert(tTest);//
                    //sqlSession.commit();
                    SelebithMapper twoU = sqlSession.getMapper(SelebithMapper.class);
                    if (type.equals("死亡")) {
                        twoU.updateZTT(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)), jTextField1.getText(), jTextField2.getText());
                    } else {

                        twoU.updateZT(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)), jTextField1.getText(), jTextField2.getText());
                    }

                    sqlSession.commit();
                    sqlSession.close();
                    JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
                    model.addRow(rowInsert);
                    jTable1.setModel(model);
                    varietiesDataPlus.validate();
                    MainApp.fourTestPageModel = new FourTestPageModel(14, fourTestMapperPlus.SelectCount(), fourTestMapperPlus, false);
                    FourTestpage(MainApp.fourTestPageModel.getBottomPageNo());
                }
                if (type.equals("生长育肥猪")) {
                    FourTestMapper fourTest = sqlSession.getMapper(FourTestMapper.class);
                    FourTest tTest = new FourTest();
                    tTest.setR_animal(selebith.getR_animal());//主键，个体编号
                    tTest.setCdrq(jTextField2.getText());//测定日期
                    tTest.setZsex(JComboBoxString(jComboBox3).equals("母") ? "1" : "0");//性别
                    tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
                    tTest.setWeight(Double.parseDouble(jTextField5.getText()));//体重
                    tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                    tTest.setFxrts(jTextField10.getText());//腹线乳头数
                    tTest.setFxqxrt(jTextField11.getText());//腹线有无缺陷乳头
                    tTest.setFxzhpf(Integer.parseInt(jTextField12.getText()));//腹线综合评分
                    tTest.setYwss(jTextField13.getText());//有无损伤
                    tTest.setSfgx(jTextField14.getText());//是否过小
                    tTest.setYgzhpf(Integer.parseInt(jTextField15.getText()));//有过综合评分
                    tTest.setZtzsfgx(jTextField16.getText());//趾是否过小
                    tTest.setZtfgjsfhl(jTextField17.getText());//跗关节是否合理
                    tTest.setZtszywssyz(jTextField18.getText());//四肢有无损伤、肿胀
                    tTest.setZtzhpf(Integer.parseInt(jTextField19.getText()));//肢体综合评分
                    tTest.setTxqhqgc(jTextField20.getText());//前和后躯宽广
                    tTest.setTxhtcqs(jTextField21.getText());//后臀长且深
                    tTest.setTxlgxz(jTextField22.getText());//肋骨形状
                    tTest.setTxzhpf(Integer.parseInt(jTextField23.getText()));//前后肋综合评分
                    tTest.setQjyl(jTextField24.getText());//强健有力
                    tTest.setJpz(jTextField25.getText());//寄生虫、皮肤和整体状态
                    tTest.setQtyd(jTextField26.getText());//其它要点
                    String bL = JComboBoxString(jComboBox27);
                    String bLiu = null;
                    if (bL.equals("保留(K)")) {
                        bLiu = "K";
                    }
                    if (bL.equals("死亡(C)")) {
                        bLiu = "C";
                    }
                    tTest.setBltt(bLiu);//保留 (K) 死亡 (C)
                    tTest.setBlbfb(jTextField28.getText()); //保留百分比:
                    tTest.setOutfenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox9)));//不符合标注后备所去栏舍
                    tTest.setCdzt(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备 2死亡 3销售4生长育肥
                    tTest.setBz(jTextField29.getText());//备注
                    tTest.setBz1(jTextField31.getText());//备注
                    tTest.setBz2(jTextField32.getText());//备注
                    tTest.setBz3(jTextField33.getText());//备注
                    int i = fourTest.insert(tTest);//
                    sqlSession.commit();
                    SelebithMapper twoU = sqlSession.getMapper(SelebithMapper.class);
                    ShengZYF sz = new ShengZYF();
                    sz.setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备 2死亡 3销售4生长育肥
                    sz.setR_animal(number);//个体号
                    sz.setHyafenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox9)));//转后
                    sz.setHyffenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//转前
                    sz.setHyfzr(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                    sz.setHysj(jTextField2.getText());//日期
                    sz.setIftwo("1");//二月
                    sz.setNifhb("1");//是否转 1
                    sz.setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox9)));//后背索取栏
                    twoU.updateF(sz);

                    sqlSession.commit();
                    sqlSession.close();
                    JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
                    model.addRow(rowInsert);
                    jTable1.setModel(model);
                    varietiesDataPlus.validate();
                    MainApp.fourTestPageModel = new FourTestPageModel(14, fourTestMapperPlus.SelectCount(), fourTestMapperPlus, false);
                    MainApp.FourTestpage(MainApp.fourTestPageModel.getBottomPageNo());
                }

            } else {
                JOptionPane.showMessageDialog(null, "请输入正确的个体编号", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                sqlSession.close();
                return;
            }
        }
        if (flagua.equals("upp")) {
            FourTestMapper fourTest = sqlSession.getMapper(FourTestMapper.class);
            FourTest tTest = new FourTest();
            tTest.setR_animal(jTextField1.getText());//主键，个体编号
            tTest.setCdrq(jTextField2.getText());//测定日期
            tTest.setZsex("母".equals(JComboBoxString(jComboBox3)) ? "1" : "0");//性别
            tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
            tTest.setWeight(Double.parseDouble(jTextField5.getText()));//体重
            tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
            tTest.setFxrts(jTextField10.getText());//腹线乳头数
            tTest.setFxqxrt(jTextField11.getText());//腹线有无缺陷乳头
            tTest.setFxzhpf(Integer.parseInt(jTextField12.getText()));//腹线综合评分
            tTest.setYwss(jTextField13.getText());//有无损伤
            tTest.setSfgx(jTextField14.getText());//是否过小
            tTest.setYgzhpf(Integer.parseInt(jTextField15.getText()));//有过综合评分
            tTest.setZtzsfgx(jTextField16.getText());//趾是否过小
            tTest.setZtfgjsfhl(jTextField17.getText());//跗关节是否合理
            tTest.setZtszywssyz(jTextField18.getText());//四肢有无损伤、肿胀
            tTest.setZtzhpf(Integer.parseInt(jTextField19.getText()));//肢体综合评分
            tTest.setTxqhqgc(jTextField20.getText());//前和后躯宽广
            tTest.setTxhtcqs(jTextField21.getText());//后臀长且深
            tTest.setTxlgxz(jTextField22.getText());//肋骨形状
            tTest.setTxzhpf(Integer.parseInt(jTextField23.getText()));//前后肋综合评分
            tTest.setQjyl(jTextField24.getText());//强健有力
            tTest.setJpz(jTextField25.getText());//寄生虫、皮肤和整体状态
            tTest.setQtyd(jTextField26.getText());//其它要点
            String bL = JComboBoxString(jComboBox27);
            String bLiu = null;
            if (bL.equals("保留(K)")) {
                bLiu = "K";
            }
            if (bL.equals("死亡(C)")) {
                bLiu = "C";
            }
            tTest.setBltt(bLiu);//保留 (K) 死亡 (C)
            tTest.setBlbfb(jTextField28.getText()); //保留百分比:
            tTest.setBz(jTextField29.getText());//备注
            tTest.setJg(jTextField30.getText());//价格
            tTest.setBz1(jTextField31.getText());//备注
            tTest.setBz2(jTextField32.getText());//备注
            tTest.setBz3(jTextField33.getText());//备注
            fourTest.updateByid(tTest);//
            sqlSession.commit();
            sqlSession.close();
            JOptionPane.showMessageDialog(null, "修改成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            model.removeRow(jTable1.getSelectedRow());
            Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
            model.addRow(rowInsert);
            jTable1.setModel(model);
            varietiesDataPlus.validate();

            System.gc();
            dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));

        }

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        // TODO add your handling code here:

        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        String number = jTextField1.getText();
        if (number.length() != 15 && number.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加个体编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Selebith selebith = mapper0.selectById("%" + number);

        if (selebith == null) {
            JOptionPane.showMessageDialog(null, "您添加个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在

        if (selebith.getR_curmark().equals("4") != true) {
            JOptionPane.showMessageDialog(null, "当前不是后备猪", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getIftwo().equals("0") == true) {
            JOptionPane.showMessageDialog(null, "此猪二月没测", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getIffour().equals("0") != true) {
            JOptionPane.showMessageDialog(null, "此猪四月已测", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }

        String lanHao = selebith.getR_pcage();

        FenceMapper fenceMapper = sqlSession.getMapper(FenceMapper.class);
        Fence fence = fenceMapper.selectByFenceid(lanHao);
        String fenceName[] = {fence.getFencename()};
        String[] selebithSex = {selebith.getR_sex().equals("1") ? "母" : "公"};
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(fenceName));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(selebithSex));
        sqlSession.close();
    }//GEN-LAST:event_jTextField1FocusLost

    private void jComboBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox7ActionPerformed
        // TODO add your handling code here:
        String type = JComboBoxString(jComboBox7);
        switch (type) {
            case "生长育肥猪":
                jComboBox8.setEnabled(true);
                jComboBox9.setEnabled(true);
                //｛所在猪舍复选框
                SqlSession sqlSession = MybatisUtil.getSqlSession();
                PiggeryMapper mapper5 = sqlSession.getMapper(PiggeryMapper.class);
                piggery = mapper5.selectAll();
                String[] things5 = new String[piggery.size()];
                for (int i = 0; i < piggery.size(); i++) {
                    things5[i] = piggery.get(i).getCategory();

                }
                jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(things5));
                //｝所在猪舍复选框
                //｛所在栏位复选框
                FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
                List<Fence> fence = mapper6.selectAllById(piggery.get(0).getNumber());
                String[] things6 = new String[fence.size()];
                for (int i = 0; i < fence.size(); i++) {
                    things6[i] = fence.get(i).getFencename();

                }
                jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things6));
                //｝所在栏位复选框
                sqlSession.close();
                jTextField30.setText("");
                jTextField30.setEnabled(false);
                break;
            case "销售":
                jTextField30.setEnabled(true);
                jComboBox8.removeAllItems();
                jComboBox9.removeAllItems();
                jComboBox8.setEnabled(false);
                jComboBox9.setEnabled(false);
                break;
            default:
                jComboBox8.removeAllItems();
                jComboBox9.removeAllItems();
                jTextField30.setText("");
                jTextField30.setEnabled(false);
                jComboBox8.setEnabled(false);
                jComboBox9.setEnabled(false);
                break;
        }
    }//GEN-LAST:event_jComboBox7ActionPerformed

    private void jComboBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox8ActionPerformed
        String id = piggeryNametoIdSmap.get(JComboBoxString(jComboBox8));
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);

        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();
    }//GEN-LAST:event_jComboBox8ActionPerformed

    private void jComboBox27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox27ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField30ActionPerformed

    private void jTextField31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField31ActionPerformed

    private void jTextField32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField32ActionPerformed

    private void jTextField33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField33ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton02;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox27;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JLabel jLabel05;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
