package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.swintypeIdtoNameSmap;
import cn.archer.mapper.RemindMapper;
import cn.archer.pojo.Selebith;
import static cn.archer.utils.MyStaticMethod.NowTime;
import static cn.archer.utils.MyStaticMethod.minusDate;
import static cn.archer.utils.MyStaticMethod.setJTableRow;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author Administrator
 */
public class ZzmytxApp extends javax.swing.JDialog {

    private String zzzt;
    private String szrq;
    private String rqdw;

    /**
     * Creates new form FormApp
     */
    public ZzmytxApp(String zzzt, String szrq, String rqdw, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.zzzt = zzzt;
        this.szrq = szrq;
        this.rqdw = rqdw;
        this.setTitle("种猪疫苗提醒");
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        RemindMapper mapper = sqlSession.getMapper(RemindMapper.class);

        if (zzzt.equals("妊娠母猪")) {
            jTabbedPane1.setTitleAt(0, "妊娠后疫苗");
            //获取出生日期
            szrq = minusDate(NowTime(), Integer.parseInt(szrq));
            List<String> Stringtemp;
            List<Selebith> selebithtemp = new ArrayList();
            Stringtemp = mapper.breedingRshtx(szrq);
            for (int i = 0; i < Stringtemp.size(); i++) {
                selebithtemp.add(mapper.zzxx(Stringtemp.get(i)));
            }

            Object[][] tableModel002 = new Object[selebithtemp.size()][4];
            for (int j = 0; j < selebithtemp.size(); j++) {
                tableModel002[j][0] = selebithtemp.get(j).getR_animal();
                tableModel002[j][1] = selebithtemp.get(j).getR_fdate();
                tableModel002[j][2] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());
                tableModel002[j][3] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());
            }

            String[] tableHead002 = new String[]{"个体编号", "出生日期", "猪只状态", "所在栏舍"};
            jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel002, tableHead002));
            setJTableRow(jTable2);
        } else if (zzzt.equals("哺乳母猪")) {
            jTabbedPane1.setTitleAt(0, "分娩后疫苗");
            //获取出生日期
            szrq = minusDate(NowTime(), Integer.parseInt(szrq));
            List<String> Stringtemp;
            List<Selebith> selebithtemp = new ArrayList();
            Stringtemp = mapper.childbirthFmhtx(szrq);
            for (int i = 0; i < Stringtemp.size(); i++) {
                selebithtemp.add(mapper.zzxx(Stringtemp.get(i)));
            }

            Object[][] tableModel002 = new Object[selebithtemp.size()][4];
            for (int j = 0; j < selebithtemp.size(); j++) {
                tableModel002[j][0] = selebithtemp.get(j).getR_animal();
                tableModel002[j][1] = selebithtemp.get(j).getR_fdate();
                tableModel002[j][2] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());
                tableModel002[j][3] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());
            }

            String[] tableHead002 = new String[]{"个体编号", "出生日期", "猪只状态", "所在栏舍"};
            jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel002, tableHead002));
            setJTableRow(jTable2);
        } else if (zzzt.equals("空怀母猪")) {
            jTabbedPane1.setTitleAt(0, "断奶后疫苗");
            szrq = minusDate(NowTime(), Integer.parseInt(szrq));
            List<String> Stringtemp;
            List<Selebith> selebithtemp = new ArrayList();
            Stringtemp = mapper.childbirthDnhtx(szrq);
            for (int i = 0; i < Stringtemp.size(); i++) {
                selebithtemp.add(mapper.zzxx(Stringtemp.get(i)));
            }

            Object[][] tableModel002 = new Object[selebithtemp.size()][4];
            for (int j = 0; j < selebithtemp.size(); j++) {
                tableModel002[j][0] = selebithtemp.get(j).getR_animal();
                tableModel002[j][1] = selebithtemp.get(j).getR_fdate();
                tableModel002[j][2] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());
                tableModel002[j][3] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());
            }

            String[] tableHead002 = new String[]{"个体编号", "出生日期", "猪只状态", "所在栏舍"};
            jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel002, tableHead002));
            setJTableRow(jTable2);
        } else if (zzzt.equals("后备母猪")) {
            jTabbedPane1.setTitleAt(0, "后备母猪一百公斤疫苗");
            szrq = minusDate(NowTime(), Integer.parseInt(szrq));
            List<String> Stringtemp;
            List<Selebith> selebithtemp = new ArrayList();
            Stringtemp = mapper.hbmzhundredtesthtx(szrq);
            for (int i = 0; i < Stringtemp.size(); i++) {
                selebithtemp.add(mapper.zzxx(Stringtemp.get(i)));
            }

            Object[][] tableModel002 = new Object[selebithtemp.size()][4];
            for (int j = 0; j < selebithtemp.size(); j++) {
                tableModel002[j][0] = selebithtemp.get(j).getR_animal();
                tableModel002[j][1] = selebithtemp.get(j).getR_fdate();
                tableModel002[j][2] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());
                tableModel002[j][3] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());
            }

            String[] tableHead002 = new String[]{"个体编号", "出生日期", "猪只状态", "所在栏舍"};
            jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel002, tableHead002));
            setJTableRow(jTable2);
        } else if (zzzt.equals("种公猪") && this.rqdw.equals("月")) {
            jTabbedPane1.setTitleAt(0, "种公猪疫苗");
            List<Selebith> selebithtemp;
            selebithtemp = mapper.zgztx();

            Object[][] tableModel002 = new Object[selebithtemp.size()][4];
            for (int j = 0; j < selebithtemp.size(); j++) {
                tableModel002[j][0] = selebithtemp.get(j).getR_animal();
                tableModel002[j][1] = selebithtemp.get(j).getR_fdate();
                tableModel002[j][2] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());
                tableModel002[j][3] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());
            }

            String[] tableHead002 = new String[]{"个体编号", "出生日期", "猪只状态", "所在栏舍"};
            jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel002, tableHead002));
            setJTableRow(jTable2);

        } else if (zzzt.equals("种公猪") && this.rqdw.equals("天")) {
            jTabbedPane1.setTitleAt(0, "种公猪一百公斤疫苗");
            szrq = minusDate(NowTime(), Integer.parseInt(szrq));
            List<String> Stringtemp;
            List<Selebith> selebithtemp = new ArrayList();
            Stringtemp = mapper.zgzhundredtesthtx(szrq);
            for (int i = 0; i < Stringtemp.size(); i++) {
                selebithtemp.add(mapper.zzxx(Stringtemp.get(i)));
            }

            Object[][] tableModel002 = new Object[selebithtemp.size()][4];
            for (int j = 0; j < selebithtemp.size(); j++) {
                tableModel002[j][0] = selebithtemp.get(j).getR_animal();
                tableModel002[j][1] = selebithtemp.get(j).getR_fdate();
                tableModel002[j][2] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());
                tableModel002[j][3] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());
            }

            String[] tableHead002 = new String[]{"个体编号", "出生日期", "猪只状态", "所在栏舍"};
            jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel002, tableHead002));
            setJTableRow(jTable2);
        }
        sqlSession.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jDesktopPane5 = new javax.swing.JDesktopPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(305, 353));

        jLabel1.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel1.setText("种猪疫苗提醒");

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton8.setText("退出查看");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jTabbedPane1.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jTabbedPane1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTabbedPane1FocusGained(evt);
            }
        });

        jTable2.setFont(new java.awt.Font("楷体", 0, 12)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable2.getTableHeader().setResizingAllowed(false);
        jScrollPane2.setViewportView(jTable2);

        jDesktopPane5.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane5Layout = new javax.swing.GroupLayout(jDesktopPane5);
        jDesktopPane5.setLayout(jDesktopPane5Layout);
        jDesktopPane5Layout.setHorizontalGroup(
            jDesktopPane5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        jDesktopPane5Layout.setVerticalGroup(
            jDesktopPane5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("疫苗提醒", jDesktopPane5);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(460, 460, 460))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1014, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(144, 144, 144))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addGap(15, 15, 15)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addComponent(jButton8)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1034, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 599, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jTabbedPane1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTabbedPane1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jTabbedPane1FocusGained

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton8;
    private static javax.swing.JDesktopPane jDesktopPane5;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
