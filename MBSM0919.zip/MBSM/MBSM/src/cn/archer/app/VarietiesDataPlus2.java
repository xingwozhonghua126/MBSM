package cn.archer.app;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.utils.MyStaticMethod.setJTableRow;
import javax.swing.JTable;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/**
 *
 * @author Administrator
 */
public class VarietiesDataPlus2 extends javax.swing.JInternalFrame {

    private Object[][] tableModel;
    private String[] tableHead;
 
    public VarietiesDataPlus2(Object[][] tableModel, String[] tableHead) {
        initComponents();
        this.tableModel = tableModel;
        this.tableHead = tableHead;
        ((BasicInternalFrameUI) getUI()).setNorthPane(null);

        TotalRecFld.setText(String.valueOf(MainApp.pageModel.getTotalRecords()));
        MaxpageFld.setText(String.valueOf(MainApp.pageModel.getBottomPageNo()));
        NowPageFld.setText(String.valueOf(MainApp.pageModel.getPageNo()));
        jTextField1.setText(String.valueOf(MainApp.pageModel.getPageNo()));
        BeginRecFld.setText(String.valueOf(MainApp.pageModel.getPageNoRecordBegin()));
        EndRecFld.setText(String.valueOf(MainApp.pageModel.getPageNoRecordEnd()));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        setJTableRow(jTable1);
    }

    /**
     * Creates new form VarietiesData
     */
    public VarietiesDataPlus2() {
        initComponents();
    }

        //公共结束浏览代码

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jPanel01 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TotalRecFld = new javax.swing.JLabel();
        jPanel02 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        BeginRecFld = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        EndRecFld = new javax.swing.JLabel();
        jPanel03 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        NowPageFld = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        MaxpageFld = new javax.swing.JLabel();
        jPanel04 = new javax.swing.JPanel();
        FirstBtn = new javax.swing.JButton();
        PrevBtn = new javax.swing.JButton();
        NextBtn = new javax.swing.JButton();
        LastBtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel4 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        GO = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(233, 242, 252));
        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setToolTipText("");
        setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        setPreferredSize(new java.awt.Dimension(990, 465));

        jTable1.setFont(new java.awt.Font("楷体", 0, 16)); // NOI18N
        jTable1.setForeground(new java.awt.Color(0, 51, 102));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable1.getTableHeader().setResizingAllowed(false);
        jScrollPane1.setViewportView(jTable1);

        jPanel1.setBackground(new java.awt.Color(226, 238, 252));
        jPanel1.setPreferredSize(new java.awt.Dimension(891, 45));

        jPanel01.setBackground(new java.awt.Color(226, 238, 252));
        jPanel01.setMinimumSize(new java.awt.Dimension(89, 40));
        jPanel01.setPreferredSize(new java.awt.Dimension(89, 40));

        jLabel1.setText("总记录数：");
        jPanel01.add(jLabel1);

        TotalRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        TotalRecFld.setForeground(new java.awt.Color(255, 0, 255));
        TotalRecFld.setText("0");
        jPanel01.add(TotalRecFld);

        jPanel02.setBackground(new java.awt.Color(226, 238, 252));
        jPanel02.setMinimumSize(new java.awt.Dimension(127, 40));
        jPanel02.setPreferredSize(new java.awt.Dimension(127, 40));

        jLabel3.setText("当前记录：");
        jPanel02.add(jLabel3);

        BeginRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        BeginRecFld.setForeground(new java.awt.Color(255, 0, 255));
        BeginRecFld.setText("0");
        jPanel02.add(BeginRecFld);

        jLabel4.setText("-");
        jPanel02.add(jLabel4);

        EndRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        EndRecFld.setForeground(new java.awt.Color(255, 0, 255));
        EndRecFld.setText("0");
        jPanel02.add(EndRecFld);

        jPanel03.setBackground(new java.awt.Color(226, 238, 252));
        jPanel03.setMinimumSize(new java.awt.Dimension(91, 40));
        jPanel03.setPreferredSize(new java.awt.Dimension(91, 40));

        jLabel2.setText("页数：");
        jPanel03.add(jLabel2);

        NowPageFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        NowPageFld.setForeground(new java.awt.Color(255, 0, 255));
        NowPageFld.setText("0");
        jPanel03.add(NowPageFld);

        jLabel6.setText("/");
        jPanel03.add(jLabel6);

        MaxpageFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        MaxpageFld.setForeground(new java.awt.Color(255, 0, 255));
        MaxpageFld.setText("0");
        jPanel03.add(MaxpageFld);

        jPanel04.setBackground(new java.awt.Color(226, 238, 252));

        FirstBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_first.png"))); // NOI18N
        FirstBtn.setToolTipText("首页");
        FirstBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        FirstBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstBtnActionPerformed(evt);
            }
        });
        jPanel04.add(FirstBtn);

        PrevBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_previous.png"))); // NOI18N
        PrevBtn.setToolTipText("上页");
        PrevBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        PrevBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrevBtnActionPerformed(evt);
            }
        });
        jPanel04.add(PrevBtn);

        NextBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_next.png"))); // NOI18N
        NextBtn.setToolTipText("下页");
        NextBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        NextBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextBtnActionPerformed(evt);
            }
        });
        jPanel04.add(NextBtn);

        LastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_last.png"))); // NOI18N
        LastBtn.setToolTipText("尾页");
        LastBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        LastBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LastBtnActionPerformed(evt);
            }
        });
        jPanel04.add(LastBtn);
        jPanel04.add(jSeparator1);

        jPanel4.setBackground(new java.awt.Color(226, 238, 252));
        jPanel4.setMinimumSize(new java.awt.Dimension(70, 40));
        jPanel4.setPreferredSize(new java.awt.Dimension(109, 40));

        jTextField1.setText("第几页");
        jTextField1.setMinimumSize(new java.awt.Dimension(6, 5));
        jTextField1.setPreferredSize(new java.awt.Dimension(45, 21));
        jPanel4.add(jTextField1);

        GO.setForeground(new java.awt.Color(255, 0, 255));
        GO.setText("GO");
        GO.setMaximumSize(new java.awt.Dimension(45, 25));
        GO.setMinimumSize(new java.awt.Dimension(45, 25));
        GO.setPreferredSize(new java.awt.Dimension(45, 25));
        GO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GOActionPerformed(evt);
            }
        });
        jPanel4.add(GO);

        jButton1.setForeground(new java.awt.Color(255, 0, 255));
        jButton1.setText("倒序");
        jButton1.setPreferredSize(new java.awt.Dimension(45, 25));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(155, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel01, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel02, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel03, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel02, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel03, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel04, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel01, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 974, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
                .addGap(2, 2, 2)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void FirstBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FirstBtnActionPerformed

        MainApp.Xzxppage(MainApp.pageModel.getTopPageNo());


    }//GEN-LAST:event_FirstBtnActionPerformed

    private void PrevBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrevBtnActionPerformed

        MainApp.Xzxppage(MainApp.pageModel.getPreviousPageNo());

    }//GEN-LAST:event_PrevBtnActionPerformed

    private void NextBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextBtnActionPerformed

        MainApp.Xzxppage(MainApp.pageModel.getNextPageNo());

    }//GEN-LAST:event_NextBtnActionPerformed

    private void LastBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LastBtnActionPerformed

        MainApp.Xzxppage(MainApp.pageModel.getBottomPageNo());

    }//GEN-LAST:event_LastBtnActionPerformed

    private void GOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GOActionPerformed

        MainApp.Xzxppage(Integer.parseInt(jTextField1.getText()));

    }//GEN-LAST:event_GOActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MainApp.pageModel.fanzhuan();
        MainApp.Xzxppage(MainApp.pageModel.getTopPageNo());
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BeginRecFld;
    private javax.swing.JLabel EndRecFld;
    public javax.swing.JButton FirstBtn;
    private javax.swing.JButton GO;
    public javax.swing.JButton LastBtn;
    private javax.swing.JLabel MaxpageFld;
    public javax.swing.JButton NextBtn;
    private javax.swing.JLabel NowPageFld;
    public javax.swing.JButton PrevBtn;
    private javax.swing.JLabel TotalRecFld;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel01;
    private javax.swing.JPanel jPanel02;
    private javax.swing.JPanel jPanel03;
    private javax.swing.JPanel jPanel04;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

    public JTable getjTable1() {
        return jTable1;
    }

    public void setjTable1(JTable jTable1) {
        this.jTable1 = jTable1;
    }

    public void setTableModel(Object[][] tableModel) {
        this.tableModel = tableModel;
    }

    public void setTableHead(String[] tableHead) {
        this.tableHead = tableHead;
    }

}
