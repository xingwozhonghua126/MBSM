package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.breedingMapperPlus;
import static cn.archer.app.MainApp.breedingPageModel;
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeePZYThingsShow;
import static cn.archer.app.MainApp.employeePZYThingsmap;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.fenceNametoIdSmap;
import static cn.archer.app.MainApp.fenceThingsmap;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.piggeryThingsmap;
import cn.archer.mapper.BreedingMapper;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.model.BreedingPageModel;
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Fence;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Selebith;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import static cn.archer.utils.MyStaticMethod.NowTime;
import static cn.archer.utils.MyStaticMethod.addDate;
import cn.archer.utils.DateChooserJButtonJDialog;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author Administrator
 */
public class BreedingApp extends javax.swing.JDialog {

    private VarietiesDataPlus varietiesDataPlus;
    private String flagua;
    private String formid0;
    private List<Piggery> piggery;

    /**
     * Creates new form FormApp
     */
    public BreedingApp(VarietiesDataPlus varietiesDataPlus, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        flagua = "add";
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("母猪配种情况登记");
        jLabel00.setText("母猪配种情况登记");

        //雇员复选框
        jComboBox16.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsShow));
        jTextField3.setText(NowTime());
        jTextField15.setText(addDate(NowTime(), 114));
        jTextField2.setEnabled(false);
        jComboBox5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox4.setEnabled(false);

    }

    public BreedingApp(VarietiesDataPlus varietiesDataPlus, String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        flagua = "upp";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("母猪配种情况更改");
        jLabel00.setText("母猪配种情况更改");
        jButton1.setText("确定提交");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        BreedingMapper mapper = sqlSession.getMapper(BreedingMapper.class);
        Breeding breeding = new Breeding();
        breeding = mapper.selectByid(formid0);
        jComboBox4.setEnabled(true);
        jComboBox5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(true);
        jComboBox8.setEnabled(true);
        jTextField1.setEditable(false);
        jTextField10.setEditable(false);
        //所在猪舍复选框
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(breeding.getFenceid().substring(0, 5))));
        //所在栏位复选框
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(breeding.getFenceid())));
        //｛一配复选框
        String[] things2 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things2[0] = "本交";
                things2[1] = "鲜交";
                things2[2] = "冻精";
                break;
            case "2":
                things2[0] = "鲜交";
                things2[1] = "本交";
                things2[2] = "冻精";
                break;
            default:
                things2[0] = "冻精";
                things2[1] = "本交";
                things2[2] = "鲜交";
                break;
        }
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things2));
        //｝一配复选框 
        //｛二配复选框
        String[] things3 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things3[0] = "本交";
                things3[1] = "鲜交";
                things3[2] = "冻精";
                break;
            case "2":
                things3[0] = "鲜交";
                things3[1] = "本交";
                things3[2] = "冻精";
                break;
            default:
                things3[0] = "冻精";
                things3[1] = "本交";
                things3[2] = "鲜交";
                break;
        }
        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel(things3));
        //｝二配复选框 
        //｛三配复选框
        String[] things4 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things4[0] = "本交";
                things4[1] = "鲜交";
                things4[2] = "冻精";
                break;
            case "2":
                things4[0] = "鲜交";
                things4[1] = "本交";
                things4[2] = "冻精";
                break;
            default:
                things4[0] = "冻精";
                things4[1] = "本交";
                things4[2] = "鲜交";
                break;
        }
        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel(things4));
        //｝三配复选框 
        //雇员复选框
        jComboBox16.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsmap.get(breeding.getEmployeeid())));
        //{妊娠栏位复选框
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(breeding.getOutfenceid().substring(0, 5))));
        //妊娠栏位
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(breeding.getOutfenceid())));
        //｝妊娠栏位复选框 
        //｛配种状态
        String[] things9 = new String[3];
        switch (breeding.getPzzt()) {
            case "1":
                things9[0] = "检验";
                things9[1] = "妊娠";
                things9[2] = "返情";
                break;
            case "2":
                things9[0] = "妊娠";
                things9[1] = "检验";
                things9[2] = "返情";
                break;
            default:
                things9[0] = "返情";
                things9[1] = "妊娠";
                things9[2] = "检验";
                break;
        }
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(things9));
        //}配种状态 

        jTextField1.setText(breeding.getR_animal());
        jTextField2.setText(String.valueOf(breeding.getPztc()));
        jTextField3.setText(breeding.getPzrq());
        jTextField10.setText(breeding.getOner_animal());
        jTextField12.setText(breeding.getTwor_animal());
        jTextField14.setText(breeding.getThreer_animal());
        jTextField15.setText(breeding.getYcrq());
        jTextArea1.setText(breeding.getBz());

        jTextField2.setEnabled(false);
        sqlSession.close();
    }

    public BreedingApp(String farmid0, java.awt.Frame parent, boolean modal, int j) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("母猪配种情况详情");
        jLabel00.setText("母猪配种情况详情");

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        BreedingMapper mapper = sqlSession.getMapper(BreedingMapper.class);
        Breeding breeding;
        breeding = mapper.selectByid(formid0);

        //所在猪舍复选框
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(breeding.getFenceid().substring(0, 5))));
        //所在栏位复选框
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(breeding.getFenceid())));
        //｛一配复选框
        String[] things2 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things2[0] = "本交";
                things2[1] = "鲜交";
                things2[2] = "冻精";
                break;
            case "2":
                things2[0] = "鲜交";
                things2[1] = "本交";
                things2[2] = "冻精";
                break;
            default:
                things2[0] = "冻精";
                things2[1] = "本交";
                things2[2] = "鲜交";
                break;
        }
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things2));
        //｝一配复选框 
        //｛二配复选框
        String[] things3 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things3[0] = "本交";
                things3[1] = "鲜交";
                things3[2] = "冻精";
                break;
            case "2":
                things3[0] = "鲜交";
                things3[1] = "本交";
                things3[2] = "冻精";
                break;
            default:
                things3[0] = "冻精";
                things3[1] = "本交";
                things3[2] = "鲜交";
                break;
        }
        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel(things3));
        //｝二配复选框 
        //｛三配复选框
        String[] things4 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things4[0] = "本交";
                things4[1] = "鲜交";
                things4[2] = "冻精";
                break;
            case "2":
                things4[0] = "鲜交";
                things4[1] = "本交";
                things4[2] = "冻精";
                break;
            default:
                things4[0] = "冻精";
                things4[1] = "本交";
                things4[2] = "鲜交";
                break;
        }
        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel(things4));
        //｝三配复选框 
        //雇员复选框
        jComboBox16.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsmap.get(breeding.getEmployeeid())));

        //妊娠猪舍
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(breeding.getOutfenceid().substring(0, 5))));
        //妊娠栏位
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(breeding.getOutfenceid())));
        //｛配种状态
        String[] things9 = new String[3];
        switch (breeding.getPzzt()) {
            case "1":
                things9[0] = "检验";
                things9[1] = "妊娠";
                things9[2] = "返情";
                break;
            case "2":
                things9[0] = "妊娠";
                things9[1] = "检验";
                things9[2] = "返情";
                break;
            default:
                things9[0] = "返情";
                things9[1] = "妊娠";
                things9[2] = "检验";
                break;
        }
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(things9));
        //}配种状态 

        jTextField1.setText(breeding.getR_animal());
        jTextField2.setText(String.valueOf(breeding.getPztc()));
        jTextField3.setText(breeding.getPzrq());
        jTextField10.setText(breeding.getOner_animal());
        jTextField12.setText(breeding.getTwor_animal());
        jTextField14.setText(breeding.getThreer_animal());
        jTextField15.setText(breeding.getYcrq());
        jTextArea1.setText(breeding.getBz());

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jTextField3.setEnabled(false);
        jComboBox4.setEnabled(false);
        jComboBox5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jComboBox11.setEnabled(false);
        jTextField12.setEnabled(false);
        jComboBox13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jComboBox16.setEnabled(false);
        jTextArea1.setEnabled(false);
        jButton0003.setEnabled(false);
        jButton0015.setEnabled(false);

        jButton1.setEnabled(false);
        jButton2.setEnabled(false);

        sqlSession.close();
    }

    public BreedingApp(String farmid0, javax.swing.JDialog parent, boolean modal, int j) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("公猪配种情况详情");
        jLabel00.setText("公猪配种情况详情");

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        BreedingMapper mapper = sqlSession.getMapper(BreedingMapper.class);
        Breeding breeding;
        breeding = mapper.selectByid(formid0);

        //所在猪舍复选框
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(breeding.getFenceid().substring(0, 5))));
        //所在栏位复选框
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(breeding.getFenceid())));
        //｛一配复选框
        String[] things2 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things2[0] = "本交";
                things2[1] = "鲜交";
                things2[2] = "冻精";
                break;
            case "2":
                things2[0] = "鲜交";
                things2[1] = "本交";
                things2[2] = "冻精";
                break;
            default:
                things2[0] = "冻精";
                things2[1] = "本交";
                things2[2] = "鲜交";
                break;
        }
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things2));
        //｝一配复选框 
        //｛二配复选框
        String[] things3 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things3[0] = "本交";
                things3[1] = "鲜交";
                things3[2] = "冻精";
                break;
            case "2":
                things3[0] = "鲜交";
                things3[1] = "本交";
                things3[2] = "冻精";
                break;
            default:
                things3[0] = "冻精";
                things3[1] = "本交";
                things3[2] = "鲜交";
                break;
        }
        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel(things3));
        //｝二配复选框 
        //｛三配复选框
        String[] things4 = new String[3];
        switch (breeding.getOnetype()) {
            case "1":
                things4[0] = "本交";
                things4[1] = "鲜交";
                things4[2] = "冻精";
                break;
            case "2":
                things4[0] = "鲜交";
                things4[1] = "本交";
                things4[2] = "冻精";
                break;
            default:
                things4[0] = "冻精";
                things4[1] = "本交";
                things4[2] = "鲜交";
                break;
        }
        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel(things4));
        //｝三配复选框 
        //雇员复选框
        jComboBox16.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsmap.get(breeding.getEmployeeid())));
        //妊娠猪舍
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(breeding.getOutfenceid().substring(0, 5))));
        //妊娠栏位
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(breeding.getOutfenceid())));
        //｝妊娠栏位复选框 
        //｛配种状态
        String[] things9 = new String[3];
        switch (breeding.getPzzt()) {
            case "1":
                things9[0] = "检验";
                things9[1] = "妊娠";
                things9[2] = "返情";
                break;
            case "2":
                things9[0] = "妊娠";
                things9[1] = "检验";
                things9[2] = "返情";
                break;
            default:
                things9[0] = "返情";
                things9[1] = "妊娠";
                things9[2] = "检验";
                break;
        }
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(things9));
        //}配种状态 

        jTextField1.setText(breeding.getR_animal());
        jTextField2.setText(String.valueOf(breeding.getPztc()));
        jTextField3.setText(breeding.getPzrq());
        jTextField10.setText(breeding.getOner_animal());
        jTextField12.setText(breeding.getTwor_animal());
        jTextField14.setText(breeding.getThreer_animal());
        jTextField15.setText(breeding.getYcrq());
        jTextArea1.setText(breeding.getBz());

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jTextField3.setEnabled(false);
        jComboBox4.setEnabled(false);
        jComboBox5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jComboBox11.setEnabled(false);
        jTextField12.setEnabled(false);
        jComboBox13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jComboBox16.setEnabled(false);
        jTextArea1.setEnabled(false);
        jButton0003.setEnabled(false);
        jButton0015.setEnabled(false);

        jButton1.setEnabled(false);
        jButton2.setEnabled(false);
        sqlSession.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jTextField10 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jComboBox16 = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jComboBox9 = new javax.swing.JComboBox<>();
        jComboBox13 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jComboBox8 = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jLabel00 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jButton0003 =  new DateChooserJButtonJDialog (jTextField3);
        jButton0015 =  new DateChooserJButtonJDialog (jTextField15);
        jLabel2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jComboBox11 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jButton1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton1.setText("连续提交");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/refues.png"))); // NOI18N
        jButton2.setText("重新输入");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setText("0");
        jScrollPane1.setViewportView(jTextArea1);

        jLabel8.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel8.setText("备    注：");

        jTextField2.setText("0");
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel4.setText("当前胎次：");

        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setText("配种日期：");

        jTextField1.setText("0");
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel1.setText("个体编号：");

        jLabel6.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel6.setText("一配方式：");

        jLabel7.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel7.setText("一配公猪：");

        jLabel10.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel10.setText("负 责 人：");

        jLabel9.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel9.setText("二配方式：");

        jButton3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton3.setText("退出输入");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel11.setText("二配公猪：");

        jLabel12.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel12.setText("配种猪舍：");

        jComboBox5.setMinimumSize(new java.awt.Dimension(12, 21));
        jComboBox5.setPreferredSize(new java.awt.Dimension(12, 21));
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });

        jTextField10.setText("0");
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jTextField12.setText("0");
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel13.setText("三配方式：");

        jLabel14.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel14.setText("三配公猪：");

        jTextField14.setText("0");
        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });

        jComboBox16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox16ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel15.setText("妊娠猪舍：");

        jComboBox7.setMinimumSize(new java.awt.Dimension(12, 21));
        jComboBox7.setPreferredSize(new java.awt.Dimension(12, 21));
        jComboBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox7ActionPerformed(evt);
            }
        });

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "检验", "妊娠", "返情" }));
        jComboBox4.setToolTipText("");
        jComboBox4.setEditor(null);
        jComboBox4.setName("检验\n妊娠\n"); // NOI18N
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel16.setText("配种状态：");

        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "本交", "鲜交", "冻精" }));
        jComboBox9.setMinimumSize(new java.awt.Dimension(12, 21));
        jComboBox9.setPreferredSize(new java.awt.Dimension(12, 21));
        jComboBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox9ActionPerformed(evt);
            }
        });

        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "本交", "鲜交", "冻精" }));
        jComboBox13.setMinimumSize(new java.awt.Dimension(12, 21));
        jComboBox13.setPreferredSize(new java.awt.Dimension(12, 21));
        jComboBox13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox13ActionPerformed(evt);
            }
        });

        jComboBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox6ActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel17.setText("配种栏位：");

        jLabel5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel5.setText("预产日期：");

        jComboBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox8ActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel18.setText("妊娠栏位：");

        jLabel00.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel00.setText("母猪配种信息录入");

        jButton0003.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton0003.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton0003ActionPerformed(evt);
            }
        });

        jButton0015.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton0015.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton0015ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("*");

        jLabel19.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(204, 0, 0));
        jLabel19.setText("*");

        jLabel20.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 0, 0));
        jLabel20.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息处理");

        jComboBox11.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "本交", "鲜交", "冻精" }));
        jComboBox11.setMinimumSize(new java.awt.Dimension(12, 21));
        jComboBox11.setPreferredSize(new java.awt.Dimension(12, 21));
        jComboBox11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(232, 232, 232)
                .addComponent(jLabel00)
                .addGap(233, 233, 233))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addGap(305, 305, 305))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel12)
                                            .addComponent(jLabel15)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel13))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jComboBox13, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jButton0015, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(jComboBox11, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(101, 101, 101)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jLabel14)
                                                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING))
                                                        .addGap(11, 11, 11)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jComboBox16, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                            .addComponent(jLabel7)
                                                            .addComponent(jLabel11))
                                                        .addGap(11, 11, 11)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(99, 99, 99)
                                                .addComponent(jLabel18))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(99, 99, 99)
                                                .addComponent(jLabel17))))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel1)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel3)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jButton0003, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jLabel2)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGap(88, 88, 88)
                                                    .addComponent(jLabel4))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGap(90, 90, 90)
                                                    .addComponent(jLabel16)))
                                            .addGap(9, 9, 9)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(jButton1)
                                            .addGap(50, 50, 50)
                                            .addComponent(jButton2)
                                            .addGap(50, 50, 50)
                                            .addComponent(jButton3)
                                            .addGap(40, 40, 40))))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel00)
                .addGap(30, 30, 30)
                .addComponent(jLabel20)
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel3)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel16))
                                            .addComponent(jButton0003, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel17))
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel12)
                                                .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel18)
                                            .addComponent(jLabel15)
                                            .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(10, 10, 10)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel6)
                                            .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel19))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel11)
                                                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jComboBox11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel9))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel13)
                                            .addComponent(jLabel14)
                                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jComboBox16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel10)
                                .addComponent(jLabel5))
                            .addComponent(jButton0015, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel8)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton1))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (StringUtils.isBlank(jTextField1.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加个体编号!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (StringUtils.isBlank(jTextField10.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加一配公猪!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        String idM = jTextField1.getText();
        String idG = jTextField10.getText();
        if (idM.length() != 15 && idM.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加母猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        if (idG.length() != 15 && idG.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加公猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }

        Selebith selebithM = mapper0.selectById("%" + jTextField1.getText());
        Selebith selebithG = mapper0.selectById("%" + jTextField10.getText());

        if (selebithM == null) {
            JOptionPane.showMessageDialog(null, "您添加种母猪个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebithG == null) {
            JOptionPane.showMessageDialog(null, "您添加种公猪个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在
        BreedingMapper mapper = sqlSession.getMapper(BreedingMapper.class);
        Breeding breeding = new Breeding();
        if (flagua.equals("add")) {
            //｛查询母猪个体编号是否存在
            int pdk = 0;
            if ((selebithM.getR_curmark().equals("5") || selebithM.getR_curmark().equals("8")) && (selebithM.getR_select() == 0)) {
                pdk = 1;
            } else {
                pdk = 0;
                JOptionPane.showMessageDialog(null, "您添加母猪个体编号不是空怀母猪和后备母猪状态，也可能正处在配种检验状态!", "系统信息", JOptionPane.WARNING_MESSAGE);
                sqlSession.close();
                return;
            }
            if (selebithG.getR_curmark().equals("9")) {
                pdk = 1;
            } else {
                pdk = 0;
                JOptionPane.showMessageDialog(null, "您添加一配公猪个体编号不是种公猪状态!", "系统信息", JOptionPane.WARNING_MESSAGE);
                sqlSession.close();
                return;
            }
        }
        //｝查询种母猪个体编号是否存在
        //复选框-关联当前栏位表{
        String jComboBox6String = fenceNametoIdSmap.get(JComboBoxString(jComboBox6));

        String jComboBox5String = "1";
        String jComboBox7String = "1";
        String jComboBox9String = "1";
        if (JComboBoxString(jComboBox9).equals("鲜交")) {
            jComboBox5String = "2";
        }
        if (JComboBoxString(jComboBox9).equals("冻精")) {
            jComboBox5String = "3";
        }
        if (JComboBoxString(jComboBox13).equals("鲜交")) {
            jComboBox7String = "2";
        }
        if (JComboBoxString(jComboBox13).equals("冻精")) {
            jComboBox7String = "3";
        }
        if (JComboBoxString(jComboBox13).equals("鲜交")) {
            jComboBox9String = "2";
        }
        if (JComboBoxString(jComboBox13).equals("冻精")) {
            jComboBox9String = "3";
        }

        String jComboBox14String = "1";
        if (JComboBoxString(jComboBox4).equals("检验")) {
            jComboBox14String = "1";
        }
        if (JComboBoxString(jComboBox4).equals("妊娠")) {
            jComboBox14String = "2";
        }
        if (JComboBoxString(jComboBox4).equals("返情")) {
            jComboBox14String = "3";
        }
        String pzztName = JComboBoxString(jComboBox4);

        //复选框-关联雇员表
        String jComboBox12String = employeeNametoIdSmap.get(JComboBoxString(jComboBox16));
        //妊娠栏位
        String jComboBox13String = fenceNametoIdSmap.get(JComboBoxString(jComboBox8));
        breeding.setR_animal(selebithM.getR_animal());
        breeding.setPztc(selebithM.getR_fno());
        breeding.setFqrq(jTextField3.getText());
        breeding.setPzrq(jTextField3.getText());
        breeding.setOnetype(jComboBox5String);
        breeding.setOner_animal(selebithG.getR_animal());
        breeding.setTwotype(jComboBox7String);
        breeding.setTwor_animal(jTextField12.getText());
        breeding.setThreetype(jComboBox9String);
        breeding.setThreer_animal(jTextField14.getText());
        breeding.setYcrq(jTextField15.getText());
        breeding.setEmployeeid(jComboBox12String);
        breeding.setOutfenceid(jComboBox13String);
        breeding.setPzzt(jComboBox14String);

        breeding.setBz(jTextArea1.getText());
        JTable jTable1 = varietiesDataPlus.getjTable1();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        if (flagua.equals("add")) {
            breeding.setOutfenceid(selebithM.getR_pcage());
            breeding.setFenceid(selebithM.getR_pcage());
            breeding.setPzzt("1");
            selebithM.setR_select(1);
            mapper0.updateByTypeid(selebithM);
            mapper.insert(breeding);
            sqlSession.commit();
            sqlSession.close();
            JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            //添加后更新数据格式
            MainApp.breedingPageModel = new BreedingPageModel(14, breedingMapperPlus.SelectCount(), breedingMapperPlus, false);
            MainApp.Breedingpage(breedingPageModel.getTopPageNo());
        } else {
            breeding.setId(formid0);
            selebithM.setR_select(0);
            breeding.setFenceid(jComboBox6String);
            if (JComboBoxString(jComboBox4).equals("妊娠")) {
                selebithM.setDqpzgzid(jTextField10.getText());
                selebithM.setR_curmark("6");
                selebithM.setR_pcage(jComboBox13String);
                selebithM.setR_cage(jComboBox13String.substring(0, 5));
            }
            if (JComboBoxString(jComboBox4).equals("检验")) {
                JOptionPane.showMessageDialog(null,
                        "修改只能改变妊娠或则返情!", "系统信息", JOptionPane.WARNING_MESSAGE);
                sqlSession.close();
                return;
            }
            if (JComboBoxString(jComboBox4).equals("返情")) {
                //?????????????????????????????????
            }
            mapper0.updateByTypeid(selebithM);
            mapper.updateByid(breeding);
            sqlSession.commit();
            sqlSession.close();
            JOptionPane.showMessageDialog(null, "修改成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            jTextField1.setEditable(true);
            jButton2.setEnabled(true);
            //移除修改那行，然后在后面加上新的一行
            model.removeRow(jTable1.getSelectedRow());

            Object[] rowInsert = new Object[]{breeding.getId(), breeding.getR_animal(), breeding.getPzrq(), JComboBoxString(jComboBox16), pzztName, fenceIdtoNameSmap.get(selebithM.getR_pcage())};
            model.addRow(rowInsert);
            jTable1.setModel(model);
            varietiesDataPlus.validate();
            System.gc();
            dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField10.setText("");
        jTextField12.setText("");
        jTextField14.setText("");
        jTextField15.setText("");
        jTextArea1.setText("");

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        if ("add".equals(flagua)) {
            return;
        }
        String name = JComboBoxString(jComboBox5);
        String id = piggeryNametoIdSmap.get(name);

        List<Fence> fencelist;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
            fencelist = mapper6.selectAllById(id);
        }
        String[] things6 = new String[fencelist.size()];
        for (int i = 0; i < fencelist.size(); i++) {
            things6[i] = fencelist.get(i).getFencename();
        }
        jComboBox6.removeAll();
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(things6));
        // TODO add your handling code here:

    }//GEN-LAST:event_jComboBox5ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jComboBox16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox16ActionPerformed

    private void jComboBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox7ActionPerformed
        String name = JComboBoxString(jComboBox7);
        String id = null;

        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        List<Fence> fence;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
            fence = mapper6.selectAllById(id);
        }
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox8.removeAll();
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(things6));
        // TODO add your handling code here:

    }//GEN-LAST:event_jComboBox7ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jComboBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox9ActionPerformed

    private void jComboBox13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox13ActionPerformed

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        if ("upp".equals(flagua)) {
            return;
        }
        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        String idM = jTextField1.getText();
        if (idM.length() != 15 && idM.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加母猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Selebith selebithM = mapper0.selectById("%" + jTextField1.getText());

        if (selebithM == null) {
            JOptionPane.showMessageDialog(null, "您添加种母猪个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在
        jTextField2.setText(String.valueOf(selebithM.getR_fno()));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(selebithM.getR_cage())));
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(selebithM.getR_pcage())));
        sqlSession.close();

    }//GEN-LAST:event_jTextField1FocusLost

    private void jComboBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox6ActionPerformed

    private void jComboBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox8ActionPerformed

    private void jButton0003ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton0003ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton0003ActionPerformed

    private void jButton0015ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton0015ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton0015ActionPerformed

    private void jComboBox11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox11ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton0003;
    private javax.swing.JButton jButton0015;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox11;
    private javax.swing.JComboBox<String> jComboBox13;
    private javax.swing.JComboBox<String> jComboBox16;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
