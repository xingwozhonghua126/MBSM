/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.app;

import static cn.archer.app.MainApp.Zzxspage;
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeeXSThingsShow;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.piggeryIdtoNameSmap;
import static cn.archer.app.MainApp.swintypeIdtoNameSmap;
import static cn.archer.app.MainApp.swintypeNametoIdSmap;
import static cn.archer.app.MainApp.zzxsMapperPlus;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.mapper.SwintypeMapper;
import cn.archer.mapper.ZzxsMapper;
import cn.archer.mapper.plus.PigMapperPlus02;
import cn.archer.model.PigPageModel02;
import cn.archer.model.ZzxsPageModel;
import cn.archer.pojo.Fence;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.Swintype;
import cn.archer.pojo.Vaccine;
import cn.archer.pojo.Zzxs;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import static cn.archer.utils.MyStaticMethod.setJTableRow;
import cn.archer.utils.DateChooserJButtonJDialog;
import static cn.archer.utils.MyStaticMethod.SsFence;
import cn.archer.utils.MyTable;
import cn.archer.utils.MybatisUtil;
import cn.archer.utils.UiUtilJDialog;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author Administrator
 */
public class PigSale02 extends javax.swing.JDialog {

    private static List<Selebith> temp;

    private String flagua;
    private String formid0;
    static VarietiesDataPlus varietiesDataPlus;
    private List<Piggery> piggery;
    private boolean jTableFlag = false;
    private int intPcage1;
    static private PigPageModel02 pigSalePageModel02;
    private List<Vaccine> vlist = null;

    /**
     * Creates new form FormApp
     */
    public PigSale02(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        flagua = "add";
        this.setTitle("猪只销售登记");
        UiUtilJDialog.setFrameCenter(this);
        //快速查询面板
        //｛所在猪舍复选框
        List<Swintype> swintypelist;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
            swintypelist = mapper.selectAll();
        }
        String[] things = new String[swintypelist.size() + 1];
        for (int i = 0; i < swintypelist.size() + 1; i++) {
            if (i == 0) {
                things[i] = "猪只状态";
            } else {
                if (swintypelist.get(i - 1).getTypename().equals("销售") || swintypelist.get(i - 1).getTypename().equals("死亡")) {
                    continue;
                }
                things[i] = swintypelist.get(i - 1).getTypename();
            }
        }
        jComboBoxPigStatue.setModel(new javax.swing.DefaultComboBoxModel(things));
        //｝所在猪舍复选框
        //显示全部舍栏
        //｛全部舍复选框
        List<Fence> fence;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper2 = sqlSession.getMapper(FenceMapper.class);
            fence = mapper2.selectAll();
        }
        String[] things2 = new String[fence.size() + 1];
        for (int i = 0; i < fence.size() + 1; i++) {
            if (i == 0) {
                things2[i] = "全部栏";
            } else {
                things2[i] = fence.get(i - 1).getFencename();
            }
        }
        jComboBoxR_pcage.setModel(new javax.swing.DefaultComboBoxModel(things2));
        //｝全部舍复选框         
        //｛全部栏复选框
        List<Piggery> piggery;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PiggeryMapper mapper3 = sqlSession.getMapper(PiggeryMapper.class);
            piggery = mapper3.selectAll();
        }
        String[] things3 = new String[piggery.size() + 1];
        for (int i = 0; i < piggery.size() + 1; i++) {
            if (i == 0) {
                things3[i] = "全部舍";
            } else {
                things3[i] = piggery.get(i - 1).getCategory();
            }
        }
        jComboBoxR_cage.setModel(new javax.swing.DefaultComboBoxModel(things3));
        //｝全部栏复选框 
        jComboBoxPerson.setModel(new javax.swing.DefaultComboBoxModel(employeeXSThingsShow));

        PigMapperPlus02 pigSaleMapperPlus02 = new PigMapperPlus02();
        pigSalePageModel02 = new PigPageModel02(15, pigSaleMapperPlus02.SelectCountSale02(), pigSaleMapperPlus02, false);
        pigSalePlus02(1);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFirst1 = new javax.swing.JPanel();
        jPanelFirst = new javax.swing.JPanel();
        jLabelNumber = new javax.swing.JLabel();
        jTextFieldNumber = new javax.swing.JTextField();
        jLabelBirthDate = new javax.swing.JLabel();
        jTextFieldBirthDate1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldBirthDate2 = new javax.swing.JTextField();
        jButtonBirthDate1 =  new DateChooserJButtonJDialog (jTextFieldBirthDate1);
        jButtonBirthDate2 =  new DateChooserJButtonJDialog (jTextFieldBirthDate2);
        jComboBoxR_cage = new javax.swing.JComboBox<>();
        jComboBoxR_pcage = new javax.swing.JComboBox<>();
        jButtonSelect = new javax.swing.JButton();
        jButtonReset = new javax.swing.JButton();
        jComboBoxPigStatue = new javax.swing.JComboBox<>();
        jLabel46 = new javax.swing.JLabel();
        jPanelDisplay = new javax.swing.JPanel();
        jDesktopPaneTurningDisplay = new javax.swing.JDesktopPane();
        jScrollPaneDisplay = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jPanel01 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TotalRecFld = new javax.swing.JLabel();
        jPanel02 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        BeginRecFld = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        EndRecFld = new javax.swing.JLabel();
        jPanel03 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        NowPageFld = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        MaxpageFld = new javax.swing.JLabel();
        jPanel04 = new javax.swing.JPanel();
        FirstBtn = new javax.swing.JButton();
        PrevBtn = new javax.swing.JButton();
        NextBtn = new javax.swing.JButton();
        LastBtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel4 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        GO = new javax.swing.JButton();
        jPanelOperation = new javax.swing.JPanel();
        jCheckBoxAll = new javax.swing.JCheckBox();
        jButtonTurningReset = new javax.swing.JButton();
        jButtonTurningDetial = new javax.swing.JButton();
        jButtonTurningOut = new javax.swing.JButton();
        jButtonTurningContinue = new javax.swing.JButton();
        jPanelPhoto = new javax.swing.JPanel();
        jLabelphoto = new javax.swing.JLabel(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/turn.png")));
        jPanel2 = new javax.swing.JPanel();
        jPanelTurning = new javax.swing.JPanel();
        jLabelCage = new javax.swing.JLabel();
        jLabelNameFirst = new javax.swing.JLabel();
        jLabelTurnDate = new javax.swing.JLabel();
        jTextFieldTurnDate = new javax.swing.JTextField();
        jLabelCage3 = new javax.swing.JLabel();
        jComboBoxPerson = new javax.swing.JComboBox<>();
        jButtonBirthDate3 =  new DateChooserJButtonJDialog (jTextFieldTurnDate);
        jLabelCage1 = new javax.swing.JLabel();
        jLabelCage2 = new javax.swing.JLabel();
        jTextFieldWeight = new javax.swing.JTextField();
        jTextFieldTotalNumber = new javax.swing.JTextField();
        jTextFieldTotalMoeny = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanelFirst1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanelFirst.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabelNumber.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jLabelNumber.setForeground(new java.awt.Color(0, 0, 102));
        jLabelNumber.setText("个体编号：");

        jTextFieldNumber.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jTextFieldNumber.setForeground(new java.awt.Color(0, 0, 102));
        jTextFieldNumber.setPreferredSize(new java.awt.Dimension(135, 25));

        jLabelBirthDate.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jLabelBirthDate.setForeground(new java.awt.Color(0, 0, 102));
        jLabelBirthDate.setText("出生日期：");

        jTextFieldBirthDate1.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextFieldBirthDate1.setForeground(new java.awt.Color(0, 0, 102));
        jTextFieldBirthDate1.setMinimumSize(new java.awt.Dimension(88, 25));
        jTextFieldBirthDate1.setPreferredSize(new java.awt.Dimension(88, 25));

        jLabel4.setText("----");

        jTextFieldBirthDate2.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextFieldBirthDate2.setForeground(new java.awt.Color(0, 0, 102));
        jTextFieldBirthDate2.setPreferredSize(new java.awt.Dimension(88, 25));

        jButtonBirthDate1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N

        jButtonBirthDate2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButtonBirthDate2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBirthDate2ActionPerformed(evt);
            }
        });

        jComboBoxR_cage.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jComboBoxR_cage.setForeground(new java.awt.Color(0, 0, 102));
        jComboBoxR_cage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "全部舍", " " }));
        jComboBoxR_cage.setPreferredSize(new java.awt.Dimension(122, 28));
        jComboBoxR_cage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxR_cageActionPerformed(evt);
            }
        });

        jComboBoxR_pcage.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jComboBoxR_pcage.setForeground(new java.awt.Color(0, 0, 102));
        jComboBoxR_pcage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "全部栏" }));
        jComboBoxR_pcage.setPreferredSize(new java.awt.Dimension(122, 28));
        jComboBoxR_pcage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxR_pcageActionPerformed(evt);
            }
        });

        jButtonSelect.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jButtonSelect.setForeground(new java.awt.Color(0, 0, 102));
        jButtonSelect.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/查询L.png"))); // NOI18N
        jButtonSelect.setText("查询");
        jButtonSelect.setMaximumSize(new java.awt.Dimension(87, 33));
        jButtonSelect.setMinimumSize(new java.awt.Dimension(87, 33));
        jButtonSelect.setPreferredSize(new java.awt.Dimension(98, 33));
        jButtonSelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSelectActionPerformed(evt);
            }
        });

        jButtonReset.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jButtonReset.setForeground(new java.awt.Color(0, 0, 102));
        jButtonReset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/重置记录.png"))); // NOI18N
        jButtonReset.setText("重置");
        jButtonReset.setPreferredSize(new java.awt.Dimension(98, 33));
        jButtonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonResetActionPerformed(evt);
            }
        });

        jComboBoxPigStatue.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jComboBoxPigStatue.setForeground(new java.awt.Color(0, 0, 102));
        jComboBoxPigStatue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪只状态", "哺乳仔猪", "生长猪", "保育猪", " " }));

        jLabel46.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 0, 0));
        jLabel46.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息处理");

        javax.swing.GroupLayout jPanelFirstLayout = new javax.swing.GroupLayout(jPanelFirst);
        jPanelFirst.setLayout(jPanelFirstLayout);
        jPanelFirstLayout.setHorizontalGroup(
            jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFirstLayout.createSequentialGroup()
                .addGroup(jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelFirstLayout.createSequentialGroup()
                        .addComponent(jLabel46)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelFirstLayout.createSequentialGroup()
                        .addGap(0, 23, Short.MAX_VALUE)
                        .addComponent(jLabelNumber)
                        .addGap(6, 6, 6)
                        .addComponent(jTextFieldNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxPigStatue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelBirthDate)
                        .addGap(6, 6, 6)
                        .addComponent(jButtonBirthDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jTextFieldBirthDate1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jButtonBirthDate2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jTextFieldBirthDate2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBoxR_cage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxR_pcage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonSelect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonReset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(5, 5, 5))
        );
        jPanelFirstLayout.setVerticalGroup(
            jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelFirstLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanelFirstLayout.createSequentialGroup()
                        .addComponent(jLabel46)
                        .addGroup(jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelFirstLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButtonSelect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanelFirstLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelBirthDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextFieldNumber, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabelNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jComboBoxPigStatue, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jTextFieldBirthDate1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4))
                                    .addComponent(jButtonBirthDate1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButtonBirthDate2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanelFirstLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanelFirstLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextFieldBirthDate2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBoxR_cage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBoxR_pcage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButtonReset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanelFirst1Layout = new javax.swing.GroupLayout(jPanelFirst1);
        jPanelFirst1.setLayout(jPanelFirst1Layout);
        jPanelFirst1Layout.setHorizontalGroup(
            jPanelFirst1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFirst1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelFirst, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanelFirst1Layout.setVerticalGroup(
            jPanelFirst1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFirst1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanelFirst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        jTable1.setFont(new java.awt.Font("楷体", 0, 12)); // NOI18N
        jTable1.getTableHeader().setResizingAllowed(false);
        jScrollPaneDisplay.setViewportView(jTable1);

        jDesktopPaneTurningDisplay.setLayer(jScrollPaneDisplay, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPaneTurningDisplayLayout = new javax.swing.GroupLayout(jDesktopPaneTurningDisplay);
        jDesktopPaneTurningDisplay.setLayout(jDesktopPaneTurningDisplayLayout);
        jDesktopPaneTurningDisplayLayout.setHorizontalGroup(
            jDesktopPaneTurningDisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPaneTurningDisplayLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jScrollPaneDisplay))
        );
        jDesktopPaneTurningDisplayLayout.setVerticalGroup(
            jDesktopPaneTurningDisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneDisplay, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        jPanel01.setMinimumSize(new java.awt.Dimension(89, 40));
        jPanel01.setPreferredSize(new java.awt.Dimension(89, 40));

        jLabel1.setFont(new java.awt.Font("宋体", 0, 13)); // NOI18N
        jLabel1.setText("总记录数：");
        jPanel01.add(jLabel1);

        TotalRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        TotalRecFld.setForeground(new java.awt.Color(255, 0, 255));
        TotalRecFld.setText("0");
        jPanel01.add(TotalRecFld);

        jPanel02.setMinimumSize(new java.awt.Dimension(127, 40));
        jPanel02.setPreferredSize(new java.awt.Dimension(127, 40));

        jLabel3.setFont(new java.awt.Font("宋体", 0, 13)); // NOI18N
        jLabel3.setText("当前记录：");
        jPanel02.add(jLabel3);

        BeginRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        BeginRecFld.setForeground(new java.awt.Color(255, 0, 255));
        BeginRecFld.setText("0");
        jPanel02.add(BeginRecFld);

        jLabel19.setText("-");
        jPanel02.add(jLabel19);

        EndRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        EndRecFld.setForeground(new java.awt.Color(255, 0, 255));
        EndRecFld.setText("0");
        jPanel02.add(EndRecFld);

        jPanel03.setMinimumSize(new java.awt.Dimension(91, 40));
        jPanel03.setPreferredSize(new java.awt.Dimension(91, 40));

        jLabel20.setFont(new java.awt.Font("宋体", 0, 13)); // NOI18N
        jLabel20.setText("页数：");
        jPanel03.add(jLabel20);

        NowPageFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        NowPageFld.setForeground(new java.awt.Color(255, 0, 255));
        NowPageFld.setText("0");
        jPanel03.add(NowPageFld);

        jLabel6.setText("/");
        jPanel03.add(jLabel6);

        MaxpageFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        MaxpageFld.setForeground(new java.awt.Color(255, 0, 255));
        MaxpageFld.setText("0");
        jPanel03.add(MaxpageFld);

        FirstBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_first.png"))); // NOI18N
        FirstBtn.setToolTipText("首页");
        FirstBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        FirstBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstBtnActionPerformed(evt);
            }
        });
        jPanel04.add(FirstBtn);

        PrevBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_previous.png"))); // NOI18N
        PrevBtn.setToolTipText("上页");
        PrevBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        PrevBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrevBtnActionPerformed(evt);
            }
        });
        jPanel04.add(PrevBtn);

        NextBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_next.png"))); // NOI18N
        NextBtn.setToolTipText("下页");
        NextBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        NextBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextBtnActionPerformed(evt);
            }
        });
        jPanel04.add(NextBtn);

        LastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_last.png"))); // NOI18N
        LastBtn.setToolTipText("尾页");
        LastBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        LastBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LastBtnActionPerformed(evt);
            }
        });
        jPanel04.add(LastBtn);
        jPanel04.add(jSeparator1);

        jPanel4.setMinimumSize(new java.awt.Dimension(70, 40));
        jPanel4.setPreferredSize(new java.awt.Dimension(109, 40));

        jTextField1.setFont(new java.awt.Font("宋体", 0, 13)); // NOI18N
        jTextField1.setText("第几页");
        jTextField1.setMinimumSize(new java.awt.Dimension(6, 5));
        jTextField1.setPreferredSize(new java.awt.Dimension(45, 21));
        jPanel4.add(jTextField1);

        GO.setFont(new java.awt.Font("宋体", 0, 13)); // NOI18N
        GO.setForeground(new java.awt.Color(255, 0, 255));
        GO.setText("GO");
        GO.setMaximumSize(new java.awt.Dimension(45, 25));
        GO.setMinimumSize(new java.awt.Dimension(45, 25));
        GO.setPreferredSize(new java.awt.Dimension(45, 25));
        GO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GOActionPerformed(evt);
            }
        });
        jPanel4.add(GO);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(83, Short.MAX_VALUE)
                .addComponent(jPanel01, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(jPanel02, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel03, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel01, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel02, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel03, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel04, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout jPanelDisplayLayout = new javax.swing.GroupLayout(jPanelDisplay);
        jPanelDisplay.setLayout(jPanelDisplayLayout);
        jPanelDisplayLayout.setHorizontalGroup(
            jPanelDisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelDisplayLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jDesktopPaneTurningDisplay))
        );
        jPanelDisplayLayout.setVerticalGroup(
            jPanelDisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDisplayLayout.createSequentialGroup()
                .addComponent(jDesktopPaneTurningDisplay)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jCheckBoxAll.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jCheckBoxAll.setForeground(new java.awt.Color(255, 51, 51));
        jCheckBoxAll.setText("全选当前");
        jCheckBoxAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxAllActionPerformed(evt);
            }
        });

        jButtonTurningReset.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButtonTurningReset.setForeground(new java.awt.Color(0, 0, 102));
        jButtonTurningReset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/重置L.png"))); // NOI18N
        jButtonTurningReset.setText("刷新页面");
        jButtonTurningReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTurningResetActionPerformed(evt);
            }
        });

        jButtonTurningDetial.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButtonTurningDetial.setForeground(new java.awt.Color(0, 0, 102));
        jButtonTurningDetial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/详细信息L.png"))); // NOI18N
        jButtonTurningDetial.setText("详细信息");
        jButtonTurningDetial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTurningDetialActionPerformed(evt);
            }
        });

        jButtonTurningOut.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButtonTurningOut.setForeground(new java.awt.Color(0, 0, 102));
        jButtonTurningOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButtonTurningOut.setText("退出销售");
        jButtonTurningOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTurningOutActionPerformed(evt);
            }
        });

        jButtonTurningContinue.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButtonTurningContinue.setForeground(new java.awt.Color(0, 0, 102));
        jButtonTurningContinue.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/添加记录.png"))); // NOI18N
        jButtonTurningContinue.setText("连续销售");
        jButtonTurningContinue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTurningContinueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelOperationLayout = new javax.swing.GroupLayout(jPanelOperation);
        jPanelOperation.setLayout(jPanelOperationLayout);
        jPanelOperationLayout.setHorizontalGroup(
            jPanelOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelOperationLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jCheckBoxAll, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonTurningContinue)
                .addGap(18, 18, 18)
                .addComponent(jButtonTurningDetial, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonTurningReset)
                .addGap(18, 18, 18)
                .addComponent(jButtonTurningOut)
                .addGap(29, 29, 29))
        );
        jPanelOperationLayout.setVerticalGroup(
            jPanelOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelOperationLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanelOperationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonTurningDetial, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonTurningOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonTurningContinue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonTurningReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jCheckBoxAll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        //注意这里是关键，将背景图标签添加到jframe的LayeredPane面板里
        //jLabelphoto.setVisible(false);
        jPanelPhoto.add(jLabelphoto,new Integer(Integer.MIN_VALUE));
        jLabelphoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/turn.png"))); // NOI18N

        javax.swing.GroupLayout jPanelPhotoLayout = new javax.swing.GroupLayout(jPanelPhoto);
        jPanelPhoto.setLayout(jPanelPhotoLayout);
        jPanelPhotoLayout.setHorizontalGroup(
            jPanelPhotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelphoto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanelPhotoLayout.setVerticalGroup(
            jPanelPhotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelPhotoLayout.createSequentialGroup()
                .addGap(0, 72, Short.MAX_VALUE)
                .addComponent(jLabelphoto, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        jLabelCage.setFont(new java.awt.Font("宋体", 1, 16));
        jLabelCage.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jLabelCage.setForeground(new java.awt.Color(0, 0, 102));
        jLabelCage.setText("销售重量：");

        jLabelNameFirst.setFont(new java.awt.Font("微软雅黑", 1, 17)); // NOI18N
        jLabelNameFirst.setForeground(new java.awt.Color(0, 0, 102));
        jLabelNameFirst.setText("销售信息选择");

        jLabelTurnDate.setFont(new java.awt.Font("宋体", 1, 16));
        jLabelTurnDate.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jLabelTurnDate.setForeground(new java.awt.Color(0, 0, 102));
        jLabelTurnDate.setText("销售日期：");

        jTextFieldTurnDate.setText(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        jTextFieldTurnDate.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextFieldTurnDate.setForeground(new java.awt.Color(0, 0, 102));

        jLabelCage3.setFont(new java.awt.Font("宋体", 1, 16));
        jLabelCage3.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jLabelCage3.setForeground(new java.awt.Color(0, 0, 102));
        jLabelCage3.setText("负 责 人：");

        jComboBoxPerson.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jComboBoxPerson.setForeground(new java.awt.Color(0, 0, 102));
        jComboBoxPerson.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "张三", "李四" }));
        jComboBoxPerson.setToolTipText("");

        jButtonBirthDate3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButtonBirthDate3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBirthDate3ActionPerformed(evt);
            }
        });

        jLabelCage1.setFont(new java.awt.Font("宋体", 1, 16));
        jLabelCage1.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jLabelCage1.setForeground(new java.awt.Color(0, 0, 102));
        jLabelCage1.setText("销售个数：");

        jLabelCage2.setFont(new java.awt.Font("宋体", 1, 16));
        jLabelCage2.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jLabelCage2.setForeground(new java.awt.Color(0, 0, 102));
        jLabelCage2.setText("销售金额：");

        jTextFieldWeight.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextFieldWeight.setForeground(new java.awt.Color(0, 0, 102));

        jTextFieldTotalNumber.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextFieldTotalNumber.setForeground(new java.awt.Color(0, 0, 102));
        jTextFieldTotalNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldTotalNumberFocusGained(evt);
            }
        });
        jTextFieldTotalNumber.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextFieldTotalNumberMouseClicked(evt);
            }
        });

        jTextFieldTotalMoeny.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextFieldTotalMoeny.setForeground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanelTurningLayout = new javax.swing.GroupLayout(jPanelTurning);
        jPanelTurning.setLayout(jPanelTurningLayout);
        jPanelTurningLayout.setHorizontalGroup(
            jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTurningLayout.createSequentialGroup()
                .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelTurningLayout.createSequentialGroup()
                        .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelCage)
                            .addComponent(jLabelTurnDate)
                            .addComponent(jLabelCage2))
                        .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelTurningLayout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jButtonBirthDate3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanelTurningLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jTextFieldTotalMoeny, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldWeight, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanelTurningLayout.createSequentialGroup()
                            .addComponent(jLabelCage3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jComboBoxPerson, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(jTextFieldTurnDate, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelTurningLayout.createSequentialGroup()
                                .addComponent(jLabelCage1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextFieldTotalNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabelNameFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanelTurningLayout.setVerticalGroup(
            jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTurningLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelNameFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48)
                .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanelTurningLayout.createSequentialGroup()
                        .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelCage, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldWeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelCage2, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldTotalMoeny, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelCage1, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldTotalNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelTurnDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonBirthDate3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jTextFieldTurnDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(jPanelTurningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCage3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxPerson, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanelDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanelPhoto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(jPanelTurning, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanelOperation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanelFirst1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanelFirst1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanelPhoto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanelTurning, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanelDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addComponent(jPanelOperation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxR_pcageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxR_pcageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxR_pcageActionPerformed

    private void jButtonSelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSelectActionPerformed

        //快速查询
        String pzzt = JComboBoxString(jComboBoxPigStatue);
        if (pzzt.equals("猪只状态")) {
            pzzt = "%";
        }
        else
        {
            pzzt = swintypeNametoIdSmap.get(JComboBoxString(jComboBoxPigStatue));
        }

        String num = jTextFieldNumber.getText();
        String fenceid = JComboBoxString(jComboBoxR_pcage);
        String startDate = jTextFieldBirthDate1.getText();
        String endDate = jTextFieldBirthDate2.getText();
        jTable1.clearSelection();
        fenceid = SsFence(fenceid, jComboBoxR_cage);
        if (startDate.equals("")) {
            startDate = "1990-01-01";
        }
        if (endDate.equals("")) {
            endDate = "2090-01-01";
        }
        PigMapperPlus02 pigImmuneMapperPlus02 = new PigMapperPlus02();
        pigSalePageModel02 = new PigPageModel02(15, pigImmuneMapperPlus02.pigImmuneSelectSearchByCount02(num, fenceid, startDate, endDate, pzzt), pigImmuneMapperPlus02, true);
        pigSalePlus02(1);
    }//GEN-LAST:event_jButtonSelectActionPerformed
    public static void pigSalePlus02(int pagenum) {
        temp = new ArrayList<>();
        pigSalePageModel02.setPageNo(pagenum);
        temp = pigSalePageModel02.getNoList();
        Object[][] tableModel = new Object[temp.size()][6];
        for (int j = 0; j < temp.size(); j++) {
            tableModel[j][0] = false;
            tableModel[j][1] = temp.get(j).getR_animal();
            tableModel[j][2] = swintypeIdtoNameSmap.get((String) temp.get(j).getR_curmark());
            tableModel[j][3] = temp.get(j).getR_fdate();
            tableModel[j][4] = piggeryIdtoNameSmap.get(temp.get(j).getR_cage());
            tableModel[j][5] = fenceIdtoNameSmap.get(temp.get(j).getR_pcage());
        }
        String[] tableHeade = {"复选框", "个体号", "当前状态", "出生日期", "当前舍栏", "当前栏位"};
        String title1 = "生长育肥猪查询";
        closeListplus(tableModel, tableHeade, title1);

    }

    public static void closeListplus(Object[][] tableModel, String[] tableHead, String title) {
        TotalRecFld.setText(String.valueOf(PigSale02.pigSalePageModel02.getTotalRecords()));
        MaxpageFld.setText(String.valueOf(PigSale02.pigSalePageModel02.getBottomPageNo()));
        NowPageFld.setText(String.valueOf(PigSale02.pigSalePageModel02.getPageNo()));
        jTextField1.setText(String.valueOf(PigSale02.pigSalePageModel02.getPageNo()));
        BeginRecFld.setText(String.valueOf(PigSale02.pigSalePageModel02.getPageNoRecordBegin()));
        EndRecFld.setText(String.valueOf(PigSale02.pigSalePageModel02.getPageNoRecordEnd()));
        jTable1.setFont(new java.awt.Font("宋体", 0, 15));
        jTable1.setModel(new MyTable(tableModel, tableHead));
        setJTableRow(jTable1);
        jScrollPaneDisplay.setViewportView(jTable1);
        System.gc();
    }
    private void jButtonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonResetActionPerformed

    }//GEN-LAST:event_jButtonResetActionPerformed

    private void jButtonTurningResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTurningResetActionPerformed

    }//GEN-LAST:event_jButtonTurningResetActionPerformed

    private void jButtonTurningDetialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTurningDetialActionPerformed
        TableModel model = jTable1.getModel();
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow != -1) {
            String lineid = (String) model.getValueAt(selectedRow, 1);
            Selebith selebith = null;
            for (int i = 0; i < temp.size(); i++) {
                selebith = temp.get(i);
                if (selebith.getR_animal().equals(lineid)) {
                    DetailedApp detailApp = new DetailedApp(selebith.getR_animal(), this, true);
                    detailApp.setVisible(true);
                    break;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "请选择一个要查询的数据项", "提示", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButtonTurningDetialActionPerformed

    private void jButtonTurningOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTurningOutActionPerformed
        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButtonTurningOutActionPerformed

    private void jButtonTurningContinueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTurningContinueActionPerformed
        // TODO add your handling code here:
        //判断是否选择了数据
        //选择了数据才能销售 
        if (!jTextFieldWeight.getText().equals("") && !jTextFieldTotalMoeny.getText().equals("")
                && !jTextFieldTotalNumber.getText().equals("") && !jTextFieldTurnDate.getText().equals("")) {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            //1.修改个体信息表
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            //2.添加信息到销售表
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            Zzxs zzxs = new Zzxs();
            StringBuffer sb = new StringBuffer();
            HashMap map = new HashMap<String, Integer>();
            List<String> fencetemp = new ArrayList<>();
            StringBuffer sb2 = new StringBuffer();
            for (int row = 0; row < jTable1.getRowCount(); row++) {
                if ((boolean) jTable1.getValueAt(row, 0)) {
                    jTableFlag = true;
                    //1.修改个体信息表
                    selebithMapper.updateZT(swintypeNametoIdSmap.get("销售"), (String) jTable1.getValueAt(row, 1), jTextFieldTurnDate.getText());
                    //2.1将选中的所有id合并
                    sb.append((String) jTable1.getValueAt(row, 1)).append(",");
                    if (map.get((String) jTable1.getValueAt(row, 4) + "-" + (String) jTable1.getValueAt(row, 5)) == null) {
                        map.put((String) jTable1.getValueAt(row, 4) + "-" + (String) jTable1.getValueAt(row, 5), 1);
                        fencetemp.add((String) jTable1.getValueAt(row, 4) + "-" + (String) jTable1.getValueAt(row, 5));
                    } else {
                        map.put((String) jTable1.getValueAt(row, 4) + "-" + (String) jTable1.getValueAt(row, 5), (Integer) map.get((String) jTable1.getValueAt(row, 4) + "-" + (String) jTable1.getValueAt(row, 5)) + 1);
                    }
                    sqlSession.commit();
                }
            }
            for (int i = 0; i < fencetemp.size(); i++) {
                sb2.append(fencetemp.get(i)).append("(").append(map.get(fencetemp.get(i))).append("),");
            }
            //2.2存入数据表  
            zzxs.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBoxPerson)));//负责人
            zzxs.setXsgs(Integer.parseInt(jTextFieldTotalNumber.getText()));//销售个数
            zzxs.setZzzl(Double.parseDouble(jTextFieldWeight.getText()));//猪只重量
            zzxs.setXsrq(jTextFieldTurnDate.getText());//销售日期
            zzxs.setXsje(Double.parseDouble(jTextFieldTotalMoeny.getText()));//销售金额
            String str = sb.substring(0, sb.length() - 1);
            String str2 = sb2.substring(0, sb2.length() - 1);
            zzxs.setBz1(str);//备注
            zzxs.setBz2(str2);//备注

            zzxsMapper.insert(zzxs);//数据存入
            sqlSession.commit();
            sqlSession.close();
            if (jTableFlag) {
                JOptionPane.showMessageDialog(null, "销售成功", "提示", JOptionPane.INFORMATION_MESSAGE);
                //更新当前猪只信息
                PigMapperPlus02 pigSaleMapperPlus02 = new PigMapperPlus02();
                pigSalePageModel02 = new PigPageModel02(15, pigSaleMapperPlus02.SelectCountSale02(), pigSaleMapperPlus02, false);
                pigSalePlus02(1);
                //更新MainApp中所猪只免疫信息
                MainApp.zzxsPageModel = new ZzxsPageModel(14, zzxsMapperPlus.SelectCount(), zzxsMapperPlus, false);
                Zzxspage(1);

            }
        } else {
            JOptionPane.showMessageDialog(null, "销售失败", "提示", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButtonTurningContinueActionPerformed

    private void jCheckBoxAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxAllActionPerformed
        // TODO add your handling code here:
        //全选事件
        int jiShu = 0;
        for (int row = 0; row < jTable1.getRowCount(); row++) {
            if (jCheckBoxAll.isSelected()) {
                jTable1.setValueAt(true, row, 0);
                jiShu++;
            } else {
                jTable1.setValueAt(false, row, 0);
            }
        }

    }//GEN-LAST:event_jCheckBoxAllActionPerformed

    private void FirstBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FirstBtnActionPerformed
        PigSale02.pigSalePlus02(PigSale02.pigSalePageModel02.getTopPageNo());
    }//GEN-LAST:event_FirstBtnActionPerformed

    private void PrevBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrevBtnActionPerformed
        PigSale02.pigSalePlus02(PigSale02.pigSalePageModel02.getPreviousPageNo());
    }//GEN-LAST:event_PrevBtnActionPerformed

    private void NextBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextBtnActionPerformed
        PigSale02.pigSalePlus02(PigSale02.pigSalePageModel02.getNextPageNo());
    }//GEN-LAST:event_NextBtnActionPerformed

    private void LastBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LastBtnActionPerformed
        PigSale02.pigSalePlus02(PigSale02.pigSalePageModel02.getBottomPageNo());
    }//GEN-LAST:event_LastBtnActionPerformed

    private void GOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GOActionPerformed
        PigSale02.pigSalePlus02(Integer.parseInt(jTextField1.getText()));
    }//GEN-LAST:event_GOActionPerformed

    private void jButtonBirthDate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBirthDate2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonBirthDate2ActionPerformed

    private void jComboBoxR_cageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxR_cageActionPerformed
        // TODO add your handling code here:
        String name = JComboBoxString(jComboBoxR_cage);
        String id = null;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PiggeryMapper mapper5 = sqlSession.getMapper(PiggeryMapper.class);
            piggery = mapper5.selectAll();
        }
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        List<Fence> fence;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
            fence = mapper6.selectAllById(id);
        }
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        if (name.equals("全部舍")) {
            things6 = new String[1];
            things6[0] = "全部栏";
        }
        jComboBoxR_pcage.removeAll();
        jComboBoxR_pcage.setModel(new javax.swing.DefaultComboBoxModel(things6));

    }//GEN-LAST:event_jComboBoxR_cageActionPerformed

    private void jButtonBirthDate3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBirthDate3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonBirthDate3ActionPerformed

    private void jTextFieldTotalNumberMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldTotalNumberMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_jTextFieldTotalNumberMouseClicked

    private void jTextFieldTotalNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldTotalNumberFocusGained
        //统计销售条数
        int jiShu = 0;
        for (int row = 0; row < jTable1.getRowCount(); row++) {
            if ((boolean) jTable1.getValueAt(row, 0) == true) {
                jiShu++;
            }
        }
        jTextFieldTotalNumber.setText(String.valueOf(jiShu));        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldTotalNumberFocusGained

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JLabel BeginRecFld;
    private static javax.swing.JLabel EndRecFld;
    public static javax.swing.JButton FirstBtn;
    private javax.swing.JButton GO;
    public static javax.swing.JButton LastBtn;
    private static javax.swing.JLabel MaxpageFld;
    public static javax.swing.JButton NextBtn;
    private static javax.swing.JLabel NowPageFld;
    public static javax.swing.JButton PrevBtn;
    private static javax.swing.JLabel TotalRecFld;
    private javax.swing.JButton jButtonBirthDate1;
    private javax.swing.JButton jButtonBirthDate2;
    private javax.swing.JButton jButtonBirthDate3;
    private javax.swing.JButton jButtonReset;
    private javax.swing.JButton jButtonSelect;
    private javax.swing.JButton jButtonTurningContinue;
    private javax.swing.JButton jButtonTurningDetial;
    private javax.swing.JButton jButtonTurningOut;
    private javax.swing.JButton jButtonTurningReset;
    private javax.swing.JCheckBox jCheckBoxAll;
    private javax.swing.JComboBox<String> jComboBoxPerson;
    private javax.swing.JComboBox<String> jComboBoxPigStatue;
    private javax.swing.JComboBox<String> jComboBoxR_cage;
    private javax.swing.JComboBox<String> jComboBoxR_pcage;
    private static javax.swing.JDesktopPane jDesktopPaneTurningDisplay;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabelBirthDate;
    private javax.swing.JLabel jLabelCage;
    private javax.swing.JLabel jLabelCage1;
    private javax.swing.JLabel jLabelCage2;
    private javax.swing.JLabel jLabelCage3;
    private static javax.swing.JLabel jLabelNameFirst;
    private javax.swing.JLabel jLabelNumber;
    private javax.swing.JLabel jLabelTurnDate;
    private javax.swing.JLabel jLabelphoto;
    private javax.swing.JPanel jPanel01;
    private javax.swing.JPanel jPanel02;
    private javax.swing.JPanel jPanel03;
    private javax.swing.JPanel jPanel04;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanelDisplay;
    private javax.swing.JPanel jPanelFirst;
    private javax.swing.JPanel jPanelFirst1;
    private javax.swing.JPanel jPanelOperation;
    private javax.swing.JPanel jPanelPhoto;
    private javax.swing.JPanel jPanelTurning;
    private static javax.swing.JScrollPane jScrollPaneDisplay;
    private javax.swing.JSeparator jSeparator1;
    private static javax.swing.JTable jTable1;
    private static javax.swing.JTextField jTextField1;
    public static javax.swing.JTextField jTextFieldBirthDate1;
    public static javax.swing.JTextField jTextFieldBirthDate2;
    private javax.swing.JTextField jTextFieldNumber;
    private javax.swing.JTextField jTextFieldTotalMoeny;
    private javax.swing.JTextField jTextFieldTotalNumber;
    public static javax.swing.JTextField jTextFieldTurnDate;
    private javax.swing.JTextField jTextFieldWeight;
    // End of variables declaration//GEN-END:variables
    private static final Logger LOG = Logger.getLogger(PigSale02.class.getName());

//    private void setMyVisible(boolean flag) {
//        jTextFieldTurnDate.setEnabled(flag);
//        jComboBoxPcage.setEnabled(flag);
//        jComboBoxCage.setEnabled(flag);
//        GO.setEnabled(flag);
//        FirstBtn.setEnabled(flag);
//        PrevBtn.setEnabled(flag);
//        NextBtn.setEnabled(flag);
//        LastBtn.setEnabled(flag);
//    }
}
