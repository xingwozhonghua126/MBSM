package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.utils.MyStaticMethod.setJTableRow;
import javax.swing.JTable;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/**
 *
 * @author Administrator
 */
public class VarietiesDataPlus extends javax.swing.JInternalFrame {

    private Object[][] tableModel;
    private String[] tableHead;

    public VarietiesDataPlus(Object[][] tableModel, String[] tableHead) {
        initComponents();
        this.tableModel = tableModel;
        this.tableHead = tableHead;
        ((BasicInternalFrameUI) getUI()).setNorthPane(null);
        if (MainApp.outsideLabel.equals("系谱数据")) {
            TotalRecFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("育种个体信息")) {
            TotalRecFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.yzgtxxPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("后备2月性状")) {
            TotalRecFld.setText(String.valueOf(MainApp.yzTwotestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.yzTwotestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.yzTwotestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.yzTwotestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.yzTwotestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.yzTwotestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("后备4月性状")) {
            TotalRecFld.setText(String.valueOf(MainApp.yzFourtestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.yzFourtestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.yzFourtestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.yzFourtestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.yzFourtestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.yzFourtestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("后备6月性状")) {
            TotalRecFld.setText(String.valueOf(MainApp.yzSixtestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.yzSixtestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.yzSixtestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.yzSixtestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.yzSixtestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.yzSixtestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("100kg测定性状")) {
            TotalRecFld.setText(String.valueOf(MainApp.yzHundredtestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.yzHundredtestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.yzHundredtestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.yzHundredtestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.yzHundredtestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.yzHundredtestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("个体基本信息")) {
            TotalRecFld.setText(String.valueOf(MainApp.selebithPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.selebithPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.selebithPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.selebithPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.selebithPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.selebithPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("公猪采精登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.takespermPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.takespermPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.takespermPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.takespermPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.takespermPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.takespermPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("母猪配种情况登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.breedingPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.breedingPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.breedingPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.breedingPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.breedingPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.breedingPageModel.getPageNoRecordEnd()));

        }
        if (MainApp.outsideLabel.equals("母猪分娩情况登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.childbirthPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.childbirthPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.childbirthPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.childbirthPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.childbirthPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.childbirthPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("母猪断奶登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.weaningPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.weaningPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.weaningPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.weaningPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.weaningPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.weaningPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("哺乳猪-保育猪")) {
            TotalRecFld.setText(String.valueOf(MainApp.feedingTurnConservationPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.feedingTurnConservationPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.feedingTurnConservationPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.feedingTurnConservationPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.feedingTurnConservationPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.feedingTurnConservationPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("保育猪-生长育肥猪")) {
            TotalRecFld.setText(String.valueOf(MainApp.conservationTurnFattingPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.conservationTurnFattingPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.conservationTurnFattingPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.conservationTurnFattingPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.conservationTurnFattingPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.conservationTurnFattingPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("保育猪-后备猪")) {
            TotalRecFld.setText(String.valueOf(MainApp.conservationTurnBackPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.conservationTurnBackPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.conservationTurnBackPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.conservationTurnBackPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.conservationTurnBackPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.conservationTurnBackPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("种公猪资料")) {
            TotalRecFld.setText(String.valueOf(MainApp.maleBoarPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.maleBoarPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.maleBoarPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.maleBoarPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.maleBoarPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.maleBoarPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("种母猪资料")) {
            TotalRecFld.setText(String.valueOf(MainApp.femaleBoarPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.femaleBoarPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.femaleBoarPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.femaleBoarPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.femaleBoarPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.femaleBoarPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("后备猪2月龄登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.twoTestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.twoTestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.twoTestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.twoTestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.twoTestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.twoTestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("后备猪4月龄登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.fourTestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.fourTestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.fourTestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.fourTestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.fourTestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.fourTestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("后备猪6月龄登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.sixTestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.sixTestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.sixTestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.sixTestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.sixTestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.sixTestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("100KG检测登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.hundredTestPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.hundredTestPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.hundredTestPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.hundredTestPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.hundredTestPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.hundredTestPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("饲料入库登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.slrkPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.slrkPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.slrkPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.slrkPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.slrkPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.slrkPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("饲料出库登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.slckPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.slckPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.slckPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.slckPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.slckPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.slckPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("药品入库登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.yprkPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.yprkPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.yprkPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.yprkPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.yprkPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.yprkPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("药品出库登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.ypckPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.ypckPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.ypckPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.ypckPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.ypckPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.ypckPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("疫苗入库登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.ymrkPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.ymrkPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.ymrkPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.ymrkPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.ymrkPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.ymrkPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("疫苗出库登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.ymckPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.ymckPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.ymckPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.ymckPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.ymckPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.ymckPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("猪只免疫登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.zzmyPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.zzmyPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.zzmyPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.zzmyPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.zzmyPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.zzmyPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("疾病治疗登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.jbzlPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.jbzlPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.jbzlPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.jbzlPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.jbzlPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.jbzlPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("基因检测登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.jyjcPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.jyjcPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.jyjcPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.jyjcPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.jyjcPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.jyjcPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("屠宰性能测定登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.tzxncdPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.tzxncdPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.tzxncdPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.tzxncdPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.tzxncdPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.tzxncdPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("猪只销售登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.zzxsPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.zzxsPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.zzxsPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.zzxsPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.zzxsPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.zzxsPageModel.getPageNoRecordEnd()));
        }
        if (MainApp.outsideLabel.equals("猪只死亡登记")) {
            TotalRecFld.setText(String.valueOf(MainApp.zzswPageModel.getTotalRecords()));
            MaxpageFld.setText(String.valueOf(MainApp.zzswPageModel.getBottomPageNo()));
            NowPageFld.setText(String.valueOf(MainApp.zzswPageModel.getPageNo()));
            jTextField1.setText(String.valueOf(MainApp.zzswPageModel.getPageNo()));
            BeginRecFld.setText(String.valueOf(MainApp.zzswPageModel.getPageNoRecordBegin()));
            EndRecFld.setText(String.valueOf(MainApp.zzswPageModel.getPageNoRecordEnd()));
        }
        jTable1.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        setJTableRow(jTable1);
    }

    /**
     * Creates new form VarietiesData
     */
    public VarietiesDataPlus() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jPanel01 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TotalRecFld = new javax.swing.JLabel();
        jPanel02 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        BeginRecFld = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        EndRecFld = new javax.swing.JLabel();
        jPanel03 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        NowPageFld = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        MaxpageFld = new javax.swing.JLabel();
        jPanel04 = new javax.swing.JPanel();
        FirstBtn = new javax.swing.JButton();
        PrevBtn = new javax.swing.JButton();
        NextBtn = new javax.swing.JButton();
        LastBtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel4 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        GO = new javax.swing.JButton();

        setBackground(new java.awt.Color(233, 242, 252));
        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setToolTipText("");
        setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        setPreferredSize(new java.awt.Dimension(1010, 536));

        jTable1.setFont(new java.awt.Font("楷体", 0, 16)); // NOI18N
        jTable1.setForeground(new java.awt.Color(0, 51, 102));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable1.getTableHeader().setResizingAllowed(false);
        jScrollPane1.setViewportView(jTable1);

        jPanel1.setBackground(new java.awt.Color(226, 238, 252));
        jPanel1.setPreferredSize(new java.awt.Dimension(891, 45));

        jPanel01.setBackground(new java.awt.Color(226, 238, 252));
        jPanel01.setMinimumSize(new java.awt.Dimension(89, 40));
        jPanel01.setPreferredSize(new java.awt.Dimension(89, 40));

        jLabel1.setText("总记录数：");
        jPanel01.add(jLabel1);

        TotalRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        TotalRecFld.setForeground(new java.awt.Color(255, 0, 255));
        TotalRecFld.setText("0");
        jPanel01.add(TotalRecFld);

        jPanel02.setBackground(new java.awt.Color(226, 238, 252));
        jPanel02.setMinimumSize(new java.awt.Dimension(127, 40));
        jPanel02.setPreferredSize(new java.awt.Dimension(127, 40));

        jLabel3.setText("当前记录：");
        jPanel02.add(jLabel3);

        BeginRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        BeginRecFld.setForeground(new java.awt.Color(255, 0, 255));
        BeginRecFld.setText("0");
        jPanel02.add(BeginRecFld);

        jLabel4.setText("-");
        jPanel02.add(jLabel4);

        EndRecFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        EndRecFld.setForeground(new java.awt.Color(255, 0, 255));
        EndRecFld.setText("0");
        jPanel02.add(EndRecFld);

        jPanel03.setBackground(new java.awt.Color(226, 238, 252));
        jPanel03.setMinimumSize(new java.awt.Dimension(91, 40));
        jPanel03.setPreferredSize(new java.awt.Dimension(91, 40));

        jLabel2.setText("页数：");
        jPanel03.add(jLabel2);

        NowPageFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        NowPageFld.setForeground(new java.awt.Color(255, 0, 255));
        NowPageFld.setText("0");
        jPanel03.add(NowPageFld);

        jLabel6.setText("/");
        jPanel03.add(jLabel6);

        MaxpageFld.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        MaxpageFld.setForeground(new java.awt.Color(255, 0, 255));
        MaxpageFld.setText("0");
        jPanel03.add(MaxpageFld);

        jPanel04.setBackground(new java.awt.Color(226, 238, 252));

        FirstBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_first.png"))); // NOI18N
        FirstBtn.setToolTipText("首页");
        FirstBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        FirstBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstBtnActionPerformed(evt);
            }
        });
        jPanel04.add(FirstBtn);

        PrevBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_previous.png"))); // NOI18N
        PrevBtn.setToolTipText("上页");
        PrevBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        PrevBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrevBtnActionPerformed(evt);
            }
        });
        jPanel04.add(PrevBtn);

        NextBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_next.png"))); // NOI18N
        NextBtn.setToolTipText("下页");
        NextBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        NextBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextBtnActionPerformed(evt);
            }
        });
        jPanel04.add(NextBtn);

        LastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/resultset_last.png"))); // NOI18N
        LastBtn.setToolTipText("尾页");
        LastBtn.setPreferredSize(new java.awt.Dimension(30, 25));
        LastBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LastBtnActionPerformed(evt);
            }
        });
        jPanel04.add(LastBtn);
        jPanel04.add(jSeparator1);

        jPanel4.setBackground(new java.awt.Color(226, 238, 252));
        jPanel4.setMinimumSize(new java.awt.Dimension(70, 40));
        jPanel4.setPreferredSize(new java.awt.Dimension(109, 40));

        jTextField1.setText("第几页");
        jTextField1.setMinimumSize(new java.awt.Dimension(6, 5));
        jTextField1.setPreferredSize(new java.awt.Dimension(45, 21));
        jPanel4.add(jTextField1);

        GO.setForeground(new java.awt.Color(255, 0, 255));
        GO.setText("GO");
        GO.setMaximumSize(new java.awt.Dimension(45, 25));
        GO.setMinimumSize(new java.awt.Dimension(45, 25));
        GO.setPreferredSize(new java.awt.Dimension(45, 25));
        GO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GOActionPerformed(evt);
            }
        });
        jPanel4.add(GO);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(137, Short.MAX_VALUE)
                .addComponent(jPanel01, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel02, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel03, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel01, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel02, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel03, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel04, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 994, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 468, Short.MAX_VALUE)
                .addGap(2, 2, 2)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void FirstBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FirstBtnActionPerformed
        if (MainApp.outsideLabel.equals("系谱数据")) {
            MainApp.Yzxppage(MainApp.yzgtxxPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("育种个体信息")) {
            MainApp.Yzgtxxpage(MainApp.yzgtxxPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("后备2月性状")) {
            MainApp.Yztwotestpage(MainApp.yzTwotestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("后备4月性状")) {
            MainApp.Yzfourtestpage(MainApp.yzFourtestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("后备6月性状")) {
            MainApp.Yzsixtestpage(MainApp.yzSixtestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("100kg测定性状")) {
            MainApp.Yzhundredtestpage(MainApp.yzHundredtestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("个体基本信息")) {
            MainApp.Selebithpage(MainApp.selebithPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("公猪采精登记")) {
            MainApp.Takespermpage(MainApp.takespermPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪配种情况登记")) {
            MainApp.Breedingpage(MainApp.breedingPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪分娩情况登记")) {
            MainApp.Childbirthpage(MainApp.childbirthPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("哺乳猪-保育猪")) {
            MainApp.FeedingTurnConservationPage(MainApp.feedingTurnConservationPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-生长育肥猪")) {
            MainApp.ConservationTurnFattingpage(MainApp.conservationTurnFattingPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-后备猪")) {
            MainApp.ConservationTurnBackpage(MainApp.conservationTurnBackPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪断奶登记")) {
            MainApp.Weaningpage(MainApp.weaningPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("种公猪资料")) {
            MainApp.MaleBoarpage(MainApp.maleBoarPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("种母猪资料")) {
            MainApp.FemaleBoarpage(MainApp.femaleBoarPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪2月龄登记")) {
            MainApp.TwoTestpage(MainApp.twoTestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪4月龄登记")) {
            MainApp.FourTestpage(MainApp.fourTestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪6月龄登记")) {
            MainApp.SixTestpage(MainApp.sixTestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("100KG检测登记")) {
            MainApp.HundredTestpage(MainApp.hundredTestPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料入库登记")) {
            MainApp.Slrkpage(MainApp.slrkPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料出库登记")) {
            MainApp.Slckpage(MainApp.slckPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("药品入库登记")) {
            MainApp.Yprkpage(MainApp.yprkPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("药品出库登记")) {
            MainApp.Ypckpage(MainApp.ypckPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗入库登记")) {
            MainApp.Ymrkpage(MainApp.ymrkPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗出库登记")) {
            MainApp.Ymckpage(MainApp.ymckPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只免疫登记")) {
            MainApp.Zzmypage(MainApp.zzmyPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("疾病治疗登记")) {
            MainApp.Jbzlpage(MainApp.jbzlPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("基因检测登记")) {
            MainApp.Jyjcpage(MainApp.jyjcPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("屠宰性能测定登记")) {
            MainApp.Tzxncdpage(MainApp.tzxncdPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只销售登记")) {
            MainApp.Zzxspage(MainApp.zzxsPageModel.getTopPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只死亡登记")) {
            MainApp.Zzswpage(MainApp.zzswPageModel.getTopPageNo());
        }

    }//GEN-LAST:event_FirstBtnActionPerformed

    private void PrevBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrevBtnActionPerformed

        if (MainApp.outsideLabel.equals("系谱数据")) {
            MainApp.Yzxppage(MainApp.yzgtxxPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("育种个体信息")) {
            MainApp.Yzgtxxpage(MainApp.yzgtxxPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("后备2月性状")) {
            MainApp.Yztwotestpage(MainApp.yzTwotestPageModel.getPreviousPageNo());
        }

        if (MainApp.outsideLabel.equals("后备4月性状")) {
            MainApp.Yzfourtestpage(MainApp.yzFourtestPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("后备6月性状")) {
            MainApp.Yzsixtestpage(MainApp.yzSixtestPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("100kg测定性状")) {
            MainApp.Yzhundredtestpage(MainApp.yzHundredtestPageModel.getPreviousPageNo());
        }

        if (MainApp.outsideLabel.equals("个体基本信息")) {
            MainApp.Selebithpage(MainApp.selebithPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("公猪采精登记")) {
            MainApp.Takespermpage(MainApp.takespermPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪配种情况登记")) {
            MainApp.Breedingpage(MainApp.breedingPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪分娩情况登记")) {
            MainApp.Childbirthpage(MainApp.childbirthPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("哺乳猪-保育猪")) {
            MainApp.FeedingTurnConservationPage(MainApp.feedingTurnConservationPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-生长育肥猪")) {
            MainApp.ConservationTurnFattingpage(MainApp.conservationTurnFattingPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-后备猪")) {
            MainApp.ConservationTurnBackpage(MainApp.conservationTurnBackPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪断奶登记")) {
            MainApp.Weaningpage(MainApp.weaningPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("种公猪资料")) {
            MainApp.MaleBoarpage(MainApp.maleBoarPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("种母猪资料")) {
            MainApp.FemaleBoarpage(MainApp.femaleBoarPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪2月龄登记")) {
            MainApp.TwoTestpage(MainApp.twoTestPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪4月龄登记")) {
            MainApp.FourTestpage(MainApp.fourTestPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪6月龄登记")) {
            MainApp.SixTestpage(MainApp.sixTestPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("100KG检测登记")) {
            MainApp.HundredTestpage(MainApp.hundredTestPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料入库登记")) {
            MainApp.Slrkpage(MainApp.slrkPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料出库登记")) {
            MainApp.Slckpage(MainApp.slckPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("药品入库登记")) {
            MainApp.Yprkpage(MainApp.yprkPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("药品出库登记")) {
            MainApp.Ypckpage(MainApp.ypckPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗入库登记")) {
            MainApp.Ymrkpage(MainApp.ymrkPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗出库登记")) {
            MainApp.Ymckpage(MainApp.ymckPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只免疫登记")) {
            MainApp.Zzmypage(MainApp.zzmyPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("疾病治疗登记")) {
            MainApp.Jbzlpage(MainApp.jbzlPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("基因检测登记")) {
            MainApp.Jyjcpage(MainApp.jyjcPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("屠宰性能测定登记")) {
            MainApp.Tzxncdpage(MainApp.tzxncdPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只销售登记")) {
            MainApp.Zzxspage(MainApp.zzxsPageModel.getPreviousPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只死亡登记")) {
            MainApp.Zzswpage(MainApp.zzswPageModel.getPreviousPageNo());
        }
    }//GEN-LAST:event_PrevBtnActionPerformed

    private void NextBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextBtnActionPerformed
        if (MainApp.outsideLabel.equals("系谱数据")) {
            MainApp.Yzxppage(MainApp.yzgtxxPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("育种个体信息")) {
            MainApp.Yzgtxxpage(MainApp.yzgtxxPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("后备2月性状")) {
            MainApp.Yztwotestpage(MainApp.yzTwotestPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("后备4月性状")) {
            MainApp.Yzfourtestpage(MainApp.yzFourtestPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("后备6月性状")) {
            MainApp.Yzsixtestpage(MainApp.yzSixtestPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("100kg测定性状")) {
            MainApp.Yzhundredtestpage(MainApp.yzHundredtestPageModel.getNextPageNo());
        }

        if (MainApp.outsideLabel.equals("个体基本信息")) {
            MainApp.Selebithpage(MainApp.selebithPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("公猪采精登记")) {
            MainApp.Takespermpage(MainApp.takespermPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪配种情况登记")) {
            MainApp.Breedingpage(MainApp.breedingPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪分娩情况登记")) {
            MainApp.Childbirthpage(MainApp.childbirthPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("哺乳猪-保育猪")) {
            MainApp.FeedingTurnConservationPage(MainApp.feedingTurnConservationPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-生长育肥猪")) {
            MainApp.ConservationTurnFattingpage(MainApp.conservationTurnFattingPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-后备猪")) {
            MainApp.ConservationTurnBackpage(MainApp.conservationTurnBackPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪断奶登记")) {
            MainApp.Weaningpage(MainApp.weaningPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("种公猪资料")) {
            MainApp.MaleBoarpage(MainApp.maleBoarPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("种母猪资料")) {
            MainApp.FemaleBoarpage(MainApp.femaleBoarPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪2月龄登记")) {
            MainApp.TwoTestpage(MainApp.twoTestPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪4月龄登记")) {
            MainApp.FourTestpage(MainApp.fourTestPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪6月龄登记")) {
            MainApp.SixTestpage(MainApp.sixTestPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("100KG检测登记")) {
            MainApp.HundredTestpage(MainApp.hundredTestPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料入库登记")) {
            MainApp.Slrkpage(MainApp.slrkPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料出库登记")) {
            MainApp.Slckpage(MainApp.slckPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("药品入库登记")) {
            MainApp.Yprkpage(MainApp.yprkPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("药品出库登记")) {
            MainApp.Ypckpage(MainApp.ypckPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗入库登记")) {
            MainApp.Ymrkpage(MainApp.ymrkPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗出库登记")) {
            MainApp.Ymckpage(MainApp.ymckPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只免疫登记")) {
            MainApp.Zzmypage(MainApp.zzmyPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("疾病治疗登记")) {
            MainApp.Jbzlpage(MainApp.jbzlPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("基因检测登记")) {
            MainApp.Jyjcpage(MainApp.jyjcPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("屠宰性能测定登记")) {
            MainApp.Tzxncdpage(MainApp.tzxncdPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只销售登记")) {
            MainApp.Zzxspage(MainApp.zzxsPageModel.getNextPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只死亡登记")) {
            MainApp.Zzswpage(MainApp.zzswPageModel.getNextPageNo());
        }
    }//GEN-LAST:event_NextBtnActionPerformed

    private void LastBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LastBtnActionPerformed
        if (MainApp.outsideLabel.equals("系谱数据")) {
            MainApp.Yzxppage(MainApp.yzgtxxPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("育种个体信息")) {
            MainApp.Yzgtxxpage(MainApp.yzgtxxPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("后备2月性状")) {
            MainApp.Yztwotestpage(MainApp.yzTwotestPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("后备4月性状")) {
            MainApp.Yzfourtestpage(MainApp.yzFourtestPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("后备6月性状")) {
            MainApp.Yzsixtestpage(MainApp.yzSixtestPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("100kg测定性状")) {
            MainApp.Yzhundredtestpage(MainApp.yzHundredtestPageModel.getBottomPageNo());
        }

        if (MainApp.outsideLabel.equals("个体基本信息")) {
            MainApp.Selebithpage(MainApp.selebithPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("公猪采精登记")) {
            MainApp.Takespermpage(MainApp.takespermPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪配种情况登记")) {
            MainApp.Breedingpage(MainApp.breedingPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪分娩情况登记")) {
            MainApp.Childbirthpage(MainApp.childbirthPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("哺乳猪-保育猪")) {
            MainApp.FeedingTurnConservationPage(MainApp.feedingTurnConservationPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-生长育肥猪")) {
            MainApp.ConservationTurnFattingpage(MainApp.conservationTurnFattingPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("保育猪-后备猪")) {
            MainApp.ConservationTurnBackpage(MainApp.conservationTurnBackPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("母猪断奶登记")) {
            MainApp.Weaningpage(MainApp.weaningPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("种公猪资料")) {
            MainApp.MaleBoarpage(MainApp.maleBoarPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("种母猪资料")) {
            MainApp.FemaleBoarpage(MainApp.femaleBoarPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪2月龄登记")) {
            MainApp.TwoTestpage(MainApp.twoTestPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪4月龄登记")) {
            MainApp.FourTestpage(MainApp.fourTestPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("后备猪6月龄登记")) {
            MainApp.SixTestpage(MainApp.sixTestPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("100KG检测登记")) {
            MainApp.HundredTestpage(MainApp.hundredTestPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料入库登记")) {
            MainApp.Slrkpage(MainApp.slrkPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("饲料出库登记")) {
            MainApp.Slckpage(MainApp.slckPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("药品入库登记")) {
            MainApp.Yprkpage(MainApp.yprkPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("药品出库登记")) {
            MainApp.Ypckpage(MainApp.ypckPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗入库登记")) {
            MainApp.Ymrkpage(MainApp.ymrkPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("疫苗出库登记")) {
            MainApp.Ymckpage(MainApp.ymckPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只免疫登记")) {
            MainApp.Zzmypage(MainApp.zzmyPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("疾病治疗登记")) {
            MainApp.Jbzlpage(MainApp.jbzlPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("基因检测登记")) {
            MainApp.Jyjcpage(MainApp.jyjcPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("屠宰性能测定登记")) {
            MainApp.Tzxncdpage(MainApp.tzxncdPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只销售登记")) {
            MainApp.Zzxspage(MainApp.zzxsPageModel.getBottomPageNo());
        }
        if (MainApp.outsideLabel.equals("猪只死亡登记")) {
            MainApp.Zzswpage(MainApp.zzswPageModel.getBottomPageNo());
        }
    }//GEN-LAST:event_LastBtnActionPerformed

    private void GOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GOActionPerformed
        if (MainApp.outsideLabel.equals("系谱数据")) {
            MainApp.Yzxppage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("育种个体信息")) {
            MainApp.Yzgtxxpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("后备2月性状")) {
            MainApp.Yztwotestpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("后备4月性状")) {
            MainApp.Yzfourtestpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("后备6月性状")) {
            MainApp.Yzsixtestpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("100kg测定性状")) {
            MainApp.Yzhundredtestpage(Integer.parseInt(jTextField1.getText()));
        }

        if (MainApp.outsideLabel.equals("个体基本信息")) {
            MainApp.Selebithpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("公猪采精登记")) {
            MainApp.Takespermpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("母猪配种情况登记")) {
            MainApp.Breedingpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("母猪分娩情况登记")) {
            MainApp.Childbirthpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("哺乳猪-保育猪")) {
            MainApp.FeedingTurnConservationPage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("保育猪-生长育肥猪")) {
            MainApp.ConservationTurnFattingpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("保育猪-后备猪")) {
            MainApp.ConservationTurnBackpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("母猪断奶登记")) {
            MainApp.Weaningpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("种公猪资料")) {
            MainApp.MaleBoarpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("种母猪资料")) {
            MainApp.FemaleBoarpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("后备猪2月龄登记")) {
            MainApp.TwoTestpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("后备猪4月龄登记")) {
            MainApp.FourTestpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("后备猪6月龄登记")) {
            MainApp.SixTestpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("100KG检测登记")) {
            MainApp.HundredTestpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("饲料入库登记")) {
            MainApp.Slrkpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("饲料出库登记")) {
            MainApp.Slckpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("药品入库登记")) {
            MainApp.Yprkpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("药品出库登记")) {
            MainApp.Ypckpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("疫苗入库登记")) {
            MainApp.Ymrkpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("疫苗出库登记")) {
            MainApp.Ymckpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("猪只免疫登记")) {
            MainApp.Zzmypage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("疾病治疗登记")) {
            MainApp.Jbzlpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("基因检测登记")) {
            MainApp.Jyjcpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("屠宰性能测定登记")) {
            MainApp.Tzxncdpage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("猪只销售登记")) {
            MainApp.Zzxspage(Integer.parseInt(jTextField1.getText()));
        }
        if (MainApp.outsideLabel.equals("猪只死亡登记")) {
            MainApp.Zzswpage(Integer.parseInt(jTextField1.getText()));
        }
    }//GEN-LAST:event_GOActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BeginRecFld;
    private javax.swing.JLabel EndRecFld;
    public javax.swing.JButton FirstBtn;
    private javax.swing.JButton GO;
    public javax.swing.JButton LastBtn;
    private javax.swing.JLabel MaxpageFld;
    public javax.swing.JButton NextBtn;
    private javax.swing.JLabel NowPageFld;
    public javax.swing.JButton PrevBtn;
    private javax.swing.JLabel TotalRecFld;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel01;
    private javax.swing.JPanel jPanel02;
    private javax.swing.JPanel jPanel03;
    private javax.swing.JPanel jPanel04;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

    public JTable getjTable1() {
        return jTable1;
    }

    public void setjTable1(JTable jTable1) {
        this.jTable1 = jTable1;
    }

    public void setTableModel(Object[][] tableModel) {
        this.tableModel = tableModel;
    }

    public void setTableHead(String[] tableHead) {
        this.tableHead = tableHead;
    }

}
