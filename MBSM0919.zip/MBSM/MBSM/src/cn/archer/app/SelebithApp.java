package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.farmNametoIdSmap;
import static cn.archer.app.MainApp.farmThingsmap;
import static cn.archer.app.MainApp.fenceNametoIdSmap;
import static cn.archer.app.MainApp.fenceThingsmap;
import static cn.archer.app.MainApp.lineherdNametoIdSmap;
import static cn.archer.app.MainApp.lineherdThingsmap;
import static cn.archer.app.MainApp.linesNametoIdSmap;
import static cn.archer.app.MainApp.linesThingsmap;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.piggeryThingsmap;
import static cn.archer.app.MainApp.selebithPageModel;
import static cn.archer.app.MainApp.selethMapperPlus;
import static cn.archer.app.MainApp.swintypeNametoIdSmap;
import static cn.archer.app.MainApp.swintypeThingsmap;
import cn.archer.mapper.FarmNameMapper;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.LineherdMapper;
import cn.archer.mapper.LinesMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.mapper.SwintypeMapper;
import cn.archer.pojo.FarmName;
import cn.archer.pojo.Fence;
import cn.archer.pojo.SelethTemp;
import cn.archer.pojo.Lineherd;
import cn.archer.pojo.Lines;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.Swintype;
import cn.archer.utils.DateChooserJButtonJDialog;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import cn.archer.model.SelethPageModel;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import static cn.archer.utils.MyStaticMethod.NowTime;
import cn.archer.mapper.SelethTempMapper;

/**
 *
 * @author Administrator
 */
public class SelebithApp extends javax.swing.JDialog {

    private VarietiesDataPlus varietiesDataPlus;
    private String flagua;
    private String formid0;
    private String[] jComboBoxString;
    private List<Lines> lines;
    private List<Piggery> piggery;

    /**
     * Creates new form BasicRegisterApp
     */
    public SelebithApp(VarietiesDataPlus varietiesDataPlus, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "add";
        jComboBoxString = new String[7];
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("个体基本信息录入");
        jLabel00.setText("个体基本信息录入");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelethTempMapper mapper0 = sqlSession.getMapper(SelethTempMapper.class);
        SelethTemp selethtemp = mapper0.selectByTypeid("1");

        //｛品种复选框
        LinesMapper mapper1 = sqlSession.getMapper(LinesMapper.class);
        lines = mapper1.selectAll();
        String[] things1 = new String[lines.size()];
        for (int i = 0; i < lines.size(); i++) {
            things1[i] = lines.get(i).getLinename();
            if (selethtemp.getR_lineid().equals(lines.get(i).getLineid())) {
                String temp = things1[0];
                things1[0] = things1[i];
                things1[i] = temp;
            }
        }
        jComboBox01.setModel(new javax.swing.DefaultComboBoxModel(things1));
        //｝品种复选框 

        //｛品系复选框
        LineherdMapper mapper2 = sqlSession.getMapper(LineherdMapper.class);
        List<Lineherd> lineherd = mapper2.selectAll();
        String[] things2 = new String[lineherd.size()];
        for (int i = 0; i < lineherd.size(); i++) {
            things2[i] = lineherd.get(i).getHerdname();
            if (selethtemp.getR_herd().equals(lineherd.get(i).getHerdid())) {
                String temp = things2[0];
                things2[0] = things2[i];
                things2[i] = temp;
            }
        }
        jComboBox02.setModel(new javax.swing.DefaultComboBoxModel(things2));
        //｝品系复选框 

        //｛当前猪场复选框
        FarmNameMapper mapper3 = sqlSession.getMapper(FarmNameMapper.class);
        List<FarmName> farmName = mapper3.selectAll();
        String[] things3 = new String[farmName.size()];
        for (int i = 0; i < farmName.size(); i++) {
            things3[i] = farmName.get(i).getFarm_name();
            if (selethtemp.getR_house().equals(farmName.get(i).getFarm_id())) {
                String temp = things3[0];
                things3[0] = things3[i];
                things3[i] = temp;
            }
        }
        jComboBox03.setModel(new javax.swing.DefaultComboBoxModel(things3));
        //｝当前猪场复选框 

        //｛猪之状态复选框
        SwintypeMapper mapper4 = sqlSession.getMapper(SwintypeMapper.class);
        List<Swintype> swintype = mapper4.selectAll();
        String[] things4 = new String[swintype.size()];
        for (int i = 0; i < swintype.size(); i++) {
            things4[i] = swintype.get(i).getTypename();
            if (selethtemp.getR_curmark().equals(swintype.get(i).getTypeid())) {
                String temp = things4[0];
                things4[0] = things4[i];
                things4[i] = temp;
            }
        }
        jComboBox07.setModel(new javax.swing.DefaultComboBoxModel(things4));
        //｝猪之状态复选框 
        //｛所在猪舍复选框
        PiggeryMapper mapper5 = sqlSession.getMapper(PiggeryMapper.class);
        piggery = mapper5.selectAll();
        String[] things5 = new String[piggery.size()];
        for (int i = 0; i < piggery.size(); i++) {
            things5[i] = piggery.get(i).getCategory();
            if (selethtemp.getR_cage().equals(piggery.get(i).getNumber())) {
                String temp = things5[0];
                things5[0] = things5[i];
                things5[i] = temp;
            }
        }
        jComboBox08.setModel(new javax.swing.DefaultComboBoxModel(things5));
        //｝所在猪舍复选框 
        //｛所在栏位复选框
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAll();
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
            if (selethtemp.getR_pcage().equals(fence.get(i).getFenceid())) {
                String temp = things6[0];
                things6[0] = things6[i];
                things6[i] = temp;
            }
        }
        jComboBox09.setModel(new javax.swing.DefaultComboBoxModel(things6));
        //｝所在栏位复选框 
        //｛性别复选框
        String[] things = new String[2];
        if (selethtemp.getR_sex().equals("0")) {
            things[0] = "公";
            things[1] = "母";
        } else {
            things[0] = "母";
            things[1] = "公";
        }
        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel(things));
        //｝性别复选框 
        jTextField04.setText(NowTime());
        jTextField05.setText(selethtemp.getR_ear_no());
        jTextField06.setText(selethtemp.getR_animal());
        jTextField11.setText(String.valueOf(selethtemp.getR_bthwt()));
//        jTextField12.setText(selethtemp.getR_sire());
//        jTextField13.setText(selethtemp.getR_dam());
        jTextField14.setText(String.valueOf(selethtemp.getR_ghatch()));
        jTextField15.setText(String.valueOf(selethtemp.getR_fno()));
        jTextField16.setText(String.valueOf(selethtemp.getR_lsize()));
        jTextField17.setText(String.valueOf(selethtemp.getR_nipple1()));
        jTextField18.setText(String.valueOf(selethtemp.getR_nipple2()));
        jTextField19.setText(selethtemp.getR_weanwt());
//        jTextField20.setText(selethtemp.getR_date());
//        jTextField21.setText(selethtemp.getR_ldate());
        jTextField22.setText(selethtemp.getR_note());
        jTextField06.setEnabled(false);
        sqlSession.close();

    }

    public SelebithApp(VarietiesDataPlus varietiesDataPlus, String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "upp";
        jComboBoxString = new String[7];
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("个体信息更改");
        jLabel00.setText("个体信息更改");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper1 = sqlSession.getMapper(SelebithMapper.class);
        Selebith selebith;
        selebith = mapper1.selectByTypeid(farmid0);
        PiggeryMapper mapper2 = sqlSession.getMapper(PiggeryMapper.class);
        piggery = mapper2.selectAll();
        //品种复选框
        jComboBox01.setModel(new javax.swing.DefaultComboBoxModel(linesThingsmap.get(selebith.getR_lineid())));
        //品系复选框
        jComboBox02.setModel(new javax.swing.DefaultComboBoxModel(lineherdThingsmap.get(selebith.getR_herd())));
        //当前猪场复选框
        jComboBox03.setModel(new javax.swing.DefaultComboBoxModel(farmThingsmap.get(selebith.getR_house())));
        //猪之状态复选框
        jComboBox07.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(selebith.getR_curmark())));
        //所在猪舍复选框
        jComboBox08.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(selebith.getR_cage())));
        //所在栏位复选框
        jComboBox09.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(selebith.getR_pcage())));

        jButton3.setText("确认提交");
        //｛性别复选框
        String[] things = new String[2];
        if (selebith.getR_sex().equals("0")) {
            things[0] = "公";
            things[1] = "母";
        } else {
            things[0] = "母";
            things[1] = "公";
        }
        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel(things));
        String jComboBox10String = JComboBoxString(jComboBox10);

        //｝性别复选框 
        jTextField04.setText(selebith.getR_fdate());
        jTextField05.setText(selebith.getR_ear_no());
        jTextField06.setText(selebith.getR_animal());
        jTextField11.setText(String.valueOf(selebith.getR_bthwt()));
        jTextField12.setText(selebith.getR_sire());
        jTextField13.setText(selebith.getR_dam());
        jTextField14.setText(String.valueOf(selebith.getR_ghatch()));
        jTextField15.setText(String.valueOf(selebith.getR_fno()));
        jTextField16.setText(String.valueOf(selebith.getR_lsize()));
        jTextField17.setText(String.valueOf(selebith.getR_nipple1()));
        jTextField18.setText(String.valueOf(selebith.getR_nipple2()));
        jTextField19.setText(selebith.getR_weanwt());
        jTextField20.setText(selebith.getR_date());
        jTextField21.setText(selebith.getR_ldate());
        jTextField22.setText(selebith.getR_note());

        jComboBox01.setEnabled(false);
        jComboBox02.setEnabled(false);
        jComboBox03.setEnabled(false);
        jTextField04.setEnabled(false);
        jButton0004.setEnabled(false);
        jTextField05.setEnabled(false);
        jTextField06.setEnabled(false);
        jButton4.setEnabled(false);
        sqlSession.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel00 = new javax.swing.JLabel();
        jLabel01 = new javax.swing.JLabel();
        jLabel02 = new javax.swing.JLabel();
        jLabel03 = new javax.swing.JLabel();
        jLabel04 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel07 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel05 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel08 = new javax.swing.JLabel();
        jLabel09 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel06 = new javax.swing.JLabel();
        jComboBox07 = new javax.swing.JComboBox<>();
        jComboBox08 = new javax.swing.JComboBox<>();
        jComboBox10 = new javax.swing.JComboBox<>();
        jComboBox02 = new javax.swing.JComboBox<>();
        jTextField04 = new javax.swing.JTextField();
        jTextField05 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jButton0004 =  new DateChooserJButtonJDialog (jTextField04);
        jLabel001 = new javax.swing.JLabel();
        jLabel002 = new javax.swing.JLabel();
        jLabel003 = new javax.swing.JLabel();
        jLabel004 = new javax.swing.JLabel();
        jLabel005 = new javax.swing.JLabel();
        jLabel006 = new javax.swing.JLabel();
        jLabel007 = new javax.swing.JLabel();
        jLabel008 = new javax.swing.JLabel();
        jLabel010 = new javax.swing.JLabel();
        jTextField20 = new javax.swing.JTextField();
        jButton0020 =  new DateChooserJButtonJDialog (jTextField20);
        jTextField21 = new javax.swing.JTextField();
        jButton0021 =  new DateChooserJButtonJDialog (jTextField21);
        jComboBox01 = new javax.swing.JComboBox<>();
        jTextField06 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jComboBox03 = new javax.swing.JComboBox<>();
        jLabel24 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jComboBox09 = new javax.swing.JComboBox<>();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("个体基本档案新登");

        jLabel00.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel00.setText("个体基本信息录入");

        jLabel01.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel01.setText("品   种：");
        jLabel01.setMaximumSize(new java.awt.Dimension(75, 16));
        jLabel01.setMinimumSize(new java.awt.Dimension(75, 16));
        jLabel01.setPreferredSize(new java.awt.Dimension(75, 16));

        jLabel02.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel02.setText("品   系：");
        jLabel02.setMaximumSize(new java.awt.Dimension(75, 16));
        jLabel02.setMinimumSize(new java.awt.Dimension(75, 16));
        jLabel02.setPreferredSize(new java.awt.Dimension(75, 16));

        jLabel03.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel03.setText("当前猪场：");

        jLabel04.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel04.setText("出生日期：");

        jLabel14.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel14.setText("母   亲：");
        jLabel14.setMaximumSize(new java.awt.Dimension(75, 16));
        jLabel14.setMinimumSize(new java.awt.Dimension(75, 16));
        jLabel14.setPreferredSize(new java.awt.Dimension(75, 16));

        jLabel15.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel15.setText("出生胎次:");

        jLabel07.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel07.setText("当前状态：");

        jLabel21.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel21.setText("断奶日期：");

        jLabel20.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel20.setText("断奶重量：");

        jLabel18.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel18.setText("左乳头数：");

        jLabel17.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel17.setText("同窝仔数：");

        jLabel16.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel16.setText("当前胎次:");

        jLabel05.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel05.setText("耳缺编号：");

        jLabel13.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel13.setText("父   亲：");
        jLabel13.setMaximumSize(new java.awt.Dimension(75, 16));
        jLabel13.setMinimumSize(new java.awt.Dimension(75, 16));
        jLabel13.setPreferredSize(new java.awt.Dimension(75, 16));

        jLabel08.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel08.setText("所在猪舍：");

        jLabel09.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel09.setText("性   别：");
        jLabel09.setMaximumSize(new java.awt.Dimension(75, 16));
        jLabel09.setMinimumSize(new java.awt.Dimension(75, 16));
        jLabel09.setPreferredSize(new java.awt.Dimension(75, 16));

        jLabel23.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel23.setText("备   注：");
        jLabel23.setMaximumSize(new java.awt.Dimension(75, 16));
        jLabel23.setMinimumSize(new java.awt.Dimension(75, 16));
        jLabel23.setPreferredSize(new java.awt.Dimension(75, 16));

        jLabel22.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel22.setText("销售时间：");

        jLabel10.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel10.setText("出生重量：");

        jLabel06.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel06.setText("个体编号：");

        jComboBox07.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox07.setPreferredSize(new java.awt.Dimension(140, 21));

        jComboBox08.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox08.setPreferredSize(new java.awt.Dimension(140, 21));
        jComboBox08.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox08ActionPerformed(evt);
            }
        });

        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "公", "母", " " }));
        jComboBox10.setPreferredSize(new java.awt.Dimension(140, 21));

        jComboBox02.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox02.setPreferredSize(new java.awt.Dimension(140, 21));

        jTextField04.setPreferredSize(new java.awt.Dimension(113, 21));

        jTextField05.setPreferredSize(new java.awt.Dimension(52, 21));
        jTextField05.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField05FocusLost(evt);
            }
        });

        jTextField11.setPreferredSize(new java.awt.Dimension(113, 21));
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jTextField12.setPreferredSize(new java.awt.Dimension(140, 21));
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jTextField13.setPreferredSize(new java.awt.Dimension(140, 21));

        jTextField14.setText("0");
        jTextField14.setPreferredSize(new java.awt.Dimension(140, 21));
        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });

        jTextField15.setText("0");
        jTextField15.setPreferredSize(new java.awt.Dimension(140, 21));

        jTextField16.setText("0");
        jTextField16.setPreferredSize(new java.awt.Dimension(140, 21));

        jTextField17.setText("6");
        jTextField17.setPreferredSize(new java.awt.Dimension(140, 21));

        jTextField18.setText("6");
        jTextField18.setPreferredSize(new java.awt.Dimension(140, 21));

        jTextField19.setText("0");
        jTextField19.setPreferredSize(new java.awt.Dimension(113, 21));

        jTextField22.setText("0");
        jTextField22.setPreferredSize(new java.awt.Dimension(140, 21));

        jButton0004.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton0004.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton0004ActionPerformed(evt);
            }
        });

        jLabel001.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel001.setForeground(new java.awt.Color(204, 0, 0));
        jLabel001.setText("*");

        jLabel002.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel002.setForeground(new java.awt.Color(204, 0, 0));
        jLabel002.setText("*");

        jLabel003.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel003.setForeground(new java.awt.Color(204, 0, 0));
        jLabel003.setText("*");

        jLabel004.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel004.setForeground(new java.awt.Color(204, 0, 0));
        jLabel004.setText("*");

        jLabel005.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel005.setForeground(new java.awt.Color(204, 0, 0));
        jLabel005.setText("*");

        jLabel006.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel006.setForeground(new java.awt.Color(204, 0, 0));
        jLabel006.setText("*");

        jLabel007.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel007.setForeground(new java.awt.Color(204, 0, 0));
        jLabel007.setText("*");

        jLabel008.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel008.setForeground(new java.awt.Color(204, 0, 0));
        jLabel008.setText("*");

        jLabel010.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel010.setForeground(new java.awt.Color(204, 0, 0));
        jLabel010.setText("*");

        jTextField20.setText("0");
        jTextField20.setPreferredSize(new java.awt.Dimension(113, 21));

        jButton0020.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N

        jTextField21.setText("0");
        jTextField21.setPreferredSize(new java.awt.Dimension(113, 21));

        jButton0021.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton0021.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton0021ActionPerformed(evt);
            }
        });

        jComboBox01.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox01.setPreferredSize(new java.awt.Dimension(140, 21));
        jComboBox01.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox01ActionPerformed(evt);
            }
        });

        jTextField06.setText("自动生成不可输入");
        jTextField06.setPreferredSize(new java.awt.Dimension(140, 21));
        jTextField06.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField06ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton3.setText("连续提交");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/refues.png"))); // NOI18N
        jButton4.setText("重新输入");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 0, 0));

        jComboBox03.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox03.setPreferredSize(new java.awt.Dimension(140, 21));

        jLabel24.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(204, 0, 0));
        jLabel24.setText("*");

        jLabel9.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 0));
        jLabel9.setText("*");

        jComboBox09.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox09.setPreferredSize(new java.awt.Dimension(140, 21));
        jComboBox09.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox09ActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel25.setText("所在栏位：");

        jLabel26.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel26.setText("右乳头数：");

        jButton5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton5.setText("退出输入");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(204, 0, 0));
        jLabel29.setText("KG");

        jLabel30.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(204, 0, 0));
        jLabel30.setText("KG");

        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("六位数字");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jButton3)
                .addGap(36, 36, 36)
                .addComponent(jButton4)
                .addGap(36, 36, 36)
                .addComponent(jButton5)
                .addGap(59, 59, 59))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel04, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel03, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel02, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel01, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel07, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel08, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel09, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel06, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel05))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel30))
                            .addComponent(jComboBox09, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox07, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jTextField04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton0004, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jComboBox03, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField05, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jComboBox08, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField06, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel001, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel002)
                            .addComponent(jLabel003)
                            .addComponent(jLabel004)
                            .addComponent(jLabel005)
                            .addComponent(jLabel006)
                            .addComponent(jLabel007)
                            .addComponent(jLabel008)
                            .addComponent(jLabel010)
                            .addComponent(jLabel24)
                            .addComponent(jLabel9))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(46, 46, 46)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel21)
                                                        .addComponent(jLabel20))
                                                    .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.TRAILING))
                                                .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel18)))
                                    .addComponent(jLabel26, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton0021, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton0020, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jTextField22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel17)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(jLabel29))
                                                .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(1, 1, 1))))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(197, 197, 197)
                        .addComponent(jLabel00)))
                .addGap(25, 25, 25)
                .addComponent(jLabel12))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(376, 376, 376)
                        .addComponent(jLabel12))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel00)
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jComboBox01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel001)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel002)
                                    .addComponent(jComboBox02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jComboBox03, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel003))
                                    .addComponent(jLabel03))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel04)
                                                .addComponent(jTextField04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jButton0004, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel16)
                                                .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jTextField05, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel005)
                                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jLabel05))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel06, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel006)
                                                    .addComponent(jTextField06, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel07)
                                                    .addComponent(jComboBox07, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel007))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel08)
                                                    .addComponent(jComboBox08, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel008))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel25)
                                                    .addComponent(jComboBox09, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel9))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel09, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel24))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel010)
                                                        .addComponent(jLabel30))))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel17))
                                                .addGap(12, 12, 12)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel26))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel18))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel20)
                                                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel29))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel21)
                                                        .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(jButton0020, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jLabel22))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                    .addComponent(jButton0021, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addComponent(jLabel004)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel15)
                                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton3)
                        .addComponent(jButton4)))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {

    }
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jTextField04.setText("0");
        jTextField05.setText("0");
        jTextField06.setText("0");
        jTextField11.setText("0");
        jTextField12.setText("0");
        jTextField13.setText("0");
        jTextField14.setText("0");
        jTextField15.setText("6");
        jTextField16.setText("6");
        jTextField17.setText("0");
        jTextField18.setText("0");
        jTextField19.setText("0");
        jTextField20.setText("0");
        jTextField21.setText("0");
        jTextField22.setText("0");

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (StringUtils.isBlank(jTextField05.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加耳缺号!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (jTextField05.getText().length()!=6) {
            JOptionPane.showMessageDialog(null,
                    "您添加的耳缺号不是6位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (StringUtils.isBlank(jTextField11.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加出生重量!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (StringUtils.isBlank(jTextField04.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加出生日期!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelethTempMapper mapper0 = sqlSession.getMapper(SelethTempMapper.class);
        SelethTemp selethtemp = mapper0.selectByTypeid("1");

        SelebithMapper mapper = sqlSession.getMapper(SelebithMapper.class);
        Selebith selebith;
        if (flagua.equals("add")) {
            selebith = new Selebith();
        } else {
            selebith = mapper.selectByTypeid(jTextField06.getText());
        }
        //复选框-关联品种表
        String jComboBox01String = linesNametoIdSmap.get(JComboBoxString(jComboBox01));
        jComboBoxString[0] = jComboBox01String;

        //复选框-关联品系表{
        String jComboBox02String = lineherdNametoIdSmap.get(JComboBoxString(jComboBox02));
        jComboBoxString[1] = jComboBox02String;

        //复选框-关联当前猪场表{
        String jComboBox03String = farmNametoIdSmap.get(JComboBoxString(jComboBox03));
        jComboBoxString[2] = jComboBox03String;

        //复选框-关联猪只状态表{
        String jComboBox07String = swintypeNametoIdSmap.get(JComboBoxString(jComboBox07));
        jComboBoxString[4] = jComboBox07String;

        //复选框-关联当前猪舍表
        String jComboBox08String = piggeryNametoIdSmap.get(JComboBoxString(jComboBox08));
        jComboBoxString[5] = jComboBox08String;

        //复选框-关联栏位管理表
        String jComboBox09String = fenceNametoIdSmap.get(JComboBoxString(jComboBox09));
        jComboBoxString[6] = jComboBox09String;

        //复选框-性别}
        String jComboBox10String = null;
        if (JComboBoxString(jComboBox10).equals("公")) {
            jComboBox10String = "0";
        } else {
            jComboBox10String = "1";
        }
        //复选框-性别}

        selebith.setR_lineid(jComboBox01String);
        selebith.setR_herd(jComboBox02String);
        selebith.setR_house(jComboBox03String);
        selebith.setR_fdate(jTextField04.getText());
        selebith.setR_ear_no(jTextField05.getText());

        //猪之编号{
        if (flagua.equals("add")) {
            String jTextField06String = jComboBox01String + jComboBox03String + jTextField04.getText().substring(2, 4) + jTextField05.getText();
            jComboBoxString[3] = jTextField06String;
            selebith.setR_animal(jTextField06String);
            jTextField05.setText("");
            jTextField06.setText("");
        }
        //猪之编号}

        selebith.setR_curmark(jComboBox07String);
        selebith.setR_cage(jComboBox08String);
        selebith.setR_pcage(jComboBox09String);
        selebith.setR_sex(jComboBox10String);
        selebith.setR_bthwt(Double.parseDouble(jTextField11.getText()));
        //可以不填加，默认为空
        selebith.setR_sire(jTextField12.getText());
        selebith.setR_dam(jTextField13.getText());
        selebith.setR_ghatch(Integer.parseInt(jTextField14.getText()));
        selebith.setR_fno(Integer.parseInt(jTextField15.getText()));
        selebith.setR_lsize(Integer.parseInt(jTextField16.getText()));
        selebith.setR_nipple1(Integer.parseInt(jTextField17.getText()));
        selebith.setR_nipple2(Integer.parseInt(jTextField18.getText()));
        selebith.setR_weanwt(jTextField19.getText());
        selebith.setR_date(jTextField20.getText());
        selebith.setR_ldate(jTextField21.getText());
        selebith.setR_note(jTextField22.getText());
        //初始化判断模式
        if (flagua.equals("add")) {
            selebith.setNifzb("0");
            selebith.setNifby("0");
            selebith.setNifhb("0");
            selebith.setNifbh("0");
            selebith.setIftwo("0");
            selebith.setIffour("0");
            selebith.setIfsix("0");
            selebith.setCzzs(0);
            selebith.setSfzz(0);
        }
        JTable jTable1 = varietiesDataPlus.getjTable1();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        if (flagua.equals("add")) {
            //{查询是否存在相同主键
            List<Selebith> selebithlist = mapper.selectAll();
            for (int i = 0; i < selebithlist.size(); i++) {
                if (selebithlist.get(i).getR_animal().equals(selebith.getR_animal())) {
                    JOptionPane.showMessageDialog(null, "添加失败！已存在相同主键", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    sqlSession.close();
                    return;
                }
            }
            //}查询是否存在相同主键

            //｛保存临时表信息
            selethtemp.setR_lineid(selebith.getR_lineid());
            selethtemp.setR_herd(selebith.getR_herd());
            selethtemp.setR_house(selebith.getR_house());
            selethtemp.setR_fdate(selebith.getR_fdate());
            selethtemp.setR_ear_no("");
            selethtemp.setR_animal("");
            selethtemp.setR_curmark(selebith.getR_curmark());
            selethtemp.setR_cage(selebith.getR_cage());
            selethtemp.setR_pcage(selebith.getR_pcage());
            selethtemp.setR_sex(selebith.getR_sex());

            selethtemp.setR_bthwt(selebith.getR_bthwt());
            //可以不填加，默认为空
            selethtemp.setR_bthwt(selebith.getR_bthwt());
            selethtemp.setR_dam(selebith.getR_dam());
            selethtemp.setR_sire(selebith.getR_sire());
            selethtemp.setR_ghatch(selebith.getR_ghatch());
            selethtemp.setR_fno(selebith.getR_fno());
            selethtemp.setR_lsize(selebith.getR_lsize());
            selethtemp.setR_nipple1(selebith.getR_nipple1());
            selethtemp.setR_nipple2(selebith.getR_nipple2());
            selethtemp.setR_weanwt(selebith.getR_weanwt());
            selethtemp.setR_date(selebith.getR_date());
            selethtemp.setR_ldate(selebith.getR_ldate());
            selethtemp.setR_note(selebith.getR_note());
            //｝保存临时表信息
            mapper0.updateByTypeid(selethtemp);
            mapper.insert(selebith);
            sqlSession.commit();
            JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            //添加后更新数据格式
            MainApp.selebithPageModel = new SelethPageModel(14, selethMapperPlus.SelectCount(), selethMapperPlus, false);
            MainApp.Selebithpage(selebithPageModel.getTopPageNo());
        } else {
            mapper.updateByTypeid(selebith);
            sqlSession.commit();
            JOptionPane.showMessageDialog(null, "修改成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);

            //移除修改那行，然后在后面加上新的一行
            model.removeRow(jTable1.getSelectedRow());
            Object[] rowInsert = new Object[]{selebith.getR_animal(), JComboBoxString(jComboBox01),
                JComboBoxString(jComboBox02), selebith.getR_fdate(), selebith.getR_ear_no(), JComboBoxString(jComboBox10),
                JComboBoxString(jComboBox07), JComboBoxString(jComboBox09), selebith.getR_sire(), selebith.getR_dam()
            };
            model.addRow(rowInsert);
            jTable1.setModel(model);
            varietiesDataPlus.validate();
            sqlSession.close();
            System.gc();
            dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField06ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField06ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField06ActionPerformed

    private void jButton0004ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton0004ActionPerformed

    }//GEN-LAST:event_jButton0004ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton0021ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton0021ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton0021ActionPerformed

    private void jComboBox09ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox09ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox09ActionPerformed

    private void jComboBox01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox01ActionPerformed
        String name = JComboBoxString(jComboBox01);
        String id = null;
        for (int i = 0; i < lines.size(); i++) {
            if (name.equals(lines.get(i).getLinename())) {
                id = lines.get(i).getLineid();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        LineherdMapper mapper2 = sqlSession.getMapper(LineherdMapper.class);
        List<Lineherd> lineherd = mapper2.selectAllById(id);

        String things2[] = new String[lineherd.size()];

        for (int i = 0; i < lineherd.size(); i++) {
            things2[i] = lineherd.get(i).getHerdname();
        }
        jComboBox02.removeAll();
        jComboBox02.setModel(new javax.swing.DefaultComboBoxModel(things2));
        sqlSession.close();
    }//GEN-LAST:event_jComboBox01ActionPerformed

    private void jComboBox08ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox08ActionPerformed
        String name = JComboBoxString(jComboBox08);
        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox09.removeAll();
        jComboBox09.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();

    }//GEN-LAST:event_jComboBox08ActionPerformed

    private void jTextField05FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField05FocusLost
        String jComboBox01String = linesNametoIdSmap.get(JComboBoxString(jComboBox01));
        String jComboBox03String = farmNametoIdSmap.get(JComboBoxString(jComboBox03));
        String jTextField06String = jComboBox01String + jComboBox03String + jTextField04.getText().substring(2, 4) + jTextField05.getText();
        jTextField06.setText(jTextField06String);
    }//GEN-LAST:event_jTextField05FocusLost

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton0004;
    private javax.swing.JButton jButton0020;
    private javax.swing.JButton jButton0021;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox01;
    private javax.swing.JComboBox<String> jComboBox02;
    private javax.swing.JComboBox<String> jComboBox03;
    private javax.swing.JComboBox<String> jComboBox07;
    private javax.swing.JComboBox<String> jComboBox08;
    private javax.swing.JComboBox<String> jComboBox09;
    private javax.swing.JComboBox<String> jComboBox10;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JLabel jLabel001;
    private javax.swing.JLabel jLabel002;
    private javax.swing.JLabel jLabel003;
    private javax.swing.JLabel jLabel004;
    private javax.swing.JLabel jLabel005;
    private javax.swing.JLabel jLabel006;
    private javax.swing.JLabel jLabel007;
    private javax.swing.JLabel jLabel008;
    private javax.swing.JLabel jLabel01;
    private javax.swing.JLabel jLabel010;
    private javax.swing.JLabel jLabel02;
    private javax.swing.JLabel jLabel03;
    private javax.swing.JLabel jLabel04;
    private javax.swing.JLabel jLabel05;
    private javax.swing.JLabel jLabel06;
    private javax.swing.JLabel jLabel07;
    private javax.swing.JLabel jLabel08;
    private javax.swing.JLabel jLabel09;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField jTextField04;
    private javax.swing.JTextField jTextField05;
    private javax.swing.JTextField jTextField06;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    // End of variables declaration//GEN-END:variables
}
