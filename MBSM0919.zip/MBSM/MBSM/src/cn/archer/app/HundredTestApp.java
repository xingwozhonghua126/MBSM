package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.employeeIdtoNameSmap;
import static cn.archer.app.MainApp.employeeJSThingsShow;
import static cn.archer.app.MainApp.employeeJSThingsmap;
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeeThingsmap;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.fenceNametoIdSmap;
import static cn.archer.app.MainApp.fenceThingsShow;
import static cn.archer.app.MainApp.hundredTestMapperPlus;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.piggeryThingsShow;
import static cn.archer.app.MainApp.swintypeIdtoNameSmap;
import static cn.archer.app.MainApp.swintypeNametoIdSmap;
import static cn.archer.app.MainApp.swintypeThingsmap;
import cn.archer.mapper.DesignbaseMapper;
import cn.archer.mapper.EmployeeMapper;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.mapper.SwintypeMapper;
import cn.archer.model.HundredTestPageModel;
import cn.archer.pojo.Employee;
import cn.archer.pojo.Fence;
import cn.archer.pojo.HundredTest;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.ShengZYF;
import cn.archer.pojo.Swintype;
import static cn.archer.utils.MyStaticMethod.NowTime;
import static cn.archer.utils.MyStaticMethod.calInterval;
import cn.archer.utils.DateChooserJButtonJDialog;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.ibatis.session.SqlSession;
import cn.archer.mapper.HundredTestMapper;
import cn.archer.pojo.Designbase;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;

/**
 *
 * @author Administrator
 */
public class HundredTestApp extends javax.swing.JDialog {

    private VarietiesDataPlus varietiesDataPlus;
    private String flagua;
    private String formid0;
    private List<Piggery> piggery;

    /**
     * Creates new form FormApp
     */
    public HundredTestApp(VarietiesDataPlus varietiesDataPlus, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "add";
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("100kg检测登记");
        jLabel00.setText("100kg检测登记");//录入，登记，更改,详情
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();

        jTextField2.setText(dateFormater.format(date));
        SqlSession sqlSession = MybatisUtil.getSqlSession();

        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel13.setText(designbase1.getTypename());
        jLabel15.setText(designbase2.getTypename());
        jLabel16.setText(designbase3.getTypename());

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsShow));

        SwintypeMapper swintypeMapper = sqlSession.getMapper(SwintypeMapper.class);
        List<Swintype> swintype = swintypeMapper.selectAll();
        String typeName[] = new String[5];
        for (int i = 0; i < swintype.size(); i++) {
            switch (swintype.get(i).getTypename()) {
                case "后备母猪":
                    typeName[0] = swintype.get(i).getTypename();
                    break;
                case "种公猪":
                    typeName[1] = swintype.get(i).getTypename();
                    break;
                case "生长育肥猪":
                    typeName[2] = swintype.get(i).getTypename();
                    break;
                case "死亡":
                    typeName[3] = swintype.get(i).getTypename();
                    break;
                case "销售":
                    typeName[4] = swintype.get(i).getTypename();
                    break;
                default:
                    break;
            }

            jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(typeName));
            jTextField23.setEnabled(false);

        }

        String type = JComboBoxString(jComboBox7);

        if (type.equals("后备母猪") || type.equals("种公猪") || type.equals("生长育肥猪")) {
            jComboBox8.setEnabled(true);
            jComboBox9.setEnabled(true);
            //所在猪舍复选框

            PiggeryMapper mapper5 = sqlSession.getMapper(PiggeryMapper.class);
            piggery = mapper5.selectAll();
            jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsShow));
            //所在栏位复选框
            jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsShow));
            sqlSession.close();
            jLabel30.setEnabled(false);
            jTextField23.setText("");
            jTextField23.setEnabled(false);

        }

    }

    public HundredTestApp(VarietiesDataPlus varietiesDataPlus, String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        flagua = "upp";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("100kg检测更改");
        jLabel00.setText("100kg检测更改");//录入，登记，更改,详情
        jButton2.setEnabled(false);
        jButton1.setText("确认更改");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
        List<HundredTest> hundredtest = hundredtestMapper.selectAll();
        HundredTest tTest = null;
        for (int i = 0; i < hundredtest.size(); i++) {
            if (hundredtest.get(i).getR_animal().equals(farmid0)) {
                tTest = hundredtest.get(i);
            }
        }
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsmap.get(tTest.getEmployeeid())));//负责人

        jTextField1.setEnabled(false);
        jTextField1.setText(tTest.getR_animal());//主键，个体编号
        jTextField2.setEnabled(false);
        jTextField2.setText(tTest.getCdrq());//测定日期
        jComboBox3.setEnabled(false);
        jComboBox3.addItem(tTest.getZsex().equals("1") ? "母" : "公");//性别

        jComboBox6.setEnabled(false);
        jComboBox6.addItem(fenceIdtoNameSmap.get(tTest.getFenceid()));//栏代码还可以关联到舍所在舍栏
        jTextField5.setText(String.valueOf(tTest.getWeight()));//体重

        PiggeryMapper piggeryMapper = sqlSession.getMapper(PiggeryMapper.class);
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(tTest.getCdzt())));//负责人
        jComboBox7.setEnabled(false);
        jComboBox8.removeAllItems();
        jComboBox8.addItem(piggeryMapper.selectByFenceId(tTest.getOutfenceid()));
        jComboBox8.setEnabled(false);

        jComboBox9.removeAllItems();
        jComboBox9.addItem(fenceIdtoNameSmap.get(tTest.getOutfenceid()));//不符合标注后备所去栏舍

        jComboBox9.setEnabled(false);
        jButton02.setEnabled(false);
        jTextField10.setEnabled(false);
        jTextField23.setEnabled(false);
        jTextField10.setText(String.valueOf(tTest.getRl()));//日龄
        jTextField11.setText(tTest.getTc());//体长
        jTextField12.setText(tTest.getTg());//体高
        jTextField13.setText(tTest.getBg());//背高
        jTextField14.setText(tTest.getXw());//胸围
        jTextField15.setText(tTest.getXs());//胸深
        jTextField16.setText(tTest.getFw());//腹围
        jTextField17.setText(tTest.getGw());//管围
        jTextField18.setText(tTest.getTtw());//退臀围
        jTextField19.setText(tTest.getHtbbh());//活体背标后
        jTextField20.setText(tTest.getHtyjmj());//活体眼机面积
        jTextField21.setText(tTest.getCddd());//测定地点
        jTextField22.setText(tTest.getBz());//备注
        jTextField23.setText(tTest.getJg());//价格
        jTextField24.setText(tTest.getBz1());//其它要点
        jTextField25.setText(tTest.getBz2());//其它要点
        jTextField26.setText(tTest.getBz3());//其它要点

        sqlSession.commit();
        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel13.setText(designbase1.getTypename());
        jLabel15.setText(designbase2.getTypename());
        jLabel16.setText(designbase3.getTypename());

        sqlSession.close();

    }

    public HundredTestApp(String farmid0, java.awt.Frame parent, boolean modal, int j) {
        super(parent, modal);
        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("100kg检测详情");
        jLabel00.setText("100kg检测详情");//录入，登记，更改,详情
        jButton1.setText("确认更改");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
        List<HundredTest> hundredtest = hundredtestMapper.selectAll();
        HundredTest tTest = null;
        for (int i = 0; i < hundredtest.size(); i++) {
            if (hundredtest.get(i).getR_animal().equals(farmid0)) {
                tTest = hundredtest.get(i);
            }
        }
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsmap.get(tTest.getEmployeeid())));//负责人
        jTextField1.setText(tTest.getR_animal());//主键，个体编号
        jTextField2.setText(tTest.getCdrq());//测定日期
        jComboBox3.addItem(tTest.getZsex().equals("1") ? "母" : "公");//性别
        jComboBox6.addItem(fenceIdtoNameSmap.get(tTest.getFenceid()));//栏代码还可以关联到舍所在舍栏
        jTextField5.setText(String.valueOf(tTest.getWeight()));//体重
        PiggeryMapper piggeryMapper = sqlSession.getMapper(PiggeryMapper.class);
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(tTest.getCdzt())));//负责人
        jComboBox8.removeAllItems();
        jComboBox8.addItem(piggeryMapper.selectByFenceId(tTest.getOutfenceid()));
        jComboBox9.removeAllItems();
        jComboBox9.addItem(fenceIdtoNameSmap.get(tTest.getOutfenceid()));//不符合标注后备所去栏舍
        jTextField10.setText(String.valueOf(tTest.getRl()));//日龄
        jTextField11.setText(tTest.getTc());//体长
        jTextField12.setText(tTest.getTg());//体高
        jTextField13.setText(tTest.getBg());//背高
        jTextField14.setText(tTest.getXw());//胸围
        jTextField15.setText(tTest.getXs());//胸深
        jTextField16.setText(tTest.getFw());//腹围
        jTextField17.setText(tTest.getGw());//管围
        jTextField18.setText(tTest.getTtw());//退臀围
        jTextField19.setText(tTest.getHtbbh());//活体背标后
        jTextField20.setText(tTest.getHtyjmj());//活体眼机面积
        jTextField21.setText(tTest.getCddd());//测定地点
        jTextField22.setText(tTest.getBz());//备注
        jTextField23.setText(tTest.getJg());//价格
        jTextField24.setText(tTest.getBz1());//其它要点
        jTextField25.setText(tTest.getBz2());//其它要点
        jTextField26.setText(tTest.getBz3());//其它要点
        sqlSession.commit();
        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel13.setText(designbase1.getTypename());
        jLabel15.setText(designbase2.getTypename());
        jLabel16.setText(designbase3.getTypename());

        sqlSession.close();

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jComboBox3.setEnabled(false);
        jComboBox4.setEnabled(false);
        jTextField5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jTextField11.setEnabled(false);
        jTextField12.setEnabled(false);
        jTextField13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jTextField16.setEnabled(false);
        jTextField17.setEnabled(false);
        jTextField18.setEnabled(false);
        jTextField19.setEnabled(false);
        jTextField20.setEnabled(false);
        jTextField21.setEnabled(false);
        jTextField22.setEnabled(false);
        jTextField23.setEnabled(false);
        jTextField24.setEnabled(false);
        jTextField25.setEnabled(false);
        jTextField26.setEnabled(false);
        jButton02.setEnabled(false);

    }

    public HundredTestApp(String farmid0, javax.swing.JDialog parent, boolean modal, int j) {
        super(parent, modal);
        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("100kg检测详情");
        jLabel00.setText("100kg检测详情");//录入，登记，更改,详情
        jButton1.setText("确认更改");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
        List<HundredTest> hundredtest = hundredtestMapper.selectAll();
        HundredTest tTest = null;
        for (int i = 0; i < hundredtest.size(); i++) {
            if (hundredtest.get(i).getR_animal().equals(farmid0)) {
                tTest = hundredtest.get(i);
            }
        }
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(employeeJSThingsmap.get(tTest.getEmployeeid())));//负责人
        jTextField1.setText(tTest.getR_animal());//主键，个体编号
        jTextField2.setText(tTest.getCdrq());//测定日期
        jComboBox3.addItem(tTest.getZsex().equals("1") ? "母" : "公");//性别
        jComboBox6.addItem(fenceIdtoNameSmap.get(tTest.getFenceid()));//栏代码还可以关联到舍所在舍栏
        jTextField5.setText(String.valueOf(tTest.getWeight()));//体重
        PiggeryMapper piggeryMapper = sqlSession.getMapper(PiggeryMapper.class);
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(tTest.getCdzt())));//负责人
         jComboBox8.removeAllItems();
        jComboBox8.addItem(piggeryMapper.selectByFenceId(tTest.getOutfenceid()));
        jComboBox9.removeAllItems();
        jComboBox9.addItem(fenceIdtoNameSmap.get(tTest.getOutfenceid()));//不符合标注后备所去栏舍
        jTextField10.setText(String.valueOf(tTest.getRl()));//日龄
        jTextField11.setText(tTest.getTc());//体长
        jTextField12.setText(tTest.getTg());//体高
        jTextField13.setText(tTest.getBg());//背高
        jTextField14.setText(tTest.getXw());//胸围
        jTextField15.setText(tTest.getXs());//胸深
        jTextField16.setText(tTest.getFw());//腹围
        jTextField17.setText(tTest.getGw());//管围
        jTextField18.setText(tTest.getTtw());//退臀围
        jTextField19.setText(tTest.getHtbbh());//活体背标后
        jTextField20.setText(tTest.getHtyjmj());//活体眼机面积
        jTextField21.setText(tTest.getCddd());//测定地点
        jTextField22.setText(tTest.getBz());//备注
        jTextField23.setText(tTest.getJg());//价格
        jTextField24.setText(tTest.getBz1());//其它要点
        jTextField25.setText(tTest.getBz2());//其它要点
        jTextField26.setText(tTest.getBz3());//其它要点
        sqlSession.commit();
        DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
        Designbase designbase1, designbase2, designbase3;
        designbase1 = mapper.selectByid("11");
        designbase2 = mapper.selectByid("12");
        designbase3 = mapper.selectByid("13");
        jLabel13.setText(designbase1.getTypename());
        jLabel15.setText(designbase2.getTypename());
        jLabel16.setText(designbase3.getTypename());

        sqlSession.close();

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jComboBox3.setEnabled(false);
        jComboBox4.setEnabled(false);
        jTextField5.setEnabled(false);
        jComboBox6.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jTextField11.setEnabled(false);
        jTextField12.setEnabled(false);
        jTextField13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jTextField16.setEnabled(false);
        jTextField17.setEnabled(false);
        jTextField18.setEnabled(false);
        jTextField19.setEnabled(false);
        jTextField20.setEnabled(false);
        jTextField21.setEnabled(false);
        jTextField22.setEnabled(false);
        jTextField23.setEnabled(false);
        jTextField24.setEnabled(false);
        jTextField25.setEnabled(false);
        jTextField26.setEnabled(false);
        jButton02.setEnabled(false);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jLabel05 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jTextField20 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jTextField21 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField22 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jTextField23 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton02 =  new DateChooserJButtonJDialog (jTextField2);
        jLabel3 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        jComboBox8 = new javax.swing.JComboBox<>();
        jComboBox9 = new javax.swing.JComboBox<>();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel00 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField24 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField26 = new javax.swing.JTextField();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel05.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel05.setText("个体编号：");
        jLabel05.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel05MouseEntered(evt);
            }
        });

        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel12.setText("负 责 人：");

        jTextField5.setText("0");
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel25.setText("体    重：");

        jLabel26.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel26.setText("测定日期：");

        jLabel33.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel33.setText("所在舍栏：");

        jLabel34.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel34.setText("性    别：");

        jTextField10.setEditable(false);
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel28.setText("日    龄：");

        jTextField11.setText("0");
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel36.setText("体    长：");

        jLabel7.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel7.setText("体    高：");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel7MouseEntered(evt);
            }
        });

        jTextField12.setText("0");
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel8.setText("背    高：");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel8MouseEntered(evt);
            }
        });

        jTextField13.setText("0");
        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel37.setText("胸    围：");

        jTextField14.setText("0");

        jLabel38.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel38.setText("胸    深：");

        jTextField15.setText("0");

        jLabel9.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel9.setText("腹    围：");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel9MouseEntered(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel27.setText("管    围：");

        jLabel35.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel35.setText("退 臀 围：");

        jTextField18.setText("0");

        jTextField17.setText("0");

        jTextField16.setText("0");
        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel10.setText("活体背膘后：");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel10MouseEntered(evt);
            }
        });

        jTextField19.setText("0");
        jTextField19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField19ActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel29.setText("活体眼机面积：");

        jTextField20.setText("0");

        jLabel39.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel39.setText("测定地点：");

        jLabel11.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel11.setText("备    注：");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel11MouseEntered(evt);
            }
        });

        jTextField22.setText("0");
        jTextField22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField22ActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel30.setText("销售价格：");

        jLabel14.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel14.setText("测定状态：");
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel14MouseEntered(evt);
            }
        });

        jLabel32.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel32.setText("所去猪舍：");

        jLabel43.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel43.setText("所去栏位：");

        jButton1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton1.setText("连续提交");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/refues.png"))); // NOI18N
        jButton2.setText("重新输入");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton3.setText("退出输入");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("*");

        jTextField2.setEditable(false);
        jTextField2.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                jTextField2CaretUpdate(evt);
            }
        });
        jTextField2.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
                jTextField2CaretPositionChanged(evt);
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                jTextField2InputMethodTextChanged(evt);
            }
        });
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jTextField2.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jTextField2PropertyChange(evt);
            }
        });
        jTextField2.addVetoableChangeListener(new java.beans.VetoableChangeListener() {
            public void vetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {
                jTextField2VetoableChange(evt);
            }
        });

        jButton02.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton02.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButton02FocusLost(evt);
            }
        });
        jButton02.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton02MouseReleased(evt);
            }
        });
        jButton02.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton02ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 0));
        jLabel3.setText("*");

        jComboBox3.setEnabled(false);
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jComboBox6.setEnabled(false);

        jComboBox8.setEnabled(false);
        jComboBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox8ActionPerformed(evt);
            }
        });

        jComboBox9.setEnabled(false);

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "后备母猪", "种公猪", "生长育肥猪", "死亡", "销售" }));
        jComboBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox7ActionPerformed(evt);
            }
        });

        jLabel00.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel00.setText("100kg检测登记");

        jLabel31.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(204, 0, 0));
        jLabel31.setText("KG");

        jLabel46.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 0, 0));
        jLabel46.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息处理");

        jLabel13.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel13.setText("备   注1：");
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel13MouseEntered(evt);
            }
        });

        jTextField24.setText("0");
        jTextField24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField24ActionPerformed(evt);
            }
        });

        jTextField25.setText("0");
        jTextField25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField25ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel15.setText("备   注2：");
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel15MouseEntered(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel16.setText("备   注3：");
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel16MouseEntered(evt);
            }
        });

        jTextField26.setText("0");
        jTextField26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField26ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel15)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jTextField25))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel10)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jTextField19))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel11)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel05)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel14)
                                            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTextField13)
                                            .addComponent(jTextField10)
                                            .addComponent(jComboBox7, 0, 141, Short.MAX_VALUE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel46)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton02, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField11)
                                    .addComponent(jComboBox8, 0, 135, Short.MAX_VALUE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(229, 229, 229)
                                .addComponent(jLabel3))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel29)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel30)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jTextField23))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel16)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jTextField26)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(92, 92, 92)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel31)))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(jTextField18, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField21))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel38)
                                .addGap(2, 2, 2)
                                .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField24)))
                        .addGap(26, 26, 26))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(217, 217, 217)
                .addComponent(jButton1)
                .addGap(31, 31, 31)
                .addComponent(jButton2)
                .addGap(31, 31, 31)
                .addComponent(jButton3)
                .addGap(217, 217, 217))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(361, 361, 361)
                .addComponent(jLabel00)
                .addGap(364, 364, 364))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel00)
                .addGap(30, 30, 30)
                .addComponent(jLabel46)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel05, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField1)
                                .addComponent(jLabel2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField13)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3)
                                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jTextField2)
                                .addGap(2, 2, 2))
                            .addComponent(jButton02, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField5)
                                    .addComponent(jLabel31))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jTextField11)
                                        .addGap(1, 1, 1)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField14)
                                    .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField16)
                        .addComponent(jTextField17))
                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField19)
                    .addComponent(jTextField20)
                    .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField24)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField22)
                        .addComponent(jTextField23))
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField25)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField26)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton3)
                        .addComponent(jButton2))
                    .addComponent(jButton1))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jLabel05MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel05MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel05MouseEntered

    private void jLabel7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseEntered

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jLabel8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseEntered

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jLabel9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseEntered

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jLabel10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel10MouseEntered

    private void jTextField19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField19ActionPerformed

    private void jLabel11MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseEntered

    private void jTextField22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField22ActionPerformed

    private void jLabel14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel14MouseEntered

    private void jButton02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton02ActionPerformed

    }//GEN-LAST:event_jButton02ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();

        jTextField5.setText("0");//体重
        jTextField11.setText("0");//体长
        jTextField12.setText("0");//体高
        jTextField13.setText("0");//背高
        jTextField14.setText("0");//胸围
        jTextField15.setText("0");//胸深
        jTextField16.setText("0");//腹围
        jTextField17.setText("0");//管围
        jTextField18.setText("0");//退臀围
        jTextField19.setText("0");//活体背标后
        jTextField20.setText("0");//活体眼机面积
        jTextField21.setText("");//测定地点
        jTextField22.setText("");//备注
        jTextField23.setText("");//价格
        jTextField23.setEnabled(false);

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JTable jTable1 = varietiesDataPlus.getjTable1();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        String number = jTextField1.getText();
        //｛提取猪之编号
        if (number.length() != 15 && number.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加个体编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Selebith selebith = mapper0.selectById("%" + number);

        if (selebith == null) {
            JOptionPane.showMessageDialog(null, "您添加个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getR_curmark().equals("4") != true) {
            JOptionPane.showMessageDialog(null, "当前不是后备猪", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在

        if (flagua.equals("add")) {
            String type = JComboBoxString(jComboBox7);
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            List<HundredTest> tw = hundredtestMapper.selectAll();
            for (int i = 0; i < tw.size(); i++) {
                if (tw.get(i).getR_animal().equals(selebith.getR_animal())) {
                    JOptionPane.showMessageDialog(null, "添加失败！已存在相同主键", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    sqlSession.close();
                    return;
                }
            }

            sqlSession.commit();
            if (selebith != null) {
                if (type.equals("后备母猪") || type.equals("种公猪") && selebith.getIftwo().equals("1") && selebith.getIffour().equals("1") && selebith.getIfsix().equals("1") && selebith.getIf100kg().equals("0")) {
                    HundredTestMapper hundredTest = sqlSession.getMapper(HundredTestMapper.class);
                    HundredTest tTest = new HundredTest();
                    tTest.setR_animal(selebith.getR_animal());  //主键，个体编号
                    tTest.setCdrq(jTextField2.getText());//测定日期
                    tTest.setZsex(JComboBoxString(jComboBox3).equals("母") ? "1" : "0");//性别
                    tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
                    tTest.setWeight(Double.parseDouble(jTextField5.getText())); //体重
                    tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                    tTest.setCddd(jTextField21.getText());//测定地点
                    tTest.setRl(Integer.parseInt(jTextField10.getText()));//日龄（测定日期-出生日期）
                    tTest.setTc(jTextField11.getText()); //体长
                    tTest.setTg(jTextField12.getText());//体高
                    tTest.setBg(jTextField13.getText()); //背高
                    tTest.setXw(jTextField14.getText());//胸围
                    tTest.setXs(jTextField15.getText());//胸深
                    tTest.setFw(jTextField16.getText());//腹围
                    tTest.setGw(jTextField17.getText()); //管围
                    tTest.setTtw(jTextField18.getText());//退臀围
                    tTest.setHtbbh(jTextField19.getText()); //活体背膘厚
                    tTest.setHtyjmj(jTextField20.getText());//活体眼肌面积
                    tTest.setOutfenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox9))); //不再是后备所去栏舍
                    tTest.setCdzt(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备母猪2种公猪 3生长育肥3死亡4销售
                    tTest.setBz(jTextField22.getText()); //备注
                    tTest.setBz1(jTextField24.getText());//备注
                    tTest.setBz2(jTextField25.getText());//备注
                    tTest.setBz3(jTextField26.getText());//备注
                    int i = hundredTest.insert(tTest);//
                    sqlSession.commit();
                    SelebithMapper twoU = sqlSession.getMapper(SelebithMapper.class);
                    ShengZYF sz = new ShengZYF();
                    sz.setR_animal(selebith.getR_animal());
                    sz.setIftwo("1");//100kg
                    sz.setSfzz("1");
                    sz.setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox9)));//后背所去栏
                    sz.setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//状态
                    twoU.updateHundred(sz);
                    sqlSession.commit();
                    sqlSession.close();

                    JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
                    model.addRow(rowInsert);
                    jTable1.setModel(model);
                    varietiesDataPlus.validate();
                    MainApp.hundredTestPageModel = new HundredTestPageModel(14, hundredTestMapperPlus.SelectCount(), hundredTestMapperPlus, false);
                    MainApp.HundredTestpage(MainApp.hundredTestPageModel.getBottomPageNo());

                }
                if (type.equals("死亡") || type.equals("销售")) {

                    HundredTestMapper hundredTest = sqlSession.getMapper(HundredTestMapper.class);
                    HundredTest tTest = new HundredTest();
                    tTest.setR_animal(selebith.getR_animal());  //主键，个体编号
                    tTest.setCdrq(jTextField2.getText());//测定日期
                    tTest.setZsex(JComboBoxString(jComboBox3).equals("母") ? "1" : "0");//性别
                    tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
                    tTest.setWeight(Double.parseDouble(jTextField5.getText())); //体重
                    tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                    tTest.setCddd(jTextField21.getText());//测定地点
                    tTest.setRl(Integer.parseInt(jTextField10.getText()));//日龄（测定日期-出生日期）
                    tTest.setTc(jTextField11.getText()); //体长
                    tTest.setTg(jTextField12.getText());//体高
                    tTest.setBg(jTextField13.getText()); //背高
                    tTest.setXw(jTextField14.getText());//胸围
                    tTest.setXs(jTextField15.getText());//胸深
                    tTest.setFw(jTextField16.getText());//腹围
                    tTest.setGw(jTextField17.getText()); //管围
                    tTest.setTtw(jTextField18.getText());//退臀围
                    tTest.setHtbbh(jTextField19.getText()); //活体背膘厚
                    tTest.setHtyjmj(jTextField20.getText());//活体眼肌面积
                    tTest.setOutfenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox9))); //不再是后备所去栏舍
                    tTest.setCdzt(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备母猪2种公猪 3生长育肥3死亡4销售
                    tTest.setBz(jTextField22.getText()); //备注
                    tTest.setBz1(jTextField24.getText());//备注
                    tTest.setBz2(jTextField25.getText());//备注
                    tTest.setBz3(jTextField26.getText());//备注
                    if (type.equals("销售")) {
                        tTest.setJg(jTextField23.getText());//销售价格
                    }
                    int i = hundredTest.insert(tTest);//
                    sqlSession.commit();
                    SelebithMapper twoU = sqlSession.getMapper(SelebithMapper.class);

                    if (type.equals("死亡")) {
                        twoU.updateZTT(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)), jTextField1.getText(), jTextField2.getText());
                    } else {
                        twoU.updateZT(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)), jTextField1.getText(), jTextField2.getText());
                    }
                    sqlSession.commit();
                    sqlSession.close();
                    JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
                    model.addRow(rowInsert);
                    jTable1.setModel(model);
                    varietiesDataPlus.validate();
                    MainApp.hundredTestPageModel = new HundredTestPageModel(14, hundredTestMapperPlus.SelectCount(), hundredTestMapperPlus, false);
                    MainApp.HundredTestpage(MainApp.hundredTestPageModel.getBottomPageNo());
                }
                if (type.equals("生长育肥猪")) {
                    HundredTestMapper hundredTest = sqlSession.getMapper(HundredTestMapper.class);
                    HundredTest tTest = new HundredTest();
                    tTest.setR_animal(selebith.getR_animal());  //主键，个体编号
                    tTest.setCdrq(jTextField2.getText());//测定日期
                    tTest.setZsex(JComboBoxString(jComboBox3).equals("母") ? "1" : "0");//性别
                    tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
                    tTest.setWeight(Double.parseDouble(jTextField5.getText())); //体重
                    tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                    tTest.setCddd(jTextField21.getText());//测定地点
                    tTest.setRl(Integer.parseInt(jTextField10.getText()));//日龄（测定日期-出生日期）
                    tTest.setTc(jTextField11.getText()); //体长
                    tTest.setTg(jTextField12.getText());//体高
                    tTest.setBg(jTextField13.getText()); //背高
                    tTest.setXw(jTextField14.getText());//胸围
                    tTest.setXs(jTextField15.getText());//胸深
                    tTest.setFw(jTextField16.getText());//腹围
                    tTest.setGw(jTextField17.getText()); //管围
                    tTest.setTtw(jTextField18.getText());//退臀围
                    tTest.setHtbbh(jTextField19.getText()); //活体背膘厚
                    tTest.setHtyjmj(jTextField20.getText());//活体眼肌面积
                    tTest.setOutfenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox9))); //不再是后备所去栏舍
                    tTest.setCdzt(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备母猪2种公猪 3生长育肥3死亡4销售
                    tTest.setBz(jTextField22.getText()); //备注
                    tTest.setBz1(jTextField24.getText());//备注
                    tTest.setBz2(jTextField25.getText());//备注
                    tTest.setBz3(jTextField26.getText());//备注
                    int i = hundredTest.insert(tTest);//
                    sqlSession.commit();
                    SelebithMapper twoU = sqlSession.getMapper(SelebithMapper.class);
                    ShengZYF sz = new ShengZYF();
                    sz.setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox7)));//1后备 2死亡 3销售4生长育肥
                    sz.setR_animal(number);//个体号
                    sz.setHyafenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox9)));//转后
                    sz.setHyffenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//转前
                    sz.setHyfzr(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
                    sz.setHysj(jTextField2.getText());//日期
                    sz.setIftwo("1");//二月
                    sz.setNifhb("1");//是否转 1
                    sz.setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox9)));//后背所去栏
                    twoU.updateH(sz);
                    sqlSession.commit();
                    sqlSession.close();
                    JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
                    model.addRow(rowInsert);
                    jTable1.setModel(model);
                    varietiesDataPlus.validate();
                    MainApp.hundredTestPageModel = new HundredTestPageModel(14, hundredTestMapperPlus.SelectCount(), hundredTestMapperPlus, false);
                    MainApp.HundredTestpage(MainApp.hundredTestPageModel.getBottomPageNo());
                }

            } else {
                JOptionPane.showMessageDialog(null, "请输入正确的个体编号", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                sqlSession.close();
                return;
            }
        }
        if (flagua.equals("upp")) {
            HundredTestMapper hundredTest = sqlSession.getMapper(HundredTestMapper.class);
            HundredTest tTest = new HundredTest();
            tTest.setR_animal(selebith.getR_animal());  //主键，个体编号
            tTest.setCdrq(jTextField2.getText());//测定日期

            tTest.setZsex(JComboBoxString(jComboBox3).equals("母") ? "1" : "0");//性别
            tTest.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox6)));//栏代码还可以关联到舍所在舍栏
            tTest.setWeight(Double.parseDouble(jTextField5.getText())); //体重

            tTest.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox4)));//负责人
            tTest.setCddd(jTextField21.getText());//测定地点
            tTest.setTc(jTextField11.getText()); //体长
            tTest.setTg(jTextField12.getText());//体高
            tTest.setBg(jTextField13.getText()); //背高
            tTest.setXw(jTextField14.getText());//胸围
            tTest.setXs(jTextField15.getText());//胸深
            tTest.setFw(jTextField16.getText());//腹围
            tTest.setGw(jTextField17.getText()); //管围
            tTest.setTtw(jTextField18.getText());//退臀围
            tTest.setHtbbh(jTextField19.getText()); //活体背膘厚
            tTest.setHtyjmj(jTextField20.getText());//活体眼肌面积
            tTest.setBz(jTextField22.getText()); //备注
            tTest.setJg(jTextField23.getText());//销售价格
            tTest.setBz1(jTextField24.getText());//备注
            tTest.setBz2(jTextField25.getText());//备注
            tTest.setBz3(jTextField26.getText());//备注
            hundredTest.updateByid(tTest);
            sqlSession.commit();
            sqlSession.close();
            JOptionPane.showMessageDialog(null, "修改成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            model.removeRow(jTable1.getSelectedRow());
            Object[] rowInsert = new Object[]{tTest.getR_animal(), tTest.getCdrq(), tTest.getZsex().equals("1") ? "母" : "公", tTest.getWeight(), fenceIdtoNameSmap.get(tTest.getFenceid()), employeeIdtoNameSmap.get(tTest.getEmployeeid())};
            model.addRow(rowInsert);
            jTable1.setModel(model);
            varietiesDataPlus.validate();

            System.gc();
            dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));

        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        // TODO add your handling code here:

        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        String number = jTextField1.getText();
        if (number.length() != 15 && number.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加个体编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Selebith selebith = mapper0.selectById("%" + number);

        if (selebith == null) {
            JOptionPane.showMessageDialog(null, "您添加的个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在

        if (selebith.getR_curmark().equals("4") != true) {
            JOptionPane.showMessageDialog(null, "当前不是后备猪", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getIftwo().equals("0") == true) {
            JOptionPane.showMessageDialog(null, "此猪二月没测", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getIffour().equals("0") == true) {
            JOptionPane.showMessageDialog(null, "此猪四月没测", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getIfsix().equals("0") == true) {
            JOptionPane.showMessageDialog(null, "此猪六月没测", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }
        if (selebith.getIf100kg().equals("0") != true) {
            JOptionPane.showMessageDialog(null, "此猪100kg已测", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            sqlSession.close();
            return;
        }

        String lanHao = selebith.getR_pcage();

        FenceMapper fenceMapper = sqlSession.getMapper(FenceMapper.class);
        Fence fence = fenceMapper.selectByFenceid(lanHao);
        String fenceName[] = {fence.getFencename()};
        String[] selebithSex = {selebith.getR_sex().equals("1") ? "母" : "公"};
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(fenceName));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(selebithSex));
        jTextField10.setText(String.valueOf(calInterval(selebith.getR_fdate(), NowTime())));
        sqlSession.close();
    }//GEN-LAST:event_jTextField1FocusLost

    private void jComboBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox7ActionPerformed
        // TODO add your handling code here:
        String type = JComboBoxString(jComboBox7);

        if (type.equals("后备母猪") || type.equals("种公猪") || type.equals("生长育肥猪")) {
            jComboBox8.setEnabled(true);
            jComboBox9.setEnabled(true);
            //｛所在猪舍复选框
            SqlSession sqlSession = MybatisUtil.getSqlSession();

            PiggeryMapper mapper5 = sqlSession.getMapper(PiggeryMapper.class);
            piggery = mapper5.selectAll();
            String[] things5 = new String[piggery.size()];
            for (int i = 0; i < piggery.size(); i++) {
                things5[i] = piggery.get(i).getCategory();

            }
            jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(things5));
            //｝所在猪舍复选框 
            //｛所在栏位复选框
            FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
            List<Fence> fence = mapper6.selectAllById(piggery.get(0).getNumber());
            String[] things6 = new String[fence.size()];
            for (int i = 0; i < fence.size(); i++) {
                things6[i] = fence.get(i).getFencename();

            }
            jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things6));
            //｝所在栏位复选框 
            sqlSession.close();
            jTextField23.setText("");
            jTextField23.setEnabled(false);

        } else if (type.equals("销售")) {
            jTextField23.setEnabled(true);
            jComboBox8.removeAllItems();
            jComboBox9.removeAllItems();
            jComboBox8.setEnabled(false);
            jComboBox9.setEnabled(false);
        } else {
            jComboBox8.removeAllItems();
            jComboBox9.removeAllItems();
            jComboBox8.setEnabled(false);
            jComboBox9.setEnabled(false);
            jTextField23.setText("");
            jTextField23.setEnabled(false);

        }
    }//GEN-LAST:event_jComboBox7ActionPerformed

    private void jComboBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox8ActionPerformed
        String id = piggeryNametoIdSmap.get(JComboBoxString(jComboBox8));
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);

        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();

    }//GEN-LAST:event_jComboBox8ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jButton02FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButton02FocusLost
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton02FocusLost

    private void jTextField2InputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jTextField2InputMethodTextChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_jTextField2InputMethodTextChanged

    private void jTextField2CaretPositionChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jTextField2CaretPositionChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_jTextField2CaretPositionChanged

    private void jTextField2PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jTextField2PropertyChange
        // TODO add your handling code here:

    }//GEN-LAST:event_jTextField2PropertyChange

    private void jTextField2VetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {//GEN-FIRST:event_jTextField2VetoableChange
        // TODO add your handling code here:

    }//GEN-LAST:event_jTextField2VetoableChange

    private void jTextField2CaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_jTextField2CaretUpdate

    }//GEN-LAST:event_jTextField2CaretUpdate

    private void jLabel13MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel13MouseEntered

    private void jTextField24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField24ActionPerformed

    private void jTextField25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField25ActionPerformed

    private void jLabel15MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel15MouseEntered

    private void jLabel16MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel16MouseEntered

    private void jTextField26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField26ActionPerformed

    private void jButton02MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton02MouseReleased
        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        String number = jTextField1.getText();
        if (number.length() != 15 && number.length() != 8) {
            return;
        }
        Selebith selebith = mapper0.selectById("%" + number);

        //｝提取猪之编号,并查询种公猪个体编号是否存在
        if (selebith != null&&(!jTextField2.getText().equals(""))) {
            jTextField2.getText();
            selebith.getR_fdate();
            jTextField10.setText(String.valueOf(calInterval(selebith.getR_fdate(), jTextField2.getText())));

        }
        sqlSession.close();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton02MouseReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton02;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JLabel jLabel05;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
