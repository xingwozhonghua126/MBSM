package cn.archer.app;

import cn.archer.mapper.plus.TjMapperPlus;
import cn.archer.tj.TjzczsTJ;
import cn.archer.tj.PzfmlTJ;
import cn.archer.tj.PzfqlTJ;
import cn.archer.mapper.BoarMapper;
import cn.archer.mapper.BreedingMapper;
import cn.archer.mapper.ChildbirthMapper;
import cn.archer.mapper.ConservationTurnBackPigMapper;
import cn.archer.mapper.ConservationTurnFatteningPigMapper;
import cn.archer.mapper.DesignbaseMapper;
import cn.archer.mapper.EmployeeMapper;
import cn.archer.mapper.FarmNameMapper;
import cn.archer.mapper.FeedingTurnConservationPigMapper;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.FourTestMapper;
import cn.archer.mapper.HundredTestMapper;
import cn.archer.mapper.JbzlMapper;
import cn.archer.mapper.JqqyjyMapper;
import cn.archer.mapper.JyjcMapper;
import cn.archer.mapper.LineherdMapper;
import cn.archer.mapper.LinesMapper;
import cn.archer.mapper.MyszMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.mapper.PigjbMapper;
import cn.archer.mapper.PigslMapper;
import cn.archer.mapper.PigypMapper;
import cn.archer.mapper.RemindMapper;
import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.mapper.SixTestMapper;
import cn.archer.mapper.SlckMapper;
import cn.archer.mapper.SlkcMapper;
import cn.archer.mapper.SllbMapper;
import cn.archer.mapper.SlrkMapper;
import cn.archer.mapper.SwintypeMapper;
import cn.archer.mapper.TakespermMapper;
import cn.archer.mapper.TwoTestMapper;
import cn.archer.mapper.TzxncdMapper;
import cn.archer.mapper.VaccineMapper;
import cn.archer.mapper.WeaningMapper;
import cn.archer.mapper.YgzwMapper;
import cn.archer.mapper.YmckMapper;
import cn.archer.mapper.YmkcMapper;
import cn.archer.mapper.YmrkMapper;
import cn.archer.mapper.YpckMapper;
import cn.archer.mapper.YpkcMapper;
import cn.archer.mapper.YprkMapper;
import cn.archer.mapper.ZslbMapper;
import cn.archer.mapper.ZzmyMapper;
import cn.archer.mapper.ZzmyszMapper;
import cn.archer.mapper.ZzswMapper;
import cn.archer.mapper.ZzxsMapper;
import cn.archer.mapper.plus.BreedingMapperPlus;
import cn.archer.model.BreedingPageModel;
import cn.archer.mapper.plus.ChildbirthMapperPlus;
import cn.archer.model.ChildbirthPageModel;
import cn.archer.mapper.plus.ConservationTurnBackMapperPlus;
import cn.archer.model.ConservationTurnBackPageModel;
import cn.archer.mapper.plus.ConservationTurnFattingMapperPlus;
import cn.archer.model.ConservationTurnFattingPageModel;
import cn.archer.mapper.plus.FeedingTurnConservationMapperPlus;
import cn.archer.model.FeedingTurnConservationPageModel;
import cn.archer.mapper.plus.FemaleBoarMapperPlus;
import cn.archer.model.FemaleBoarPageModel;
import cn.archer.mapper.plus.FourTestMapperPlus;
import cn.archer.model.FourTestPageModel;
import cn.archer.mapper.plus.HundredTestMapperPlus;
import cn.archer.model.HundredTestPageModel;
import cn.archer.mapper.plus.JbzlMapperPlus;
import cn.archer.mapper.plus.JqqyjyMapperPlus;
import cn.archer.model.JbzlPageModel;
import cn.archer.mapper.plus.JyjcMapperPlus;
import cn.archer.model.JyjcPageModel;
import cn.archer.mapper.plus.MaleBoarMapperPlus;
import cn.archer.model.MaleBoarPageModel;
import cn.archer.mapper.plus.SelethMapperPlus;
import cn.archer.model.SelethPageModel;
import cn.archer.mapper.plus.SixTestMapperPlus;
import cn.archer.model.SixTestPageModel;
import cn.archer.mapper.plus.SlckMapperPlus;
import cn.archer.model.SlckPageModel;
import cn.archer.mapper.plus.SlrkMapperPlus;
import cn.archer.model.SlrkPageModel;
import cn.archer.mapper.plus.TakespermMapperPlus;
import cn.archer.model.TakespermPageModel;
import cn.archer.mapper.plus.TwoTestMapperPlus;
import cn.archer.model.TwoTestPageModel;
import cn.archer.mapper.plus.TzxncdMapperPlus;
import cn.archer.model.TzxncdPageModel;
import cn.archer.mapper.plus.WeaningMapperPlus;
import cn.archer.mapper.plus.XzxpMapperPlus;
import cn.archer.model.WeaningPageModel;
import cn.archer.model.YmckPageModel;
import cn.archer.model.YmrkPageModel;
import cn.archer.mapper.plus.YpckMapperPlus;
import cn.archer.model.YpckPageModel;
import cn.archer.mapper.plus.YprkMapperPlus;
import cn.archer.model.YprkPageModel;
import cn.archer.mapper.plus.ZzmyMapperPlus;
import cn.archer.model.ZzmyPageModel;
import cn.archer.mapper.plus.ZzswMapperPlus;
import cn.archer.model.ZzswPageModel;
import cn.archer.mapper.plus.ZzxsMapperPlus;
import cn.archer.model.ZzxsPageModel;
import cn.archer.mapper.plus.YmckMapperPlus;
import cn.archer.mapper.plus.YmrkMapperPlus;
import cn.archer.mapper.plus.YzMapperPlus;
import cn.archer.model.PageModel;
import cn.archer.model.YzFourtestPageModel;
import cn.archer.model.YzHundredtestPageModel;
import cn.archer.model.YzSixtestPageModel;
import cn.archer.model.YzTwotestPageModel;
import cn.archer.model.YzgtxxPageModel;
import cn.archer.pojo.Designbase;
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Data;
import cn.archer.pojo.Employee;
import cn.archer.pojo.FarmName;
import cn.archer.pojo.Fence;
import cn.archer.pojo.FourTest;
import cn.archer.pojo.HundredTest;
import cn.archer.pojo.Jbzl;
import cn.archer.pojo.Jyjc;
import cn.archer.pojo.Lineherd;
import cn.archer.pojo.Lines;
import cn.archer.pojo.Mysz;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Pigjb;
import cn.archer.pojo.Pigsl;
import cn.archer.pojo.Pigyp;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.SixTest;
import cn.archer.pojo.Slck;
import cn.archer.pojo.Slkc;
import cn.archer.pojo.Sllb;
import cn.archer.pojo.Slrk;
import cn.archer.pojo.Swintype;
import cn.archer.pojo.Takesperm;
import cn.archer.pojo.TwoTest;
import cn.archer.pojo.Tzxncd;
import cn.archer.pojo.Vaccine;
import cn.archer.pojo.Ygzw;
import cn.archer.pojo.Ymck;
import cn.archer.pojo.Ymkc;
import cn.archer.pojo.Ymrk;
import cn.archer.pojo.Ypck;
import cn.archer.pojo.Ypkc;
import cn.archer.pojo.Yprk;
import cn.archer.pojo.Zslb;
import cn.archer.pojo.Zzmy;
import cn.archer.pojo.Zzmysz;
import cn.archer.pojo.Zzsw;
import cn.archer.pojo.Zzxs;
import cn.archer.tj.ByqchlTJ;
import cn.archer.tj.CshtgsTJ;
import cn.archer.tj.CshtgzTJ;
import cn.archer.tj.DngtzTJ;
import cn.archer.tj.DnzzchlTJ;
import cn.archer.tj.JdlrbTJ;
import cn.archer.tj.Plxz;
import cn.archer.tj.SlckTJ;
import cn.archer.tj.SlrkTJ;
import cn.archer.tj.TjdnhzsTJ;
import cn.archer.tj.TjhczsTJ;
import cn.archer.tj.Xzxp;
import cn.archer.tj.YfqchlTJ;
import cn.archer.tj.YmckTJ;
import cn.archer.tj.YmrkTJ;
import cn.archer.tj.YpckTJ;
import cn.archer.tj.YprkTJ;
import cn.archer.tj.Yzfx;
import cn.archer.tj.ZzswTJ;
import cn.archer.tj.ZzxsTJ;
import static cn.archer.utils.MyStaticMethod.NowTime;
import cn.archer.utils.DateChooserJButton;
import cn.archer.utils.ExcelWrite_jxl;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import static cn.archer.utils.MyStaticMethod.FileWrite_Overwrite;
import cn.archer.utils.MybatisUtil;
import java.awt.FileDialog;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import jxl.write.WriteException;
import org.apache.ibatis.session.SqlSession;
import static cn.archer.utils.MyStaticMethod.SsFence;
import static cn.archer.utils.MyStaticMethod.addDate;
import static cn.archer.utils.MyStaticMethod.minusDate;
import cn.archer.utils.PrintData;
import static cn.archer.utils.PrintImage.printImage;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import javax.imageio.ImageIO;
import javax.swing.JInternalFrame;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author Administrator
 */
public class MainApp extends javax.swing.JFrame {

    private static List<Selebith> changepages;
    public static HashMap<String, String> lineidIdtoNameSmap;
    public static HashMap<String, String[]> linesThingsmap;
    public static HashMap<String, String> linesNametoIdSmap;

    public static HashMap<String, String> lineherdIdtoNameSmap;
    public static HashMap<String, String[]> lineherdThingsmap;
    public static HashMap<String, String> lineherdNametoIdSmap;

    public static HashMap<String, String> swintypeIdtoNameSmap;
    public static HashMap<String, String[]> swintypeThingsmap;
    public static HashMap<String, String> swintypeNametoIdSmap;
    public static String[] swintypeThingsShow;

    public static HashMap<String, String> fenceIdtoNameSmap;
    public static HashMap<String, String[]> fenceThingsmap;
    public static HashMap<String, String> fenceNametoIdSmap;
    public static String[] fenceThingsShow;

    public static HashMap<String, String> employeeIdtoNameSmap;
    public static HashMap<String, String[]> employeeGLYThingsmap;
    public static HashMap<String, String[]> employeeSYYThingsmap;
    public static HashMap<String, String[]> employeePZYThingsmap;
    public static HashMap<String, String[]> employeeSYThingsmap;
    public static HashMap<String, String[]> employeeCKThingsmap;
    public static HashMap<String, String[]> employeeXSThingsmap;
    public static HashMap<String, String[]> employeeJSThingsmap;
    public static HashMap<String, String[]> employeeThingsmap;
    public static HashMap<String, String> employeeNametoIdSmap;
    public static String[] employeeGLYThingsShow;
    public static String[] employeeSYYThingsShow;
    public static String[] employeePZYThingsShow;
    public static String[] employeeSYThingsShow;
    public static String[] employeeCKThingsShow;
    public static String[] employeeXSThingsShow;
    public static String[] employeeJSThingsShow;
    public static String[] employeeThingsShowPlus;
    public static String[] employeeThingsShow;

    public static HashMap<String, String> piggeryIdtoNameSmap;
    public static HashMap<String, String[]> piggeryThingsmap;
    public static HashMap<String, String> piggeryNametoIdSmap;
    public static String[] piggeryThingsShow;

    public static HashMap<String, String> pigslIdtoNameSmap;
    public static HashMap<String, String[]> pigslThingsmap;
    public static HashMap<String, String> pigslNametoIdSmap;
    public static String[] pigslThingsShow;

    public static String[] pigSllbThingsShow;
    public static String[] pigslSLLBThingsShow;
    public static String[] pigslBRZZThingsShow;
    public static String[] pigslBYZThingsShow;
    public static String[] pigslSZYFZThingsShow;
    public static String[] pigslHBZThingsShow;
    public static String[] pigslHBMZThingsShow;
    public static String[] pigslRSMZThingsShow;
    public static String[] pigslBRMZThingsShow;
    public static String[] pigslKHMZThingsShow;
    public static String[] pigslZGZThingsShow;

    public static HashMap<String, String> pigypIdtoNameSmap;
    public static HashMap<String, String[]> pigypThingsmap;
    public static HashMap<String, String> pigypNametoIdSmap;
    public static String[] pigypThingsShow;

    public static HashMap<String, String> pigjbIdtoNameSmap;
    public static HashMap<String, String[]> pigjbThingsmap;
    public static HashMap<String, String> pigjbNametoIdSmap;
    public static String[] pigjbThingsShow;

    public static HashMap<String, String> vaccineIdtoNameSmap;
    public static HashMap<String, String[]> vaccineThingsmap;
    public static HashMap<String, String> vaccineNametoIdSmap;
    public static String[] vaccineThingsShow;

    public static HashMap<String, String> farmIdtoNameSmap;
    public static HashMap<String, String[]> farmThingsmap;
    public static HashMap<String, String> farmNametoIdSmap;
    public static String[] farmThingsShow;

    public static HashMap<String, String> sllbListIdtoNameSmap;
    public static HashMap<String, String[]> sllbListThingsmap;
    public static HashMap<String, String> sllbListNametoIdSmap;
    public static String[] sllbListThingsShow;

    public static String[] pigCategoryThingsShow;
    public static String[] pigBYCategoryThingsShow;
    public static String[] pigYFCategoryThingsShow;
    public static String[] pigHBCategoryThingsShow;
    public static String[] pigBRZZCategoryThingsShow;
    public static String[] pigFenceThingsShow;
    public static String[] pigSwintypeThingsShow;
    public static String[] pigYpThingsShow;
    public static String[] pigYmThingsShow;
    /**
     * Creates new form MainApp
     */
    private boolean ssf;//是否搜索
    private static VarietiesData varietiesData;
    private static VarietiesDataPlus varietiesDataPlus;
    static String outsideLabel;

    public static PageModel pageModel;
    public static SelethPageModel selebithPageModel;
    public static TakespermPageModel takespermPageModel;
    public static BreedingPageModel breedingPageModel;
    public static ChildbirthPageModel childbirthPageModel;
    public static WeaningPageModel weaningPageModel;
    public static FemaleBoarPageModel femaleBoarPageModel;
    public static MaleBoarPageModel maleBoarPageModel;
    public static SlrkPageModel slrkPageModel;
    public static SlckPageModel slckPageModel;
    public static YprkPageModel yprkPageModel;
    public static YpckPageModel ypckPageModel;
    public static YmrkPageModel ymrkPageModel;
    public static YmckPageModel ymckPageModel;
    public static ZzmyPageModel zzmyPageModel;
    public static JbzlPageModel jbzlPageModel;
    public static JyjcPageModel jyjcPageModel;
    public static TzxncdPageModel tzxncdPageModel;
    public static ZzxsPageModel zzxsPageModel;
    public static ZzswPageModel zzswPageModel;
    public static TwoTestPageModel twoTestPageModel;
    public static FourTestPageModel fourTestPageModel;
    public static SixTestPageModel sixTestPageModel;
    public static HundredTestPageModel hundredTestPageModel;
    public static ConservationTurnFattingPageModel conservationTurnFattingPageModel;
    public static ConservationTurnBackPageModel conservationTurnBackPageModel;
    public static FeedingTurnConservationPageModel feedingTurnConservationPageModel;
    public static YzgtxxPageModel yzgtxxPageModel;
    public static YzTwotestPageModel yzTwotestPageModel;
    public static YzFourtestPageModel yzFourtestPageModel;
    public static YzSixtestPageModel yzSixtestPageModel;
    public static YzHundredtestPageModel yzHundredtestPageModel;
    //搜索条件
    private String zzzt;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String pignum;
    private FileDialog saveDia;

    public static SelethMapperPlus selethMapperPlus;
    public static TakespermMapperPlus takespermMapperPlus;
    public static BreedingMapperPlus breedingMapperPlus;
    public static ChildbirthMapperPlus childbirthMapperPlus;
    public static WeaningMapperPlus weaningMapperPlus;
    public static ConservationTurnFattingMapperPlus conservationTurnFattingMapperPlus;
    public static ConservationTurnBackMapperPlus conservationTurnBackMapperPlus;
    public static FeedingTurnConservationMapperPlus feedingTurnConservationMapperPlus;
    public static MaleBoarMapperPlus maleBoarMapperPlus;
    public static FemaleBoarMapperPlus famaleBoarMapperPlus;
    public static TwoTestMapperPlus twoTestMapperPlus;
    public static FourTestMapperPlus fourTestMapperPlus;
    public static SixTestMapperPlus sixTestMapperPlus;
    public static HundredTestMapperPlus hundredTestMapperPlus;
    public static SlrkMapperPlus slrkMapperPlus;
    public static SlckMapperPlus slckMapperPlus;
    public static YprkMapperPlus yprkMapperPlus;
    public static YpckMapperPlus ypckMapperPlus;
    public static YmrkMapperPlus ymrkMapperPlus;
    public static YmckMapperPlus ymckMapperPlus;
    public static ZzmyMapperPlus zzmyMapperPlus;
    public static JbzlMapperPlus jbzlMapperPlus;
    public static TzxncdMapperPlus tzxncdMapperPlus;
    public static ZzxsMapperPlus zzxsMapperPlus;
    public static ZzswMapperPlus zzswMapperPlus;
    public static JyjcMapperPlus jyjcMapperPlus;
    public static JqqyjyMapperPlus jqqyjyMapperPlus;
    public static TjMapperPlus tjMapperPlus;
    public static YzMapperPlus yzMapperPlus;

    private static PzfmlTJ pzfmlTJ;
    private static PzfqlTJ pzfqlTJ;
    private static TjzczsTJ tjzczsTJ;
    private static ByqchlTJ byqchlTJ;
    private static CshtgsTJ cshtgsTJ;
    private static CshtgzTJ cshtgzTJ;
    private static DngtzTJ dngtzTJ;
    private static DnzzchlTJ dnzzchlTJ;
    private static JdlrbTJ jdlrbTj;
    private static SlckTJ slckTJ;
    private static SlrkTJ slrkTJ;
    private static TjdnhzsTJ tjdnhzsTJ;
    private static TjhczsTJ tjhczsTJ;
    private static YfqchlTJ yfqchlTJ;
    private static YmckTJ ymckTJ;
    private static YmrkTJ ymrkTJ;
    private static YpckTJ ypckTJ;
    private static YprkTJ yprkTJ;
    private static ZzswTJ zzswTJ;
    private static ZzxsTJ zzxsTJ;
    private static LctApp lctApp;
    private static Yzfx yzfx;
    private static Xzxp xzxp;
    private static Plxz plxz;
    public static List<String> BYPiggeryList;
    public static List<String> YFPiggeryList;
    public static List<String> HBPiggeryList;
    public static List<String> BRZZPiggeryList;

    public static List<String> SLLBpigslList;
    public static List<String> BRZZpigslList;
    public static List<String> BYZpigslList;
    public static List<String> SZYFZpigslList;
    public static List<String> HBZpigslList;
    public static List<String> HBMZpigslList;
    public static List<String> RSMZpigslList;
    public static List<String> BRMZpigslList;
    public static List<String> KHMZpigslList;
    public static List<String> ZGZpigslList;

    private static String[] kongString;
    public static Employee nowEmployee;
    private static ControlApp controlApp;
    private static PrintData printData;

    private static List<FarmName> farmName;
    private static List<Lines> linesList;
    private static List<Sllb> sllbList;
    private static List<Pigsl> pigslList;
    private static List<Zslb> zslbList;
    private static List<Swintype> swintypeList;
    private static List<Piggery> piggeryList;
    private static List<Lineherd> lineherdList;
    private static List<Pigyp> pigypList;
    private static List<Vaccine> vaccineList;
    private static List<Mysz> myszList;
    private static List<Zzmysz> zzmyszList;
    private static List<Pigjb> pigjbList;
    private static List<Designbase> designbaselist;
    private static List<Fence> fenceList;
    private static List<Ygzw> ygzwList;
    private static List<Employee> employeeList;
    private static List<Slkc> slkcList;
    private static List<Ypkc> ypkcList;
    private static List<Ymkc> ymkcList;
    private static List<Selebith> selebithList;

    public Employee getNowEmployee() {
        return nowEmployee;
    }

    public void setNowEmployee(Employee nowEmployee) {
        this.nowEmployee = nowEmployee;
    }

    public MainApp(ControlApp controlApp) {
        initComponents();
        setLocationRelativeTo(controlApp);
        this.setResizable(false);
        this.controlApp = controlApp;
        //全部舍
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PiggeryMapper mapper3 = sqlSession.getMapper(PiggeryMapper.class);
            piggeryList = mapper3.selectAll();
        }
        BYPiggeryList = new ArrayList<>();
        YFPiggeryList = new ArrayList<>();
        HBPiggeryList = new ArrayList<>();
        BRZZPiggeryList = new ArrayList<>();
        pigCategoryThingsShow = new String[piggeryList.size() + 1];
        for (int i = 0; i < piggeryList.size() + 1; i++) {
            if (i == 0) {
                pigCategoryThingsShow[i] = "全部舍";
            } else {
                pigCategoryThingsShow[i] = piggeryList.get(i - 1).getCategory();
            }
            if (i == 0) {
                BYPiggeryList.add("全部保育舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("3")) {
                BYPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }
            if (i == 0) {
                YFPiggeryList.add("全部育肥舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("1")) {
                YFPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }
            if (i == 0) {
                HBPiggeryList.add("全部后备舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("4")) {
                HBPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }
            if (i == 0) {
                BRZZPiggeryList.add("全部哺乳仔猪舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("2")) {
                BRZZPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }

        }
        pigBYCategoryThingsShow = new String[BYPiggeryList.size()];
        for (int i = 0; i < BYPiggeryList.size(); i++) {
            pigBYCategoryThingsShow[i] = BYPiggeryList.get(i);
        }

        pigYFCategoryThingsShow = new String[YFPiggeryList.size()];
        for (int i = 0; i < YFPiggeryList.size(); i++) {
            pigYFCategoryThingsShow[i] = YFPiggeryList.get(i);
        }

        pigHBCategoryThingsShow = new String[HBPiggeryList.size()];
        for (int i = 0; i < HBPiggeryList.size(); i++) {
            pigHBCategoryThingsShow[i] = HBPiggeryList.get(i);
        }

        pigBRZZCategoryThingsShow = new String[BRZZPiggeryList.size()];
        for (int i = 0; i < BRZZPiggeryList.size(); i++) {
            pigBRZZCategoryThingsShow[i] = BRZZPiggeryList.get(i);
        }
        //全部饲料
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SllbMapper mapper = sqlSession.getMapper(SllbMapper.class);
            sllbList = mapper.selectAll();
        }
        pigSllbThingsShow = new String[sllbList.size() + 1];
        for (int i = 0; i < sllbList.size() + 1; i++) {
            if (i == 0) {
                pigSllbThingsShow[i] = "全部饲料类型";
            } else {
                pigSllbThingsShow[i] = sllbList.get(i - 1).getTypename();
            }
        }
        //全部栏
        List<Fence> fence;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper = sqlSession.getMapper(FenceMapper.class);
            fence = mapper.selectAll();
        }
        pigFenceThingsShow = new String[fence.size() + 1];
        for (int i = 0; i < fence.size() + 1; i++) {
            if (i == 0) {
                pigFenceThingsShow[i] = "全部栏";
            } else {
                pigFenceThingsShow[i] = fence.get(i - 1).getFencename();
            }
        }
        //猪只状态
        List<Swintype> swintypelist;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
            swintypelist = mapper.selectAll();
        }
        pigSwintypeThingsShow = new String[swintypelist.size() + 1];
        for (int i = 0; i < swintypelist.size() + 1; i++) {
            if (i == 0) {
                pigSwintypeThingsShow[i] = "猪只状态";
            } else {
                pigSwintypeThingsShow[i] = swintypelist.get(i - 1).getTypename();
            }
        }
        //全部药品
        List<Pigyp> pigypList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PigypMapper mapper = sqlSession.getMapper(PigypMapper.class);
            pigypList = mapper.selectAll();
        }
        pigYpThingsShow = new String[pigypList.size() + 1];

        for (int i = 0; i < pigypList.size() + 1; i++) {
            if (i == 0) {
                pigYpThingsShow[i] = "全部药品";
            } else {
                pigYpThingsShow[i] = pigypList.get(i - 1).getTypename();
            }
        }
        //全部疫苗
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            VaccineMapper mapper = sqlSession.getMapper(VaccineMapper.class);
            vaccineList = mapper.selectAll();
        }
        pigYmThingsShow = new String[vaccineList.size() + 1];

        for (int i = 0; i < vaccineList.size() + 1; i++) {
            if (i == 0) {
                pigYmThingsShow[i] = "全部疫苗";
            } else {
                pigYmThingsShow[i] = vaccineList.get(i - 1).getTypename();
            }
        }
        //全部饲料
        SLLBpigslList = new ArrayList<>();
        BRZZpigslList = new ArrayList<>();
        BYPiggeryList = new ArrayList<>();
        BYZpigslList = new ArrayList<>();
        SZYFZpigslList = new ArrayList<>();
        HBZpigslList = new ArrayList<>();
        HBMZpigslList = new ArrayList<>();
        RSMZpigslList = new ArrayList<>();
        BRMZpigslList = new ArrayList<>();
        KHMZpigslList = new ArrayList<>();
        ZGZpigslList = new ArrayList<>();
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PigslMapper mapper = sqlSession.getMapper(PigslMapper.class);
            pigslList = mapper.selectAll();
        }
        for (int i = 0; i < pigslList.size() + 1; i++) {
            if (i == 0) {
                SLLBpigslList.add("全部饲料类型");
            } else {
                SLLBpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                BRZZpigslList.add("全部哺乳仔猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("1")) {
                BRZZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                BYZpigslList.add("全部保育猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("2")) {
                BYZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                SZYFZpigslList.add("全部生长育肥猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("3")) {
                SZYFZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                HBZpigslList.add("全部后备猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("4")) {
                HBZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                HBMZpigslList.add("全部后备母猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("5")) {
                HBMZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                RSMZpigslList.add("全部妊娠母猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("6")) {
                RSMZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                BRMZpigslList.add("全部哺乳母猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("7")) {
                BRMZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                KHMZpigslList.add("全部空怀母猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("8")) {
                KHMZpigslList.add(pigslList.get(i - 1).getTypename());
            }
            if (i == 0) {
                ZGZpigslList.add("全部种公猪类型");
            } else if (pigslList.get(i - 1).getSwintypeid().equals("9")) {
                ZGZpigslList.add(pigslList.get(i - 1).getTypename());
            }

        }

        pigslSLLBThingsShow = new String[SLLBpigslList.size()];
        for (int i = 0; i < SLLBpigslList.size(); i++) {
            pigslSLLBThingsShow[i] = SLLBpigslList.get(i);
        }
        pigslBRZZThingsShow = new String[BRZZpigslList.size()];
        for (int i = 0; i < BRZZpigslList.size(); i++) {
            pigslBRZZThingsShow[i] = BRZZpigslList.get(i);
        }
        pigslBYZThingsShow = new String[BYZpigslList.size()];
        for (int i = 0; i < BYZpigslList.size(); i++) {
            pigslBYZThingsShow[i] = BYZpigslList.get(i);
        }
        pigslSZYFZThingsShow = new String[SZYFZpigslList.size()];
        for (int i = 0; i < SZYFZpigslList.size(); i++) {
            pigslSZYFZThingsShow[i] = SZYFZpigslList.get(i);
        }
        pigslHBZThingsShow = new String[HBZpigslList.size()];
        for (int i = 0; i < HBZpigslList.size(); i++) {
            pigslHBZThingsShow[i] = HBZpigslList.get(i);
        }
        pigslHBMZThingsShow = new String[HBMZpigslList.size()];
        for (int i = 0; i < HBMZpigslList.size(); i++) {
            pigslHBMZThingsShow[i] = HBMZpigslList.get(i);
        }
        pigslRSMZThingsShow = new String[RSMZpigslList.size()];
        for (int i = 0; i < RSMZpigslList.size(); i++) {
            pigslRSMZThingsShow[i] = RSMZpigslList.get(i);
        }
        pigslBRMZThingsShow = new String[BRMZpigslList.size()];
        for (int i = 0; i < BRMZpigslList.size(); i++) {
            pigslBRMZThingsShow[i] = BRMZpigslList.get(i);
        }
        pigslKHMZThingsShow = new String[KHMZpigslList.size()];
        for (int i = 0; i < KHMZpigslList.size(); i++) {
            pigslKHMZThingsShow[i] = KHMZpigslList.get(i);
        }
        pigslZGZThingsShow = new String[ZGZpigslList.size()];
        for (int i = 0; i < ZGZpigslList.size(); i++) {
            pigslZGZThingsShow[i] = ZGZpigslList.get(i);
        }

        BYPiggeryList = new ArrayList<>();
        varietiesData = new VarietiesData();
        varietiesDataPlus = new VarietiesDataPlus();
        outsideLabel = "";
        ssf = false;
        selethMapperPlus = new SelethMapperPlus();
        takespermMapperPlus = new TakespermMapperPlus();
        breedingMapperPlus = new BreedingMapperPlus();
        childbirthMapperPlus = new ChildbirthMapperPlus();
        weaningMapperPlus = new WeaningMapperPlus();
        conservationTurnFattingMapperPlus = new ConservationTurnFattingMapperPlus();
        conservationTurnBackMapperPlus = new ConservationTurnBackMapperPlus();
        feedingTurnConservationMapperPlus = new FeedingTurnConservationMapperPlus();
        maleBoarMapperPlus = new MaleBoarMapperPlus();
        famaleBoarMapperPlus = new FemaleBoarMapperPlus();
        twoTestMapperPlus = new TwoTestMapperPlus();
        fourTestMapperPlus = new FourTestMapperPlus();
        sixTestMapperPlus = new SixTestMapperPlus();
        hundredTestMapperPlus = new HundredTestMapperPlus();
        slrkMapperPlus = new SlrkMapperPlus();
        slckMapperPlus = new SlckMapperPlus();
        yprkMapperPlus = new YprkMapperPlus();
        ypckMapperPlus = new YpckMapperPlus();
        ymrkMapperPlus = new YmrkMapperPlus();
        ymckMapperPlus = new YmckMapperPlus();
        zzmyMapperPlus = new ZzmyMapperPlus();
        jbzlMapperPlus = new JbzlMapperPlus();
        jyjcMapperPlus = new JyjcMapperPlus();
        tzxncdMapperPlus = new TzxncdMapperPlus();
        zzxsMapperPlus = new ZzxsMapperPlus();
        zzswMapperPlus = new ZzswMapperPlus();
        tjMapperPlus = new TjMapperPlus();
        yzMapperPlus = new YzMapperPlus();

        pzfqlTJ = new PzfqlTJ();
        pzfmlTJ = new PzfmlTJ();
        tjzczsTJ = new TjzczsTJ();
        byqchlTJ = new ByqchlTJ();
        cshtgsTJ = new CshtgsTJ();
        cshtgzTJ = new CshtgzTJ();
        dngtzTJ = new DngtzTJ();
        dnzzchlTJ = new DnzzchlTJ();
        jdlrbTj = new JdlrbTJ();
        slckTJ = new SlckTJ();
        slrkTJ = new SlrkTJ();
        tjdnhzsTJ = new TjdnhzsTJ();
        tjhczsTJ = new TjhczsTJ();
        yfqchlTJ = new YfqchlTJ();
        ymckTJ = new YmckTJ();
        ymrkTJ = new YmrkTJ();
        ypckTJ = new YpckTJ();
        yprkTJ = new YprkTJ();
        zzswTJ = new ZzswTJ();
        zzxsTJ = new ZzxsTJ();
        yzfx = new Yzfx();
        xzxp = new Xzxp();

        lineidIdtoNameSmap = new HashMap<>();
        linesNametoIdSmap = new HashMap<>();
        linesThingsmap = new HashMap<>();

        lineherdIdtoNameSmap = new HashMap<>();
        lineherdNametoIdSmap = new HashMap<>();
        lineherdThingsmap = new HashMap<>();

        swintypeIdtoNameSmap = new HashMap<>();
        swintypeNametoIdSmap = new HashMap<>();
        swintypeThingsmap = new HashMap<>();

        fenceIdtoNameSmap = new HashMap<>();
        fenceNametoIdSmap = new HashMap<>();
        fenceThingsmap = new HashMap<>();

        employeeIdtoNameSmap = new HashMap<>();
        employeeNametoIdSmap = new HashMap<>();
        employeeThingsmap = new HashMap<>();
        employeeGLYThingsmap = new HashMap<>();
        employeeSYYThingsmap = new HashMap<>();
        employeePZYThingsmap = new HashMap<>();
        employeeSYThingsmap = new HashMap<>();
        employeeCKThingsmap = new HashMap<>();
        employeeXSThingsmap = new HashMap<>();
        employeeJSThingsmap = new HashMap<>();

        piggeryIdtoNameSmap = new HashMap<>();
        piggeryNametoIdSmap = new HashMap<>();
        piggeryThingsmap = new HashMap<>();

        pigslIdtoNameSmap = new HashMap<>();
        pigslNametoIdSmap = new HashMap<>();
        pigslThingsmap = new HashMap<>();

        pigypIdtoNameSmap = new HashMap<>();
        pigypNametoIdSmap = new HashMap<>();
        pigypThingsmap = new HashMap<>();

        pigjbIdtoNameSmap = new HashMap<>();
        pigjbNametoIdSmap = new HashMap<>();
        pigjbThingsmap = new HashMap<>();

        vaccineIdtoNameSmap = new HashMap<>();
        vaccineNametoIdSmap = new HashMap<>();
        vaccineThingsmap = new HashMap<>();

        farmIdtoNameSmap = new HashMap<>();
        farmNametoIdSmap = new HashMap<>();
        farmThingsmap = new HashMap<>();

        sllbListIdtoNameSmap = new HashMap<>();
        sllbListThingsmap = new HashMap<>();
        sllbListNametoIdSmap = new HashMap<>();

        printData = new PrintData();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            LinesMapper mapper = sqlSession.getMapper(LinesMapper.class);
            linesList = mapper.selectAll();
        }
        for (int i = 0; i < linesList.size(); i++) {
            String[] things = new String[linesList.size()];
            lineidIdtoNameSmap.put(linesList.get(i).getLineid(), linesList.get(i).getLinename());
            linesNametoIdSmap.put(linesList.get(i).getLinename(), linesList.get(i).getLineid());
            for (int j = 0; j < linesList.size(); j++) {
                things[j] = linesList.get(j).getLinename();
                if (linesList.get(i).getLineid().equals(linesList.get(j).getLineid())) {
                    String thingstemp = things[0];
                    things[0] = things[j];
                    things[j] = thingstemp;
                }
            }
            linesThingsmap.put(linesList.get(i).getLineid(), things);
        }

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            LineherdMapper mapper = sqlSession.getMapper(LineherdMapper.class);
            lineherdList = mapper.selectAll();
        }
        for (int i = 0; i < lineherdList.size(); i++) {
            String[] things1 = new String[lineherdList.size()];
            lineherdIdtoNameSmap.put(lineherdList.get(i).getHerdid(), lineherdList.get(i).getHerdname());
            lineherdNametoIdSmap.put(lineherdList.get(i).getHerdname(), lineherdList.get(i).getHerdid());
            for (int j = 0; j < lineherdList.size(); j++) {
                things1[j] = lineherdList.get(j).getHerdname();
                if (lineherdList.get(i).getHerdid().equals(lineherdList.get(j).getHerdid())) {
                    String thingstemp = things1[0];
                    things1[0] = things1[j];
                    things1[j] = thingstemp;
                }
            }
            lineherdThingsmap.put(lineherdList.get(i).getHerdid(), things1);

        }

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SllbMapper mapper = sqlSession.getMapper(SllbMapper.class);
            sllbList = mapper.selectAll();
        }
        for (int i = 0; i < sllbList.size(); i++) {
            String[] sllbListThingsShow = new String[sllbList.size()];
            sllbListIdtoNameSmap.put(sllbList.get(i).getTypeid(), sllbList.get(i).getTypename());
            sllbListNametoIdSmap.put(sllbList.get(i).getTypename(), sllbList.get(i).getTypeid());
            for (int j = 0; j < sllbList.size(); j++) {
                sllbListThingsShow[j] = sllbList.get(j).getTypename();
                if (sllbList.get(i).getTypeid().equals(sllbList.get(j).getTypeid())) {
                    String thingstemp = sllbListThingsShow[0];
                    sllbListThingsShow[0] = sllbListThingsShow[j];
                    sllbListThingsShow[j] = thingstemp;
                }
            }
            sllbListThingsmap.put(sllbList.get(i).getTypeid(), sllbListThingsShow);

        }

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
            swintypeList = mapper.selectAll();
        }
        for (int i = 0; i < swintypeList.size(); i++) {
            swintypeThingsShow = new String[swintypeList.size()];
            swintypeIdtoNameSmap.put(swintypeList.get(i).getTypeid(), swintypeList.get(i).getTypename());
            swintypeNametoIdSmap.put(swintypeList.get(i).getTypename(), swintypeList.get(i).getTypeid());
            for (int j = 0; j < swintypeList.size(); j++) {
                swintypeThingsShow[j] = swintypeList.get(j).getTypename();
                if (swintypeList.get(i).getTypeid().equals(swintypeList.get(j).getTypeid())) {
                    String thingstemp = swintypeThingsShow[0];
                    swintypeThingsShow[0] = swintypeThingsShow[j];
                    swintypeThingsShow[j] = thingstemp;
                }
            }
            swintypeThingsmap.put(swintypeList.get(i).getTypeid(), swintypeThingsShow);

        }

        List<Fence> fenceList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper = sqlSession.getMapper(FenceMapper.class);
            fenceList = mapper.selectAll();
        }
        for (int i = 0; i < fenceList.size(); i++) {
            fenceThingsShow = new String[fenceList.size()];
            fenceIdtoNameSmap.put(fenceList.get(i).getFenceid(), fenceList.get(i).getFencename());
            fenceNametoIdSmap.put(fenceList.get(i).getFencename(), fenceList.get(i).getFenceid());
            for (int j = 0; j < fenceList.size(); j++) {
                fenceThingsShow[j] = fenceList.get(j).getFencename();
                if (fenceList.get(i).getFenceid().equals(fenceList.get(j).getFenceid())) {
                    String thingstemp = fenceThingsShow[0];
                    fenceThingsShow[0] = fenceThingsShow[j];
                    fenceThingsShow[j] = thingstemp;
                }
            }
            fenceThingsmap.put(fenceList.get(i).getFenceid(), fenceThingsShow);
        }

        List<Employee> employeeGLYList = new ArrayList<>();
        List<Employee> employeeSYYList = new ArrayList<>();
        List<Employee> employeePZYList = new ArrayList<>();
        List<Employee> employeeSYList = new ArrayList<>();
        List<Employee> employeeCKList = new ArrayList<>();
        List<Employee> employeeXSList = new ArrayList<>();
        List<Employee> employeeJSList = new ArrayList<>();
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
            employeeList = mapper.selectAll();
        }
        for (int i = 0; i < employeeList.size(); i++) {
            employeeThingsShow = new String[employeeList.size()];
            employeeThingsShowPlus = new String[employeeList.size() + 1];
            employeeThingsShowPlus[0] = "负责人";
            employeeIdtoNameSmap.put(employeeList.get(i).getEmployeeid(), employeeList.get(i).getUser_name());
            employeeNametoIdSmap.put(employeeList.get(i).getUser_name(), employeeList.get(i).getEmployeeid());
            for (int j = 0; j < employeeList.size(); j++) {
                employeeThingsShow[j] = employeeList.get(j).getUser_name();
                employeeThingsShowPlus[j + 1] = employeeList.get(j).getUser_name();
                if (employeeList.get(i).getEmployeeid().equals(employeeList.get(j).getEmployeeid())) {
                    String thingstemp = employeeThingsShow[0];
                    employeeThingsShow[0] = employeeThingsShow[j];
                    employeeThingsShow[j] = thingstemp;
                }
            }
            employeeThingsmap.put(employeeList.get(i).getEmployeeid(), employeeThingsShow);
            if (employeeList.get(i).getYgzw().equals("1")) {
                employeeGLYList.add(employeeList.get(i));

            } else if (employeeList.get(i).getYgzw().equals("2")) {
                employeeSYYList.add(employeeList.get(i));

            } else if (employeeList.get(i).getYgzw().equals("3")) {
                employeePZYList.add(employeeList.get(i));

            } else if (employeeList.get(i).getYgzw().equals("4")) {
                employeeSYList.add(employeeList.get(i));

            } else if (employeeList.get(i).getYgzw().equals("5")) {
                employeeCKList.add(employeeList.get(i));

            } else if (employeeList.get(i).getYgzw().equals("6")) {
                employeeXSList.add(employeeList.get(i));

            } else if (employeeList.get(i).getYgzw().equals("7")) {
                employeeJSList.add(employeeList.get(i));

            }
        }
        for (int i = 0; i < employeeGLYList.size(); i++) {
            employeeGLYThingsShow = new String[employeeGLYList.size()];
            for (int j = 0; j < employeeGLYList.size(); j++) {
                employeeGLYThingsShow[j] = employeeGLYList.get(j).getUser_name();
                if (employeeGLYList.get(i).getEmployeeid().equals(employeeGLYList.get(j).getEmployeeid())) {
                    String thingstemp = employeeGLYThingsShow[0];
                    employeeGLYThingsShow[0] = employeeGLYThingsShow[j];
                    employeeGLYThingsShow[j] = thingstemp;
                }
            }
            employeeGLYThingsmap.put(employeeGLYList.get(i).getEmployeeid(), employeeGLYThingsShow);
        }

        for (int i = 0; i < employeeSYYList.size(); i++) {
            employeeSYYThingsShow = new String[employeeSYYList.size()];
            for (int j = 0; j < employeeSYYList.size(); j++) {
                employeeSYYThingsShow[j] = employeeSYYList.get(j).getUser_name();
                if (employeeSYYList.get(i).getEmployeeid().equals(employeeSYYList.get(j).getEmployeeid())) {
                    String thingstemp = employeeSYYThingsShow[0];
                    employeeSYYThingsShow[0] = employeeSYYThingsShow[j];
                    employeeSYYThingsShow[j] = thingstemp;
                }
            }
            employeeSYYThingsmap.put(employeeSYYList.get(i).getEmployeeid(), employeeSYYThingsShow);
        }
        for (int i = 0; i < employeePZYList.size(); i++) {
            employeePZYThingsShow = new String[employeePZYList.size()];
            for (int j = 0; j < employeePZYList.size(); j++) {
                employeePZYThingsShow[j] = employeePZYList.get(j).getUser_name();
                if (employeePZYList.get(i).getEmployeeid().equals(employeePZYList.get(j).getEmployeeid())) {
                    String thingstemp = employeePZYThingsShow[0];
                    employeePZYThingsShow[0] = employeePZYThingsShow[j];
                    employeePZYThingsShow[j] = thingstemp;
                }
            }
            employeePZYThingsmap.put(employeePZYList.get(i).getEmployeeid(), employeePZYThingsShow);
        }
        for (int i = 0; i < employeeSYList.size(); i++) {
            employeeSYThingsShow = new String[employeeSYList.size()];
            for (int j = 0; j < employeeSYList.size(); j++) {
                employeeSYThingsShow[j] = employeeSYList.get(j).getUser_name();
                if (employeeSYList.get(i).getEmployeeid().equals(employeeSYList.get(j).getEmployeeid())) {
                    String thingstemp = employeeSYThingsShow[0];
                    employeeSYThingsShow[0] = employeeSYThingsShow[j];
                    employeeSYThingsShow[j] = thingstemp;
                }
            }
            employeeSYThingsmap.put(employeeSYList.get(i).getEmployeeid(), employeeSYThingsShow);
        }
        for (int i = 0; i < employeeCKList.size(); i++) {
            employeeCKThingsShow = new String[employeeCKList.size()];
            for (int j = 0; j < employeeCKList.size(); j++) {
                employeeCKThingsShow[j] = employeeCKList.get(j).getUser_name();
                if (employeeCKList.get(i).getEmployeeid().equals(employeeCKList.get(j).getEmployeeid())) {
                    String thingstemp = employeeCKThingsShow[0];
                    employeeCKThingsShow[0] = employeeCKThingsShow[j];
                    employeeCKThingsShow[j] = thingstemp;
                }
            }
            employeeCKThingsmap.put(employeeCKList.get(i).getEmployeeid(), employeeCKThingsShow);
        }
        for (int i = 0; i < employeeXSList.size(); i++) {
            employeeXSThingsShow = new String[employeeXSList.size()];
            for (int j = 0; j < employeeXSList.size(); j++) {
                employeeXSThingsShow[j] = employeeXSList.get(j).getUser_name();
                if (employeeXSList.get(i).getEmployeeid().equals(employeeXSList.get(j).getEmployeeid())) {
                    String thingstemp = employeeXSThingsShow[0];
                    employeeXSThingsShow[0] = employeeXSThingsShow[j];
                    employeeXSThingsShow[j] = thingstemp;
                }
            }
            employeeXSThingsmap.put(employeeXSList.get(i).getEmployeeid(), employeeXSThingsShow);
        }
        for (int i = 0; i < employeeJSList.size(); i++) {
            employeeJSThingsShow = new String[employeeJSList.size()];
            for (int j = 0; j < employeeJSList.size(); j++) {
                employeeJSThingsShow[j] = employeeJSList.get(j).getUser_name();
                if (employeeJSList.get(i).getEmployeeid().equals(employeeJSList.get(j).getEmployeeid())) {
                    String thingstemp = employeeJSThingsShow[0];
                    employeeJSThingsShow[0] = employeeJSThingsShow[j];
                    employeeJSThingsShow[j] = thingstemp;
                }
            }
            employeeJSThingsmap.put(employeeJSList.get(i).getEmployeeid(), employeeJSThingsShow);
        }

        for (int i = 0; i < piggeryList.size(); i++) {
            piggeryThingsShow = new String[piggeryList.size()];
            piggeryIdtoNameSmap.put(piggeryList.get(i).getNumber(), piggeryList.get(i).getCategory());
            piggeryNametoIdSmap.put(piggeryList.get(i).getCategory(), piggeryList.get(i).getNumber());
            for (int j = 0; j < piggeryList.size(); j++) {
                piggeryThingsShow[j] = piggeryList.get(j).getCategory();
                if (piggeryList.get(i).getNumber().equals(piggeryList.get(j).getNumber())) {
                    String thingstemp = piggeryThingsShow[0];
                    piggeryThingsShow[0] = piggeryThingsShow[j];
                    piggeryThingsShow[j] = thingstemp;
                }
            }
            piggeryThingsmap.put(piggeryList.get(i).getNumber(), piggeryThingsShow);

        }

        for (int i = 0; i < pigslList.size(); i++) {
            pigslThingsShow = new String[pigslList.size()];
            pigslIdtoNameSmap.put(pigslList.get(i).getTypeid(), pigslList.get(i).getTypename());
            pigslNametoIdSmap.put(pigslList.get(i).getTypename(), pigslList.get(i).getTypeid());
            for (int j = 0; j < pigslList.size(); j++) {
                pigslThingsShow[j] = pigslList.get(j).getTypename();
                if (pigslList.get(i).getTypeid().equals(pigslList.get(j).getTypeid())) {
                    String thingstemp = pigslThingsShow[0];
                    pigslThingsShow[0] = pigslThingsShow[j];
                    pigslThingsShow[j] = thingstemp;
                }
            }
            pigslThingsmap.put(pigslList.get(i).getTypeid(), pigslThingsShow);

        }

        for (int i = 0; i < pigypList.size(); i++) {
            pigypThingsShow = new String[pigypList.size()];
            pigypIdtoNameSmap.put(pigypList.get(i).getTypeid(), pigypList.get(i).getTypename());
            pigypNametoIdSmap.put(pigypList.get(i).getTypename(), pigypList.get(i).getTypeid());
            for (int j = 0; j < pigypList.size(); j++) {
                pigypThingsShow[j] = pigypList.get(j).getTypename();
                if (pigypList.get(i).getTypeid().equals(pigypList.get(j).getTypeid())) {
                    String thingstemp = pigypThingsShow[0];
                    pigypThingsShow[0] = pigypThingsShow[j];
                    pigypThingsShow[j] = thingstemp;
                }
            }
            pigypThingsmap.put(pigypList.get(i).getTypeid(), pigypThingsShow);

        }

        List<Pigjb> pigjbList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PigjbMapper mapper = sqlSession.getMapper(PigjbMapper.class);
            pigjbList = mapper.selectAll();
        }

        for (int i = 0; i < pigjbList.size(); i++) {
            pigjbThingsShow = new String[pigjbList.size()];
            pigjbIdtoNameSmap.put(pigjbList.get(i).getTypeid(), pigjbList.get(i).getTypename());
            pigjbNametoIdSmap.put(pigjbList.get(i).getTypename(), pigjbList.get(i).getTypeid());
            for (int j = 0; j < pigjbList.size(); j++) {
                pigjbThingsShow[j] = pigjbList.get(j).getTypename();
                if (pigjbList.get(i).getTypeid().equals(pigjbList.get(j).getTypeid())) {
                    String thingstemp = pigjbThingsShow[0];
                    pigjbThingsShow[0] = pigjbThingsShow[j];
                    pigjbThingsShow[j] = thingstemp;
                }
            }
            pigjbThingsmap.put(pigjbList.get(i).getTypeid(), pigjbThingsShow);
        }

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            VaccineMapper mapper = sqlSession.getMapper(VaccineMapper.class);
            vaccineList = mapper.selectAll();
        }

        for (int i = 0; i < vaccineList.size(); i++) {
            vaccineThingsShow = new String[vaccineList.size()];
            vaccineIdtoNameSmap.put(vaccineList.get(i).getTypeid(), vaccineList.get(i).getTypename());
            vaccineNametoIdSmap.put(vaccineList.get(i).getTypename(), vaccineList.get(i).getTypeid());
            for (int j = 0; j < vaccineList.size(); j++) {
                vaccineThingsShow[j] = vaccineList.get(j).getTypename();
                if (vaccineList.get(i).getTypeid().equals(vaccineList.get(j).getTypeid())) {
                    String thingstemp = vaccineThingsShow[0];
                    vaccineThingsShow[0] = vaccineThingsShow[j];
                    vaccineThingsShow[j] = thingstemp;
                }
            }
            vaccineThingsmap.put(vaccineList.get(i).getTypeid(), vaccineThingsShow);
        }

        List<FarmName> farmList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FarmNameMapper mapper = sqlSession.getMapper(FarmNameMapper.class);
            farmList = mapper.selectAll();
        }

        for (int i = 0; i < farmList.size(); i++) {
            farmThingsShow = new String[farmList.size()];
            farmIdtoNameSmap.put(farmList.get(i).getFarm_id(), farmList.get(i).getFarm_name());
            farmNametoIdSmap.put(farmList.get(i).getFarm_name(), farmList.get(i).getFarm_id());
            for (int j = 0; j < farmList.size(); j++) {
                farmThingsShow[j] = farmList.get(j).getFarm_name();
                if (farmList.get(i).getFarm_id().equals(farmList.get(j).getFarm_id())) {
                    String thingstemp = farmThingsShow[0];
                    farmThingsShow[0] = farmThingsShow[j];
                    farmThingsShow[j] = thingstemp;
                }
            }
            farmThingsmap.put(farmList.get(i).getFarm_id(), farmThingsShow);
        }

        selebithPageModel = new SelethPageModel(17, selethMapperPlus.SelectCount(), selethMapperPlus, false);

        takespermPageModel = new TakespermPageModel(17, takespermMapperPlus.SelectCount(), takespermMapperPlus, false);

        breedingPageModel = new BreedingPageModel(17, breedingMapperPlus.SelectCount(), breedingMapperPlus, false);

        childbirthPageModel = new ChildbirthPageModel(17, childbirthMapperPlus.SelectCount(), childbirthMapperPlus, false);

        weaningPageModel = new WeaningPageModel(17, weaningMapperPlus.SelectCount(), weaningMapperPlus, false);

        conservationTurnFattingPageModel = new ConservationTurnFattingPageModel(17, conservationTurnFattingMapperPlus.SelectCount(), conservationTurnFattingMapperPlus, false);

        conservationTurnBackPageModel = new ConservationTurnBackPageModel(17, conservationTurnBackMapperPlus.SelectCount(), conservationTurnBackMapperPlus, false);

        feedingTurnConservationPageModel = new FeedingTurnConservationPageModel(17, feedingTurnConservationMapperPlus.SelectCount(), feedingTurnConservationMapperPlus, false);

        maleBoarPageModel = new MaleBoarPageModel(17, maleBoarMapperPlus.selectAllMaleCount(), maleBoarMapperPlus, false);

        femaleBoarPageModel = new FemaleBoarPageModel(17, famaleBoarMapperPlus.selectAllFemaleCount(), famaleBoarMapperPlus, false);

        twoTestPageModel = new TwoTestPageModel(17, twoTestMapperPlus.SelectCount(), twoTestMapperPlus, false);

        fourTestPageModel = new FourTestPageModel(17, fourTestMapperPlus.SelectCount(), fourTestMapperPlus, false);

        sixTestPageModel = new SixTestPageModel(17, sixTestMapperPlus.SelectCount(), sixTestMapperPlus, false);

        hundredTestPageModel = new HundredTestPageModel(17, hundredTestMapperPlus.SelectCount(), hundredTestMapperPlus, false);

        slrkPageModel = new SlrkPageModel(17, slrkMapperPlus.SelectCount(), slrkMapperPlus, false);

        slckPageModel = new SlckPageModel(17, slckMapperPlus.SelectCount(), slckMapperPlus, false);

        yprkPageModel = new YprkPageModel(17, yprkMapperPlus.SelectCount(), yprkMapperPlus, false);

        ypckPageModel = new YpckPageModel(17, ypckMapperPlus.SelectCount(), ypckMapperPlus, false);

        ymrkPageModel = new YmrkPageModel(17, ymrkMapperPlus.SelectCount(), ymrkMapperPlus, false);

        ymckPageModel = new YmckPageModel(17, ymckMapperPlus.SelectCount(), ymckMapperPlus, false);

        zzmyPageModel = new ZzmyPageModel(17, zzmyMapperPlus.SelectCount(), zzmyMapperPlus, false);

        jbzlPageModel = new JbzlPageModel(17, jbzlMapperPlus.SelectCount(), jbzlMapperPlus, false);

        jyjcPageModel = new JyjcPageModel(17, jyjcMapperPlus.SelectCount(), jyjcMapperPlus, false);

        tzxncdPageModel = new TzxncdPageModel(17, tzxncdMapperPlus.SelectCount(), tzxncdMapperPlus, false);

        zzxsPageModel = new ZzxsPageModel(17, zzxsMapperPlus.SelectCount(), zzxsMapperPlus, false);

        zzswPageModel = new ZzswPageModel(17, zzswMapperPlus.SelectCount(), zzswMapperPlus, false);

        yzgtxxPageModel = new YzgtxxPageModel(17, yzMapperPlus);

        yzTwotestPageModel = new YzTwotestPageModel(17, yzMapperPlus);

        yzFourtestPageModel = new YzFourtestPageModel(17, yzMapperPlus);

        yzSixtestPageModel = new YzSixtestPageModel(17, yzMapperPlus);

        yzHundredtestPageModel = new YzHundredtestPageModel(17, yzMapperPlus);

        lctApp = new LctApp();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(lctApp); //在父窗口中添加这个子窗口

        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jTextField2.setEnabled(false);//时间起始框
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jLabel46.setVisible(false);//标签

        kongString = new String[1];
        kongString[0] = "       ";

        jButtonPrint.setEnabled(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField01 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel02 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jButton7 =  new DateChooserJButton (jTextField2);
        jTextField3 = new javax.swing.JTextField();
        jButton9 =  new DateChooserJButton (jTextField3);
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel46 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton1NowExcel = new javax.swing.JButton();
        jButton1AllExcel = new javax.swing.JButton();
        jButtonPrint = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jDesktopPane1 = new javax.swing.JDesktopPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("华夏地方猪信息化管理及育种分析应用软件（MABS）");
        setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        setMaximizedBounds(new java.awt.Rectangle(32767, 32767, 32767, 32767));

        jPanel4.setBackground(new java.awt.Color(226, 238, 252));
        jPanel4.setPreferredSize(new java.awt.Dimension(1280, 626));

        jPanel5.setBackground(new java.awt.Color(226, 237, 252));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "猪只快速查询", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("微软雅黑", 3, 16))); // NOI18N
        jPanel5.setToolTipText("");
        jPanel5.setMaximumSize(new java.awt.Dimension(1222, 63));
        jPanel5.setMinimumSize(new java.awt.Dimension(1212, 63));
        jPanel5.setPreferredSize(new java.awt.Dimension(1280, 80));

        jLabel1.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("个体编号");

        jTextField01.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextField01.setForeground(new java.awt.Color(0, 0, 102));
        jTextField01.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField01FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField01FocusLost(evt);
            }
        });

        jComboBox1.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jComboBox1.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "猪只状态", "哺乳仔猪", "生长猪", "保育猪", " " }));
        jComboBox1.setPreferredSize(new java.awt.Dimension(125, 30));

        jButton1.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 102));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/查询L.png"))); // NOI18N
        jButton1.setText("查询");
        jButton1.setMaximumSize(new java.awt.Dimension(110, 33));
        jButton1.setMinimumSize(new java.awt.Dimension(110, 33));
        jButton1.setPreferredSize(new java.awt.Dimension(110, 33));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 0, 51));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/重置L.png"))); // NOI18N
        jButton5.setText("重置");
        jButton5.setMaximumSize(new java.awt.Dimension(110, 33));
        jButton5.setMinimumSize(new java.awt.Dimension(110, 33));
        jButton5.setPreferredSize(new java.awt.Dimension(110, 33));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel02.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jLabel02.setForeground(new java.awt.Color(0, 0, 102));
        jLabel02.setText("出生日期");

        jTextField2.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(0, 0, 102));
        jTextField2.setPreferredSize(new java.awt.Dimension(88, 25));

        jLabel4.setText("--");

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N

        jTextField3.setFont(new java.awt.Font("宋体", 0, 16)); // NOI18N
        jTextField3.setForeground(new java.awt.Color(0, 0, 102));
        jTextField3.setPreferredSize(new java.awt.Dimension(88, 25));

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N

        jComboBox3.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jComboBox3.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "全部栏" }));
        jComboBox3.setPreferredSize(new java.awt.Dimension(134, 28));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jComboBox2.setFont(new java.awt.Font("微软雅黑", 1, 16)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "全部舍", " " }));
        jComboBox2.setPreferredSize(new java.awt.Dimension(134, 28));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 0, 0));
        jLabel46.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息查询");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(2, 2, 2)
                        .addComponent(jTextField01, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel02)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel4)
                        .addGap(0, 0, 0)
                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jLabel46)
                .addGap(0, 0, 0)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(jLabel02)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1))
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(3, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(226, 238, 252));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "快速操作", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("微软雅黑", 3, 16))); // NOI18N
        jPanel1.setPreferredSize(new java.awt.Dimension(1330, 1000));

        jButton2.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 102));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/删除记录L.png"))); // NOI18N
        jButton2.setText("删除记录");
        jButton2.setPreferredSize(new java.awt.Dimension(112, 33));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 102));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/增加记录1.png"))); // NOI18N
        jButton3.setText("增加记录");
        jButton3.setMaximumSize(new java.awt.Dimension(133, 35));
        jButton3.setMinimumSize(new java.awt.Dimension(111, 22));
        jButton3.setPreferredSize(new java.awt.Dimension(128, 33));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 0, 102));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/更改记录L.png"))); // NOI18N
        jButton4.setText("更改记录");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 0, 102));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/刷新页面L.png"))); // NOI18N
        jButton6.setText("刷新页面");
        jButton6.setMaximumSize(new java.awt.Dimension(114, 35));
        jButton6.setMinimumSize(new java.awt.Dimension(111, 32));
        jButton6.setPreferredSize(new java.awt.Dimension(112, 33));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton8.setForeground(new java.awt.Color(0, 0, 102));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/详细信息L.png"))); // NOI18N
        jButton8.setText("详细信息");
        jButton8.setMaximumSize(new java.awt.Dimension(122, 33));
        jButton8.setPreferredSize(new java.awt.Dimension(112, 33));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton1NowExcel.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton1NowExcel.setForeground(new java.awt.Color(0, 0, 102));
        jButton1NowExcel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/导出当前L.png"))); // NOI18N
        jButton1NowExcel.setText("导出当前");
        jButton1NowExcel.setMaximumSize(new java.awt.Dimension(122, 33));
        jButton1NowExcel.setPreferredSize(new java.awt.Dimension(112, 33));
        jButton1NowExcel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1NowExcelActionPerformed(evt);
            }
        });

        jButton1AllExcel.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton1AllExcel.setForeground(new java.awt.Color(0, 0, 102));
        jButton1AllExcel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/导出全部L.png"))); // NOI18N
        jButton1AllExcel.setText("导出全部");
        jButton1AllExcel.setMaximumSize(new java.awt.Dimension(133, 33));
        jButton1AllExcel.setPreferredSize(new java.awt.Dimension(112, 33));
        jButton1AllExcel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1AllExcelActionPerformed(evt);
            }
        });

        jButtonPrint.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButtonPrint.setForeground(new java.awt.Color(0, 0, 102));
        jButtonPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/打印数据L.png"))); // NOI18N
        jButtonPrint.setText("打印数据");
        jButtonPrint.setMaximumSize(new java.awt.Dimension(133, 33));
        jButtonPrint.setPreferredSize(new java.awt.Dimension(112, 33));
        jButtonPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPrintActionPerformed(evt);
            }
        });

        jButton10.setFont(new java.awt.Font("微软雅黑", 1, 15)); // NOI18N
        jButton10.setForeground(new java.awt.Color(102, 0, 102));
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/主菜单.png"))); // NOI18N
        jButton10.setText("返回菜单");
        jButton10.setPreferredSize(new java.awt.Dimension(112, 35));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("宋体", 0, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 51, 51));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("管理员-Admin");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jButtonPrint, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1AllExcel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1NowExcel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel5)
                .addGap(20, 20, 20)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton1NowExcel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton1AllExcel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButtonPrint, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jDesktopPane1.setBackground(new java.awt.Color(226, 237, 252));
        jDesktopPane1.setPreferredSize(new java.awt.Dimension(1008, 540));

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1008, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 540, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 4, Short.MAX_VALUE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 1170, Short.MAX_VALUE))
                .addGap(6, 6, 6))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1182, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //公共结束浏览代码
    public static void closeList(Object[][] tableModel, String[] tableHead, String title) {
        varietiesData = new VarietiesData(tableModel, tableHead);
        varietiesData.setVisible(true);
        varietiesData.setTitle(title);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(varietiesData); //在父窗口中添加这个子窗口
        try {
            varietiesData.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

        System.gc();
    }

    //公共结束浏览代码
    public static void closeListplus(Object[][] tableModel, String[] tableHead, String title) {
        varietiesDataPlus = new VarietiesDataPlus(tableModel, tableHead);
        varietiesDataPlus.setVisible(true);
        varietiesDataPlus.setTitle(title);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(varietiesDataPlus); //在父窗口中添加这个子窗口
        try {
            varietiesDataPlus.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
        System.gc();
    }

    /**
     * 快捷操作--增加记录按钮事件
     *
     * @param evt
     */
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        String title = "";

        String gti = jDesktopPane1.getSelectedFrame().getTitle();

        if (gti.equals("个体基本信息") || gti.equals("公猪采精登记") || gti.equals("母猪配种情况登记")
                || gti.equals("母猪分娩情况登记") || gti.equals("母猪断奶登记") || gti.equals("种公猪资料") || gti.equals("种母猪资料")
                || gti.equals("后备猪2月龄登记") || gti.equals("后备猪4月龄登记") || gti.equals("后备猪6月龄登记") || gti.equals("100KG检测登记")
                || gti.equals("哺乳猪-保育猪") || gti.equals("保育猪-生长育肥猪") || gti.equals("保育猪-后备猪")
                || gti.equals("饲料出库登记") || gti.equals("饲料入库登记") || gti.equals("药品出库登记") || gti.equals("药品入库登记") || gti.equals("疫苗出库登记") || gti.equals("疫苗入库登记")
                || gti.equals("猪只免疫登记") || gti.equals("猪只销售登记") || gti.equals("疾病治疗登记") || gti.equals("基因检测登记") || gti.equals("猪只死亡登记") || gti.equals("屠宰性能测定登记")) {
            varietiesDataPlus = (VarietiesDataPlus) jDesktopPane1.getSelectedFrame();
            title = varietiesDataPlus.getTitle();
        } else {
            varietiesData = (VarietiesData) jDesktopPane1.getSelectedFrame();
            title = varietiesData.getTitle();
        }
        if (title.equals("猪场设置")) {
            FarmNameApp formNameApp = new FarmNameApp(varietiesData, MainApp.this, true);
            formNameApp.setVisible(true);
            return;
        }
        if (title.equals("品种资料")) {
            LinesApp linesApp = new LinesApp(varietiesData, MainApp.this, true);
            linesApp.setVisible(true);
            return;
        }
        if (title.equals("场内圈舍")) {
            PiggeryApp linesApp = new PiggeryApp(varietiesData, MainApp.this, true);
            linesApp.setVisible(true);
            return;
        }
        if (title.equals("猪只状态")) {
            SwintypeApp linesApp = new SwintypeApp(varietiesData, MainApp.this, true);
            linesApp.setVisible(true);
            return;
        }
        if (title.equals("品系管理")) {
            LineherdApp linesApp = new LineherdApp(varietiesData, MainApp.this, true);
            linesApp.setVisible(true);
            return;
        }
        if (title.equals("饲料类别")) {
            SllbApp sllbListApp = new SllbApp(varietiesData, MainApp.this, true);
            sllbListApp.setVisible(true);
            return;
        }

        if (title.equals("饲料信息")) {
            PigslApp pigslApp = new PigslApp(varietiesData, MainApp.this, true);
            pigslApp.setVisible(true);
            return;
        }
        if (title.equals("猪舍类别")) {
            ZslbApp zslbApp = new ZslbApp(varietiesData, MainApp.this, true);
            zslbApp.setVisible(true);
            return;
        }
        if (title.equals("药品信息")) {
            PigypApp pigypApp = new PigypApp(varietiesData, MainApp.this, true);
            pigypApp.setVisible(true);
            return;
        }
        if (title.equals("疫苗信息")) {
            VaccineApp vaccineApp = new VaccineApp(varietiesData, MainApp.this, true);
            vaccineApp.setVisible(true);
            return;
        }
        if (title.equals("免疫设置")) {
            MyszApp myszApp = new MyszApp(varietiesData, MainApp.this, true);
            myszApp.setVisible(true);
            return;
        }
        if (title.equals("种猪免疫设置")) {
            ZzmyszApp zzmyszApp = new ZzmyszApp(varietiesData, MainApp.this, true);
            zzmyszApp.setVisible(true);
            return;
        }
        if (title.equals("疾病信息")) {
            PigjbApp pigjbApp = new PigjbApp(varietiesData, MainApp.this, true);
            pigjbApp.setVisible(true);
            return;
        }
        if (title.equals("参数设置")) {
            DesignbaseApp designbaseApp = new DesignbaseApp(varietiesData, MainApp.this, true);
            designbaseApp.setVisible(true);
            return;
        }

        if (title.equals("栏位管理")) {
            FenceApp fenceApp = new FenceApp(varietiesData, MainApp.this, true);
            fenceApp.setVisible(true);
            return;
        }
        if (title.equals("员工职位")) {
            YgzwApp ygzwApp = new YgzwApp(varietiesData, MainApp.this, true);
            ygzwApp.setVisible(true);
            return;
        }
        if (title.equals("用户管理")) {
            EmployeeApp employeeApp = new EmployeeApp(varietiesData, MainApp.this, true);
            employeeApp.setVisible(true);
            return;
        }

        if (title.equals("个体基本信息")) {
            SelebithApp selebithApp = new SelebithApp(varietiesDataPlus, MainApp.this, true);
            selebithApp.setVisible(true);

        }
        if (title.equals("公猪采精登记")) {
            TakespermApp takespermApp = new TakespermApp(varietiesDataPlus, MainApp.this, true);
            takespermApp.setVisible(true);
        }
        if (title.equals("母猪配种情况登记")) {
            BreedingApp breedingApp = new BreedingApp(varietiesDataPlus, MainApp.this, true);
            breedingApp.setVisible(true);
        }
        if (title.equals("母猪分娩情况登记")) {
            ChildbirthApp childbirthApp = new ChildbirthApp(varietiesDataPlus, MainApp.this, true);
            childbirthApp.setVisible(true);
        }
        if (title.equals("母猪断奶登记")) {
            WeaningApp weaningApp = new WeaningApp(varietiesDataPlus, MainApp.this, true);
            weaningApp.setVisible(true);
        }
        if (title.equals("保育猪-生长育肥猪")) {
            TurnPig02 turnPig02 = new TurnPig02(MainApp.this, true, "保育猪-生长育肥猪");
            turnPig02.setVisible(true);
        }
        if (title.equals("保育猪-后备猪")) {
            TurnPig02 turnPig02 = new TurnPig02(MainApp.this, true, "保育猪-后备猪");
            turnPig02.setVisible(true);
        }
        if (title.equals("后备猪2月龄登记")) {
            TwoTestApp linesApp = new TwoTestApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("后备猪4月龄登记")) {
            FourTestApp linesApp = new FourTestApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("后备猪6月龄登记")) {
            SixTestApp linesApp = new SixTestApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("100KG检测登记")) {
            HundredTestApp linesApp = new HundredTestApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("饲料出库登记")) {
            SlckApp linesApp = new SlckApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("饲料入库登记")) {
            SlrkApp linesApp = new SlrkApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("药品出库登记")) {
            YpckApp linesApp = new YpckApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("药品入库登记")) {
            YprkApp linesApp = new YprkApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("疫苗出库登记")) {
            YmckApp linesApp = new YmckApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("疫苗入库登记")) {
            YmrkApp linesApp = new YmrkApp(varietiesDataPlus, MainApp.this, true);
            linesApp.setVisible(true);
        }
        if (title.equals("猪只免疫登记")) {
            PigImmune02 pigImmune02 = new PigImmune02(MainApp.this, true);
            pigImmune02.setVisible(true);
        }
        if (title.equals("猪只销售登记")) {
            PigSale02 pigSale02 = new PigSale02(MainApp.this, true);
            pigSale02.setVisible(true);
        }
        if (title.equals("疾病治疗登记")) {
            JbzlApp jbzlApp = new JbzlApp(varietiesDataPlus, MainApp.this, true);
            jbzlApp.setVisible(true);
        }
        if (title.equals("基因检测登记")) {
            JyjcApp jyjcApp = new JyjcApp(varietiesDataPlus, MainApp.this, true);
            jyjcApp.setVisible(true);
        }
        if (title.equals("猪只死亡登记")) {
            ZzswApp zzswApp = new ZzswApp(varietiesDataPlus, MainApp.this, true);
            zzswApp.setVisible(true);
        }
        if (title.equals("屠宰性能测定登记")) {
            TzxncdApp tzxncdApp = new TzxncdApp(varietiesDataPlus, MainApp.this, true);
            tzxncdApp.setVisible(true);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        JInternalFrame selectedFrame = jDesktopPane1.getSelectedFrame();
        selectedFrame.repaint();
    }//GEN-LAST:event_jButton6ActionPerformed
    /**
     * 快捷操作---删除记录
     *
     * @param evt
     */
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        String title = "";
        JTable jTable1 = null;
        String gti = jDesktopPane1.getSelectedFrame().getTitle();
        if (gti.equals("个体基本信息") || gti.equals("公猪采精登记") || gti.equals("母猪配种情况登记")
                || gti.equals("母猪分娩情况登记") || gti.equals("母猪断奶登记") || gti.equals("种公猪资料")
                || gti.equals("种母猪资料") || gti.equals("猪只免疫登记") || gti.equals("猪只销售登记")
                || gti.equals("饲料入库登记") || gti.equals("饲料出库登记") || gti.equals("药品入库登记") || gti.equals("药品出库登记") || gti.equals("疫苗入库登记") || gti.equals("疫苗出库登记")
                || gti.equals("疾病治疗登记") || gti.equals("基因检测登记") || gti.equals("猪只死亡登记") || gti.equals("屠宰性能测定登记")) {
            varietiesDataPlus = (VarietiesDataPlus) jDesktopPane1.getSelectedFrame();
            title = varietiesDataPlus.getTitle();
            jTable1 = varietiesDataPlus.getjTable1();

        } else {
            varietiesData = (VarietiesData) jDesktopPane1.getSelectedFrame();
            title = varietiesData.getTitle();
            jTable1 = varietiesData.getjTable1();
        }
        //猪只免疫登记   删除当前页
        if (title.equals("猪只免疫登记")) {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            if (jTable1.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null,
                        "无要修改的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            for (int row = 0; row < jTable1.getRowCount(); row++) {
                zzmyMapper.deleteByid((String) jTable1.getValueAt(row, 1));//根据id删除
                sqlSession.commit();
            }
            JOptionPane.showMessageDialog(null,
                    "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            //跟新界面
            zzmyPageModel = new ZzmyPageModel(17, zzmyMapperPlus.SelectCount(), zzmyMapperPlus, false);
            Zzmypage(1);
            return;
        }
        if (title.equals("猪只销售登记")) {
            SqlSession sqlSession = MybatisUtil.getSqlSession();
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            if (jTable1.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null,
                        "无要修改的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            for (int row = 0; row < jTable1.getRowCount(); row++) {
                zzxsMapper.deleteByid((String) jTable1.getValueAt(row, 0));//根据id删除
                sqlSession.commit();
            }
            JOptionPane.showMessageDialog(null,
                    "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            //跟新界面
            zzxsPageModel = new ZzxsPageModel(17, zzxsMapperPlus.SelectCount(), zzxsMapperPlus, false);
            Zzxspage(1);
            return;
        }

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null,
                    "请选择您要修改的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        if (title.equals("猪场设置")) {
            String farmid = (String) model.getValueAt(selectedRow, 1);
            String farmname = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除猪场设置：" + farmname + "---" + farmid);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                FarmNameMapper mapper = sqlSession.getMapper(FarmNameMapper.class);
                mapper.deleteByFarmid(farmid);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if (title.equals("品种资料")) {
            String lineid = (String) model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除品种资料：" + linename + "---" + lineid);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                LinesMapper mapper = sqlSession.getMapper(LinesMapper.class);
                mapper.deleteByLineid(lineid);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //品种map更新
                List<Lines> linesList = mapper.selectAll();
                for (int i = 0; i < linesList.size(); i++) {
                    String[] things = new String[linesList.size()];
                    lineidIdtoNameSmap.put(linesList.get(i).getLineid(), linesList.get(i).getLinename());
                    linesNametoIdSmap.put(linesList.get(i).getLinename(), linesList.get(i).getLineid());
                    for (int j = 0; j < linesList.size(); j++) {
                        things[j] = linesList.get(j).getLinename();
                        if (linesList.get(i).getLineid().equals(linesList.get(j).getLineid())) {
                            String thingstemp = things[0];
                            things[0] = things[j];
                            things[j] = thingstemp;
                        }
                    }
                    linesThingsmap.put(linesList.get(i).getLineid(), things);
                }
                sqlSession.close();
            }

        }
        if (title.equals("场内圈舍")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除场内圈舍：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                PiggeryMapper mapper = sqlSession.getMapper(PiggeryMapper.class);
                mapper.deleteByPiggeryid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //猪舍map更新
                piggeryList = mapper.selectAll();
                for (int i = 0; i < piggeryList.size(); i++) {
                    piggeryThingsShow = new String[piggeryList.size()];
                    piggeryIdtoNameSmap.put(piggeryList.get(i).getNumber(), piggeryList.get(i).getCategory());
                    piggeryNametoIdSmap.put(piggeryList.get(i).getCategory(), piggeryList.get(i).getNumber());
                    for (int j = 0; j < piggeryList.size(); j++) {
                        piggeryThingsShow[j] = piggeryList.get(j).getCategory();
                        if (piggeryList.get(i).getNumber().equals(piggeryList.get(j).getNumber())) {
                            String thingstemp = piggeryThingsShow[0];
                            piggeryThingsShow[0] = piggeryThingsShow[j];
                            piggeryThingsShow[j] = thingstemp;
                        }
                    }
                    piggeryThingsmap.put(piggeryList.get(i).getNumber(), piggeryThingsShow);
                }
                pigCategoryThingsShow = new String[piggeryList.size() + 1];
                for (int i = 0; i < piggeryList.size() + 1; i++) {
                    if (i == 0) {
                        pigCategoryThingsShow[i] = "全部舍";
                    } else {
                        pigCategoryThingsShow[i] = piggeryList.get(i - 1).getCategory();
                    }
                }
                sqlSession.close();

            }
        }
        if (title.equals("猪只状态")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除猪只状态：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                mapper.deleteByTypeid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //状态map更新
                List<Swintype> swintypeList = mapper.selectAll();
                for (int i = 0; i < swintypeList.size(); i++) {
                    swintypeThingsShow = new String[swintypeList.size()];
                    swintypeIdtoNameSmap.put(swintypeList.get(i).getTypeid(), swintypeList.get(i).getTypename());
                    swintypeNametoIdSmap.put(swintypeList.get(i).getTypename(), swintypeList.get(i).getTypeid());
                    for (int j = 0; j < swintypeList.size(); j++) {
                        swintypeThingsShow[j] = swintypeList.get(j).getTypename();
                        if (swintypeList.get(i).getTypeid().equals(swintypeList.get(j).getTypeid())) {
                            String thingstemp = swintypeThingsShow[0];
                            swintypeThingsShow[0] = swintypeThingsShow[j];
                            swintypeThingsShow[j] = thingstemp;
                        }
                    }
                    swintypeThingsmap.put(swintypeList.get(i).getTypeid(), swintypeThingsShow);
                }
                sqlSession.close();
            }
        }
        if (title.equals("品系管理")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除品系管理：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                LineherdMapper mapper = sqlSession.getMapper(LineherdMapper.class);
                mapper.deleteByTypeid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //品系map更新
                List<Lineherd> lineherdList = mapper.selectAll();
                for (int i = 0; i < lineherdList.size(); i++) {
                    String[] things1 = new String[lineherdList.size()];
                    lineherdIdtoNameSmap.put(lineherdList.get(i).getHerdid(), lineherdList.get(i).getHerdname());
                    lineherdNametoIdSmap.put(lineherdList.get(i).getHerdname(), lineherdList.get(i).getHerdid());
                    for (int j = 0; j < lineherdList.size(); j++) {
                        things1[j] = lineherdList.get(j).getHerdname();
                        if (lineherdList.get(i).getHerdid().equals(lineherdList.get(j).getHerdid())) {
                            String thingstemp = things1[0];
                            things1[0] = things1[j];
                            things1[j] = thingstemp;
                        }
                    }
                    lineherdThingsmap.put(lineherdList.get(i).getHerdid(), things1);

                }
                sqlSession.close();
            }
        }
        if (title.equals("饲料信息")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除饲料信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                PigslMapper mapper = sqlSession.getMapper(PigslMapper.class);
                SlkcMapper mapper1 = sqlSession.getMapper(SlkcMapper.class);
                mapper.deleteByid(linename);
                mapper1.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //饲料map更新
                List<Pigsl> pigslList = mapper.selectAll();
                for (int i = 0; i < pigslList.size(); i++) {
                    pigslThingsShow = new String[pigslList.size()];
                    pigslIdtoNameSmap.put(pigslList.get(i).getTypeid(), pigslList.get(i).getTypename());
                    pigslNametoIdSmap.put(pigslList.get(i).getTypename(), pigslList.get(i).getTypeid());
                    for (int j = 0; j < pigslList.size(); j++) {
                        pigslThingsShow[j] = pigslList.get(j).getTypename();
                        if (pigslList.get(i).getTypeid().equals(pigslList.get(j).getTypeid())) {
                            String thingstemp = pigslThingsShow[0];
                            pigslThingsShow[0] = pigslThingsShow[j];
                            pigslThingsShow[j] = thingstemp;
                        }
                    }
                    pigslThingsmap.put(pigslList.get(i).getTypeid(), pigslThingsShow);
                }
                sqlSession.close();
            }
        }
        if (title.equals("药品信息")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除药品信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                PigypMapper mapper = sqlSession.getMapper(PigypMapper.class);
                YpkcMapper mapper1 = sqlSession.getMapper(YpkcMapper.class);
                mapper.deleteByid(linename);
                mapper1.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //药品map更新
                List<Pigyp> pigypList = mapper.selectAll();
                for (int i = 0; i < pigypList.size(); i++) {
                    pigypThingsShow = new String[pigypList.size()];
                    pigypIdtoNameSmap.put(pigypList.get(i).getTypeid(), pigypList.get(i).getTypename());
                    pigypNametoIdSmap.put(pigypList.get(i).getTypename(), pigypList.get(i).getTypeid());
                    for (int j = 0; j < pigypList.size(); j++) {
                        pigypThingsShow[j] = pigypList.get(j).getTypename();
                        if (pigypList.get(i).getTypeid().equals(pigypList.get(j).getTypeid())) {
                            String thingstemp = pigypThingsShow[0];
                            pigypThingsShow[0] = pigypThingsShow[j];
                            pigypThingsShow[j] = thingstemp;
                        }
                    }
                    pigypThingsmap.put(pigypList.get(i).getTypeid(), pigypThingsShow);
                }
                sqlSession.close();
            }
        }
        if (title.equals("疾病信息")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除疾病信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                PigjbMapper mapper = sqlSession.getMapper(PigjbMapper.class);

                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //疾病map更新
                List<Pigjb> pigjbList = mapper.selectAll();
                for (int i = 0; i < pigjbList.size(); i++) {
                    pigjbThingsShow = new String[pigjbList.size()];
                    pigjbIdtoNameSmap.put(pigjbList.get(i).getTypeid(), pigjbList.get(i).getTypename());
                    pigjbNametoIdSmap.put(pigjbList.get(i).getTypename(), pigjbList.get(i).getTypeid());
                    for (int j = 0; j < pigjbList.size(); j++) {
                        pigjbThingsShow[j] = pigjbList.get(j).getTypename();
                        if (pigjbList.get(i).getTypeid().equals(pigjbList.get(j).getTypeid())) {
                            String thingstemp = pigjbThingsShow[0];
                            pigjbThingsShow[0] = pigjbThingsShow[j];
                            pigjbThingsShow[j] = thingstemp;
                        }
                    }
                    pigjbThingsmap.put(pigjbList.get(i).getTypeid(), pigjbThingsShow);
                }
                sqlSession.close();
            }
        }
        if (title.equals("疫苗信息")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除疫苗信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                VaccineMapper mapper = sqlSession.getMapper(VaccineMapper.class);
                YmkcMapper mapper1 = sqlSession.getMapper(YmkcMapper.class);
                mapper1.deleteByid(linename);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //疫苗map更新
                List<Vaccine> vaccineList = mapper.selectAll();
                for (int i = 0; i < vaccineList.size(); i++) {
                    vaccineThingsShow = new String[vaccineList.size()];
                    vaccineIdtoNameSmap.put(vaccineList.get(i).getTypeid(), vaccineList.get(i).getTypename());
                    vaccineNametoIdSmap.put(vaccineList.get(i).getTypename(), vaccineList.get(i).getTypeid());
                    for (int j = 0; j < vaccineList.size(); j++) {
                        vaccineThingsShow[j] = vaccineList.get(j).getTypename();
                        if (vaccineList.get(i).getTypeid().equals(vaccineList.get(j).getTypeid())) {
                            String thingstemp = vaccineThingsShow[0];
                            vaccineThingsShow[0] = vaccineThingsShow[j];
                            vaccineThingsShow[j] = thingstemp;
                        }
                    }
                    vaccineThingsmap.put(vaccineList.get(i).getTypeid(), vaccineThingsShow);
                }
                sqlSession.close();
            }
        }
        if (title.equals("免疫设置")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除疾病信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                MyszMapper mapper = sqlSession.getMapper(MyszMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if (title.equals("种猪免疫设置")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除疾病信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                ZzmyszMapper mapper = sqlSession.getMapper(ZzmyszMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if (title.equals("参数设置")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除设置名称：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if (title.equals("猪舍类别")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除设置名称：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                ZslbMapper mapper = sqlSession.getMapper(ZslbMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if (title.equals("饲料类别")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除设置名称：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                SllbMapper mapper = sqlSession.getMapper(SllbMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if (title.equals("员工职位")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除员工职位：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                YgzwMapper mapper = sqlSession.getMapper(YgzwMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        if (title.equals("栏位管理")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除栏位编号：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                FenceMapper mapper = sqlSession.getMapper(FenceMapper.class);
                mapper.deleteByFenceid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //栏位map更新
                List<Fence> fenceList = mapper.selectAll();
                for (int i = 0; i < fenceList.size(); i++) {
                    fenceThingsShow = new String[fenceList.size()];
                    fenceIdtoNameSmap.put(fenceList.get(i).getFenceid(), fenceList.get(i).getFencename());
                    fenceNametoIdSmap.put(fenceList.get(i).getFencename(), fenceList.get(i).getFenceid());
                    for (int j = 0; j < fenceList.size(); j++) {
                        fenceThingsShow[j] = fenceList.get(j).getFencename();
                        if (fenceList.get(i).getFenceid().equals(fenceList.get(j).getFenceid())) {
                            String thingstemp = fenceThingsShow[0];
                            fenceThingsShow[0] = fenceThingsShow[j];
                            fenceThingsShow[j] = thingstemp;
                        }
                    }
                    fenceThingsmap.put(fenceList.get(i).getFenceid(), fenceThingsShow);
                }
                //全部栏   
                pigFenceThingsShow = new String[fenceList.size() + 1];
                for (int i = 0; i < fenceList.size() + 1; i++) {
                    if (i == 0) {
                        pigFenceThingsShow[i] = "全部栏";
                    } else {
                        pigFenceThingsShow[i] = fenceList.get(i - 1).getFencename();
                    }
                }
                sqlSession.close();

            }
        }
        if (title.equals("用户管理")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除员工编号：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesData.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //雇员map更新
                List<Employee> employeeList = mapper.selectAll();
                for (int i = 0; i < employeeList.size(); i++) {
                    employeeThingsShow = new String[employeeList.size()];
                    employeeIdtoNameSmap.put(employeeList.get(i).getEmployeeid(), employeeList.get(i).getUser_name());
                    employeeNametoIdSmap.put(employeeList.get(i).getUser_name(), employeeList.get(i).getEmployeeid());
                    for (int j = 0; j < employeeList.size(); j++) {
                        employeeThingsShow[j] = employeeList.get(j).getUser_name();
                        if (employeeList.get(i).getEmployeeid().equals(employeeList.get(j).getEmployeeid())) {
                            String thingstemp = employeeThingsShow[0];
                            employeeThingsShow[0] = employeeThingsShow[j];
                            employeeThingsShow[j] = thingstemp;
                        }
                    }
                    employeeThingsmap.put(employeeList.get(i).getEmployeeid(), employeeThingsShow);
                }
                sqlSession.close();
            }
        }

        if (title.equals("个体基本信息")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除个体信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                SelebithMapper mapper = sqlSession.getMapper(SelebithMapper.class);
                mapper.deleteByTypeid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();

                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.selebithPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = selethMapperPlus.SelectCount();
                } else {
                    cout = selethMapperPlus.SelebithSelectSearchByCount(pignum, fenceid, zzzt, startDate, endDate);
                }
                selebithPageModel.reset(cout, ssf);
                Selebithpage(pageAge);
                sqlSession.close();
            }
        }
        if (title.equals("公猪采精登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除个体编号：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                TakespermMapper mapper = sqlSession.getMapper(TakespermMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                sqlSession.close();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式
                int pageAge = MainApp.takespermPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = takespermMapperPlus.SelectCount();
                } else {
                    cout = takespermMapperPlus.TakespermSelectSearchByCount(pignum, startDate, endDate);
                }
                takespermPageModel.reset(cout, ssf);

                Takespermpage(pageAge);

                sqlSession.close();

            }
        }
        if (title.equals("母猪分娩情况登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除个体信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                ChildbirthMapper mapper = sqlSession.getMapper(ChildbirthMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式
                int pageAge = MainApp.childbirthPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = childbirthMapperPlus.SelectCount();
                } else {
                    cout = childbirthMapperPlus.ChildbirthSelectSearchByCount(pignum, fenceid, startDate, endDate);
                }
                childbirthPageModel.reset(cout, ssf);

                Childbirthpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("饲料入库登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除个体信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                SlrkMapper mapper = sqlSession.getMapper(SlrkMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式
                int pageAge = MainApp.slrkPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = slrkMapperPlus.SelectCount();
                } else {
                    cout = slrkMapperPlus.SlrkSelectSearchByCount(startDate, endDate);
                }
                slrkPageModel.reset(cout, ssf);

                Slrkpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("饲料出库登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除个体信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                SlckMapper mapper = sqlSession.getMapper(SlckMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.slckPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = slckMapperPlus.SelectCount();
                } else {
                    cout = slckMapperPlus.SlckSelectSearchByCount(fenceid, startDate, endDate);
                }
                slckPageModel.reset(cout, ssf);

                Slckpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("药品入库登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除个体信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                YprkMapper mapper = sqlSession.getMapper(YprkMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.yprkPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = yprkMapperPlus.SelectCount();
                } else {
                    cout = yprkMapperPlus.YprkSelectSearchByCount(startDate, endDate);
                }
                yprkPageModel.reset(cout, ssf);

                Yprkpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("药品出库登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除出库信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                YpckMapper mapper = sqlSession.getMapper(YpckMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.ypckPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = ypckMapperPlus.SelectCount();
                } else {
                    cout = ypckMapperPlus.YpckSelectSearchByCount(fenceid, startDate, endDate);
                }
                ypckPageModel.reset(cout, ssf);

                Ypckpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("疫苗入库登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除个体信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                YmrkMapper mapper = sqlSession.getMapper(YmrkMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.ymrkPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = ymrkMapperPlus.SelectCount();
                } else {
                    cout = ymrkMapperPlus.YmrkSelectSearchByCount(startDate, endDate);
                }
                ymrkPageModel.reset(cout, ssf);

                Ymrkpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("疫苗出库登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除出库信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                YmckMapper mapper = sqlSession.getMapper(YmckMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.ymckPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = ymckMapperPlus.SelectCount();
                } else {
                    cout = ymckMapperPlus.YmckSelectSearchByCount(fenceid, startDate, endDate);
                }
                ymckPageModel.reset(cout, ssf);

                Ymckpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("疾病治疗登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除治疗信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                JbzlMapper mapper = sqlSession.getMapper(JbzlMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.jbzlPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = jbzlMapperPlus.SelectCount();
                } else {
                    cout = jbzlMapperPlus.JbzlSelectSearchByCount(pignum, zzzt, startDate, endDate);
                }
                jbzlPageModel.reset(cout, ssf);

                Jbzlpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("基因检测登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除治疗信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                JyjcMapper mapper = sqlSession.getMapper(JyjcMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.jyjcPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = jyjcMapperPlus.SelectCount();
                } else {
                    cout = jyjcMapperPlus.JyjcSelectSearchByCount(pignum, fenceid, startDate, endDate);
                }
                jyjcPageModel.reset(cout, ssf);

                Jyjcpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("猪只死亡登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除死亡登记信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                ZzswMapper mapper = sqlSession.getMapper(ZzswMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.zzswPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = zzswMapperPlus.SelectCount();
                } else {
                    cout = zzswMapperPlus.ZzswSelectSearchByCount(pignum, fenceid, startDate, endDate);
                }
                zzswPageModel.reset(cout, ssf);
                Zzswpage(pageAge);

                sqlSession.close();
            }
        }
        if (title.equals("屠宰性能测定登记")) {
            // String lineid = (String)model.getValueAt(selectedRow, 1);
            String linename = (String) model.getValueAt(selectedRow, 0);
            int resultfarmname = JOptionPane.showConfirmDialog(null,
                    "是否删除屠宰登记信息：" + linename);
            if (resultfarmname == JOptionPane.YES_OPTION) {
                TzxncdMapper mapper = sqlSession.getMapper(TzxncdMapper.class);
                mapper.deleteByid(linename);
                model.removeRow(selectedRow);
                varietiesDataPlus.validate();
                sqlSession.commit();
                JOptionPane.showMessageDialog(null,
                        "删除成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                //删除后更新数据格式

                int pageAge = MainApp.tzxncdPageModel.getPageNo();
                int cout = 0;
                if (ssf == false) {
                    cout = tzxncdMapperPlus.SelectCount();
                } else {
                    cout = tzxncdMapperPlus.TzxncdSelectSearchByCount(pignum, fenceid, startDate, endDate);
                }
                tzxncdPageModel.reset(cout, ssf);
                Tzxncdpage(pageAge);

                sqlSession.close();
            }
        }

    }//GEN-LAST:event_jButton2ActionPerformed
    /**
     * 快捷操作---更改记录
     *
     * @param evt
     */
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        String title = "";
        JTable jTable1 = null;
        String gti = jDesktopPane1.getSelectedFrame().getTitle();
        if (gti.equals("个体基本信息") || gti.equals("公猪采精登记") || gti.equals("母猪配种情况登记")
                || gti.equals("母猪分娩情况登记") || gti.equals("母猪断奶登记") || gti.equals("种公猪资料")
                || gti.equals("种母猪资料") || gti.equals("后备猪2月龄登记") || gti.equals("后备猪4月龄登记") || gti.equals("后备猪6月龄登记") || gti.equals("100KG检测登记")
                || gti.equals("饲料入库登记") || gti.equals("饲料出库登记") || gti.equals("药品入库登记") || gti.equals("药品出库登记") || gti.equals("疫苗入库登记") || gti.equals("疫苗出库登记")
                || gti.equals("疾病治疗登记") || gti.equals("基因检测登记") || gti.equals("猪只死亡登记") || gti.equals("屠宰性能测定登记")) {
            varietiesDataPlus = (VarietiesDataPlus) jDesktopPane1.getSelectedFrame();
            title = varietiesDataPlus.getTitle();
            jTable1 = varietiesDataPlus.getjTable1();

        } else {
            varietiesData = (VarietiesData) jDesktopPane1.getSelectedFrame();
            title = varietiesData.getTitle();
            jTable1 = varietiesData.getjTable1();
        }
        System.out.println(title);
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null,
                    "请选择您要修改的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (title.equals("猪场设置")) {
            String farmid = (String) model.getValueAt(selectedRow, 1);
            FarmNameApp formNameApp = new FarmNameApp(varietiesData, farmid, MainApp.this, true);
            formNameApp.setVisible(true);

        }
        if (title.equals("品种资料")) {
            String lineid = (String) model.getValueAt(selectedRow, 1);
            LinesApp lineApp = new LinesApp(varietiesData, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("场内圈舍")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            PiggeryApp lineApp = new PiggeryApp(varietiesData, lineid, MainApp.this, true);
            lineApp.setVisible(true);

        }
        if (title.equals("猪只状态")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            SwintypeApp lineApp = new SwintypeApp(varietiesData, lineid, MainApp.this, true);
            lineApp.setVisible(true);

        }
        if (title.equals("品系管理")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            LineherdApp lineApp = new LineherdApp(varietiesData, lineid, MainApp.this, true);
            lineApp.setVisible(true);

        }
        if (title.equals("饲料类别")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            SllbApp lineApp = new SllbApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }

        if (title.equals("饲料信息")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            PigslApp lineApp = new PigslApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("猪舍类别")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            ZslbApp lineApp = new ZslbApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("药品信息")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            PigypApp lineApp = new PigypApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("疫苗信息")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            VaccineApp lineApp = new VaccineApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("免疫设置")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            MyszApp lineApp = new MyszApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("种猪免疫设置")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            ZzmyszApp lineApp = new ZzmyszApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("疾病信息")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            PigjbApp lineApp = new PigjbApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("参数设置")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            DesignbaseApp lineApp = new DesignbaseApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("栏位管理")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            FenceApp lineApp = new FenceApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("用户管理")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            EmployeeApp lineApp = new EmployeeApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }
        if (title.equals("员工职位")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            YgzwApp lineApp = new YgzwApp(varietiesData, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);

        }//免疫提醒
        if (title.equals("疫苗提醒")) {
            String lineid = (String) model.getValueAt(selectedRow, 3);
            MytxApp lineApp = new MytxApp(lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);
        }
        if (title.equals("种猪疫苗提醒")) {
            String zzzt = (String) model.getValueAt(selectedRow, 1);
            String szrq = (String) model.getValueAt(selectedRow, 2);
            String rqdw = (String) model.getValueAt(selectedRow, 3);
            ZzmytxApp lineApp = new ZzmytxApp(zzzt, szrq, rqdw, MainApp.this, true) {
            };
            lineApp.setVisible(true);
        }
        if (title.equals("个体基本信息")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            SelebithApp lineApp = new SelebithApp(varietiesDataPlus, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);
        }

        if (title.equals("公猪采精登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            TakespermApp lineApp = new TakespermApp(varietiesDataPlus, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);
        }

        if (title.equals("母猪配种情况登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            BreedingApp lineApp = new BreedingApp(varietiesDataPlus, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);
        }
        if (title.equals("母猪分娩情况登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            ChildbirthApp lineApp = new ChildbirthApp(varietiesDataPlus, lineid, MainApp.this, true) {
            };
            lineApp.setVisible(true);
        }
        //业绩查询
        if (title.equals("种公猪资料")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            MaleBoarApp maleBoarApp = new MaleBoarApp(lineid, MainApp.this, true);
            maleBoarApp.setVisible(true);
        }
        if (title.equals("种母猪资料")) {
            System.out.println(title);
            String lineid = (String) model.getValueAt(selectedRow, 0);
            FemaleBoarApp femaleBoarApp = new FemaleBoarApp(lineid, MainApp.this, true);
            femaleBoarApp.setVisible(true);
        }
        if (title.equals("后备猪2月龄登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            TwoTestApp lineApp = new TwoTestApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("后备猪4月龄登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            FourTestApp lineApp = new FourTestApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("后备猪6月龄登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            SixTestApp lineApp = new SixTestApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("100KG检测登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            HundredTestApp lineApp = new HundredTestApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("饲料入库登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            SlrkApp lineApp = new SlrkApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("饲料出库登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            SlckApp lineApp = new SlckApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("药品出库登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            YpckApp lineApp = new YpckApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("药品入库登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            YprkApp lineApp = new YprkApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("疫苗出库登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            YmckApp lineApp = new YmckApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("疫苗入库登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            YmrkApp lineApp = new YmrkApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("疾病治疗登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            JbzlApp lineApp = new JbzlApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("基因检测登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            JyjcApp lineApp = new JyjcApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("猪只死亡登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            ZzswApp lineApp = new ZzswApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("屠宰性能测定登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            TzxncdApp lineApp = new TzxncdApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
        if (title.equals("屠宰性能测定登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            TzxncdApp lineApp = new TzxncdApp(varietiesDataPlus, lineid, MainApp.this, true);
            lineApp.setVisible(true);
        }
    }//GEN-LAST:event_jButton4ActionPerformed
    /**
     * 快捷操作---详细信息
     *
     * @param evt
     */
    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        String title = "";
        JTable jTable1 = null;
        String gti = jDesktopPane1.getSelectedFrame().getTitle();
        if (gti.equals("个体基本信息") || gti.equals("公猪采精登记") || gti.equals("母猪配种情况登记")
                || gti.equals("母猪分娩情况登记") || gti.equals("母猪断奶登记") || gti.equals("种公猪资料")
                || gti.equals("种母猪资料") || gti.equals("后备猪2月龄登记") || gti.equals("后备猪4月龄登记") || gti.equals("后备猪6月龄登记")
                || gti.equals("100KG检测登记") || gti.equals("屠宰性能测定登记") || gti.equals("系谱数据") || gti.equals("育种个体信息")
                || gti.equals("后备2月性状") || gti.equals("后备4月性状") || gti.equals("后备6月性状") || gti.equals("100kg测定性状")) {//
            varietiesDataPlus = (VarietiesDataPlus) jDesktopPane1.getSelectedFrame();
            title = varietiesDataPlus.getTitle();
            jTable1 = varietiesDataPlus.getjTable1();
        } else if (gti.equals("选种选配")) {
            title = xzxp.varietiesDataPlus2.getTitle();
            jTable1 = xzxp.varietiesDataPlus2.getjTable1();
        } else {
            varietiesData = (VarietiesData) jDesktopPane1.getSelectedFrame();
            title = varietiesData.getTitle();
            jTable1 = varietiesData.getjTable1();
        }

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null,
                    "请选择您要查询的数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (title.equals("个体基本信息") || title.equals("系谱数据") || title.equals("育种个体信息") || title.equals("选种选配")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            DetailedApp detailApp = new DetailedApp(lineid, MainApp.this, true);
            detailApp.setVisible(true);

        }
        if (title.equals("公猪采精登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            TakespermApp takespermApp = new TakespermApp(lineid, MainApp.this, true, 1);
            takespermApp.setVisible(true);
        }
        if (title.equals("母猪配种情况登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            BreedingApp breedingApp = new BreedingApp(lineid, MainApp.this, true, 1);
            breedingApp.setVisible(true);
        }
        if (title.equals("母猪分娩情况登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            ChildbirthApp childbirthApp = new ChildbirthApp(lineid, MainApp.this, true);
            childbirthApp.setVisible(true);
        }
        if (title.equals("母猪断奶登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            WeaningApp weaningApp = new WeaningApp(lineid, MainApp.this, true);
            weaningApp.setVisible(true);
        }
        if (title.equals("后备猪2月龄登记") || title.equals("后备2月性状")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            TwoTestApp twoTestApp = new TwoTestApp(lineid, MainApp.this, true, 1);
            twoTestApp.setVisible(true);
        }
        if (title.equals("后备猪4月龄登记") || title.equals("后备4月性状")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            FourTestApp fourTestApp = new FourTestApp(lineid, MainApp.this, true, 1);
            fourTestApp.setVisible(true);
        }
        if (title.equals("后备猪6月龄登记") || title.equals("后备6月性状")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            SixTestApp sixTestApp = new SixTestApp(lineid, MainApp.this, true, 1);
            sixTestApp.setVisible(true);
        }
        if (title.equals("100KG检测登记") || title.equals("100kg测定性状")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            HundredTestApp hundredTestApp = new HundredTestApp(lineid, MainApp.this, true, 1);
            hundredTestApp.setVisible(true);
        }
        if (title.equals("屠宰性能测定登记")) {
            String lineid = (String) model.getValueAt(selectedRow, 0);
            TzxncdApp tzxncdApp = new TzxncdApp(lineid, MainApp.this, true, 1);
            tzxncdApp.setVisible(true);
        }

    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * 搜索栏---查询信息
     *
     * @param evt
     */
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }

        if (jDesktopPane1.getSelectedFrame().getTitle().equals("选种选配")) {
            ssf = true;

            pignum = "%" + jTextField01.getText();
            if (StringUtils.isBlank(jTextField01.getText())) {
                return;
            }
            XzxpMapperPlus xzxpMapperPlus = new XzxpMapperPlus();
            if (xzxpMapperPlus.selectById(pignum) == null || StringUtils.isBlank(jTextField01.getText())) {
                JOptionPane.showMessageDialog(null, "请输入正确种猪编号！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            xzxp.setSelebithtemp(xzxpMapperPlus.Jqjy(pignum));
            pageModel = new PageModel(xzxp.getSelebithtemp());
            Xzxppage(1);
            jButton8.setEnabled(true);
            jButton1NowExcel.setEnabled(true);
            jButton1AllExcel.setEnabled(true);
            jButtonPrint.setEnabled(true);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("系谱数据")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            if (fenceid.equals("全部舍")) {
                fenceid = "%";
            } else {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            }
            yzgtxxPageModel.reset(yzMapperPlus.selectAllyzgtxxBycount(startDate, endDate, fenceid));
            Yzxppage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("育种个体信息")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            if (fenceid.equals("全部舍")) {
                fenceid = "%";
            } else {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            }

            yzgtxxPageModel.reset(yzMapperPlus.selectAllyzgtxxBycount(startDate, endDate, fenceid));
            Yzgtxxpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("后备2月性状")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            if (fenceid.equals("全部舍")) {
                fenceid = "%";
            } else {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            }

            yzTwotestPageModel.reset(yzMapperPlus.selectAlltwotestBycount(startDate, endDate, fenceid));
            Yztwotestpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("后备4月性状")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            if (fenceid.equals("全部舍")) {
                fenceid = "%";
            } else {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            }

            yzFourtestPageModel.reset(yzMapperPlus.selectAllfourtestBycount(startDate, endDate, fenceid));
            Yzfourtestpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("后备6月性状")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            if (fenceid.equals("全部舍")) {
                fenceid = "%";
            } else {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            }

            yzSixtestPageModel.reset(yzMapperPlus.selectAllsixtestBycount(startDate, endDate, fenceid));
            Yzsixtestpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("100kg测定性状")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            if (fenceid.equals("全部舍")) {
                fenceid = "%";
            } else {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            }

            yzHundredtestPageModel.reset(yzMapperPlus.selectAllhundredtestBycount(startDate, endDate, fenceid));
            Yzhundredtestpage(1);

        }

        //上面的复杂查询 复杂搜索
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("母猪非亲缘公猪查询")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = jTextField01.getText();
            JqqyjyMapperPlus jqqyjyAapperPlus = new JqqyjyMapperPlus();

            List<Selebith> SelebithList = jqqyjyAapperPlus.Jqjy(pignum);
            ArrayList<String> SelebithList2 = new ArrayList<>();
            if (SelebithList == null) {
                return;
            }
            SelebithList2.add("非亲缘公猪个体编号   所在猪舍   所在猪栏");
            Object[][] tableModel = new Object[SelebithList.size()][3];
            for (int j = 0; j < SelebithList.size(); j++) {
                tableModel[j][0] = SelebithList.get(j).getR_animal();
                tableModel[j][1] = piggeryIdtoNameSmap.get(SelebithList.get(j).getR_cage());
                tableModel[j][2] = fenceIdtoNameSmap.get(SelebithList.get(j).getR_pcage());
                SelebithList2.add(tableModel[j][0] + " " + tableModel[j][1] + " " + tableModel[j][2]);
            }
            printData.setPrintDataStringList(SelebithList2);

            String[] tableHead = new String[]{"非亲缘公猪个体编号", "所在猪舍", "所在猪栏"};
            String title1 = "母猪非亲缘公猪查询";
            closeList(tableModel, tableHead, title1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("个体基本信息")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            selebithPageModel.reset(selethMapperPlus.SelebithSelectSearchByCount(pignum, fenceid, zzzt, startDate, endDate), true);
            Selebithpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("种公猪资料")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = jTextField01.getText() + "%";

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            maleBoarPageModel.reset(maleBoarMapperPlus.MaleBoarSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            MaleBoarpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("种母猪资料")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("种母猪")) {
                zzzt = "%";
            }
            if (zzzt.equals("后备母猪")) {
                zzzt = "5";
            }
            if (zzzt.equals("妊娠母猪")) {
                zzzt = "6";
            }
            if (zzzt.equals("哺乳母猪")) {
                zzzt = "7";
            }
            if (zzzt.equals("空怀母猪")) {
                zzzt = "8";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            femaleBoarPageModel.reset(famaleBoarMapperPlus.FemaleBoarSelectSearchByCount(pignum, fenceid, zzzt, startDate, endDate), true);
            FemaleBoarpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("公猪采精登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            takespermPageModel.reset(takespermMapperPlus.TakespermSelectSearchByCount(pignum, startDate, endDate), true);
            Takespermpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("母猪配种情况登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            switch (zzzt) {
                case "配种状态":
                    zzzt = "%";
                    break;
                case "检验状态":
                    zzzt = "1";
                    break;
                case "妊娠状态":
                    zzzt = "2";
                    break;
                case "返情状态":
                    zzzt = "3";
                    break;
                default:
                    break;
            }
            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            breedingPageModel.reset(breedingMapperPlus.BreedingSelectSearchByCount(pignum, fenceid, zzzt, startDate, endDate), true);
            Breedingpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("母猪分娩情况登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            childbirthPageModel.reset(childbirthMapperPlus.ChildbirthSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            Childbirthpage(1);
        }

        if (jDesktopPane1.getSelectedFrame().getTitle().equals("母猪断奶登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            weaningPageModel.reset(weaningMapperPlus.WeaningSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            Weaningpage(1);
        }
        //快速查询
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("哺乳猪-保育猪")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            feedingTurnConservationPageModel.reset(feedingTurnConservationMapperPlus.FeedingTurnConservationSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            FeedingTurnConservationPage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("保育猪-生长育肥猪")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            conservationTurnFattingPageModel.reset(conservationTurnFattingMapperPlus.ConservationTurnFattingSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            ConservationTurnFattingpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("保育猪-后备猪")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            conservationTurnBackPageModel.reset(conservationTurnBackMapperPlus.ConservationTurnBackSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            ConservationTurnBackpage(1);

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("后备猪2月龄登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            switch (zzzt) {
                case "猪只状态":
                    zzzt = "%";
                    break;
                case "后备猪":
                    zzzt = "4";
                    break;
                case "生长育肥猪":
                    zzzt = "3";
                    break;
                case "销售":
                    zzzt = "10";
                    break;
                case "死亡":
                    zzzt = "11";
                    break;
                default:
                    break;
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            twoTestPageModel.reset(twoTestMapperPlus.TwoTestSelectSearchByCount(pignum, zzzt, fenceid, startDate, endDate), true);
            TwoTestpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("后备猪4月龄登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            switch (zzzt) {
                case "猪只状态":
                    zzzt = "%";
                    break;
                case "后备猪":
                    zzzt = "4";
                    break;
                case "生长育肥猪":
                    zzzt = "3";
                    break;
                case "销售":
                    zzzt = "10";
                    break;
                case "死亡":
                    zzzt = "11";
                    break;
                default:
                    break;
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            fourTestPageModel.reset(fourTestMapperPlus.FourTestSelectSearchByCount(pignum, zzzt, fenceid, startDate, endDate), true);
            FourTestpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("后备猪6月龄登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            switch (zzzt) {
                case "猪只状态":
                    zzzt = "%";
                    break;
                case "后备猪":
                    zzzt = "4";
                    break;
                case "生长育肥猪":
                    zzzt = "3";
                    break;
                case "销售":
                    zzzt = "10";
                    break;
                case "死亡":
                    zzzt = "11";
                    break;
                default:
                    break;
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            sixTestPageModel.reset(sixTestMapperPlus.SixTestSelectSearchByCount(pignum, zzzt, fenceid, startDate, endDate), true);
            SixTestpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("100KG检测登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            switch (zzzt) {
                case "猪只状态":
                    zzzt = "%";
                    break;
                case "后备母猪":
                    zzzt = "5";
                    break;
                case "种公猪":
                    zzzt = "9";
                    break;
                case "生长育肥猪":
                    zzzt = "3";
                    break;
                case "销售":
                    zzzt = "10";
                    break;
                case "死亡":
                    zzzt = "11";
                    break;
                default:
                    break;
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            hundredTestPageModel.reset(hundredTestMapperPlus.HundredTestSelectSearchByCount(pignum, zzzt, fenceid, startDate, endDate), true);
            HundredTestpage(1);
        }

        if (jDesktopPane1.getSelectedFrame().getTitle().equals("猪只免疫登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            zzmyPageModel.reset(zzmyMapperPlus.ZzmySelectSearchByCount(pignum, zzzt, startDate, endDate), true);
            Zzmypage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("疾病治疗登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            List<Swintype> SwintypeList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                SwintypeList = mapper.selectAll();
            }
            for (int j = 0; j < SwintypeList.size(); j++) {
                if (zzzt.equals(SwintypeList.get(j).getTypename())) {
                    zzzt = SwintypeList.get(j).getTypeid();
                    break;
                }
            }
            if (zzzt.equals("猪只状态")) {
                zzzt = "%";
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            jbzlPageModel.reset(jbzlMapperPlus.JbzlSelectSearchByCount(pignum, zzzt, startDate, endDate), true);
            Jbzlpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("基因检测登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            jyjcPageModel.reset(jyjcMapperPlus.JyjcSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            Jyjcpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("屠宰性能测定登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            tzxncdPageModel.reset(tzxncdMapperPlus.TzxncdSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            Tzxncdpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("猪只销售登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            zzxsPageModel.reset(zzxsMapperPlus.ZzxsSelectSearchByCount(startDate, endDate), true);
            Zzxspage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("猪只死亡登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            pignum = "%" + jTextField01.getText();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            zzswPageModel.reset(zzswMapperPlus.ZzswSelectSearchByCount(pignum, fenceid, startDate, endDate), true);
            Zzswpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("饲料入库登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            slrkPageModel.reset(slrkMapperPlus.SlrkSelectSearchByCount(startDate, endDate), true);
            Slrkpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("饲料出库登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            if (!JComboBoxString(jComboBox2).equals("全部舍")) {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            } else {
                fenceid = "%";
            }
            slckPageModel.reset(slckMapperPlus.SlckSelectSearchByCount(fenceid, startDate, endDate), true);

            Slckpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("药品入库登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            yprkPageModel.reset(yprkMapperPlus.YprkSelectSearchByCount(startDate, endDate), true);
            Yprkpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("药品出库登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            if (!JComboBoxString(jComboBox2).equals("全部舍")) {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            } else {
                fenceid = "%";
            }
            ypckPageModel.reset(ypckMapperPlus.YpckSelectSearchByCount(fenceid, startDate, endDate), true);
            Ypckpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("疫苗入库登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            ymrkPageModel.reset(ymrkMapperPlus.YmrkSelectSearchByCount(startDate, endDate), true);
            Ymrkpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("疫苗出库登记")) {
            ssf = true;
            jDesktopPane1.removeAll();

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();
            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            if (!JComboBoxString(jComboBox2).equals("全部舍")) {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox2));
            } else {
                fenceid = "%";
            }
            ymckPageModel.reset(ymckMapperPlus.YmckSelectSearchByCount(fenceid, startDate, endDate), true);
            Ymckpage(1);
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("配种返情率")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);

            pzfqlTJ.setData(startDate, endDate, pignum, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectPzcs(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFqcs(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectPzcsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectPzcsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectPzcsyear(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFqcsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFqcsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFqcsyear(startDate, endDate, pignum, fenceid, zzzt));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("配种分娩率")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);

            String startDate2 = addDate(startDate, 114);
            String endDate2 = addDate(endDate, 114);

            pzfmlTJ.setData(startDate, endDate, pignum, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectRscs(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmcs(startDate2, endDate2, pignum, fenceid, zzzt), tjMapperPlus.selectRscsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectRscsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectRscsyear(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmcsday(startDate2, endDate2, pignum, fenceid, zzzt), tjMapperPlus.selectFmcsmonth(startDate2, endDate2, pignum, fenceid, zzzt), tjMapperPlus.selectFmcsyear(startDate2, endDate2, pignum, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("胎均总产仔数")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            tjzczsTJ.setData(startDate, endDate, pignum, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectFmts(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmzzs(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsyear(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmzzsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmzzsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmzzsyear(startDate, endDate, pignum, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("胎均活产仔数")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            tjhczsTJ.setData(startDate, endDate, pignum, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectFmts(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzs(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsyear(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsyear(startDate, endDate, pignum, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("出生活体个重")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            cshtgzTJ.setData(startDate, endDate, pignum, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectFmhzs(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectCswzz(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsyear(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectCswzzday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectCswzzmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectCswzzyear(startDate, endDate, pignum, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("出生活体个数")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            cshtgsTJ.setData(startDate, endDate, pignum, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectFmts(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzs(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmtsyear(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsday(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsmonth(startDate, endDate, pignum, fenceid, zzzt), tjMapperPlus.selectFmhzsyear(startDate, endDate, pignum, fenceid, zzzt));
        }

        if (jDesktopPane1.getSelectedFrame().getTitle().equals("胎均断奶活仔数")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            tjdnhzsTJ.setData(startDate, endDate, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectDnts(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgs(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDntsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDntsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDntsyear(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsyear(startDate, endDate, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("断奶个体重")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            dngtzTJ.setData(startDate, endDate, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectDnzwwz(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgs(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzwwzday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzwwzmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzwwzyear(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsyear(startDate, endDate, fenceid, zzzt));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("断奶仔猪成活率")) {
            ssf = true;
            pignum = "%" + jTextField01.getText();

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);

            dnzzchlTJ.setData(startDate, endDate, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectFmhzs(startDate, endDate, "%", fenceid, zzzt), tjMapperPlus.selectDnzgs(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectFmhzsday(startDate, endDate, "%", fenceid, zzzt), tjMapperPlus.selectFmhzsmonth(startDate, endDate, "%", fenceid, zzzt), tjMapperPlus.selectFmhzsyear(startDate, endDate, "%", fenceid, zzzt), tjMapperPlus.selectDnzgsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectDnzgsyear(startDate, endDate, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("保育期成活率")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            byqchlTJ.setData(startDate, endDate, JComboBoxString(jComboBox2), JComboBoxString(jComboBox1), tjMapperPlus.selectByszs(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectBysswzs(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectByszsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectByszsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectByszsyear(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectBysswzsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectBysswzsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectBysswzsyear(startDate, endDate, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("育肥期成活率")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            yfqchlTJ.setData(startDate, endDate, JComboBoxString(jComboBox2), JComboBoxString(jComboBox1), tjMapperPlus.selectYfszs(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYfsswzs(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYfszsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYfszsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYfszsyear(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYfsswzsday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYfsswzsmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYfsswzsyear(startDate, endDate, fenceid, zzzt));

        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("饲料入库统计")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            pignum = JComboBoxString(jComboBox2);
            fenceid = JComboBoxString(jComboBox3);

            slrkTJ.setData(startDate, endDate, JComboBoxString(jComboBox1), pignum, fenceid, tjMapperPlus.selectSlrk(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectSlrkday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectSlrkmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectSlrkyear(startDate, endDate, fenceid, zzzt));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("药品入库统计")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            yprkTJ.setData(startDate, endDate, JComboBoxString(jComboBox1), fenceid, tjMapperPlus.selectYprk(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYprkday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYprkmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYprkyear(startDate, endDate, fenceid, zzzt));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("疫苗入库统计")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox2);
            ymrkTJ.setData(startDate, endDate, JComboBoxString(jComboBox1), fenceid, tjMapperPlus.selectYmrk(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYmrkday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYmrkmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectYmrkyear(startDate, endDate, fenceid, zzzt));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("饲料出库统计")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            pignum = JComboBoxString(jComboBox2);

            if (!JComboBoxString(jComboBox3).equals("全部舍")) {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox3));
            } else {
                fenceid = "%";
            }

            slckTJ.setData(startDate, endDate, JComboBoxString(jComboBox1), JComboBoxString(jComboBox3), pignum, tjMapperPlus.selectSlck(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectSlckday(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectSlckmonth(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectSlckyear(startDate, endDate, pignum, zzzt, fenceid));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("药品出库统计")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            pignum = JComboBoxString(jComboBox2);

            if (!JComboBoxString(jComboBox3).equals("全部舍")) {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox3));
            } else {
                fenceid = "%";
            }

            ypckTJ.setData(startDate, endDate, JComboBoxString(jComboBox1), JComboBoxString(jComboBox3), pignum, tjMapperPlus.selectYpck(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectYpckday(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectYpckmonth(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectYpckyear(startDate, endDate, pignum, zzzt, fenceid));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("疫苗出库统计")) {
            ssf = true;
            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            pignum = JComboBoxString(jComboBox2);

            if (!JComboBoxString(jComboBox3).equals("全部舍")) {
                fenceid = piggeryNametoIdSmap.get(JComboBoxString(jComboBox3));
            } else {
                fenceid = "%";
            }

            ymckTJ.setData(startDate, endDate, JComboBoxString(jComboBox1), JComboBoxString(jComboBox3), pignum, tjMapperPlus.selectYmck(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectYmckday(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectYmckmonth(startDate, endDate, pignum, zzzt, fenceid), tjMapperPlus.selectYmckyear(startDate, endDate, pignum, zzzt, fenceid));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("猪只死亡统计")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }

            fenceid = JComboBoxString(jComboBox3);
            fenceid = SsFence(fenceid, jComboBox2);
            zzswTJ.setData(startDate, endDate, JComboBoxString(jComboBox2), JComboBoxString(jComboBox3), JComboBoxString(jComboBox1), tjMapperPlus.selectZzsw(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectZzswday(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectZzswmonth(startDate, endDate, fenceid, zzzt), tjMapperPlus.selectZzswyear(startDate, endDate, fenceid, zzzt));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("猪场销售统计")) {
            ssf = true;

            zzzt = JComboBoxString(jComboBox1);
            if (zzzt.equals("负责人")) {
                zzzt = "%";
            } else {
                zzzt = employeeNametoIdSmap.get(zzzt);
            }

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            zzxsTJ.setData(startDate, endDate, JComboBoxString(jComboBox1), tjMapperPlus.selectZzxs(startDate, endDate, zzzt), tjMapperPlus.selectZzxsday(startDate, endDate, zzzt), tjMapperPlus.selectZzxsmonth(startDate, endDate, zzzt), tjMapperPlus.selectZzxsyear(startDate, endDate, zzzt));
        }
        if (jDesktopPane1.getSelectedFrame().getTitle().equals("简单料肉比")) {
            ssf = true;

            startDate = jTextField2.getText();
            endDate = jTextField3.getText();

            if (startDate.equals("")) {
                startDate = "1990-01-01";
            }
            if (endDate.equals("")) {
                endDate = "2090-01-01";
            }
            jdlrbTj.setData(startDate, endDate, tjMapperPlus.selectLrbSlck(startDate, endDate), tjMapperPlus.selectLrbZzxs(startDate, endDate), tjMapperPlus.selectLrbSlckday(startDate, endDate), tjMapperPlus.selectLrbSlckmonth(startDate, endDate), tjMapperPlus.selectLrbSlckyear(startDate, endDate), tjMapperPlus.selectLrbZzxsday(startDate, endDate), tjMapperPlus.selectLrbZzxsmonth(startDate, endDate), tjMapperPlus.selectLrbZzxsyear(startDate, endDate));
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jComboBox3.setSelectedIndex(0);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed

        if (outsideLabel.equals("饲料入库统计")) {
            if (JComboBoxString(jComboBox2).equals("全部饲料类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslSLLBThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("哺乳仔猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslBRZZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("保育猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslBYZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("生长育肥猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslSZYFZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("后备猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslHBZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("后备母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslHBMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("妊娠母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslRSMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("哺乳母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslBRMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("空怀母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslKHMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("种公猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslZGZThingsShow));
            }
        } else if (outsideLabel.equals("饲料出库统计")) {
            if (JComboBoxString(jComboBox2).equals("全部饲料类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslSLLBThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("哺乳仔猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslBRZZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("保育猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslBYZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("生长育肥猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslSZYFZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("后备猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslHBZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("后备母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslHBMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("妊娠母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslRSMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("哺乳母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslBRMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("空怀母猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslKHMZThingsShow));
            }
            if (JComboBoxString(jComboBox2).equals("种公猪类型")) {
                jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslZGZThingsShow));
            }
        } else if (outsideLabel.equals("药品入库统计") || (outsideLabel.equals("药品出库统计"))) {
        } else {
            String name = JComboBoxString(jComboBox2);
            String id = null;

            for (int i = 0; i < piggeryList.size(); i++) {
                if (name.equals(piggeryList.get(i).getCategory())) {
                    id = piggeryList.get(i).getNumber();
                }
            }
            List<Fence> fence;

            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class
                );
                fence = mapper6.selectAllById(id);
            }
            String[] things6 = new String[fence.size() + 1];
            for (int i = 0; i < fence.size() + 1; i++) {
                if (i == 0) {
                    things6[0] = "全部栏";
                } else {
                    things6[i] = fence.get(i - 1).getFencename();
                }
            }
            if (name.equals("全部舍")) {
                things6 = new String[1];
                things6[0] = "全部栏";
            }
            jComboBox3.removeAll();
            jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(things6));
        }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton1NowExcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1NowExcelActionPerformed
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        try {
            //导出当前
            //选择保存的路径 并生成excel
            if (saveDia == null) {
                saveDia = new FileDialog(this, "我的保存", FileDialog.SAVE);
            }
            saveDia.setVisible(true);
            String dirPath = saveDia.getDirectory();
            String fileName = saveDia.getFile();
            boolean flag = false;
            if (dirPath != null || fileName != null) {
                if (outsideLabel.equals("系谱数据")) {
                    ArrayList<String> Stringlist = new ArrayList<>();
                    List<Selebith> yzgtxxList = yzMapperPlus.selectAllyzgtxx();
                    Stringlist.add("个体编号\t母亲编号\t父亲编号");
                    for (int i = 0; i < yzgtxxList.size(); i++) {
                        Stringlist.add(yzgtxxList.get(i).getR_animal() + "\t" + yzgtxxList.get(i).getR_dam() + "\t" + yzgtxxList.get(i).getR_sire());
                    }
                    FileWrite_Overwrite(dirPath + fileName, Stringlist);
                    flag = true;
                } else if (outsideLabel.equals("育种个体信息")) {
                    ArrayList<String> Stringlist = new ArrayList<>();
                    List<Selebith> yzgtxxList = yzMapperPlus.selectAllyzgtxx();
                    Stringlist.add("个体编号\t品种\t品系\t猪场\t出生日期\t当前状态\t当前猪舍\t性别\t出生重量\t出生胎次\t断奶重量\t采精次数\t当前胎次\t产仔总数");
                    for (int i = 0; i < yzgtxxList.size(); i++) {
                        String cjcs = yzgtxxList.get(i).getR_sex().equals("0") ? String.valueOf(yzgtxxList.get(i).getGzcjcs()) : "NA";//"采精次数
                        String dqtc = yzgtxxList.get(i).getR_sex().equals("0") ? "NA" : String.valueOf(yzgtxxList.get(i).getR_fno());//"当前胎次
                        String czzs = yzgtxxList.get(i).getR_sex().equals("0") ? "NA" : String.valueOf(yzgtxxList.get(i).getCzzs());//"产仔总数
                        yzgtxxList.get(i).setR_sex(yzgtxxList.get(i).getR_sex().equals("1") ? "公" : "母");
                        Stringlist.add(
                                yzgtxxList.get(i).getR_animal() + "\t" + lineidIdtoNameSmap.get(yzgtxxList.get(i).getR_lineid()) + "\t" + lineherdIdtoNameSmap.get(yzgtxxList.get(i).getR_herd())
                                + "\t" + farmIdtoNameSmap.get(yzgtxxList.get(i).getR_house()) + "\t" + yzgtxxList.get(i).getR_fdate() + "\t" + swintypeIdtoNameSmap.get(yzgtxxList.get(i).getR_curmark())
                                + "\t" + piggeryIdtoNameSmap.get(yzgtxxList.get(i).getR_cage()) + "\t" + yzgtxxList.get(i).getR_sex() + "\t" + yzgtxxList.get(i).getR_bthwt() + "\t" + yzgtxxList.get(i).getR_ghatch()
                                + "\t" + yzgtxxList.get(i).getR_weanwt() + "\t" + cjcs + "\t" + dqtc + "\t" + czzs
                        );
                    }
                    FileWrite_Overwrite(dirPath + fileName, Stringlist);
                    flag = true;
                } else if (outsideLabel.equals("后备2月性状")) {
                    ArrayList<String> Stringlist = new ArrayList<>();
                    List<TwoTest> twotestList = yzMapperPlus.selectAlltwotest();
                    Stringlist.add("个体编号\t测定时间\t性别\t体重\t登记状态\t所在猪舍\t腹线乳头数\t腹线有无缺陷乳头\t综合评分\t有无损伤"
                            + "\t是否过小\t综合评分\t趾是否过小\t跗关节是否合理\t四肢有无损伤、肿胀\t综合评分\t前和后躯宽广\t后臀长且深\t肋骨形状\t综合评分\t强健有力\t寄生虫、皮肤和整体状态（1-10分）"
                            + "\t其它要点（1-10分）\t保留百分比\t备注\t备注1\t备注2\t备注3");
                    for (int i = 0; i < twotestList.size(); i++) {
                        twotestList.get(i).setZsex(twotestList.get(i).getZsex().equals("1") ? "公" : "母");
                        twotestList.get(i).setCdzt(swintypeIdtoNameSmap.get(twotestList.get(i).getCdzt()));
                        twotestList.get(i).setFenceid(piggeryIdtoNameSmap.get(twotestList.get(i).getFenceid().substring(0, 5)));
                        Stringlist.add(twotestList.get(i).getR_animal() + "\t" + twotestList.get(i).getCdrq() + "\t" + twotestList.get(i).getZsex()
                                + "\t" + twotestList.get(i).getWeight() + "\t" + twotestList.get(i).getCdzt() + "\t" + twotestList.get(i).getFenceid()
                                + "\t" + twotestList.get(i).getFxrts() + "\t" + twotestList.get(i).getFxqxrt() + "\t" + twotestList.get(i).getFxzhpf() + "\t" + twotestList.get(i).getYwss()
                                + "\t" + twotestList.get(i).getSfgx() + "\t" + twotestList.get(i).getYgzhpf() + "\t" + twotestList.get(i).getZtzsfgx() + "\t" + twotestList.get(i).getZtfgjsfhl()
                                + "\t" + twotestList.get(i).getZtszywssyz() + "\t" + twotestList.get(i).getZtzhpf() + "\t" + twotestList.get(i).getTxqhqgc() + "\t" + twotestList.get(i).getTxhtcqs()
                                + "\t" + twotestList.get(i).getTxlgxz() + "\t" + twotestList.get(i).getTxzhpf() + "\t" + twotestList.get(i).getQjyl() + "\t" + twotestList.get(i).getJpz()
                                + "\t" + twotestList.get(i).getQtyd() + "\t" + twotestList.get(i).getBlbfb() + "\t" + twotestList.get(i).getBz()
                                + "\t" + twotestList.get(i).getBz1() + "\t" + twotestList.get(i).getBz2() + "\t" + twotestList.get(i).getBz3());
                    }
                    FileWrite_Overwrite(dirPath + fileName, Stringlist);
                    flag = true;
                } else if (outsideLabel.equals("后备4月性状")) {
                    ArrayList<String> Stringlist = new ArrayList<>();
                    List<FourTest> yzgtxxList = yzMapperPlus.selectAllfourtest();
                    Stringlist.add("个体编号\t测定时间\t性别\t体重\t登记状态\t所在猪舍\t腹线乳头数\t腹线有无缺陷乳头\t综合评分\t有无损伤"
                            + "\t是否过小\t综合评分\t趾是否过小\t跗关节是否合理\t四肢有无损伤、肿胀\t综合评分\t前和后躯宽广\t后臀长且深\t肋骨形状\t综合评分\t强健有力\t寄生虫、皮肤和整体状态（1-10分）"
                            + "\t其它要点（1-10分）\t保留百分比\t备注\t备注1\t备注2\t备注3");
                    for (int i = 0; i < yzgtxxList.size(); i++) {
                        yzgtxxList.get(i).setZsex(yzgtxxList.get(i).getZsex().equals("1") ? "公" : "母");
                        yzgtxxList.get(i).setCdzt(swintypeIdtoNameSmap.get(yzgtxxList.get(i).getCdzt()));
                        yzgtxxList.get(i).setFenceid(piggeryIdtoNameSmap.get(yzgtxxList.get(i).getFenceid().substring(0, 5)));
                        Stringlist.add(yzgtxxList.get(i).getR_animal() + "\t" + yzgtxxList.get(i).getCdrq() + "\t" + yzgtxxList.get(i).getZsex()
                                + "\t" + yzgtxxList.get(i).getWeight() + "\t" + yzgtxxList.get(i).getCdzt() + "\t" + yzgtxxList.get(i).getFenceid()
                                + "\t" + yzgtxxList.get(i).getFxrts() + "\t" + yzgtxxList.get(i).getFxqxrt() + "\t" + yzgtxxList.get(i).getFxzhpf() + "\t" + yzgtxxList.get(i).getYwss()
                                + "\t" + yzgtxxList.get(i).getSfgx() + "\t" + yzgtxxList.get(i).getYgzhpf() + "\t" + yzgtxxList.get(i).getZtzsfgx() + "\t" + yzgtxxList.get(i).getZtfgjsfhl()
                                + "\t" + yzgtxxList.get(i).getZtszywssyz() + "\t" + yzgtxxList.get(i).getZtzhpf() + "\t" + yzgtxxList.get(i).getTxqhqgc() + "\t" + yzgtxxList.get(i).getTxhtcqs()
                                + "\t" + yzgtxxList.get(i).getTxlgxz() + "\t" + yzgtxxList.get(i).getTxzhpf() + "\t" + yzgtxxList.get(i).getQjyl() + "\t" + yzgtxxList.get(i).getJpz()
                                + "\t" + yzgtxxList.get(i).getQtyd() + "\t" + yzgtxxList.get(i).getBlbfb() + "\t" + yzgtxxList.get(i).getBz()
                                + "\t" + yzgtxxList.get(i).getBz1() + "\t" + yzgtxxList.get(i).getBz2() + "\t" + yzgtxxList.get(i).getBz3());
                    }
                    FileWrite_Overwrite(dirPath + fileName, Stringlist);
                    flag = true;
                } else if (outsideLabel.equals("后备6月性状")) {
                    ArrayList<String> Stringlist = new ArrayList<>();
                    List<SixTest> yzgtxxList = yzMapperPlus.selectAllsixtest();
                    Stringlist.add("个体编号\t测定时间\t性别\t体重\t登记状态\t所在猪舍\t腹线乳头数\t腹线有无缺陷乳头\t综合评分\t有无损伤"
                            + "\t是否过小\t综合评分\t趾是否过小\t跗关节是否合理\t四肢有无损伤、肿胀\t综合评分\t前和后躯宽广\t后臀长且深\t肋骨形状\t综合评分\t强健有力\t寄生虫、皮肤和整体状态（1-10分）"
                            + "\t其它要点（1-10分）\t保留百分比\t备注\t备注1\t备注2\t备注3");
                    for (int i = 0; i < yzgtxxList.size(); i++) {
                        yzgtxxList.get(i).setZsex(yzgtxxList.get(i).getZsex().equals("1") ? "公" : "母");
                        yzgtxxList.get(i).setCdzt(swintypeIdtoNameSmap.get(yzgtxxList.get(i).getCdzt()));
                        yzgtxxList.get(i).setFenceid(piggeryIdtoNameSmap.get(yzgtxxList.get(i).getFenceid().substring(0, 5)));
                        Stringlist.add(yzgtxxList.get(i).getR_animal() + "\t" + yzgtxxList.get(i).getCdrq() + "\t" + yzgtxxList.get(i).getZsex()
                                + "\t" + yzgtxxList.get(i).getWeight() + "\t" + yzgtxxList.get(i).getCdzt() + "\t" + yzgtxxList.get(i).getFenceid()
                                + "\t" + yzgtxxList.get(i).getFxrts() + "\t" + yzgtxxList.get(i).getFxqxrt() + "\t" + yzgtxxList.get(i).getFxzhpf() + "\t" + yzgtxxList.get(i).getYwss()
                                + "\t" + yzgtxxList.get(i).getSfgx() + "\t" + yzgtxxList.get(i).getYgzhpf() + "\t" + yzgtxxList.get(i).getZtzsfgx() + "\t" + yzgtxxList.get(i).getZtfgjsfhl()
                                + "\t" + yzgtxxList.get(i).getZtszywssyz() + "\t" + yzgtxxList.get(i).getZtzhpf() + "\t" + yzgtxxList.get(i).getTxqhqgc() + "\t" + yzgtxxList.get(i).getTxhtcqs()
                                + "\t" + yzgtxxList.get(i).getTxlgxz() + "\t" + yzgtxxList.get(i).getTxzhpf() + "\t" + yzgtxxList.get(i).getQjyl() + "\t" + yzgtxxList.get(i).getJpz()
                                + "\t" + yzgtxxList.get(i).getQtyd() + "\t" + yzgtxxList.get(i).getBlbfb() + "\t" + yzgtxxList.get(i).getBz()
                                + "\t" + yzgtxxList.get(i).getBz1() + "\t" + yzgtxxList.get(i).getBz2() + "\t" + yzgtxxList.get(i).getBz3());
                    }
                    FileWrite_Overwrite(dirPath + fileName, Stringlist);
                    flag = true;
                } else if (outsideLabel.equals("100kg测定性状")) {
                    ArrayList<String> Stringlist = new ArrayList<>();
                    List<HundredTest> yzgtxxList = yzMapperPlus.selectAllhundredtest();
                    Stringlist.add("个体编号\t测定时间\t体重日龄\t性别\t体重\t状态\t所在猪舍\t体长\t体高\t背高"
                            + "\t胸围\t胸深\t腹围\t管围\t退臀围\t活体背膘后\t活体眼机面积\t备注\t备注字段1\t备注字段2\t备注字段3"
                    );
                    for (int i = 0; i < yzgtxxList.size(); i++) {
                        yzgtxxList.get(i).setZsex(yzgtxxList.get(i).getZsex().equals("1") ? "公" : "母");
                        yzgtxxList.get(i).setCdzt(swintypeIdtoNameSmap.get(yzgtxxList.get(i).getCdzt()));
                        yzgtxxList.get(i).setFenceid(piggeryIdtoNameSmap.get(yzgtxxList.get(i).getFenceid().substring(0, 5)));
                        Stringlist.add(yzgtxxList.get(i).getR_animal() + "\t" + yzgtxxList.get(i).getCdrq() + "\t" + yzgtxxList.get(i).getRl() + "\t" + yzgtxxList.get(i).getZsex()
                                + "\t" + yzgtxxList.get(i).getWeight() + "\t" + yzgtxxList.get(i).getCdzt() + "\t" + yzgtxxList.get(i).getFenceid()
                                + "\t" + yzgtxxList.get(i).getTc() + "\t" + yzgtxxList.get(i).getTg() + "\t" + yzgtxxList.get(i).getBg()
                                + "\t" + yzgtxxList.get(i).getXw() + "\t" + yzgtxxList.get(i).getXs() + "\t" + yzgtxxList.get(i).getFw() + "\t" + yzgtxxList.get(i).getGw()
                                + "\t" + yzgtxxList.get(i).getTtw() + "\t" + yzgtxxList.get(i).getHtbbh() + "\t" + yzgtxxList.get(i).getHtyjmj() + "\t" + yzgtxxList.get(i).getBz() + "\t" + yzgtxxList.get(i).getBz1()
                                + "\t" + yzgtxxList.get(i).getBz2() + "\t" + yzgtxxList.get(i).getBz3());
                    }
                    FileWrite_Overwrite(dirPath + fileName, Stringlist);
                    flag = true;
                } else if (outsideLabel.equals("批量选种")) {
                    ArrayList<String> Stringlist = plxz.ypxx(0);
                    FileWrite_Overwrite(dirPath + fileName, Stringlist);
                    flag = true;
                } else {
                    File file = new File(dirPath, fileName);

                    if (jDesktopPane1.getSelectedFrame() == varietiesDataPlus) {
                        if (varietiesDataPlus.getjTable1().getRowCount() != 0) {
                            flag = ExcelWrite_jxl.writeExcel(file.toString().concat(".xls"), varietiesDataPlus.getjTable1());
                        }
                    }
                    if (jDesktopPane1.getSelectedFrame() == varietiesData) {
                        if (varietiesData.getjTable1().getRowCount() != 0) {
                            flag = ExcelWrite_jxl.writeExcel(file.toString().concat(".xls"), varietiesData.getjTable1());
                        }
                    }
                    if (jDesktopPane1.getSelectedFrame() == xzxp) {
                        if (xzxp.varietiesDataPlus2.getjTable1().getRowCount() != 0) {
                            flag = ExcelWrite_jxl.writeExcel(file.toString().concat(".xls"), xzxp.varietiesDataPlus2.getjTable1());
                        }
                    }
                    if (jDesktopPane1.getSelectedFrame() == plxz) {
                        if (plxz.getjTable3().getRowCount() != 0) {
                            flag = ExcelWrite_jxl.writeExcel(file.toString().concat(".xls"), plxz.getjTable3());
                        }
                    }
                }
                if (flag) {
                    JOptionPane.showMessageDialog(null, "数据导出成功", "提示", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            if (!flag) {
                JOptionPane.showMessageDialog(null, "数据导出失败", "提示", JOptionPane.ERROR_MESSAGE);

            }

        } catch (UnsupportedEncodingException | WriteException ex) {
            Logger.getLogger(MainApp.class
                    .getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(MainApp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton1NowExcelActionPerformed

    private void jButton1AllExcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1AllExcelActionPerformed

        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        // TODO add your handling code here:
        //导出所有
        //选择保存的路径 并生成excel
        if (saveDia == null) {
            saveDia = new FileDialog(this, "我的保存", FileDialog.SAVE);
        }
        saveDia.setVisible(true);
        String dirPath = saveDia.getDirectory();
        String fileName = saveDia.getFile();
        JTable jTable1Excel = null;
        boolean flag = false;
        if (dirPath != null || fileName != null) {
            File file = new File(dirPath, fileName);
            SqlSession sqlSession = MybatisUtil.getSqlSession();

            if (ssf) {
                //按条件查询
                SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class
                );
                if (outsideLabel.equals("选种选配")) {
                    ArrayList<Selebith> list;
                    list = (ArrayList<Selebith>) pageModel.getList();
                    if (list != null) {
                        jTable1Excel = SelebithList2(list);
                    }
                }
                if (outsideLabel.equals("个体基本信息")) {
                    ArrayList<Selebith> list;
                    list = (ArrayList<Selebith>) searchMapper.SelebithSelectSearch(pignum, fenceid, zzzt, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = SelebithList(list);
                    }
                }
                if (outsideLabel.equals("种公猪资料")) {
                    ArrayList<Selebith> list;
                    list = (ArrayList<Selebith>) searchMapper.MaleBoarSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = MaleBoarList(list);
                    }
                }
                if (outsideLabel.equals("种母猪资料")) {
                    ArrayList<Selebith> list;
                    if (this.zzzt.equals("%")) {
                        list = (ArrayList<Selebith>) searchMapper.FemaleBoarSelectSearch02(pignum, zzzt, startDate, endDate);
                    } else {
                        list = (ArrayList<Selebith>) searchMapper.FemaleBoarSelectSearch(pignum, fenceid, zzzt, startDate, endDate);
                    }
                    if (list != null) {
                        jTable1Excel = FemaleBoarList(list);
                    }
                }
                if (outsideLabel.equals("公猪采精登记")) {
                    ArrayList<Takesperm> list;
                    list = (ArrayList<Takesperm>) searchMapper.TakespermSelectSearch(pignum, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = TakespermList(list);
                    }
                }
                if (outsideLabel.equals("母猪配种情况登记")) {
                    ArrayList<Breeding> list;
                    list = (ArrayList<Breeding>) searchMapper.BreedingSelectSearch(pignum, fenceid, zzzt, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = BreedingList(list);
                    }
                }
                if (outsideLabel.equals("母猪分娩情况登记")) {
                    ArrayList<Childbirth> list;
                    list = (ArrayList<Childbirth>) searchMapper.ChildbirthSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = ChildbirthList(list);
                    }
                }
                if (outsideLabel.equals("母猪断奶登记")) {
                    ArrayList<Childbirth> list;
                    list = (ArrayList<Childbirth>) searchMapper.WeaningSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = WeaningList(list);
                    }
                }
                if (outsideLabel.equals("哺乳猪-保育猪")) {
                    ArrayList<Selebith> list;
                    list = (ArrayList<Selebith>) searchMapper.FeedingTurnConservationSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = FeedingTurnConservationList(list);
                    }
                }
                if (outsideLabel.equals("保育猪-生长育肥猪")) {
                    ArrayList<Selebith> list;
                    list = (ArrayList<Selebith>) searchMapper.ConservationTurnFattingSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = ConservationTurnFattingList(list);
                    }
                }
                if (outsideLabel.equals("保育猪-后备猪")) {
                    ArrayList<Selebith> list;
                    list = (ArrayList<Selebith>) searchMapper.ConservationTurnBackSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = ConservationTurnBackList(list);
                    }
                }
                if (outsideLabel.equals("后备猪2月龄登记")) {
                    ArrayList<TwoTest> list;
                    list = (ArrayList<TwoTest>) searchMapper.TwoTestSelectSearch(pignum, zzzt, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = TwoTestList(list);
                    }
                }
                if (outsideLabel.equals("后备猪4月龄登记")) {
                    ArrayList<FourTest> list;
                    list = (ArrayList<FourTest>) searchMapper.FourTestSelectSearch(pignum, zzzt, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = FourTestList(list);
                    }
                }
                if (outsideLabel.equals("后备猪6月龄登记")) {
                    ArrayList<SixTest> list;
                    list = (ArrayList<SixTest>) searchMapper.SixTestSelectSearch(pignum, zzzt, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = SixTestList(list);
                    }
                }
                if (outsideLabel.equals("100KG检测登记")) {
                    ArrayList<HundredTest> list;
                    list = (ArrayList<HundredTest>) searchMapper.HundredTestSelectSearch(pignum, zzzt, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = HundredTestList(list);
                    }
                }
                if (outsideLabel.equals("猪只免疫登记")) {
                    ArrayList<Zzmy> list;
                    list = (ArrayList<Zzmy>) searchMapper.ZzmySelectSearch(pignum, zzzt, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = ZzmyList(list);
                    }
                }
                if (outsideLabel.equals("疾病治疗登记")) {
                    ArrayList<Jbzl> list;
                    list = (ArrayList<Jbzl>) searchMapper.JbzlSelectSearch(pignum, zzzt, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = JbzlList(list);
                    }
                }
                if (outsideLabel.equals("基因检测登记")) {
                    ArrayList<Jyjc> list;
                    list = (ArrayList<Jyjc>) searchMapper.JyjcSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = JyjcList(list);
                    }
                }
                if (outsideLabel.equals("屠宰性能测定登记")) {
                    ArrayList<Tzxncd> list;
                    list = (ArrayList<Tzxncd>) searchMapper.TzxncdSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = TzxncdList(list);
                    }
                }
                if (outsideLabel.equals("猪只销售登记")) {
                    ArrayList<Zzxs> list;
                    list = (ArrayList<Zzxs>) searchMapper.ZzxsSelectSearch(startDate, endDate);
                    if (list != null) {
                        jTable1Excel = ZzxsList(list);
                    }
                }
                if (outsideLabel.equals("猪只死亡登记")) {
                    ArrayList<Zzsw> list;
                    list = (ArrayList<Zzsw>) searchMapper.ZzswSelectSearch(pignum, fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = ZzswList(list);
                    }
                }
                if (outsideLabel.equals("饲料入库登记")) {
                    ArrayList<Slrk> list;
                    list = (ArrayList<Slrk>) searchMapper.SlrkSelectSearch(startDate, endDate);
                    if (list != null) {
                        jTable1Excel = SlrkList(list);
                    }
                }
                if (outsideLabel.equals("饲料出库登记")) {
                    ArrayList<Slck> list;
                    list = (ArrayList<Slck>) searchMapper.SlckSelectSearch(fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = SlckList(list);
                    }
                }
                if (outsideLabel.equals("药品入库登记")) {
                    ArrayList<Yprk> list;
                    list = (ArrayList<Yprk>) searchMapper.YprkSelectSearch(startDate, endDate);
                    if (list != null) {
                        jTable1Excel = YprkList(list);
                    }
                }
                if (outsideLabel.equals("药品出库登记")) {
                    ArrayList<Ypck> list;
                    list = (ArrayList<Ypck>) searchMapper.YpckSelectSearch(fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = YpckList(list);
                    }
                }
                if (outsideLabel.equals("疫苗入库登记")) {
                    ArrayList<Ymrk> list;
                    list = (ArrayList<Ymrk>) searchMapper.YmrkSelectSearch(startDate, endDate);
                    if (list != null) {
                        jTable1Excel = YmrkList(list);
                    }
                }
                if (outsideLabel.equals("疫苗出库登记")) {
                    ArrayList<Ymck> list;
                    list = (ArrayList<Ymck>) searchMapper.YmckSelectSearch(fenceid, startDate, endDate);
                    if (list != null) {
                        jTable1Excel = YmckList(list);
                    }
                }
            } else {
                ///查询所有
                if (outsideLabel.equals("个体基本信息")) {
                    ArrayList<Selebith> list;
                    SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class
                    );
                    list = (ArrayList<Selebith>) selebithMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = SelebithList(list);
                    }
                }
                if (outsideLabel.equals("种公猪资料")) {
                    ArrayList<Selebith> list;
                    BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class
                    );
                    list = (ArrayList<Selebith>) boarMapper.selectAllMale();
                    if (list != null) {
                        jTable1Excel = MaleBoarList(list);
                    }
                }
                if (outsideLabel.equals("种母猪资料")) {
                    ArrayList<Selebith> list;
                    BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class
                    );
                    list = (ArrayList<Selebith>) boarMapper.selectAllFemale();
                    if (list != null) {
                        jTable1Excel = FemaleBoarList(list);
                    }
                }
                if (outsideLabel.equals("公猪采精登记")) {
                    ArrayList<Takesperm> list;
                    TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class
                    );
                    list = (ArrayList<Takesperm>) takespermMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = TakespermList(list);
                    }
                }
                if (outsideLabel.equals("母猪配种情况登记")) {
                    ArrayList<Breeding> list;
                    BreedingMapper breedingMapper = sqlSession.getMapper(BreedingMapper.class
                    );
                    list = (ArrayList<Breeding>) breedingMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = BreedingList(list);
                    }
                }
                if (outsideLabel.equals("母猪分娩情况登记")) {
                    ArrayList<Childbirth> list;
                    ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class
                    );
                    list = (ArrayList<Childbirth>) childbirthMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = ChildbirthList(list);
                    }
                }
                if (outsideLabel.equals("母猪断奶登记")) {
                    ArrayList<Childbirth> list;
                    WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class
                    );
                    list = (ArrayList<Childbirth>) weaningMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = WeaningList(list);
                    }
                }
                if (outsideLabel.equals("哺乳猪-保育猪")) {
                    ArrayList<Selebith> list;
                    FeedingTurnConservationPigMapper feedingTurnConservationMapper = sqlSession.getMapper(FeedingTurnConservationPigMapper.class
                    );
                    list = (ArrayList<Selebith>) feedingTurnConservationMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = FeedingTurnConservationList(list);
                    }
                }
                if (outsideLabel.equals("保育猪-生长育肥猪")) {
                    ArrayList<Selebith> list;
                    ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class
                    );
                    list = (ArrayList<Selebith>) conservationTurnFatteningPigMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = ConservationTurnFattingList(list);
                    }
                }
                if (outsideLabel.equals("保育猪-后备猪")) {
                    ArrayList<Selebith> list;
                    ConservationTurnBackPigMapper conservationTurnBackPigMapper = sqlSession.getMapper(ConservationTurnBackPigMapper.class
                    );
                    list = (ArrayList<Selebith>) conservationTurnBackPigMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = ConservationTurnBackList(list);
                    }
                }
                if (outsideLabel.equals("后备猪2月龄登记")) {
                    ArrayList<TwoTest> list;
                    TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class
                    );
                    list = (ArrayList<TwoTest>) twoTestMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = TwoTestList(list);
                    }
                }
                if (outsideLabel.equals("后备猪4月龄登记")) {
                    ArrayList<FourTest> list;
                    FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class
                    );
                    list = (ArrayList<FourTest>) fourTestMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = FourTestList(list);
                    }
                }
                if (outsideLabel.equals("后备猪6月龄登记")) {
                    ArrayList<SixTest> list;
                    SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class
                    );
                    list = (ArrayList<SixTest>) sixTestMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = SixTestList(list);
                    }
                }
                if (outsideLabel.equals("100KG检测登记")) {
                    ArrayList<HundredTest> list;
                    HundredTestMapper hundredTestMapper = sqlSession.getMapper(HundredTestMapper.class
                    );
                    list = (ArrayList<HundredTest>) hundredTestMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = HundredTestList(list);
                    }
                }
                if (outsideLabel.equals("猪只免疫登记")) {
                    ArrayList<Zzmy> list;
                    ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class
                    );
                    list = (ArrayList<Zzmy>) zzmyMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = ZzmyList(list);
                    }
                }
                if (outsideLabel.equals("疾病治疗登记")) {
                    ArrayList<Jbzl> list;
                    JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class
                    );
                    list = (ArrayList<Jbzl>) jbzlMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = JbzlList(list);
                    }
                }
                if (outsideLabel.equals("基因检测登记")) {
                    ArrayList<Jyjc> list;
                    JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class
                    );
                    list = (ArrayList<Jyjc>) jyjcMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = JyjcList(list);
                    }
                }
                if (outsideLabel.equals("屠宰性能测定登记")) {
                    ArrayList<Tzxncd> list;
                    TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class
                    );
                    list = (ArrayList<Tzxncd>) tzxncdMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = TzxncdList(list);
                    }
                }
                if (outsideLabel.equals("猪只销售登记")) {
                    ArrayList<Zzxs> list;
                    ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class
                    );
                    list = (ArrayList<Zzxs>) zzxsMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = ZzxsList(list);
                    }
                }
                if (outsideLabel.equals("猪只死亡登记")) {
                    ArrayList<Zzsw> list;
                    ZzswMapper zzswMapper = sqlSession.getMapper(ZzswMapper.class
                    );
                    list = (ArrayList<Zzsw>) zzswMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = ZzswList(list);
                    }
                }

                if (outsideLabel.equals("饲料出库登记")) {
                    ArrayList<Slck> list;
                    SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class
                    );
                    list = (ArrayList<Slck>) slckMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = SlckList(list);
                    }
                }
                if (outsideLabel.equals("饲料入库登记")) {
                    ArrayList<Slrk> list;
                    SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class
                    );
                    list = (ArrayList<Slrk>) slrkMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = SlrkList(list);
                    }
                }
                if (outsideLabel.equals("药品出库登记")) {
                    ArrayList<Ypck> list;
                    YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class
                    );
                    list = (ArrayList<Ypck>) ypckMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = YpckList(list);
                    }
                }
                if (outsideLabel.equals("药品入库登记")) {
                    ArrayList<Yprk> list;
                    YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class
                    );
                    list = (ArrayList<Yprk>) yprkMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = YprkList(list);
                    }
                }
                if (outsideLabel.equals("疫苗出库登记")) {
                    ArrayList<Ymck> list;
                    YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class
                    );
                    list = (ArrayList<Ymck>) ymckMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = YmckList(list);
                    }
                }
                if (outsideLabel.equals("疫苗入库登记")) {
                    ArrayList<Ymrk> list;
                    YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class
                    );
                    list = (ArrayList<Ymrk>) ymrkMapper.selectAll();
                    if (list != null) {
                        jTable1Excel = YmrkList(list);
                    }
                }
            }
            sqlSession.close();
            if (jTable1Excel.getRowCount() != 0) {
                try {
                    try {
                        flag = ExcelWrite_jxl.writeExcel(file.toString().concat(".xls"), jTable1Excel);

                    } catch (WriteException ex) {
                        Logger.getLogger(MainApp.class
                                .getName()).log(Level.SEVERE, null, ex);

                    }
                } catch (UnsupportedEncodingException ex) {
                    Logger.getLogger(MainApp.class
                            .getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "数据导出成功", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        if (!flag) {
            JOptionPane.showMessageDialog(null, "数据导出失败", "提示", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton1AllExcelActionPerformed

    private void jTextField01FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField01FocusGained
        jLabel46.setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField01FocusGained

    private void jTextField01FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField01FocusLost
        jLabel46.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField01FocusLost

    private void jButtonPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPrintActionPerformed
        if (jDesktopPane1.getSelectedFrame() == null) {
            return;
        }
        String title = "";
        JTable jTable1 = null;
        String gti = jDesktopPane1.getSelectedFrame().getTitle();
        if (gti.equals("个体基本信息") || gti.equals("公猪采精登记") || gti.equals("母猪配种情况登记")//
                || gti.equals("母猪分娩情况登记") || gti.equals("母猪断奶登记") || gti.equals("种公猪资料")
                || gti.equals("种母猪资料") || gti.equals("后备猪2月龄登记") || gti.equals("后备猪4月龄登记") || gti.equals("后备猪6月龄登记")
                || gti.equals("100KG检测登记") || gti.equals("屠宰性能测定登记") || gti.equals("猪只免疫登记") || gti.equals("疾病治疗登记")
                || gti.equals("基因检测登记") || gti.equals("猪只销售登记") || gti.equals("猪只死亡登记")
                || gti.equals("饲料入库登记") || gti.equals("饲料出库登记") || gti.equals("药品入库登记") || gti.equals("药品出库登记")
                || gti.equals("疫苗入库登记") || gti.equals("疫苗出库登记") || gti.equals("药品入库登记") || gti.equals("药品入库登记")
                || gti.equals("哺乳猪-保育猪") || gti.equals("保育猪-生长育肥猪") || gti.equals("保育猪-后备猪")) {//
            varietiesDataPlus = (VarietiesDataPlus) jDesktopPane1.getSelectedFrame();
            title = varietiesDataPlus.getTitle();
        } else if (gti.equals("选种选配")) {
            ArrayList<String> StringList = new ArrayList<>();
            selebithList = pageModel.getList();
            if (selebithList.get(0).getR_sex().equals("公")) {
                StringList.add("个体编号 综合育种 出生日期 当前状态 所在猪舍 所在栏位 采精次数 最近采精日期 性  别");
                for (int j = 0; j < selebithList.size(); j++) {
                    String s0 = selebithList.get(j).getR_animal();//"个体编号"
                    String s1 = selebithList.get(j).getR_farmid();//"综合育种"
                    String s2 = selebithList.get(j).getR_fdate();//"出生日期"
                    String s3 = swintypeIdtoNameSmap.get(selebithList.get(j).getR_curmark());//"当前状态"
                    String s4 = piggeryIdtoNameSmap.get(selebithList.get(j).getR_cage());//"所在猪舍"
                    String s5 = fenceIdtoNameSmap.get(selebithList.get(j).getR_pcage());//"所在猪舍"
                    String s6 = String.valueOf(selebithList.get(j).getGzcjcs());//"采精次数",*
                    String s7 = selebithList.get(j).getTtsj();//"最近采精日期",*
                    String s8 = selebithList.get(j).getR_sex();//"性  别"
                    StringList.add(s0 + "  " + s1 + "  " + s2 + "  " + s3 + "  " + s4 + "  " + s5 + "  " + s6 + "  " + s7 + "  " + s8);
                }
            } else {
                StringList.add("个体编号 综合育种 出生日期 当前状态 所在猪舍 所在栏位 当前胎次 性  别");
                for (int j = 0; j < selebithList.size(); j++) {
                    String s0 = selebithList.get(j).getR_animal();//"个体编号"
                    String s1 = selebithList.get(j).getR_farmid();//"综合育种"
                    String s2 = selebithList.get(j).getR_fdate();//"出生日期"
                    String s3 = swintypeIdtoNameSmap.get(selebithList.get(j).getR_curmark());//"当前状态"
                    String s4 = piggeryIdtoNameSmap.get(selebithList.get(j).getR_cage());//"所在猪舍"
                    String s5 = fenceIdtoNameSmap.get(selebithList.get(j).getR_pcage());//"所在猪舍"
                    String s6 = String.valueOf(selebithList.get(j).getR_fno());//"采精次数",*
                    String s7 = selebithList.get(j).getR_sex();//"性  别"
                    StringList.add(s0 + "  " + s1 + "  " + s2 + "  " + s3 + "  " + s4 + "  " + s5 + "  " + s6 + "  " + s7);
                }
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        } else if (gti.equals("批量选种")) {
            printData.setPrintDataStringList(plxz.ypxx(1));
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        } else {
            varietiesData = (VarietiesData) jDesktopPane1.getSelectedFrame();
            title = varietiesData.getTitle();
        }

        if (title.equals("母猪非亲缘公猪查询")) {
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }

        if (title.equals("品种资料")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                LinesMapper mapper = sqlSession.getMapper(LinesMapper.class);
                linesList = mapper.selectAll();
            }
            StringList.add("品种名称  品种简码");
            for (int j = 0; j < linesList.size(); j++) {
                String name = linesList.get(j).getLinename();
                String lineid = linesList.get(j).getLineid();
                StringList.add(name + "  " + lineid);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("品系管理")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                LineherdMapper mapper = sqlSession.getMapper(LineherdMapper.class);
                lineherdList = mapper.selectAll();
            }
            StringList.add("品系代码  品系名称  品种简码");
            for (int j = 0; j < lineherdList.size(); j++) {
                String Herdid = lineherdList.get(j).getHerdid();
                String Herdname = lineherdList.get(j).getHerdname();
                String Lineid = lineherdList.get(j).getLineid();
                StringList.add(Herdid + "  " + Herdname + "  " + Lineid);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("猪场设置")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                FarmNameMapper mapper = sqlSession.getMapper(FarmNameMapper.class);
                farmName = mapper.selectAll();
            }
            StringList.add("猪场名称  猪场简码  猪场地址  猪场电话  负 责 人  备    注");
            for (int j = 0; j < farmName.size(); j++) {
                String name = farmName.get(j).getFarm_name();
                String farmid = farmName.get(j).getFarm_id();
                String farmadd = farmName.get(j).getFarm_add();
                String farmcode = farmName.get(j).getFarm_code();
                String farmfzr = employeeIdtoNameSmap.get(farmName.get(j).getFarm_fzr());
                String bz = farmName.get(j).getBz();
                StringList.add(name + "  " + farmid + "  " + farmadd + "  " + farmcode + "  " + farmfzr + "  " + bz);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("场内圈舍")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                PiggeryMapper mapper = sqlSession.getMapper(PiggeryMapper.class);
                piggeryList = mapper.selectAll();
            }
            StringList.add("猪舍编号  饲 养 员  猪舍名称  使用状态  饲养品种  猪舍类别");
            for (int j = 0; j < piggeryList.size(); j++) {
                for (int i = 0; i < zslbList.size(); i++) {
                    if (zslbList.get(i).getTypeid().equals(piggeryList.get(j).getZslb())) {
                        piggeryList.get(j).setZslb(zslbList.get(i).getTypename());
                    }
                }

                String Number = piggeryList.get(j).getNumber();
                String Category = piggeryList.get(j).getCategory();
                String Employee = employeeIdtoNameSmap.get(piggeryList.get(j).getFeeder());
                String Statue = piggeryList.get(j).getStatue();
                String Variety = piggeryList.get(j).getVariety();
                String Zslb = piggeryList.get(j).getZslb();

                StringList.add(Number + "  " + Category + "  " + Employee + "  " + Statue + "  " + Variety + "  " + Zslb);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("猪舍类别")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                ZslbMapper mapper = sqlSession.getMapper(ZslbMapper.class);
                zslbList = mapper.selectAll();
            }
            StringList.add("流水编号  类型名称");
            for (int j = 0; j < zslbList.size(); j++) {
                String Typeid = zslbList.get(j).getTypeid();
                String Typename = zslbList.get(j).getTypename();

                StringList.add(Typeid + "  " + Typename);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("栏位管理")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                FenceMapper mapper = sqlSession.getMapper(FenceMapper.class);
                fenceList = mapper.selectAll();
            }
            StringList.add("栏位编号  栏位名称  猪舍编号  备   注");
            for (int j = 0; j < fenceList.size(); j++) {
                String Fenceid = fenceList.get(j).getFenceid();
                String Fencename = fenceList.get(j).getFencename();
                String Number = fenceList.get(j).getNumber();
                String Bz = fenceList.get(j).getBz();

                StringList.add(Fenceid + "  " + Fencename + "  " + Number + "  " + Bz);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("猪只状态")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
                swintypeList = mapper.selectAll();
            }
            StringList.add("状态编号  状态名称  状态去向");
            for (int j = 0; j < swintypeList.size(); j++) {
                String Typeid = swintypeList.get(j).getTypeid();
                String Typename = swintypeList.get(j).getTypename();
                String Totypeid = swintypeList.get(j).getTotypeid();

                StringList.add(Typeid + "  " + Typename + "  " + Totypeid);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("饲料类别")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SllbMapper mapper = sqlSession.getMapper(SllbMapper.class);
                sllbList = mapper.selectAll();
            }
            StringList.add("流水编号  类型名称");
            for (int j = 0; j < sllbList.size(); j++) {
                String Typeid = sllbList.get(j).getTypeid();
                String Typename = sllbList.get(j).getTypename();
                StringList.add(Typeid + "  " + Typename);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("饲料信息")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                PigslMapper mapper = sqlSession.getMapper(PigslMapper.class);
                pigslList = mapper.selectAll();
                SllbMapper mapper1 = sqlSession.getMapper(SllbMapper.class);
                sllbList = mapper1.selectAll();
            }
            StringList.add("饲料简码  饲料名称  适合猪只");
            for (int j = 0; j < pigslList.size(); j++) {
                for (int i = 0; i < sllbList.size(); i++) {
                    if (sllbList.get(i).getTypeid().equals(pigslList.get(j).getSwintypeid())) {
                        pigslList.get(j).setSwintypeid(sllbList.get(i).getTypename());
                    }
                }
                String Typeid = pigslList.get(j).getTypeid();
                String Typename = pigslList.get(j).getTypename();
                String Bz = pigslList.get(j).getSwintypeid();
                StringList.add(Typeid + "  " + Typename + "  " + Bz);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("药品信息")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                PigypMapper mapper = sqlSession.getMapper(PigypMapper.class);
                pigypList = mapper.selectAll();
            }
            StringList.add("药品简码  药品名称  说    明");
            for (int j = 0; j < pigypList.size(); j++) {
                String Typeid = pigypList.get(j).getTypeid();
                String Typename = pigypList.get(j).getTypename();
                String Bz = pigypList.get(j).getBz();

                StringList.add(Typeid + "  " + Typename + "  " + Bz);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("疫苗信息")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                VaccineMapper mapper = sqlSession.getMapper(VaccineMapper.class);
                vaccineList = mapper.selectAll();
            }
            StringList.add("疫苗简码  疫苗名称  说    明");
            for (int j = 0; j < vaccineList.size(); j++) {
                String Typeid = vaccineList.get(j).getTypeid();
                String Typename = vaccineList.get(j).getTypename();
                String Bz = vaccineList.get(j).getBz();

                StringList.add(Typeid + "  " + Typename + "  " + Bz);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("免疫设置")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                MyszMapper mapper = sqlSession.getMapper(MyszMapper.class);
                myszList = mapper.selectAll();
            }
            StringList.add("流水编号  日   龄  疫苗名称  备   注");
            for (int j = 0; j < myszList.size(); j++) {
                String Typeid = myszList.get(j).getId();
                String Typename = String.valueOf(myszList.get(j).getRl());
                String Bz = vaccineIdtoNameSmap.get(myszList.get(j).getMyname());
                String Bz1 = myszList.get(j).getBz();

                StringList.add(Typeid + "  " + Typename + "  " + Bz + "  " + Bz1);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("种猪免疫设置")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                ZzmyszMapper mapper = sqlSession.getMapper(ZzmyszMapper.class);
                zzmyszList = mapper.selectAll();
            }
            StringList.add("流水编号  猪只状态  设置日期  日期单位  疫苗名称  备   注");
            for (int j = 0; j < zzmyszList.size(); j++) {
                String Id = zzmyszList.get(j).getId();
                String Typeid = swintypeIdtoNameSmap.get(zzmyszList.get(j).getTypeid());
                String Szrq = zzmyszList.get(j).getSzrq();
                String Rqdw = zzmyszList.get(j).getRqdw().equals("1") ? "天" : "月";
                String Myname = vaccineIdtoNameSmap.get(zzmyszList.get(j).getMyname());
                String Bz = zzmyszList.get(j).getBz();

                StringList.add(Id + "  " + Typeid + "  " + Szrq + "  " + Rqdw + "  " + Myname + "  " + Bz);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("疾病信息")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                PigjbMapper mapper = sqlSession.getMapper(PigjbMapper.class);
                pigjbList = mapper.selectAll();
            }
            StringList.add("疾病编号  疾病名称");
            for (int j = 0; j < pigjbList.size(); j++) {
                String Typeid = pigjbList.get(j).getTypeid();
                String Typename = pigjbList.get(j).getTypename();

                StringList.add(Typeid + "  " + Typename);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("参数设置")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                ZzmyszMapper mapper = sqlSession.getMapper(ZzmyszMapper.class);
                zzmyszList = mapper.selectAll();
            }
            StringList.add("流水编号  猪只状态  设置日期  日期单位  疫苗名称  备   注");
            for (int j = 0; j < designbaselist.size(); j++) {
                String Id = designbaselist.get(j).getId();
                String Typename = designbaselist.get(j).getTypename();
                String Typevalue = designbaselist.get(j).getTypevalue();

                StringList.add(Id + "  " + Typename + "  " + Typevalue);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("饲料库存")) {// 药品库存 疫苗库存  员工职位  用户管理
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SlkcMapper mapper = sqlSession.getMapper(SlkcMapper.class);
                slkcList = mapper.selectAll();
            }
            StringList.add("饲料名称   饲料数量");
            for (int j = 0; j < slkcList.size(); j++) {
                String Typeid = pigslIdtoNameSmap.get(slkcList.get(j).getTypeid());
                String Num = String.valueOf(slkcList.get(j).getNum());

                StringList.add(Typeid + "  " + Num);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("药品库存")) {//  疫苗库存  员工职位  用户管理
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                YpkcMapper mapper = sqlSession.getMapper(YpkcMapper.class);
                ypkcList = mapper.selectAll();
            }
            StringList.add("药品名称   药品数量");
            for (int j = 0; j < ypkcList.size(); j++) {
                String Typeid = pigypIdtoNameSmap.get(ypkcList.get(j).getTypeid());
                String Num = String.valueOf(ypkcList.get(j).getNum());

                StringList.add(Typeid + "  " + Num);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("疫苗库存")) {//    员工职位  用户管理
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                YmkcMapper mapper = sqlSession.getMapper(YmkcMapper.class);
                ymkcList = mapper.selectAll();
            }
            StringList.add("疫苗名称  库存数量");
            for (int j = 0; j < ymkcList.size(); j++) {
                String Typeid = vaccineIdtoNameSmap.get(ymkcList.get(j).getTypeid());
                String Num = String.valueOf(ymkcList.get(j).getNum());

                StringList.add(Typeid + "  " + Num);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("员工职位")) {
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                YgzwMapper mapper = sqlSession.getMapper(YgzwMapper.class);
                ygzwList = mapper.selectAll();
            }
            StringList.add("流水编号  职位名称");
            for (int j = 0; j < ygzwList.size(); j++) {
                String Zwid = ygzwList.get(j).getZwid();
                String Zwname = ygzwList.get(j).getZwname();

                StringList.add(Zwid + "  " + Zwname);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("用户管理")) {//      用户管理
            ArrayList<String> StringList = new ArrayList<>();
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
                YgzwMapper mapper0 = sqlSession.getMapper(YgzwMapper.class);
                employeeList = mapper.selectAll();
                ygzwList = mapper0.selectAll();
            }
            StringList.add("员工编号  员工姓名  职    位  是否管理员  疫苗名称  备   注");
            for (int j = 0; j < employeeList.size(); j++) {
                for (int i = 0; i < ygzwList.size(); i++) {
                    if (employeeList.get(j).getYgzw().equals(ygzwList.get(i).getZwid())) {
                        employeeList.get(j).setYgzw(ygzwList.get(i).getZwname());
                    }
                }
                String Employeeid = employeeList.get(j).getEmployeeid();
                String User_name = employeeList.get(j).getUser_name();
                String Ygzw = employeeList.get(j).getYgzw();
                String Superroot = employeeList.get(j).getSuperroot();
                String Isallfarm = employeeList.get(j).getIsallfarm();
                String Money = employeeList.get(j).getMoney();
                String Rzsj = employeeList.get(j).getRzsj();
                String Worksm = employeeList.get(j).getWorksm();
                String Bz = employeeList.get(j).getBz();

                StringList.add(Employeeid + "  " + User_name + "  " + Ygzw + "  " + Superroot + "  " + Isallfarm + "  " + Money + "  " + Rzsj + "  " + Worksm + "  " + Bz);
            }
            printData.setPrintDataStringList(StringList);
            if (printData.getPrintDataStringList() == null) {
                JOptionPane.showMessageDialog(null,
                        "不错存在数据无法打印！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();
        }
        if (title.equals("个体基本信息") || title.equals("公猪采精登记") || title.equals("母猪配种情况登记")//
                || title.equals("母猪分娩情况登记") || title.equals("母猪断奶登记") || title.equals("种公猪资料")
                || title.equals("种母猪资料") || title.equals("后备猪2月龄登记") || title.equals("后备猪4月龄登记") || title.equals("后备猪6月龄登记")
                || title.equals("100KG检测登记") || title.equals("屠宰性能测定登记") || title.equals("猪只免疫登记") || title.equals("疾病治疗登记")
                || title.equals("基因检测登记") || title.equals("猪只销售登记") || title.equals("猪只死亡登记")
                || title.equals("饲料入库登记") || title.equals("饲料出库登记") || title.equals("药品入库登记") || title.equals("药品出库登记")
                || title.equals("疫苗入库登记") || title.equals("疫苗出库登记") || title.equals("药品入库登记") || title.equals("药品入库登记")
                || title.equals("哺乳猪-保育猪") || title.equals("保育猪-生长育肥猪") || title.equals("保育猪-后备猪")) {
            BufferedImage bi = new BufferedImage(varietiesDataPlus.getWidth(), varietiesDataPlus.getHeight(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = bi.createGraphics();
            varietiesDataPlus.paint(g2d);
            try {
                ImageIO.write(bi, "PNG", new File("D:\\pigdata\\temp.png"));
                printImage("D:\\pigdata\\temp.png");// TODO add your handling code here:
            } catch (IOException ex) {
            }
        }

    }//GEN-LAST:event_jButtonPrintActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        this.setVisible(false);
        controlApp.setLocationRelativeTo(this);
        controlApp.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed
    //第一个参数读取页数第二个参数判断是否是搜索

    public static void Xzxppage(int pagenum) {
        pageModel.setPageNo(pagenum);
        List<Selebith> selebithtemp = pageModel.getNoList();

        if (selebithtemp == null) {
            return;
        }
        boolean gm = true;//gong - ture;
        Object[][] tableModel = null;
        for (int j = 0; j < selebithtemp.size(); j++) {
            if (selebithtemp.get(j).getR_sex().equals("0")) {
                if (j == 0) {
                    gm = true;
                    tableModel = new Object[selebithtemp.size()][9];
                }
                selebithtemp.get(j).setR_sex("公");
                tableModel[j][7] = selebithtemp.get(j).getGzcjcs();//"采精次数",*
                tableModel[j][8] = jqqyjyMapperPlus.selectByCjrq(selebithtemp.get(j).getR_animal());//"采精次数",*
            } else {
                if (j == 0) {
                    gm = false;
                    tableModel = new Object[selebithtemp.size()][8];
                }
                selebithtemp.get(j).setR_sex("母");
                tableModel[j][7] = selebithtemp.get(j).getR_fno();//"采精次数",*
            }
            tableModel[j][0] = selebithtemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = selebithtemp.get(j).getR_farmid();//"综合育种"
            tableModel[j][2] = selebithtemp.get(j).getR_fdate();//"出生日期"
            tableModel[j][3] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());//"当前状态"
            tableModel[j][4] = piggeryIdtoNameSmap.get(selebithtemp.get(j).getR_cage());//"所在猪舍"
            tableModel[j][5] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());//"所在猪舍"
            tableModel[j][6] = selebithtemp.get(j).getR_sex();//"性  别"
        }

        String[] tableHead1 = new String[]{"个体编号", "综合育种", "出生日期", "当前状态", "所在猪舍", "所在栏位", "性  别", "采精次数", "最近采精"};
        String[] tableHead2 = new String[]{"个体编号", "综合育种", "出生日期", "当前状态", "所在猪舍", "所在栏位", "性  别", "当前胎次"};
        String title1 = "选种选配";
        if (gm == true) {
            xzxp.closeListplus2(tableModel, tableHead1, title1);
        } else {
            xzxp.closeListplus2(tableModel, tableHead2, title1);
        }
    }

    public static void Yzxppage(int pagenum) {
        List<Selebith> selebithtemp;

        yzgtxxPageModel.setPageNo(pagenum);
        selebithtemp = yzgtxxPageModel.getNoList();
        if (selebithtemp == null) {
            return;
        }
        Object[][] tableModel = new Object[selebithtemp.size()][3];
        for (int j = 0; j < selebithtemp.size(); j++) {
            tableModel[j][0] = selebithtemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = selebithtemp.get(j).getR_sire();//"父   亲"
            tableModel[j][2] = selebithtemp.get(j).getR_dam();//"母   亲"
        }

        String[] tableHead = new String[]{"个体编号", "父亲编号", "母亲编号"};
        String title1 = "系谱数据";
        closeListplus(tableModel, tableHead, title1);
    }

    public static void Yzgtxxpage(int pagenum) {
        List<Selebith> selebithtemp;

        yzgtxxPageModel.setPageNo(pagenum);
        selebithtemp = yzgtxxPageModel.getNoList();
        if (selebithtemp == null) {
            return;
        }
        Object[][] tableModel = new Object[selebithtemp.size()][11];
        for (int j = 0; j < selebithtemp.size(); j++) {

            tableModel[j][0] = selebithtemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = lineherdIdtoNameSmap.get(selebithtemp.get(j).getR_herd());//"品   系"
            tableModel[j][2] = selebithtemp.get(j).getR_fdate();//"出生日期"
            tableModel[j][4] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());//"当前状态",*
            tableModel[j][5] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());//"所在栏舍",*
            tableModel[j][6] = selebithtemp.get(j).getR_ghatch();//"出生胎次
            tableModel[j][7] = selebithtemp.get(j).getR_weanwt();//"断奶重量
            if (selebithtemp.get(j).getR_sex().equals("0")) {
                selebithtemp.get(j).setR_sex(selebithtemp.get(j).getR_sex().equals("0") ? "公" : "母");
                tableModel[j][8] = selebithtemp.get(j).getGzcjcs();//"采精次数
                tableModel[j][9] = "NA";//"当前胎次
                tableModel[j][10] = "NA";//"产仔总数
                tableModel[j][3] = selebithtemp.get(j).getR_sex();//"性   别"

            } else {
                selebithtemp.get(j).setR_sex(selebithtemp.get(j).getR_sex().equals("0") ? "公" : "母");
                tableModel[j][8] = "NA";//"采精次数
                tableModel[j][9] = selebithtemp.get(j).getR_fno();//"当前胎次
                tableModel[j][10] = selebithtemp.get(j).getCzzs();//"产仔总数
                tableModel[j][3] = selebithtemp.get(j).getR_sex();//"性   别"
            }

        }

        String[] tableHead = new String[]{"个体编号", "品   系", "出生日期", "性   别", "当前状态", "所在栏舍", "出生胎次", "断奶重量", "采精次数", "当前胎次", "产仔总数"};
        String title1 = "育种个体信息";
        closeListplus(tableModel, tableHead, title1);
    }

    public static void Yztwotestpage(int pagenum) {
        List<TwoTest> twotesttemp;
        yzTwotestPageModel.setPageNo(pagenum);
        twotesttemp = yzTwotestPageModel.getNoList();
        if (twotesttemp == null) {
            return;
        }
        Object[][] tableModel = new Object[twotesttemp.size()][5];
        for (int j = 0; j < twotesttemp.size(); j++) {
            twotesttemp.get(j).setZsex(twotesttemp.get(j).getZsex().equals("0") ? "公" : "母");
            tableModel[j][0] = twotesttemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = twotesttemp.get(j).getCdrq();//"个体编号"
            tableModel[j][2] = twotesttemp.get(j).getZsex();//"性   别"
            tableModel[j][3] = twotesttemp.get(j).getWeight();//"体  重"
            tableModel[j][4] = fenceIdtoNameSmap.get(twotesttemp.get(j).getFenceid());//"所在栏舍",*
        }

        String[] tableHead = new String[]{"个体编号", "测定日起", "性   别", "体   重", "所在栏位"};
        String title1 = "后备2月性状";
        closeListplus(tableModel, tableHead, title1);
    }

    public static void Yzfourtestpage(int pagenum) {
        List<FourTest> fourtesttemp;
        yzFourtestPageModel.setPageNo(pagenum);
        fourtesttemp = yzFourtestPageModel.getNoList();
        if (fourtesttemp == null) {
            return;
        }
        Object[][] tableModel = new Object[fourtesttemp.size()][5];
        for (int j = 0; j < fourtesttemp.size(); j++) {
            fourtesttemp.get(j).setZsex(fourtesttemp.get(j).getZsex().equals("0") ? "公" : "母");
            tableModel[j][0] = fourtesttemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = fourtesttemp.get(j).getCdrq();//"个体编号"
            tableModel[j][2] = fourtesttemp.get(j).getZsex();//"性   别"
            tableModel[j][3] = fourtesttemp.get(j).getWeight();//"体  重"
            tableModel[j][4] = fenceIdtoNameSmap.get(fourtesttemp.get(j).getFenceid());//"所在栏舍",*
        }

        String[] tableHead = new String[]{"个体编号", "测定日起", "性   别", "体   重", "所在栏位"};
        String title1 = "后备4月性状";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Yzsixtestpage(int pagenum) {
        List<SixTest> sixtesttemp;
        yzSixtestPageModel.setPageNo(pagenum);
        sixtesttemp = yzSixtestPageModel.getNoList();
        if (sixtesttemp == null) {
            return;
        }
        Object[][] tableModel = new Object[sixtesttemp.size()][5];
        for (int j = 0; j < sixtesttemp.size(); j++) {
            sixtesttemp.get(j).setZsex(sixtesttemp.get(j).getZsex().equals("0") ? "公" : "母");
            tableModel[j][0] = sixtesttemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = sixtesttemp.get(j).getCdrq();//"个体编号"
            tableModel[j][2] = sixtesttemp.get(j).getZsex();//"性   别"
            tableModel[j][3] = sixtesttemp.get(j).getWeight();//"体  重"
            tableModel[j][4] = fenceIdtoNameSmap.get(sixtesttemp.get(j).getFenceid());//"所在栏舍",*
        }

        String[] tableHead = new String[]{"个体编号", "测定日起", "性   别", "体   重", "所在栏位"};
        String title1 = "后备6月性状";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Yzhundredtestpage(int pagenum) {
        List<HundredTest> hundredtesttemp;
        yzHundredtestPageModel.setPageNo(pagenum);
        hundredtesttemp = yzHundredtestPageModel.getNoList();
        if (hundredtesttemp == null) {
            return;
        }
        Object[][] tableModel = new Object[hundredtesttemp.size()][6];
        for (int j = 0; j < hundredtesttemp.size(); j++) {
            hundredtesttemp.get(j).setZsex(hundredtesttemp.get(j).getZsex().equals("0") ? "公" : "母");
            tableModel[j][0] = hundredtesttemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = hundredtesttemp.get(j).getCdrq();//"个体编号"
            tableModel[j][2] = hundredtesttemp.get(j).getZsex();//"性   别"
            tableModel[j][3] = hundredtesttemp.get(j).getWeight();//"体  重"
            tableModel[j][4] = fenceIdtoNameSmap.get(hundredtesttemp.get(j).getFenceid());//"所在栏舍",*
            tableModel[j][5] = hundredtesttemp.get(j).getRl();//"所在栏舍",*
        }

        String[] tableHead = new String[]{"个体编号", "测定日起", "性   别", "体   重", "所在栏位", "体重日龄"};
        String title1 = "100kg测定性状";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Selebithpage(int pagenum) {
        List<Selebith> selebithtemp;

        selebithPageModel.setPageNo(pagenum);
        selebithtemp = selebithPageModel.getNoList();
        if (selebithtemp == null) {
            return;
        }
        Object[][] tableModel = new Object[selebithtemp.size()][10];
        for (int j = 0; j < selebithtemp.size(); j++) {
            selebithtemp.get(j).setR_sex(selebithtemp.get(j).getR_sex().equals("0") ? "公" : "母");

            tableModel[j][0] = selebithtemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = lineidIdtoNameSmap.get(selebithtemp.get(j).getR_lineid());//"品   种"
            tableModel[j][2] = lineherdIdtoNameSmap.get(selebithtemp.get(j).getR_herd());//"品   系"
            tableModel[j][3] = selebithtemp.get(j).getR_fdate();//"出生日期"
            tableModel[j][4] = selebithtemp.get(j).getR_ear_no();//"耳 缺 号"
            tableModel[j][5] = selebithtemp.get(j).getR_sex();//"性   别"
            tableModel[j][6] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());//"当前状态",*
            tableModel[j][7] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());//"所在栏舍",*
            tableModel[j][8] = selebithtemp.get(j).getR_sire();//"父   亲"
            tableModel[j][9] = selebithtemp.get(j).getR_dam();//"母   亲"
        }

        String[] tableHead = new String[]{"个体编号", "品   种", "品   系", "出生日期", "耳 缺 号", "性   别", "当前状态", "所在栏舍", "父   亲", "母   亲"};
        String title1 = "个体基本信息";
        closeListplus(tableModel, tableHead, title1);
    }

    public static void Takespermpage(int pagenum) {
        List<Takesperm> takespermtemp;

        takespermPageModel.setPageNo(pagenum);
        takespermtemp = takespermPageModel.getNoList();

        if (takespermtemp == null) {
            return;
        }
        List<String> TakespermCage = new ArrayList<>();
        List<String> TakespermPcage = new ArrayList<>();
//备注：
        Selebith selebith;
        for (int i = 0; i < takespermtemp.size(); i++) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SelebithMapper mapper = sqlSession.getMapper(SelebithMapper.class
                );
                selebith = mapper.selectByTypeid(takespermtemp.get(i).getR_animal());
            }
            TakespermCage.add(piggeryIdtoNameSmap.get(selebith.getR_cage()));
            TakespermPcage.add(fenceIdtoNameSmap.get(selebith.getR_pcage()));
            takespermtemp.get(i).setEmployeeid(employeeIdtoNameSmap.get(takespermtemp.get(i).getEmployeeid()));

        }

        Object[][] tableModel = new Object[takespermtemp.size()][6];
        for (int j = 0; j < takespermtemp.size(); j++) {
            tableModel[j][0] = takespermtemp.get(j).getId();
            tableModel[j][1] = takespermtemp.get(j).getR_animal();
            tableModel[j][2] = takespermtemp.get(j).getCjrq();
            tableModel[j][3] = TakespermCage.get(j);
            tableModel[j][4] = TakespermPcage.get(j);
            tableModel[j][5] = takespermtemp.get(j).getEmployeeid();
        }

        String[] tableHead = new String[]{"采精编号", "个体编号", "采精日期", "所在猪舍", "所在栏位 ", "负 责 人"};
        String title1 = "公猪采精登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Breedingpage(int pagenum) {
        List<Breeding> breedingtemp;

        breedingPageModel.setPageNo(pagenum);
        breedingtemp = breedingPageModel.getNoList();

        if (breedingtemp == null) {
            return;
        }

        for (int i = 0; i < breedingtemp.size(); i++) {
            if (breedingtemp.get(i).getPzzt().equals("1")) {
                breedingtemp.get(i).setPzzt("检验");
            }
            if (breedingtemp.get(i).getPzzt().equals("2")) {
                breedingtemp.get(i).setPzzt("妊娠");
            }
            if (breedingtemp.get(i).getPzzt().equals("3")) {
                breedingtemp.get(i).setPzzt("返情");
            }
        }

        Object[][] tableModel = new Object[breedingtemp.size()][6];
        for (int j = 0; j < breedingtemp.size(); j++) {
            tableModel[j][0] = breedingtemp.get(j).getId();
            tableModel[j][1] = breedingtemp.get(j).getR_animal();
            tableModel[j][2] = breedingtemp.get(j).getPzrq();
            tableModel[j][3] = employeeIdtoNameSmap.get(breedingtemp.get(j).getEmployeeid());
            tableModel[j][4] = breedingtemp.get(j).getPzzt();
            tableModel[j][5] = fenceIdtoNameSmap.get(breedingtemp.get(j).getFenceid());
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "配种日期", "负 责 人", "配种状态 ", "所在栏舍  "};
        String title1 = "母猪配种情况登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Childbirthpage(int pagenum) {
        List<Childbirth> childbirthtemp;

        childbirthPageModel.setPageNo(pagenum);
        childbirthtemp = childbirthPageModel.getNoList();

        if (childbirthtemp == null) {
            return;
        }

        Object[][] tableModel = new Object[childbirthtemp.size()][7];
        for (int j = 0; j < childbirthtemp.size(); j++) {
            switch (childbirthtemp.get(j).getZt()) {
                case "1":
                    childbirthtemp.get(j).setZt("分娩状态");
                    break;
                case "2":
                    childbirthtemp.get(j).setZt("断奶状态");
                    break;
                case "3":
                    childbirthtemp.get(j).setZt("未知状态");
                    break;
            }

            tableModel[j][0] = childbirthtemp.get(j).getId();
            tableModel[j][1] = childbirthtemp.get(j).getR_animal();
            tableModel[j][2] = childbirthtemp.get(j).getCzrq();
            tableModel[j][3] = childbirthtemp.get(j).getZt();
            tableModel[j][4] = employeeIdtoNameSmap.get(childbirthtemp.get(j).getFwemployeeid());
            tableModel[j][5] = fenceIdtoNameSmap.get(childbirthtemp.get(j).getFenceid());
            tableModel[j][6] = fenceIdtoNameSmap.get(childbirthtemp.get(j).getFwfenceid());
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "分娩日期", "当前状态", "负 责 人", "妊娠栏舍", "分娩栏舍"};
        String title1 = "母猪分娩情况登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Weaningpage(int pagenum) {
        List<Childbirth> childbirthtemp;

        weaningPageModel.setPageNo(pagenum);
        childbirthtemp = weaningPageModel.getNoList();

        if (childbirthtemp == null) {
            return;
        }

        Object[][] tableModel = new Object[childbirthtemp.size()][8];
        for (int j = 0; j < childbirthtemp.size(); j++) {
            tableModel[j][0] = childbirthtemp.get(j).getId();
            tableModel[j][1] = childbirthtemp.get(j).getR_animal();
            tableModel[j][2] = childbirthtemp.get(j).getTc();
            tableModel[j][3] = childbirthtemp.get(j).getDnrq();
            tableModel[j][4] = childbirthtemp.get(j).getDnts();
            tableModel[j][5] = childbirthtemp.get(j).getDnwz();
            tableModel[j][6] = fenceIdtoNameSmap.get(childbirthtemp.get(j).getOutfenceid());
            tableModel[j][7] = employeeIdtoNameSmap.get(childbirthtemp.get(j).getEmployeeid());
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "当前胎次", "断奶日期", "断奶头数 ", "断奶窝重", "断奶后栏舍", "负 责 人"};
        String title1 = "母猪断奶登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void ConservationTurnFattingpage(int pagenum) {
        if (changepages == null) {
            changepages = new ArrayList<>();
        } else {
            changepages.clear();
        }
        MainApp.conservationTurnFattingPageModel.setPageNo(pagenum);
        changepages = MainApp.conservationTurnFattingPageModel.getNoList();
        Object[][] tableModel = new Object[changepages.size()][6];
        for (int j = 0; j < changepages.size(); j++) {
            tableModel[j][0] = changepages.get(j).getR_animal();
            tableModel[j][1] = swintypeIdtoNameSmap.get(changepages.get(j).getR_curmark());
            tableModel[j][2] = changepages.get(j).getBysj();
            tableModel[j][3] = fenceIdtoNameSmap.get(changepages.get(j).getByffenceid());
            tableModel[j][4] = fenceIdtoNameSmap.get(changepages.get(j).getByafenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(changepages.get(j).getByfzr());
        }

        String[] tableHead = new String[]{"个体编号", "当前状态", "保育转育肥时间 ", "转前栏舍", "转后栏舍", "负 责 人"};
        String title1 = "保育猪-生长育肥猪";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void ConservationTurnBackpage(int pagenum) {
        if (changepages == null) {
            changepages = new ArrayList<>();
        } else {
            changepages.clear();
        }
        MainApp.conservationTurnBackPageModel.setPageNo(pagenum);
        changepages = MainApp.conservationTurnBackPageModel.getNoList();
        Object[][] tableModel = new Object[changepages.size()][6];
        for (int j = 0; j < changepages.size(); j++) {
            tableModel[j][0] = changepages.get(j).getR_animal();
            tableModel[j][1] = swintypeIdtoNameSmap.get(changepages.get(j).getR_curmark());
            tableModel[j][2] = changepages.get(j).getR_predate();
            tableModel[j][3] = fenceIdtoNameSmap.get(changepages.get(j).getBhffenceid());
            tableModel[j][4] = fenceIdtoNameSmap.get(changepages.get(j).getBhafenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(changepages.get(j).getWhodo());
        }

        String[] tableHead = new String[]{"个体编号", "当前状态", "保育转后备时间 ", "转前栏舍", "转后栏舍", "负 责 人"};
        String title1 = "保育猪-后备猪";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void FeedingTurnConservationPage(int pagenum) {
        if (changepages == null) {
            changepages = new ArrayList<>();
        } else {
            changepages.clear();
        }
        MainApp.feedingTurnConservationPageModel.setPageNo(pagenum);
        changepages = MainApp.feedingTurnConservationPageModel.getNoList();
        if (changepages == null) {
            return;
        }
        Object[][] tableModel = new Object[changepages.size()][6];
        for (int j = 0; j < changepages.size(); j++) {
            tableModel[j][0] = changepages.get(j).getR_animal();
            tableModel[j][1] = swintypeIdtoNameSmap.get(changepages.get(j).getR_curmark());
            tableModel[j][2] = changepages.get(j).getR_weandate();
            tableModel[j][3] = fenceIdtoNameSmap.get(changepages.get(j).getZbffenceid());
            tableModel[j][4] = fenceIdtoNameSmap.get(changepages.get(j).getZbafenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(changepages.get(j).getZbfzr());
        }

        String[] tableHead = new String[]{"个体编号", "当前状态", "哺乳转保育时间 ", "转前栏舍", "转后栏舍", "负 责 人"};
        String title1 = "哺乳猪-保育猪";
        closeListplus(tableModel, tableHead, title1);
    }

    public static void MaleBoarpage(int pagenum) {
        List<Selebith> selebithtemp;

        maleBoarPageModel.setPageNo(pagenum);
        selebithtemp = maleBoarPageModel.getNoList();

        if (selebithtemp == null) {
            return;
        }

        Object[][] tableModel = new Object[selebithtemp.size()][5];
        for (int j = 0; j < selebithtemp.size(); j++) {
            tableModel[j][0] = selebithtemp.get(j).getR_animal();
            tableModel[j][1] = selebithtemp.get(j).getR_fdate();
            tableModel[j][2] = selebithtemp.get(j).getR_sire();
            tableModel[j][3] = selebithtemp.get(j).getR_dam();
            tableModel[j][4] = selebithtemp.get(j).getGzcjcs();
        }

        String[] tableHead = new String[]{"个体编号", "出生日期", "父亲编号", "母亲编号 ", "采精次数"};
        String title1 = "种公猪资料";
        closeListplus(tableModel, tableHead, title1);
    }

    public static void FemaleBoarpage(int pagenum) {
        List<Selebith> selebithtemp;

        femaleBoarPageModel.setPageNo(pagenum);
        selebithtemp = femaleBoarPageModel.getNoList();

        if (selebithtemp == null) {
            return;
        }

        Object[][] tableModel = new Object[selebithtemp.size()][5];
        for (int j = 0; j < selebithtemp.size(); j++) {
            tableModel[j][0] = selebithtemp.get(j).getR_animal();
            tableModel[j][1] = selebithtemp.get(j).getR_fdate();
            tableModel[j][2] = selebithtemp.get(j).getR_sire();
            tableModel[j][3] = selebithtemp.get(j).getR_dam();
            tableModel[j][4] = selebithtemp.get(j).getR_fno();
        }

        String[] tableHead = new String[]{"个体编号", "出生日期", "父亲编号", "母亲编号", "胎   次"};
        String title1 = "种母猪资料";
        closeListplus(tableModel, tableHead, title1);
    }

    public static void TwoTestpage(int pagenum) {
        List<TwoTest> twotesttemp;

        MainApp.twoTestPageModel.setPageNo(pagenum);
        twotesttemp = MainApp.twoTestPageModel.getNoList();

        if (twotesttemp == null) {
            return;
        }

        Object[][] tableModel = new Object[twotesttemp.size()][6];
        for (int j = 0; j < twotesttemp.size(); j++) {

            tableModel[j][0] = twotesttemp.get(j).getR_animal();
            tableModel[j][1] = twotesttemp.get(j).getCdrq();
            tableModel[j][2] = twotesttemp.get(j).getZsex().equals("1") ? "母" : "公";
            tableModel[j][3] = String.valueOf(twotesttemp.get(j).getWeight());
            tableModel[j][4] = fenceIdtoNameSmap.get(twotesttemp.get(j).getFenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(twotesttemp.get(j).getEmployeeid());

        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性   别", "体   重", "所在舍栏", "负 责 人"};
        String title1 = "后备猪2月龄登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void FourTestpage(int pagenum) {
        List<FourTest> fourtesttemp = new ArrayList<FourTest>() {
        };

        MainApp.fourTestPageModel.setPageNo(pagenum);
        fourtesttemp = MainApp.fourTestPageModel.getNoList();

        if (fourtesttemp == null) {
            return;
        }

        Object[][] tableModel = new Object[fourtesttemp.size()][6];
        for (int j = 0; j < fourtesttemp.size(); j++) {

            String Password = fourtesttemp.get(j).getZsex();
            if (Password != null) {
                Password = Password.equals("1") ? "母" : "公";
            }

            tableModel[j][0] = fourtesttemp.get(j).getR_animal();
            tableModel[j][1] = fourtesttemp.get(j).getCdrq();
            tableModel[j][2] = Password;
            tableModel[j][3] = String.valueOf(fourtesttemp.get(j).getWeight());
            tableModel[j][4] = fenceIdtoNameSmap.get(fourtesttemp.get(j).getFenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(fourtesttemp.get(j).getEmployeeid());

        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性   别", "体   重", "所在舍栏", "负 责 人"};
        String title1 = "后备猪4月龄登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void SixTestpage(int pagenum) {
        List<SixTest> sixtesttemp = new ArrayList<SixTest>() {
        };

        MainApp.sixTestPageModel.setPageNo(pagenum);
        sixtesttemp = MainApp.sixTestPageModel.getNoList();

        if (sixtesttemp == null) {
            return;
        }

        Object[][] tableModel = new Object[sixtesttemp.size()][6];
        for (int j = 0; j < sixtesttemp.size(); j++) {
            String Password = sixtesttemp.get(j).getZsex();
            if (Password != null) {
                Password = Password.equals("1") ? "母" : "公";
            }

            tableModel[j][0] = sixtesttemp.get(j).getR_animal();
            tableModel[j][1] = sixtesttemp.get(j).getCdrq();
            tableModel[j][2] = Password;
            tableModel[j][3] = String.valueOf(sixtesttemp.get(j).getWeight());
            tableModel[j][4] = fenceIdtoNameSmap.get(sixtesttemp.get(j).getFenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(sixtesttemp.get(j).getEmployeeid());

        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性   别", "体   重", "所在舍栏", "负 责 人"};
        String title1 = "后备猪6月龄登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void HundredTestpage(int pagenum) {
        List<HundredTest> Hundredtesttemp = new ArrayList<HundredTest>() {
        };

        MainApp.hundredTestPageModel.setPageNo(pagenum);
        Hundredtesttemp = MainApp.hundredTestPageModel.getNoList();

        if (Hundredtesttemp == null) {
            return;
        }

        Object[][] tableModel = new Object[Hundredtesttemp.size()][6];
        for (int j = 0; j < Hundredtesttemp.size(); j++) {
            String Password = Hundredtesttemp.get(j).getZsex();
            if (Password != null) {
                Password = Password.equals("1") ? "母" : "公";
            }

            tableModel[j][0] = Hundredtesttemp.get(j).getR_animal();
            tableModel[j][1] = Hundredtesttemp.get(j).getCdrq();
            tableModel[j][2] = Password;
            tableModel[j][3] = String.valueOf(Hundredtesttemp.get(j).getWeight());
            tableModel[j][4] = fenceIdtoNameSmap.get(Hundredtesttemp.get(j).getFenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(Hundredtesttemp.get(j).getEmployeeid());

        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性   别", "体   重", "所在舍栏", "负 责 人"};
        String title1 = "100KG检测登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Slrkpage(int pagenum) {
        List<Slrk> slrktemp;

        slrkPageModel.setPageNo(pagenum);
        slrktemp = slrkPageModel.getNoList();

        if (slrktemp == null) {
            return;
        }

        Object[][] tableModel = new Object[slrktemp.size()][8];
        for (int j = 0; j < slrktemp.size(); j++) {
            tableModel[j][0] = slrktemp.get(j).getId();
            tableModel[j][1] = slrktemp.get(j).getRksj();
            tableModel[j][2] = pigslIdtoNameSmap.get(slrktemp.get(j).getTypeid());
            tableModel[j][3] = slrktemp.get(j).getSl();
            tableModel[j][4] = slrktemp.get(j).getSldw();
            tableModel[j][5] = slrktemp.get(j).getGmje();
            tableModel[j][6] = employeeIdtoNameSmap.get(slrktemp.get(j).getEmployeeid());
            tableModel[j][7] = slrktemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "入库时间", "饲料名称", "数    量", "数量单位", "购买金额", "负 责 人", "备   注"};
        String title1 = "饲料入库登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Slckpage(int pagenum) {
        List<Slck> slcktemp;

        slckPageModel.setPageNo(pagenum);
        slcktemp = slckPageModel.getNoList();

        if (slcktemp == null) {
            return;
        }

        Object[][] tableModel = new Object[slcktemp.size()][8];
        for (int j = 0; j < slcktemp.size(); j++) {
            tableModel[j][0] = slcktemp.get(j).getId();
            tableModel[j][1] = slcktemp.get(j).getCksj();
            tableModel[j][2] = piggeryIdtoNameSmap.get(slcktemp.get(j).getNumber());
            tableModel[j][3] = pigslIdtoNameSmap.get(slcktemp.get(j).getTypeid());
            tableModel[j][4] = slcktemp.get(j).getSl();
            tableModel[j][5] = slcktemp.get(j).getSldw();
            tableModel[j][6] = employeeIdtoNameSmap.get(slcktemp.get(j).getEmployeeid());
            tableModel[j][7] = slcktemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "出库时间", "使用猪舍", "饲料名称", "数   量", "数量单位", "负 责 人", "备   注"};
        String title1 = "饲料出库登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Yprkpage(int pagenum) {
        List<Yprk> yprktemp;

        yprkPageModel.setPageNo(pagenum);
        yprktemp = yprkPageModel.getNoList();

        if (yprktemp == null) {
            return;
        }

        Object[][] tableModel = new Object[yprktemp.size()][8];
        for (int j = 0; j < yprktemp.size(); j++) {
            tableModel[j][0] = yprktemp.get(j).getId();
            tableModel[j][1] = yprktemp.get(j).getRksj();
            tableModel[j][2] = pigypIdtoNameSmap.get(yprktemp.get(j).getTypeid());
            tableModel[j][3] = yprktemp.get(j).getSl();
            tableModel[j][4] = yprktemp.get(j).getSldw();
            tableModel[j][5] = yprktemp.get(j).getGmje();
            tableModel[j][6] = employeeIdtoNameSmap.get(yprktemp.get(j).getEmployeeid());
            tableModel[j][7] = yprktemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "入库时间", "药品简码", "数    量", "数量单位", "购买金额", "负 责 人", "备   注"};
        String title1 = "药品入库登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Ypckpage(int pagenum) {
        List<Ypck> ypcktemp;

        ypckPageModel.setPageNo(pagenum);
        ypcktemp = ypckPageModel.getNoList();

        if (ypcktemp == null) {
            return;
        }

        Object[][] tableModel = new Object[ypcktemp.size()][8];
        for (int j = 0; j < ypcktemp.size(); j++) {
            tableModel[j][0] = ypcktemp.get(j).getId();
            tableModel[j][1] = ypcktemp.get(j).getCksj();
            tableModel[j][2] = piggeryIdtoNameSmap.get(ypcktemp.get(j).getNumber());
            tableModel[j][3] = pigypIdtoNameSmap.get(ypcktemp.get(j).getTypeid());
            tableModel[j][4] = ypcktemp.get(j).getSl();
            tableModel[j][5] = ypcktemp.get(j).getSldw();
            tableModel[j][6] = employeeIdtoNameSmap.get(ypcktemp.get(j).getEmployeeid());
            tableModel[j][7] = ypcktemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "出库时间", "使用猪舍", "药品简码", "数   量", "数量单位", "负 责 人", "备   注"};
        String title1 = "药品出库登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Ymrkpage(int pagenum) {
        List<Ymrk> ymrktemp;

        ymrkPageModel.setPageNo(pagenum);
        ymrktemp = ymrkPageModel.getNoList();

        if (ymrktemp == null) {
            return;
        }

        Object[][] tableModel = new Object[ymrktemp.size()][8];
        for (int j = 0; j < ymrktemp.size(); j++) {
            tableModel[j][0] = ymrktemp.get(j).getId();
            tableModel[j][1] = ymrktemp.get(j).getRksj();
            tableModel[j][2] = vaccineIdtoNameSmap.get(ymrktemp.get(j).getTypeid());
            tableModel[j][3] = ymrktemp.get(j).getSl();
            tableModel[j][4] = ymrktemp.get(j).getSldw();
            tableModel[j][5] = ymrktemp.get(j).getGmje();
            tableModel[j][6] = employeeIdtoNameSmap.get(ymrktemp.get(j).getEmployeeid());
            tableModel[j][7] = ymrktemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "入库时间", "疫苗简码", "数    量", "数量单位", "购买金额", "负 责 人", "备   注"};
        String title1 = "疫苗入库登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Ymckpage(int pagenum) {
        List<Ymck> ymcktemp;

        ymckPageModel.setPageNo(pagenum);
        ymcktemp = ymckPageModel.getNoList();

        if (ymcktemp == null) {
            return;
        }

        Object[][] tableModel = new Object[ymcktemp.size()][8];
        for (int j = 0; j < ymcktemp.size(); j++) {
            tableModel[j][0] = ymcktemp.get(j).getId();
            tableModel[j][1] = ymcktemp.get(j).getCksj();
            tableModel[j][2] = piggeryIdtoNameSmap.get(ymcktemp.get(j).getNumber());
            tableModel[j][3] = vaccineIdtoNameSmap.get(ymcktemp.get(j).getTypeid());
            tableModel[j][4] = ymcktemp.get(j).getSl();
            tableModel[j][5] = ymcktemp.get(j).getSldw();
            tableModel[j][6] = employeeIdtoNameSmap.get(ymcktemp.get(j).getEmployeeid());
            tableModel[j][7] = ymcktemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "出库时间", "使用猪舍", "疫苗简码", "数   量", "数量单位", "负 责 人", "备   注"};
        String title1 = "疫苗出库登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Zzmypage(int pagenum) {
        List<Zzmy> zzmytemp;

        zzmyPageModel.setPageNo(pagenum);
        zzmytemp = zzmyPageModel.getNoList();
        if (zzmytemp == null) {
            return;
        }

        Object[][] tableModel = new Object[zzmytemp.size()][9];
        for (int j = 0; j < zzmytemp.size(); j++) {
            tableModel[j][0] = zzmytemp.get(j).getId();
            tableModel[j][1] = zzmytemp.get(j).getR_animal();
            tableModel[j][2] = swintypeIdtoNameSmap.get(zzmytemp.get(j).getZtid());
            tableModel[j][3] = zzmytemp.get(j).getZsrq();
            tableModel[j][4] = pigypIdtoNameSmap.get(zzmytemp.get(j).getYmid());
            tableModel[j][5] = employeeIdtoNameSmap.get(zzmytemp.get(j).getEmployeeid());
            tableModel[j][6] = fenceIdtoNameSmap.get(zzmytemp.get(j).getFenceid());
            tableModel[j][7] = zzmytemp.get(j).getZssm();
            tableModel[j][8] = zzmytemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "猪只状态", "注射日期", "疫苗名称", "负 责 人", "所在栏舍", "备   注"};
        String title1 = "猪只免疫登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Jbzlpage(int pagenum) {
        List<Jbzl> jbzltemp;

        jbzlPageModel.setPageNo(pagenum);
        jbzltemp = jbzlPageModel.getNoList();

        if (jbzltemp == null) {
            return;
        }

        Object[][] tableModel = new Object[jbzltemp.size()][8];
        for (int j = 0; j < jbzltemp.size(); j++) {
            tableModel[j][0] = jbzltemp.get(j).getId();
            tableModel[j][1] = jbzltemp.get(j).getR_animal();
            tableModel[j][2] = swintypeIdtoNameSmap.get(jbzltemp.get(j).getZtid());
            tableModel[j][3] = pigjbIdtoNameSmap.get(jbzltemp.get(j).getJbid());
            tableModel[j][4] = pigypIdtoNameSmap.get(jbzltemp.get(j).getYpid());
            tableModel[j][5] = jbzltemp.get(j).getZlrq();
            tableModel[j][6] = employeeIdtoNameSmap.get(jbzltemp.get(j).getEmployeeid());
            tableModel[j][7] = jbzltemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "猪只状态", "疾病名称", "药品名称", "治疗日期", "负 责 人", "备注"};
        String title1 = "疾病治疗登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Jyjcpage(int pagenum) {
        List<Jyjc> jyjctemp;

        jyjcPageModel.setPageNo(pagenum);
        jyjctemp = jyjcPageModel.getNoList();

        if (jyjctemp == null) {
            return;
        }

        Object[][] tableModel = new Object[jyjctemp.size()][8];
        for (int j = 0; j < jyjctemp.size(); j++) {
            tableModel[j][0] = jyjctemp.get(j).getId();
            tableModel[j][1] = jyjctemp.get(j).getR_animal();
            tableModel[j][2] = fenceIdtoNameSmap.get(jyjctemp.get(j).getFenceid());
            tableModel[j][3] = jyjctemp.get(j).getJcrq();
            tableModel[j][4] = jyjctemp.get(j).getJyname();
            tableModel[j][5] = jyjctemp.get(j).getJcresult();
            tableModel[j][6] = employeeIdtoNameSmap.get(jyjctemp.get(j).getEmployeeid());
            tableModel[j][7] = jyjctemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "所在烂位", "检测日期", "基因名称", "检测结果", "负 责 人", "备   注"};
        String title1 = "基因检测登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Tzxncdpage(int pagenum) {
        List<Tzxncd> tzxncdtemp;

        tzxncdPageModel.setPageNo(pagenum);
        tzxncdtemp = tzxncdPageModel.getNoList();

        if (tzxncdtemp == null) {
            return;
        }

        Object[][] tableModel = new Object[tzxncdtemp.size()][6];
        for (int j = 0; j < tzxncdtemp.size(); j++) {
            tableModel[j][0] = tzxncdtemp.get(j).getR_animal();
            tableModel[j][1] = fenceIdtoNameSmap.get(tzxncdtemp.get(j).getFenceid());
            tableModel[j][2] = tzxncdtemp.get(j).getCdrq();
            tableModel[j][3] = tzxncdtemp.get(j).getZqhz();
            tableModel[j][4] = employeeIdtoNameSmap.get(tzxncdtemp.get(j).getEmployeeid());
            tableModel[j][5] = tzxncdtemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"个体编号", "所在烂位", "测定日期", "宰前活重", "负 责 人", "备   注"};
        String title1 = "屠宰性能测定登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Zzxspage(int pagenum) {
        List<Zzxs> zzxstemp;

        zzxsPageModel.setPageNo(pagenum);
        zzxstemp = zzxsPageModel.getNoList();
        if (zzxstemp == null) {
            return;
        }

        Object[][] tableModel = new Object[zzxstemp.size()][7];
        for (int j = 0; j < zzxstemp.size(); j++) {
            tableModel[j][0] = zzxstemp.get(j).getId();
            tableModel[j][1] = zzxstemp.get(j).getXsrq();
            tableModel[j][2] = zzxstemp.get(j).getXsgs();
            tableModel[j][3] = zzxstemp.get(j).getZzzl();
            tableModel[j][4] = zzxstemp.get(j).getXsje();
            tableModel[j][5] = employeeIdtoNameSmap.get(zzxstemp.get(j).getEmployeeid());
            tableModel[j][6] = zzxstemp.get(j).getBz2();
        }

        String[] tableHead = new String[]{"流水编号", "销售日期", "销售个数", "猪只重量", "销售金额", "负 责 人", "备   注"};
        String title1 = "猪只销售登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static void Zzswpage(int pagenum) {
        List<Zzsw> zzswtemp;

        zzswPageModel.setPageNo(pagenum);
        zzswtemp = zzswPageModel.getNoList();

        if (zzswtemp == null) {
            return;
        }

        Object[][] tableModel = new Object[zzswtemp.size()][6];
        for (int j = 0; j < zzswtemp.size(); j++) {
            tableModel[j][0] = zzswtemp.get(j).getR_animal();
            tableModel[j][1] = zzswtemp.get(j).getSwrq();
            tableModel[j][2] = fenceIdtoNameSmap.get(zzswtemp.get(j).getFenceid());
            tableModel[j][3] = zzswtemp.get(j).getSwyy();
            tableModel[j][4] = employeeIdtoNameSmap.get(zzswtemp.get(j).getEmployeeid());
            tableModel[j][5] = zzswtemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"个体编号", "死亡时间", "所在栏位", "死亡原因", "负 责 人", "备   注"};
        String title1 = "猪只死亡登记";
        closeListplus(tableModel, tableHead, title1);

    }

    public static JTable SelebithList2(ArrayList<Selebith> selebithtemp) {
        Object[][] tableModel = null;
        boolean gm = true;//gong - ture;
        for (int j = 0; j < selebithtemp.size(); j++) {
            if (selebithtemp.get(j).getR_sex().equals("0") || selebithtemp.get(j).getR_sex().equals("公")) {
                if (j == 0) {
                    tableModel = new Object[selebithtemp.size()][9];
                }
                gm = true;
                selebithtemp.get(j).setR_sex("公");
                tableModel[j][7] = selebithtemp.get(j).getGzcjcs();//"采精次数",*
                tableModel[j][8] = selebithtemp.get(j).getTtsj();//"采精次数",*
            } else {
                if (j == 0) {
                    tableModel = new Object[selebithtemp.size()][8];
                }
                gm = false;
                selebithtemp.get(j).setR_sex("母");
                tableModel[j][7] = selebithtemp.get(j).getR_fno();//"采精次数",*
            }
            tableModel[j][0] = selebithtemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = selebithtemp.get(j).getR_farmid();//"综合育种"
            tableModel[j][2] = selebithtemp.get(j).getR_fdate();//"出生日期"
            tableModel[j][3] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());//"当前状态"
            tableModel[j][4] = piggeryIdtoNameSmap.get(selebithtemp.get(j).getR_cage());//"所在猪舍"
            tableModel[j][5] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());//"所在猪舍"
            tableModel[j][6] = selebithtemp.get(j).getR_sex();//"性  别"
        }

        String[] tableHead1 = new String[]{"个体编号", "综合育种", "出生日期", "当前状态", "所在猪舍", "所在栏位", "性  别", "采精次数", "最近采精日期"};
        String[] tableHead2 = new String[]{"个体编号", "综合育种", "出生日期", "当前状态", "所在猪舍", "所在栏位", "性  别", "当前胎次"};
        JTable jtable = new JTable();
        if (gm == true) {
            jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead1));
        } else {
            jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead2));
        }

        return jtable;
    }

    //导出全部数据
    public static JTable SelebithList(ArrayList<Selebith> selebithtemp) {
        Object[][] tableModel = new Object[selebithtemp.size()][10];
        for (int j = 0; j < selebithtemp.size(); j++) {
            selebithtemp.get(j).setR_sex(selebithtemp.get(j).getR_sex().equals("0") ? "公" : "母");

            tableModel[j][0] = selebithtemp.get(j).getR_animal();//"个体编号"
            tableModel[j][1] = lineidIdtoNameSmap.get(selebithtemp.get(j).getR_lineid());//"品   种"
            tableModel[j][2] = lineherdIdtoNameSmap.get(selebithtemp.get(j).getR_herd());//"品   系"
            tableModel[j][3] = selebithtemp.get(j).getR_fdate();//"出生日期"
            tableModel[j][4] = selebithtemp.get(j).getR_ear_no();//"耳 缺 号"
            tableModel[j][5] = selebithtemp.get(j).getR_sex();//"性   别"
            tableModel[j][6] = swintypeIdtoNameSmap.get(selebithtemp.get(j).getR_curmark());//"当前状态",*
            tableModel[j][7] = fenceIdtoNameSmap.get(selebithtemp.get(j).getR_pcage());//"所在栏舍",*
            tableModel[j][8] = selebithtemp.get(j).getR_sire();//"父   亲"
            tableModel[j][9] = selebithtemp.get(j).getR_dam();//"母   亲"
        }

        String[] tableHead = new String[]{"个体编号", "品   种", "品   系", "出生日期", "耳 缺 号", "性   别", "当前状态", "所在栏舍", "父   亲", "母   亲"};
        String title1 = "个体基本信息";
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable MaleBoarList(ArrayList<Selebith> list) {
        Object[][] tableModel = new Object[list.size()][5];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = list.get(j).getR_fdate();
            tableModel[j][2] = list.get(j).getR_sire();
            tableModel[j][3] = list.get(j).getR_dam();
            tableModel[j][4] = list.get(j).getGzcjcs();
        }

        String[] tableHead = new String[]{"个体编号", "出生日期", "父亲编号", "母亲编号 ", "采精次数"};
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable FemaleBoarList(ArrayList<Selebith> list) {
        Object[][] tableModel = new Object[list.size()][5];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = list.get(j).getR_fdate();
            tableModel[j][2] = list.get(j).getR_sire();
            tableModel[j][3] = list.get(j).getR_dam();
            tableModel[j][4] = list.get(j).getR_fno();
        }

        String[] tableHead = new String[]{"个体编号", "出生日期", "父亲编号", "母亲编号", "胎   次"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable TakespermList(ArrayList<Takesperm> takespermtemp) {
        List<String> TakespermCage = new ArrayList<>();
        List<String> TakespermPcage = new ArrayList<>();
//备注：
        Selebith selebith;
        for (int i = 0; i < takespermtemp.size(); i++) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                SelebithMapper mapper = sqlSession.getMapper(SelebithMapper.class
                );
                selebith = mapper.selectByTypeid(takespermtemp.get(i).getR_animal());
            }
            TakespermCage.add(piggeryIdtoNameSmap.get(selebith.getR_cage()));
            TakespermPcage.add(fenceIdtoNameSmap.get(selebith.getR_pcage()));
            takespermtemp.get(i).setEmployeeid(employeeIdtoNameSmap.get(takespermtemp.get(i).getEmployeeid()));

        }

        Object[][] tableModel = new Object[takespermtemp.size()][6];
        for (int j = 0; j < takespermtemp.size(); j++) {
            tableModel[j][0] = takespermtemp.get(j).getId();
            tableModel[j][1] = takespermtemp.get(j).getR_animal();
            tableModel[j][2] = takespermtemp.get(j).getCjrq();
            tableModel[j][3] = TakespermCage.get(j);
            tableModel[j][4] = TakespermPcage.get(j);
            tableModel[j][5] = takespermtemp.get(j).getEmployeeid();
        }

        String[] tableHead = new String[]{"采精编号", "个体编号", "采精日期", "所在猪舍", "所在栏位 ", "负 责 人"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable BreedingList(ArrayList<Breeding> breedingtemp) {

        for (int i = 0; i < breedingtemp.size(); i++) {
            if (breedingtemp.get(i).getPzzt().equals("1")) {
                breedingtemp.get(i).setPzzt("检验");
            }
            if (breedingtemp.get(i).getPzzt().equals("2")) {
                breedingtemp.get(i).setPzzt("妊娠");
            }
            if (breedingtemp.get(i).getPzzt().equals("3")) {
                breedingtemp.get(i).setPzzt("返情");
            }
        }

        Object[][] tableModel = new Object[breedingtemp.size()][6];
        for (int j = 0; j < breedingtemp.size(); j++) {
            tableModel[j][0] = breedingtemp.get(j).getId();
            tableModel[j][1] = breedingtemp.get(j).getR_animal();
            tableModel[j][2] = breedingtemp.get(j).getPzrq();
            tableModel[j][3] = employeeIdtoNameSmap.get(breedingtemp.get(j).getEmployeeid());
            tableModel[j][4] = breedingtemp.get(j).getPzzt();
            tableModel[j][5] = fenceIdtoNameSmap.get(breedingtemp.get(j).getFenceid());
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "配种日期", "负 责 人", "配种状态 ", "所在栏舍  "};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable ChildbirthList(ArrayList<Childbirth> list) {
        Object[][] tableModel = new Object[list.size()][7];
        for (int j = 0; j < list.size(); j++) {
            switch (list.get(j).getZt()) {
                case "1":
                    list.get(j).setZt("分娩状态");
                    break;
                case "2":
                    list.get(j).setZt("断奶状态");
                    break;
                case "3":
                    list.get(j).setZt("未知状态");
                    break;
            }

            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getR_animal();
            tableModel[j][2] = list.get(j).getCzrq();
            tableModel[j][3] = list.get(j).getZt();
            tableModel[j][4] = employeeIdtoNameSmap.get(list.get(j).getFwemployeeid());
            tableModel[j][5] = fenceIdtoNameSmap.get(list.get(j).getFenceid());
            tableModel[j][6] = fenceIdtoNameSmap.get(list.get(j).getFwfenceid());
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "分娩日期", "当前状态", "负 责 人", "妊娠栏舍", "分娩栏舍"};
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable WeaningList(ArrayList<Childbirth> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getR_animal();
            tableModel[j][2] = list.get(j).getTc();
            tableModel[j][3] = list.get(j).getDnrq();
            tableModel[j][4] = list.get(j).getDnts();
            tableModel[j][5] = list.get(j).getDnwz();
            tableModel[j][6] = fenceIdtoNameSmap.get(list.get(j).getOutfenceid());
            tableModel[j][7] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "当前胎次", "断奶日期", "断奶头数 ", "断奶窝重", "断奶后栏舍", "负 责 人"};
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable FeedingTurnConservationList(ArrayList<Selebith> list) {
        Object[][] tableModel = new Object[list.size()][6];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = swintypeIdtoNameSmap.get(list.get(j).getR_curmark());
            tableModel[j][2] = list.get(j).getR_weandate();
            tableModel[j][3] = fenceIdtoNameSmap.get(list.get(j).getZbffenceid());
            tableModel[j][4] = fenceIdtoNameSmap.get(list.get(j).getZbafenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(list.get(j).getZbfzr());
        }

        String[] tableHead = new String[]{"个体编号", "当前状态", "哺乳转保育时间 ", "转前栏舍", "转后栏舍", "负 责 人"};
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable ConservationTurnFattingList(ArrayList<Selebith> list) {
        Object[][] tableModel = new Object[list.size()][6];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = swintypeIdtoNameSmap.get(list.get(j).getR_curmark());
            tableModel[j][2] = list.get(j).getBysj();
            tableModel[j][3] = fenceIdtoNameSmap.get(list.get(j).getByffenceid());
            tableModel[j][4] = fenceIdtoNameSmap.get(list.get(j).getByafenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(list.get(j).getByfzr());
        }

        String[] tableHead = new String[]{"个体编号", "当前状态", "保育转育肥时间 ", "转前栏舍", "转后栏舍", "负 责 人"};
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable ConservationTurnBackList(ArrayList<Selebith> list) {
        Object[][] tableModel = new Object[list.size()][6];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = swintypeIdtoNameSmap.get(list.get(j).getR_curmark());
            tableModel[j][2] = list.get(j).getR_predate();
            tableModel[j][3] = fenceIdtoNameSmap.get(list.get(j).getBhffenceid());
            tableModel[j][4] = fenceIdtoNameSmap.get(list.get(j).getBhafenceid());
            tableModel[j][5] = employeeIdtoNameSmap.get(String.valueOf(list.get(j).getWhodo()));
        }

        String[] tableHead = new String[]{"个体编号", "当前状态", "保育转后备时间 ", "转前栏舍", "转后栏舍", "负 责 人"};
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable TwoTestList(ArrayList<TwoTest> list) {
        Object[][] tableModel = new Object[list.size()][30];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = list.get(j).getCdrq();
            tableModel[j][2] = list.get(j).getZsex().equals("1") ? "母" : "公";
            tableModel[j][3] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][4] = list.get(j).getWeight();
            tableModel[j][5] = fenceIdtoNameSmap.get(list.get(j).getFenceid());
            tableModel[j][6] = swintypeIdtoNameSmap.get(list.get(j).getCdzt());
            tableModel[j][7] = list.get(j).getOutfenceid() != null ? piggeryIdtoNameSmap.get(list.get(j).getOutfenceid().substring(0, 5)) : "";
            tableModel[j][8] = list.get(j).getOutfenceid() != null ? fenceIdtoNameSmap.get(list.get(j).getOutfenceid()) : "";
            tableModel[j][9] = list.get(j).getFxrts();
            tableModel[j][10] = list.get(j).getFxqxrt();
            tableModel[j][11] = list.get(j).getFxzhpf();
            tableModel[j][12] = list.get(j).getYwss();
            tableModel[j][13] = list.get(j).getSfgx();
            tableModel[j][14] = list.get(j).getYgzhpf();
            tableModel[j][15] = list.get(j).getZtzsfgx();
            tableModel[j][16] = list.get(j).getZtfgjsfhl();
            tableModel[j][17] = list.get(j).getZtszywssyz();
            tableModel[j][18] = list.get(j).getZtzhpf();
            tableModel[j][19] = list.get(j).getTxqhqgc();
            tableModel[j][20] = list.get(j).getTxhtcqs();
            tableModel[j][21] = list.get(j).getTxlgxz();
            tableModel[j][22] = list.get(j).getTxzhpf();
            tableModel[j][23] = list.get(j).getQjyl();
            tableModel[j][24] = list.get(j).getJpz();
            tableModel[j][25] = list.get(j).getQtyd();
            tableModel[j][26] = list.get(j).getBltt().equals("K") ? "保留(K)" : "死亡(C)";
            tableModel[j][27] = list.get(j).getBlbfb();
            tableModel[j][28] = list.get(j).getBz();
            tableModel[j][29] = list.get(j).getJg();

        }

        String[] tableHead = new String[]{
            "个体编号", "测定日期", "性    别", "负 责 人", "体   重", "所在舍栏", "登记状态", "所去猪舍", "所去栏位", "腹线乳头数", "腹线有无缺陷乳头", "综合评分", "有无损伤", "是否过小", "综合评分", "趾是否过小", "跗关节是否合理", "四肢有无损伤", "综合评分", "前和后躯宽广", "后臀长且深", "肋骨形状", "综合评分", "强健有力", "寄生虫皮肤和整体状态", "其它要点", "保留或死亡", "保留百分比", "备    注", "销售价格"
        };

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable FourTestList(ArrayList<FourTest> list) {
        Object[][] tableModel = new Object[list.size()][30];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = list.get(j).getCdrq();
            tableModel[j][2] = list.get(j).getZsex().equals("1") ? "母" : "公";
            tableModel[j][3] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][4] = list.get(j).getWeight();
            tableModel[j][5] = fenceIdtoNameSmap.get(list.get(j).getFenceid());
            tableModel[j][6] = swintypeIdtoNameSmap.get(String.valueOf(list.get(j).getCdzt()));
            tableModel[j][7] = list.get(j).getOutfenceid() != null ? piggeryIdtoNameSmap.get(list.get(j).getOutfenceid().substring(0, 5)) : "";
            tableModel[j][8] = list.get(j).getOutfenceid() != null ? fenceIdtoNameSmap.get(list.get(j).getOutfenceid()) : "";
            tableModel[j][9] = list.get(j).getFxrts();
            tableModel[j][10] = list.get(j).getFxqxrt();
            tableModel[j][11] = list.get(j).getFxzhpf();
            tableModel[j][12] = list.get(j).getYwss();
            tableModel[j][13] = list.get(j).getSfgx();
            tableModel[j][14] = list.get(j).getYgzhpf();
            tableModel[j][15] = list.get(j).getZtzsfgx();
            tableModel[j][16] = list.get(j).getZtfgjsfhl();
            tableModel[j][17] = list.get(j).getZtszywssyz();
            tableModel[j][18] = list.get(j).getZtzhpf();
            tableModel[j][19] = list.get(j).getTxqhqgc();
            tableModel[j][20] = list.get(j).getTxhtcqs();
            tableModel[j][21] = list.get(j).getTxlgxz();
            tableModel[j][22] = list.get(j).getTxzhpf();
            tableModel[j][23] = list.get(j).getQjyl();
            tableModel[j][24] = list.get(j).getJpz();
            tableModel[j][25] = list.get(j).getQtyd();
            tableModel[j][26] = list.get(j).getBltt().equals("K") ? "保留(K)" : "死亡(C)";
            tableModel[j][27] = list.get(j).getBlbfb();
            tableModel[j][28] = list.get(j).getBz();
            tableModel[j][29] = list.get(j).getJg();

        }

        String[] tableHead = new String[]{
            "个体编号", "测定日期", "性    别", "负 责 人", "体   重", "所在舍栏", "登记状态", "所去猪舍", "所去栏位", "腹线乳头数", "腹线有无缺陷乳头", "综合评分", "有无损伤", "是否过小", "综合评分", "趾是否过小", "跗关节是否合理", "四肢有无损伤", "综合评分", "前和后躯宽广", "后臀长且深", "肋骨形状", "综合评分", "强健有力", "寄生虫皮肤和整体状态", "其它要点", "保留或死亡", "保留百分比", "备    注", "销售价格"
        };
        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable SixTestList(ArrayList<SixTest> list) {
        Object[][] tableModel = new Object[list.size()][30];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = list.get(j).getCdrq();
            tableModel[j][2] = list.get(j).getZsex().equals("1") ? "母" : "公";
            tableModel[j][3] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][4] = list.get(j).getWeight();
            tableModel[j][5] = fenceIdtoNameSmap.get(list.get(j).getFenceid());
            tableModel[j][6] = swintypeIdtoNameSmap.get(String.valueOf(list.get(j).getCdzt()));
            tableModel[j][7] = list.get(j).getOutfenceid() != null ? piggeryIdtoNameSmap.get(list.get(j).getOutfenceid().substring(0, 5)) : "";
            tableModel[j][8] = list.get(j).getOutfenceid() != null ? fenceIdtoNameSmap.get(list.get(j).getOutfenceid()) : "";
            tableModel[j][9] = list.get(j).getFxrts();
            tableModel[j][10] = list.get(j).getFxqxrt();
            tableModel[j][11] = list.get(j).getFxzhpf();
            tableModel[j][12] = list.get(j).getYwss();
            tableModel[j][13] = list.get(j).getSfgx();
            tableModel[j][14] = list.get(j).getYgzhpf();
            tableModel[j][15] = list.get(j).getZtzsfgx();
            tableModel[j][16] = list.get(j).getZtfgjsfhl();
            tableModel[j][17] = list.get(j).getZtszywssyz();
            tableModel[j][18] = list.get(j).getZtzhpf();
            tableModel[j][19] = list.get(j).getTxqhqgc();
            tableModel[j][20] = list.get(j).getTxhtcqs();
            tableModel[j][21] = list.get(j).getTxlgxz();
            tableModel[j][22] = list.get(j).getTxzhpf();
            tableModel[j][23] = list.get(j).getQjyl();
            tableModel[j][24] = list.get(j).getJpz();
            tableModel[j][25] = list.get(j).getQtyd();
            tableModel[j][26] = list.get(j).getBltt().equals("K") ? "保留(K)" : "死亡(C)";
            tableModel[j][27] = list.get(j).getBlbfb();
            tableModel[j][28] = list.get(j).getBz();
            tableModel[j][29] = list.get(j).getJg();

        }

        String[] tableHead = new String[]{
            "个体编号", "测定日期", "性    别", "负 责 人", "体   重", "所在舍栏", "登记状态", "所去猪舍", "所去栏位", "腹线乳头数", "腹线有无缺陷乳头", "综合评分", "有无损伤", "是否过小", "综合评分", "趾是否过小", "跗关节是否合理", "四肢有无损伤", "综合评分", "前和后躯宽广", "后臀长且深", "肋骨形状", "综合评分", "强健有力", "寄生虫皮肤和整体状态", "其它要点", "保留或死亡", "保留百分比", "备    注", "销售价格"
        };

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable HundredTestList(ArrayList<HundredTest> list) {
        Object[][] tableModel = new Object[list.size()][23];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = list.get(j).getCdrq();
            tableModel[j][2] = list.get(j).getZsex().equals("1") ? "母" : "公";
            tableModel[j][3] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][4] = list.get(j).getWeight();
            tableModel[j][5] = fenceIdtoNameSmap.get(list.get(j).getFenceid());
            tableModel[j][6] = swintypeIdtoNameSmap.get(String.valueOf(list.get(j).getCdzt()));
            tableModel[j][7] = list.get(j).getOutfenceid() != null ? piggeryIdtoNameSmap.get(list.get(j).getOutfenceid().substring(0, 5)) : "";
            tableModel[j][8] = list.get(j).getOutfenceid() != null ? fenceIdtoNameSmap.get(list.get(j).getOutfenceid()) : "";
            tableModel[j][9] = list.get(j).getRl();
            tableModel[j][10] = list.get(j).getTc();
            tableModel[j][11] = list.get(j).getTg();
            tableModel[j][12] = list.get(j).getBg();
            tableModel[j][13] = list.get(j).getXw();
            tableModel[j][14] = list.get(j).getXs();
            tableModel[j][15] = list.get(j).getFw();
            tableModel[j][16] = list.get(j).getGw();
            tableModel[j][17] = list.get(j).getTtw();
            tableModel[j][18] = list.get(j).getHtbbh();
            tableModel[j][19] = list.get(j).getHtyjmj();
            tableModel[j][20] = list.get(j).getCddd();
            tableModel[j][21] = list.get(j).getBz();
            tableModel[j][22] = list.get(j).getJg();

        }

        String[] tableHead = new String[]{
            "个体编号", "测定日期", "性    别", "负 责 人", "体   重", "所在舍栏", "测定状态", "所去猪舍", "所去栏位", "日    龄", "体    长", "体    高", "背    高", "胸    围", "胸    深", "腹    围", "管    围", "退 臀 围", "活体背膘后", "活体眼机面积", "测定地点", "备    注", "销售价格"
        };

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable ZzmyList(ArrayList<Zzmy> zzmytemp) {

        Object[][] tableModel = new Object[zzmytemp.size()][9];
        for (int j = 0; j < zzmytemp.size(); j++) {
            tableModel[j][0] = zzmytemp.get(j).getId();
            tableModel[j][1] = zzmytemp.get(j).getR_animal();
            tableModel[j][2] = swintypeIdtoNameSmap.get(zzmytemp.get(j).getZtid());
            tableModel[j][3] = zzmytemp.get(j).getZsrq();
            tableModel[j][4] = pigypIdtoNameSmap.get(zzmytemp.get(j).getYmid());
            tableModel[j][5] = employeeIdtoNameSmap.get(zzmytemp.get(j).getEmployeeid());
            tableModel[j][6] = fenceIdtoNameSmap.get(zzmytemp.get(j).getFenceid());
            tableModel[j][7] = zzmytemp.get(j).getZssm();
            tableModel[j][8] = zzmytemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "猪只状态", "注射日期", "疫苗名称", "负 责 人", "所在栏舍", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable SlckList(ArrayList<Slck> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getCksj();
            tableModel[j][2] = piggeryIdtoNameSmap.get(list.get(j).getNumber());
            tableModel[j][3] = pigslIdtoNameSmap.get(list.get(j).getTypeid());
            tableModel[j][4] = list.get(j).getSl();
            tableModel[j][5] = list.get(j).getSldw();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "出库时间", "使用猪舍", "饲料名称", "数   量", "数量单位", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable SlrkList(ArrayList<Slrk> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getRksj();
            tableModel[j][2] = pigypIdtoNameSmap.get(list.get(j).getTypeid());
            tableModel[j][3] = list.get(j).getSl();
            tableModel[j][4] = list.get(j).getSldw();
            tableModel[j][5] = list.get(j).getGmje();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "入库时间", "饲料名称", "数    量", "数量单位", "购买金额", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable YpckList(ArrayList<Ypck> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getCksj();
            tableModel[j][2] = piggeryIdtoNameSmap.get(list.get(j).getNumber());
            tableModel[j][3] = pigypIdtoNameSmap.get(list.get(j).getTypeid());
            tableModel[j][4] = list.get(j).getSl();
            tableModel[j][5] = list.get(j).getSldw();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "出库时间", "使用猪舍", "药品名称", "数   量", "数量单位", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable YprkList(ArrayList<Yprk> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getRksj();
            tableModel[j][2] = pigypIdtoNameSmap.get(list.get(j).getTypeid());
            tableModel[j][3] = list.get(j).getSl();
            tableModel[j][4] = list.get(j).getSldw();
            tableModel[j][5] = list.get(j).getGmje();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "入库时间", "药品名称", "数    量", "数量单位", "购买金额", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable YmckList(ArrayList<Ymck> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getCksj();
            tableModel[j][2] = piggeryIdtoNameSmap.get(list.get(j).getNumber());
            tableModel[j][3] = vaccineIdtoNameSmap.get(list.get(j).getTypeid());
            tableModel[j][4] = list.get(j).getSl();
            tableModel[j][5] = list.get(j).getSldw();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "出库时间", "使用猪舍", "疫苗名称", "数   量", "数量单位", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable YmrkList(ArrayList<Ymrk> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getRksj();
            tableModel[j][2] = vaccineIdtoNameSmap.get(list.get(j).getTypeid());
            tableModel[j][3] = list.get(j).getSl();
            tableModel[j][4] = list.get(j).getSldw();
            tableModel[j][5] = list.get(j).getGmje();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "入库时间", "疫苗名称", "数    量", "数量单位", "购买金额", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable JbzlList(ArrayList<Jbzl> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getR_animal();
            tableModel[j][2] = swintypeIdtoNameSmap.get(list.get(j).getZtid());
            tableModel[j][3] = pigjbIdtoNameSmap.get(list.get(j).getJbid());
            tableModel[j][4] = pigypIdtoNameSmap.get(list.get(j).getYpid());
            tableModel[j][5] = list.get(j).getZlrq();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "状态代码", "疾病名称", "药品名称", "治疗日期", "负 责 人", "备注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable JyjcList(ArrayList<Jyjc> list) {
        Object[][] tableModel = new Object[list.size()][8];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getId();
            tableModel[j][1] = list.get(j).getR_animal();
            tableModel[j][2] = fenceIdtoNameSmap.get(list.get(j).getFenceid());
            tableModel[j][3] = list.get(j).getJcrq();
            tableModel[j][4] = list.get(j).getJyname();
            tableModel[j][5] = list.get(j).getJcresult();
            tableModel[j][6] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][7] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "个体编号", "所在烂位", "检测日期", "基因名称", "检测结果", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable ZzswList(ArrayList<Zzsw> list) {
        Object[][] tableModel = new Object[list.size()][6];
        for (int j = 0; j < list.size(); j++) {
            tableModel[j][0] = list.get(j).getR_animal();
            tableModel[j][1] = list.get(j).getSwrq();
            tableModel[j][2] = fenceIdtoNameSmap.get(list.get(j).getFenceid());
            tableModel[j][3] = list.get(j).getSwyy();
            tableModel[j][4] = employeeIdtoNameSmap.get(list.get(j).getEmployeeid());
            tableModel[j][5] = list.get(j).getBz();
        }

        String[] tableHead = new String[]{"个体编号", "死亡时间", "所在栏位", "死亡原因", "负 责 人 ", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable ZzxsList(ArrayList<Zzxs> zzxstemp) {
        Object[][] tableModel = new Object[zzxstemp.size()][7];
        for (int j = 0; j < zzxstemp.size(); j++) {
            tableModel[j][0] = zzxstemp.get(j).getId();
            tableModel[j][1] = zzxstemp.get(j).getXsrq();
            tableModel[j][2] = zzxstemp.get(j).getXsgs();
            tableModel[j][3] = zzxstemp.get(j).getZzzl();
            tableModel[j][4] = zzxstemp.get(j).getXsje();
            tableModel[j][5] = employeeIdtoNameSmap.get(zzxstemp.get(j).getEmployeeid());
            tableModel[j][6] = zzxstemp.get(j).getBz2();
        }

        String[] tableHead = new String[]{"流水编号", "销售日期", "销售个数", "猪只重量", "销售金额", "负 责 人 ", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable TzxncdList(ArrayList<Tzxncd> tzxncdtemp) {

        Object[][] tableModel = new Object[tzxncdtemp.size()][6];
        for (int j = 0; j < tzxncdtemp.size(); j++) {
            tableModel[j][0] = tzxncdtemp.get(j).getR_animal();
            tableModel[j][1] = fenceIdtoNameSmap.get(tzxncdtemp.get(j).getFenceid());
            tableModel[j][2] = tzxncdtemp.get(j).getCdrq();
            tableModel[j][3] = tzxncdtemp.get(j).getZqhz();
            tableModel[j][4] = employeeIdtoNameSmap.get(tzxncdtemp.get(j).getEmployeeid());
            tableModel[j][5] = tzxncdtemp.get(j).getBz();
        }

        String[] tableHead = new String[]{"个体编号", "所在烂位", "测定日期", "宰前活重", "负 责 人", "备   注"};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable PrintList(ArrayList<Data> pzfmltemp) {
        ArrayList<String> StringList = new ArrayList<>();

        Object[][] tableModel = new Object[pzfmltemp.size()][9];
        for (int j = 0; j < pzfmltemp.size(); j++) {
            if (j == 9) {
                tableModel[j][0] = "序号";
            } else if (j < 9) {
                tableModel[j][0] = "";
            } else {
                tableModel[j][0] = "" + (j - 9);
            }

            tableModel[j][1] = pzfmltemp.get(j).getD1();
            tableModel[j][2] = pzfmltemp.get(j).getD2();
            tableModel[j][3] = pzfmltemp.get(j).getD3();
            tableModel[j][4] = pzfmltemp.get(j).getD4();
            tableModel[j][5] = pzfmltemp.get(j).getD5();
            tableModel[j][6] = pzfmltemp.get(j).getD6();
            tableModel[j][7] = pzfmltemp.get(j).getD7();
            tableModel[j][8] = pzfmltemp.get(j).getD8();

            if (j < 10) {
                StringList.add(tableModel[j][0] + " " + tableModel[j][1] + " " + tableModel[j][2]
                        + " " + tableModel[j][3] + " " + tableModel[j][4] + " " + tableModel[j][5]
                        + " " + tableModel[j][6] + " " + tableModel[j][7] + " " + tableModel[j][8]);
            } else {
                tableModel[j][4] = tableModel[j][4];
                StringList.add(tableModel[j][0] + "    " + tableModel[j][1] + " " + tableModel[j][2]
                        + "     " + tableModel[j][3] + "     " + tableModel[j][4] + "    " + tableModel[j][5]
                        + " " + tableModel[j][6] + " " + tableModel[j][7] + " " + tableModel[j][8]);
            }

        }
        printData.setPrintDataStringList(StringList);
        String[] tableHead = new String[]{"", "", "", "", "", "", "", "", ""};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable PrintList1(ArrayList<Data> pzfmltemp) {
        ArrayList<String> StringList = new ArrayList<>();

        Object[][] tableModel = new Object[pzfmltemp.size()][9];
        for (int j = 0; j < pzfmltemp.size(); j++) {
            if (j == 7) {
                tableModel[j][0] = "序号";
            } else if (j < 7) {
                tableModel[j][0] = "";
            } else {
                tableModel[j][0] = "" + (j - 7);
            }

            tableModel[j][1] = pzfmltemp.get(j).getD1();
            tableModel[j][2] = pzfmltemp.get(j).getD2();
            tableModel[j][3] = pzfmltemp.get(j).getD3();
            tableModel[j][4] = pzfmltemp.get(j).getD4();
            tableModel[j][5] = pzfmltemp.get(j).getD5();
            tableModel[j][6] = pzfmltemp.get(j).getD6();
            tableModel[j][7] = pzfmltemp.get(j).getD7();
            tableModel[j][8] = pzfmltemp.get(j).getD8();

            if (j < 10) {
                StringList.add(tableModel[j][0] + " " + tableModel[j][1] + " " + tableModel[j][2]
                        + " " + tableModel[j][3] + " " + tableModel[j][4] + " " + tableModel[j][5]
                        + " " + tableModel[j][6] + " " + tableModel[j][7] + " " + tableModel[j][8]);
            } else {
                tableModel[j][4] = tableModel[j][4];
                StringList.add(tableModel[j][0] + "    " + tableModel[j][1] + " " + tableModel[j][2]
                        + "     " + tableModel[j][3] + "     " + tableModel[j][4] + "    " + tableModel[j][5]
                        + " " + tableModel[j][6] + " " + tableModel[j][7] + " " + tableModel[j][8]);
            }

        }
        printData.setPrintDataStringList(StringList);
        String[] tableHead = new String[]{"", "", "", "", "", "", "", "", ""};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public static JTable PrintList2(ArrayList<Data> pzfmltemp) {
        ArrayList<String> StringList = new ArrayList<>();

        Object[][] tableModel = new Object[pzfmltemp.size()][9];
        for (int j = 0; j < pzfmltemp.size(); j++) {
            if (j == 6) {
                tableModel[j][0] = "序号";
            } else if (j < 6) {
                tableModel[j][0] = "";
            } else {
                tableModel[j][0] = "" + (j - 6);
            }

            tableModel[j][1] = pzfmltemp.get(j).getD1();
            tableModel[j][2] = pzfmltemp.get(j).getD2();
            tableModel[j][3] = pzfmltemp.get(j).getD3();
            tableModel[j][4] = pzfmltemp.get(j).getD4();
            tableModel[j][5] = pzfmltemp.get(j).getD5();
            tableModel[j][6] = pzfmltemp.get(j).getD6();
            tableModel[j][7] = pzfmltemp.get(j).getD7();
            tableModel[j][8] = pzfmltemp.get(j).getD8();

            if (j < 10) {
                StringList.add(tableModel[j][0] + " " + tableModel[j][1] + " " + tableModel[j][2]
                        + " " + tableModel[j][3] + " " + tableModel[j][4] + " " + tableModel[j][5]
                        + " " + tableModel[j][6] + " " + tableModel[j][7] + " " + tableModel[j][8]);
            } else {
                tableModel[j][4] = tableModel[j][4];
                StringList.add(tableModel[j][0] + "    " + tableModel[j][1] + " " + tableModel[j][2]
                        + "     " + tableModel[j][3] + "     " + tableModel[j][4] + "    " + tableModel[j][5]
                        + " " + tableModel[j][6] + " " + tableModel[j][7] + " " + tableModel[j][8]);
            }

        }
        printData.setPrintDataStringList(StringList);
        String[] tableHead = new String[]{"", "", "", "", "", "", "", "", ""};

        JTable jtable = new JTable();
        jtable.setModel(new javax.swing.table.DefaultTableModel(tableModel, tableHead));
        return jtable;
    }

    public void Showstart() {
        outsideLabel = "MABS";
        //上排按钮可用否--查询
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号
        jComboBox1.setEnabled(false);//猪只状态
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        jLabel5.setText(getNowEmployee().getUser_name());
    }

    public void Showzcsz() {
        outsideLabel = "猪场设置";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FarmNameMapper mapper = sqlSession.getMapper(FarmNameMapper.class);
            farmName = mapper.selectAll();
        }

        Object[][] tableModel = new Object[farmName.size()][7];
        for (int j = 0; j < farmName.size(); j++) {
            String name = farmName.get(j).getFarm_name();
            String farmid = farmName.get(j).getFarm_id();
            String farmadd = farmName.get(j).getFarm_add();
            String farmcode = farmName.get(j).getFarm_code();
            String farmfzr = farmName.get(j).getFarm_fzr();
            String bz = farmName.get(j).getBz();

            tableModel[j][0] = name;
            tableModel[j][1] = farmid;
            tableModel[j][2] = farmadd;
            tableModel[j][3] = farmcode;
            tableModel[j][4] = employeeIdtoNameSmap.get(farmfzr);
            tableModel[j][5] = bz;
        }

        String[] tableHead = new String[]{"猪场名称", "猪场简码", "猪场地址", "猪场电话", "负 责 人", "备    注"};
        String title1 = "猪场设置";
        closeList(tableModel, tableHead, title1);
    }

    public void Showpzzl() {
        outsideLabel = "品种资料";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            LinesMapper mapper = sqlSession.getMapper(LinesMapper.class);
            linesList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[linesList.size()][2];
        for (int j = 0; j < linesList.size(); j++) {
            String name = linesList.get(j).getLinename();
            String lineid = linesList.get(j).getLineid();

            tableModel[j][0] = name;
            tableModel[j][1] = lineid;
        }

        String[] tableHead = new String[]{"品种名称", "品种简码"};
        String title1 = "品种资料";
        closeList(tableModel, tableHead, title1);

    }

    public void Showsllb() {
        outsideLabel = "饲料类别";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SllbMapper mapper = sqlSession.getMapper(SllbMapper.class);
            sllbList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[sllbList.size()][2];
        for (int j = 0; j < sllbList.size(); j++) {
            tableModel[j][0] = sllbList.get(j).getTypeid();
            tableModel[j][1] = sllbList.get(j).getTypename();
        }

        String[] tableHead = new String[]{"流水编号", "类型名称"};
        String title1 = "饲料类别";
        closeList(tableModel, tableHead, title1);
    }

    public void Showslxx() {
        outsideLabel = "饲料信息";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PigslMapper mapper = sqlSession.getMapper(PigslMapper.class);
            pigslList = mapper.selectAll();
            SllbMapper mapper1 = sqlSession.getMapper(SllbMapper.class);
            sllbList = mapper1.selectAll();
        }
        Object[][] tableModel = new Object[pigslList.size()][3];
        for (int j = 0; j < pigslList.size(); j++) {
            for (int i = 0; i < sllbList.size(); i++) {
                if (sllbList.get(i).getTypeid().equals(pigslList.get(j).getSwintypeid())) {
                    pigslList.get(j).setSwintypeid(sllbList.get(i).getTypename());
                }
            }
            tableModel[j][0] = pigslList.get(j).getTypeid();
            tableModel[j][1] = pigslList.get(j).getTypename();
            tableModel[j][2] = pigslList.get(j).getSwintypeid();
        }

        String[] tableHead = new String[]{"饲料简码", "饲料名称", "适合猪只"};
        String title1 = "饲料信息";
        closeList(tableModel, tableHead, title1);
    }

    public void Showzslb() {
        outsideLabel = "猪舍类别";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZslbMapper mapper = sqlSession.getMapper(ZslbMapper.class);
            zslbList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[zslbList.size()][2];
        for (int j = 0; j < zslbList.size(); j++) {
            tableModel[j][0] = zslbList.get(j).getTypeid();
            tableModel[j][1] = zslbList.get(j).getTypename();
        }

        String[] tableHead = new String[]{"流水编号", "类型名称"};
        String title1 = "猪舍类别";
        closeList(tableModel, tableHead, title1);

    }

    public void Showcnjs() {
        outsideLabel = "场内圈舍";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PiggeryMapper mapper = sqlSession.getMapper(PiggeryMapper.class);
            piggeryList = mapper.selectAll();
            ZslbMapper mapper1 = sqlSession.getMapper(ZslbMapper.class);
            zslbList = mapper1.selectAll();
        }

        Object[][] tableModel = new Object[piggeryList.size()][6];
        for (int j = 0; j < piggeryList.size(); j++) {
            for (int i = 0; i < zslbList.size(); i++) {
                if (zslbList.get(i).getTypeid().equals(piggeryList.get(j).getZslb())) {
                    piggeryList.get(j).setZslb(zslbList.get(i).getTypename());
                }
            }
            tableModel[j][0] = piggeryList.get(j).getNumber();
            tableModel[j][1] = piggeryList.get(j).getCategory();
            tableModel[j][2] = employeeIdtoNameSmap.get(piggeryList.get(j).getFeeder());
            tableModel[j][3] = piggeryList.get(j).getStatue();
            tableModel[j][4] = piggeryList.get(j).getVariety();
            tableModel[j][5] = piggeryList.get(j).getZslb();
        }

        String[] tableHead = new String[]{"猪舍编号", "猪舍名称", "饲 养 员", "使用状态", "饲养品种", "猪舍类别"};
        String title1 = "场内圈舍";
        closeList(tableModel, tableHead, title1);

    }

    public void Showzzzt() {
        outsideLabel = "猪只状态";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否            
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SwintypeMapper mapper = sqlSession.getMapper(SwintypeMapper.class);
            swintypeList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[swintypeList.size()][3];
        for (int j = 0; j < swintypeList.size(); j++) {
            tableModel[j][0] = swintypeList.get(j).getTypeid();
            tableModel[j][1] = swintypeList.get(j).getTypename();
            tableModel[j][2] = swintypeList.get(j).getTotypeid();
        }

        String[] tableHead = new String[]{"状态编号", "状态名称", "状态去向"};
        String title1 = "猪只状态";
        closeList(tableModel, tableHead, title1);

    }

    public void Showpxgl() {
        outsideLabel = "品系管理";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否            
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            LineherdMapper mapper = sqlSession.getMapper(LineherdMapper.class);
            lineherdList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[lineherdList.size()][3];
        for (int j = 0; j < lineherdList.size(); j++) {
            tableModel[j][0] = lineherdList.get(j).getHerdid();
            tableModel[j][1] = lineherdList.get(j).getHerdname();
            tableModel[j][2] = lineherdList.get(j).getLineid();
        }

        String[] tableHead = new String[]{"品系代码", "品系名称", "品种简码"};
        String title1 = "品系管理";
        closeList(tableModel, tableHead, title1);

    }

    public void Showypxx() {
        outsideLabel = "药品信息";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否            
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否            
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PigypMapper mapper = sqlSession.getMapper(PigypMapper.class);
            pigypList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[pigypList.size()][3];
        for (int j = 0; j < pigypList.size(); j++) {
            tableModel[j][0] = pigypList.get(j).getTypeid();
            tableModel[j][1] = pigypList.get(j).getTypename();
            tableModel[j][2] = pigypList.get(j).getBz();
        }

        String[] tableHead = new String[]{"药品简码", "药品名称", "说    明"};
        String title1 = "药品信息";
        closeList(tableModel, tableHead, title1);

    }

    public void Showymxx() {
        outsideLabel = "疫苗信息";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出当前
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            VaccineMapper mapper = sqlSession.getMapper(VaccineMapper.class);
            vaccineList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[vaccineList.size()][3];
        for (int j = 0; j < vaccineList.size(); j++) {
            tableModel[j][0] = vaccineList.get(j).getTypeid();
            tableModel[j][1] = vaccineList.get(j).getTypename();
            tableModel[j][2] = vaccineList.get(j).getBz();
        }

        String[] tableHead = new String[]{"疫苗简码", "疫苗名称", "说    明"};
        String title1 = "疫苗信息";
        closeList(tableModel, tableHead, title1);

    }

    public void Showmysz() {
        outsideLabel = "免疫设置";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            MyszMapper mapper = sqlSession.getMapper(MyszMapper.class);
            myszList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[myszList.size()][4];
        for (int j = 0; j < myszList.size(); j++) {
            tableModel[j][0] = myszList.get(j).getId();
            tableModel[j][1] = myszList.get(j).getRl();
            tableModel[j][2] = vaccineIdtoNameSmap.get(myszList.get(j).getMyname());
            tableModel[j][3] = myszList.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "日   龄", "疫苗名称", "备   注"};
        String title1 = "免疫设置";
        closeList(tableModel, tableHead, title1);

    }

    public void Showzzmysz() {
        outsideLabel = "种猪免疫设置";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyszMapper mapper = sqlSession.getMapper(ZzmyszMapper.class);
            zzmyszList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[zzmyszList.size()][6];
        for (int j = 0; j < zzmyszList.size(); j++) {

            tableModel[j][0] = zzmyszList.get(j).getId();
            tableModel[j][1] = swintypeIdtoNameSmap.get(zzmyszList.get(j).getTypeid());
            tableModel[j][2] = zzmyszList.get(j).getSzrq();
            if (zzmyszList.get(j).getRqdw().equals("1")) {
                tableModel[j][3] = "天";

            } else {
                tableModel[j][3] = "月";

            }
            tableModel[j][4] = vaccineIdtoNameSmap.get(zzmyszList.get(j).getMyname());
            tableModel[j][5] = zzmyszList.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "猪只状态", "设置日期", "日期单位", "疫苗名称", "备   注"};
        String title1 = "种猪免疫设置";
        closeList(tableModel, tableHead, title1);

    }

    public void Showjbxx() {
        outsideLabel = "疾病信息";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            PigjbMapper mapper = sqlSession.getMapper(PigjbMapper.class);
            pigjbList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[pigjbList.size()][3];
        for (int j = 0; j < pigjbList.size(); j++) {
            tableModel[j][0] = pigjbList.get(j).getTypeid();
            tableModel[j][1] = pigjbList.get(j).getTypename();
        }

        String[] tableHead = new String[]{"疾病编号", "疾病名称"};
        String title1 = "疾病信息";
        closeList(tableModel, tableHead, title1);
    }

    public void Showcssz() {
        outsideLabel = "参数设置";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            DesignbaseMapper mapper = sqlSession.getMapper(DesignbaseMapper.class);
            designbaselist = mapper.selectAll();
        }
        Object[][] tableModel = new Object[designbaselist.size()][3];
        for (int j = 0; j < designbaselist.size(); j++) {
            tableModel[j][0] = designbaselist.get(j).getId();
            tableModel[j][1] = designbaselist.get(j).getTypename();
            tableModel[j][2] = designbaselist.get(j).getTypevalue();
        }

        String[] tableHead = new String[]{"设置简码", "设置条目", "设置初值"};
        String title1 = "参数设置";
        closeList(tableModel, tableHead, title1);

    }

    public void Showlwgl() {
        outsideLabel = "栏位管理";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper = sqlSession.getMapper(FenceMapper.class);
            fenceList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[fenceList.size()][5];
        for (int j = 0; j < fenceList.size(); j++) {
            tableModel[j][0] = fenceList.get(j).getFenceid();
            tableModel[j][1] = fenceList.get(j).getFencename();
            tableModel[j][2] = fenceList.get(j).getNumber();
            tableModel[j][3] = fenceList.get(j).getBz();
        }
        String[] tableHead = new String[]{"栏位编号", "栏位名称", "猪舍编号", "备   注"};
        String title1 = "栏位管理";
        closeList(tableModel, tableHead, title1);
    }

    public void Showygzw() {
        outsideLabel = "员工职位";
        if (!(nowEmployee.getYgzw().equals("1"))) {
            JOptionPane.showMessageDialog(null, "您没有权限访问当前功能！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YgzwMapper mapper = sqlSession.getMapper(YgzwMapper.class);
            ygzwList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[ygzwList.size()][2];
        for (int j = 0; j < ygzwList.size(); j++) {
            tableModel[j][0] = ygzwList.get(j).getZwid();
            tableModel[j][1] = ygzwList.get(j).getZwname();

        }

        String[] tableHead = new String[]{"流水编号 ", "职位名称 "};
        String title1 = "员工职位";
        closeList(tableModel, tableHead, title1);

    }

    public void Showyhgl() {
        outsideLabel = "用户管理";
        if (!(nowEmployee.getYgzw().equals("1"))) {
            JOptionPane.showMessageDialog(null, "您没有权限访问当前功能！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
            YgzwMapper mapper0 = sqlSession.getMapper(YgzwMapper.class);
            employeeList = mapper.selectAll();
            ygzwList = mapper0.selectAll();
        }
        Object[][] tableModel = new Object[employeeList.size()][9];
        for (int j = 0; j < employeeList.size(); j++) {
            for (int i = 0; i < ygzwList.size(); i++) {
                if (employeeList.get(j).getYgzw().equals(ygzwList.get(i).getZwid())) {
                    employeeList.get(j).setYgzw(ygzwList.get(i).getZwname());
                }
            }
            tableModel[j][0] = employeeList.get(j).getEmployeeid();
            tableModel[j][1] = employeeList.get(j).getUser_name();
            tableModel[j][2] = employeeList.get(j).getYgzw();
            tableModel[j][3] = employeeList.get(j).getSuperroot();
            tableModel[j][4] = employeeList.get(j).getIsallfarm();
            tableModel[j][5] = employeeList.get(j).getMoney();
            tableModel[j][6] = employeeList.get(j).getRzsj();
            tableModel[j][7] = employeeList.get(j).getWorksm();
            tableModel[j][8] = employeeList.get(j).getBz();
        }

        String[] tableHead = new String[]{"员工编号 ", "员工姓名 ", "职    位", "权限级别 ", "是否管理员", "工    资", "入职日期 ", "工作说明 ", "备    注"};
        String title1 = "用户管理";
        closeList(tableModel, tableHead, title1);
    }

    public void Showmmxg() {

        ChangepwApp changepwApp = new ChangepwApp(nowEmployee);
        changepwApp.setVisible(true);
    }

    public void Showgywm() {

        AboutUsApp aboutUsApp = new AboutUsApp();
        aboutUsApp.setVisible(true);
    }

    public void Showgtxx() {
        outsideLabel = "个体基本信息";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("出生日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(pigSwintypeThingsShow));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jDesktopPane1.removeAll();

        selebithPageModel.reset(selethMapperPlus.SelectCount(), false);
        Selebithpage(1);
    }

    public void Showgzcjdj() {
        outsideLabel = "公猪采精登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("采精日期：");
        String[] things = new String[1];
        things[0] = "种公猪";
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));

        jDesktopPane1.removeAll();
        takespermPageModel.reset(takespermMapperPlus.SelectCount(), false);

        Takespermpage(1);
    }

    public void Showmzfqygzcx() {
        outsideLabel = "母猪非亲缘公猪查询";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        jLabel02.setText("测定日期:");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        List<String> StringList = new ArrayList<>();
        Object[][] tableModel = new Object[StringList.size()][3];
        for (int j = 0; j < StringList.size(); j++) {
            tableModel[j][0] = StringList.get(j);
            tableModel[j][1] = StringList.get(j);
            tableModel[j][2] = StringList.get(j);
        }

        String[] tableHead = new String[]{"非亲缘公猪个体编号", "所在猪舍", "所在猪栏"};
        String title1 = "母猪非亲缘公猪查询";
        closeList(tableModel, tableHead, title1);
    }

    public void Showpzqkdj() {
        outsideLabel = "母猪配种情况登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        //搜索控件可用否
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        String[] things1 = new String[4];
        things1[0] = "配种状态";
        things1[1] = "检验状态";
        things1[2] = "妊娠状态";
        things1[3] = "返情状态";
        jLabel02.setText("配种日期：");
        jButton3.setText("添加信息");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jDesktopPane1.removeAll();
        breedingPageModel.reset(breedingMapperPlus.SelectCount(), false);

        Breedingpage(1);
    }

    public void Showmzfmqkdj() {
        outsideLabel = "母猪分娩情况登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        String[] things1 = new String[1];
        things1[0] = "分娩状态";
        jLabel02.setText("分娩日期：");
        jButton3.setText("添加信息");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        jDesktopPane1.removeAll();
        childbirthPageModel.reset(childbirthMapperPlus.SelectCount(), false);

        Childbirthpage(1);

    }

    public void Showmzdndj() {
        outsideLabel = "母猪断奶登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否

        String[] things1 = new String[1];
        things1[0] = "断奶状态";
        jComboBox1.setEnabled(false);
        jLabel02.setText("断奶日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        jDesktopPane1.removeAll();
        weaningPageModel.reset(weaningMapperPlus.SelectCount(), false);
        Weaningpage(1);

    }

    public void Showbyzzszyfz() {
        outsideLabel = "保育猪-生长育肥猪";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //让快捷删除不好使
        jButton1NowExcel.setEnabled(true);
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否

        jLabel02.setText("转群日期：");
        String[] things1 = new String[1];
        things1[0] = "育肥状态";
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        //查询所有
        conservationTurnFattingPageModel.reset(conservationTurnFattingMapperPlus.SelectCount(), false);
        ConservationTurnFattingpage(1);

    }

    public void Showbyzzhbz() {
        outsideLabel = "保育猪-后备猪";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //让快捷删除不好使
        jButton1NowExcel.setEnabled(true);
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否

        jLabel02.setText("转群日期：");
        String[] things1 = new String[1];
        things1[0] = "后备状态";
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        //查询所有
        conservationTurnBackPageModel.reset(conservationTurnBackMapperPlus.SelectCount(), false);

        ConservationTurnBackpage(1);

    }

    public void Showbrzzbyz() {
        outsideLabel = "哺乳猪-保育猪";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否

        jLabel02.setText("转群日期：");
        String[] things1 = new String[1];
        things1[0] = "保育状态";
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        //查询所有
        feedingTurnConservationPageModel.reset(feedingTurnConservationMapperPlus.SelectCount(), false);
        FeedingTurnConservationPage(1);

    }

    public void Showzgzzl() {
        outsideLabel = "种公猪资料";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("业绩查询");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否

        jLabel02.setText("出生日期");
        String[] things1 = new String[2];
        things1[0] = "种公猪";
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        jDesktopPane1.removeAll();
        maleBoarPageModel.reset(maleBoarMapperPlus.selectAllMaleCount(), false);

        MaleBoarpage(1);
    }

    public void Showzmzzl() {
        outsideLabel = "种母猪资料";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("业绩查询");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("出生日期");
        String[] things1 = new String[5];
        things1[0] = "种母猪";
        things1[1] = "后备母猪";
        things1[2] = "妊娠母猪";
        things1[3] = "哺乳母猪";
        things1[4] = "空怀母猪";
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        jDesktopPane1.removeAll();
        femaleBoarPageModel.reset(famaleBoarMapperPlus.selectAllFemaleCount(), false);
        FemaleBoarpage(1);
    }

    public void Showhbz2yldj() {
        outsideLabel = "后备猪2月龄登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否

        String[] things1 = new String[5];
        things1[0] = "猪只状态";
        things1[1] = "后备猪";
        things1[2] = "生长育肥猪";
        things1[3] = "销售";
        things1[4] = "死亡";
        jLabel02.setText("测定日期：");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        jDesktopPane1.removeAll();
        twoTestPageModel.reset(twoTestMapperPlus.SelectCount(), false);

        TwoTestpage(1);
    }

    public void Showhbz4yldj() {
        outsideLabel = "后备猪4月龄登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        String[] things1 = new String[5];
        things1[0] = "猪只状态";
        things1[1] = "后备猪";
        things1[2] = "生长育肥猪";
        things1[3] = "销售";
        things1[4] = "死亡";
        jLabel02.setText("测定日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        jDesktopPane1.removeAll();
        fourTestPageModel.reset(fourTestMapperPlus.SelectCount(), false);
        FourTestpage(1);
    }

    public void Showhbz6yldj() {
        outsideLabel = "后备猪6月龄登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        String[] things1 = new String[5];
        things1[0] = "猪只状态";
        things1[1] = "后备猪";
        things1[2] = "生长育肥猪";
        things1[3] = "销售";
        things1[4] = "死亡";
        jLabel02.setText("测定日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));

        jDesktopPane1.removeAll();
        sixTestPageModel.reset(sixTestMapperPlus.SelectCount(), false);
        SixTestpage(1);
    }

    public void Show100kgjcdj() {
        outsideLabel = "100KG检测登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        String[] things1 = new String[6];
        things1[0] = "猪只状态";
        things1[1] = "后备母猪";
        things1[2] = "种公猪";
        things1[3] = "生长育肥猪";
        things1[4] = "死亡";
        things1[5] = "销售";
        jLabel02.setText("测定日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jDesktopPane1.removeAll();
        hundredTestPageModel.reset(hundredTestMapperPlus.SelectCount(), false);

        HundredTestpage(1);
    }

    public void Showslkc() {
        outsideLabel = "饲料库存";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("入库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlkcMapper mapper = sqlSession.getMapper(SlkcMapper.class);
            slkcList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[slkcList.size()][2];
        for (int j = 0; j < slkcList.size(); j++) {
            tableModel[j][0] = pigslIdtoNameSmap.get(slkcList.get(j).getTypeid());
            tableModel[j][1] = slkcList.get(j).getNum();
        }

        String[] tableHead = new String[]{"饲料名称", "饲料数量"};
        String title1 = "饲料库存";
        closeList(tableModel, tableHead, title1);

    }

    public void Showslrk() {
        outsideLabel = "饲料入库登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("入库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigSllbThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslSLLBThingsShow));
        jDesktopPane1.removeAll();
        slrkPageModel.reset(slrkMapperPlus.SelectCount(), false);
        Slrkpage(1);

    }

    public void Showslck() {
        outsideLabel = "饲料出库登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("出库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigSllbThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslSLLBThingsShow));
        jDesktopPane1.removeAll();
        slckPageModel.reset(slckMapperPlus.SelectCount(), false);

        Slckpage(1);

    }

    public void Showypkc() {
        outsideLabel = "药品库存";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("入库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        List<Ypkc> ypkcList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpkcMapper mapper = sqlSession.getMapper(YpkcMapper.class);
            ypkcList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[ypkcList.size()][2];
        for (int j = 0; j < ypkcList.size(); j++) {
            tableModel[j][0] = pigypIdtoNameSmap.get(ypkcList.get(j).getTypeid());
            tableModel[j][1] = ypkcList.get(j).getNum();
        }

        String[] tableHead = new String[]{"药品名称", "药品数量"};
        String title1 = "药品库存";
        closeList(tableModel, tableHead, title1);
    }

    public void Showyprk() {
        outsideLabel = "药品入库登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("入库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        yprkPageModel.reset(yprkMapperPlus.SelectCount(), false);
        Yprkpage(1);
    }

    public void Showypck() {
        outsideLabel = "药品出库登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jLabel02.setText("出库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        ypckPageModel.reset(ypckMapperPlus.SelectCount(), false);

        Ypckpage(1);

    }

    public void Showymkc() {
        outsideLabel = "疫苗库存";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("入库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();

        List<Ymkc> ymkcList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmkcMapper mapper = sqlSession.getMapper(YmkcMapper.class);
            ymkcList = mapper.selectAll();
        }
        Object[][] tableModel = new Object[ymkcList.size()][2];
        for (int j = 0; j < ymkcList.size(); j++) {
            tableModel[j][0] = vaccineIdtoNameSmap.get(ymkcList.get(j).getTypeid());
            tableModel[j][1] = ymkcList.get(j).getNum();
        }

        String[] tableHead = new String[]{"疫苗名称", "库存数量"};
        String title1 = "疫苗库存";
        closeList(tableModel, tableHead, title1);

    }

    public void Showymrk() {
        outsideLabel = "疫苗入库登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("入库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        ymrkPageModel.reset(ymrkMapperPlus.SelectCount(), false);
        Ymrkpage(1);
    }

    public void Showymck() {
        outsideLabel = "疫苗出库登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("出库日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        ymckPageModel.reset(ymckMapperPlus.SelectCount(), false);

        Ymckpage(1);

    }

    public void Showzzmydj() {
        outsideLabel = "猪只免疫登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("注射日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(pigSwintypeThingsShow));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        zzmyPageModel.reset(zzmyMapperPlus.SelectCount(), false);

        Zzmypage(1);

    }

    public void Showjbzldj() {
        outsideLabel = "疾病治疗登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("治疗日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(pigSwintypeThingsShow));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        jbzlPageModel.reset(jbzlMapperPlus.SelectCount(), false);
        Jbzlpage(1);
    }

    public void Showjyjcdj() {
        outsideLabel = "基因检测登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("检测日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jDesktopPane1.removeAll();
        jyjcPageModel.reset(jyjcMapperPlus.SelectCount(), false);
        Jyjcpage(1);

    }

    public void Showtzxncddj() {
        outsideLabel = "屠宰性能测定登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jButton4.setText("更改信息");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        jLabel02.setText("测定日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jDesktopPane1.removeAll();
        tzxncdPageModel.reset(tzxncdMapperPlus.SelectCount(), false);
        Tzxncdpage(1);
    }

    public void Showzzxsdj() {
        outsideLabel = "猪只销售登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(true);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部            
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        String[] things1 = new String[1];
        things1[0] = "销售    ";
        jLabel02.setText("销售日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jDesktopPane1.removeAll();
        zzxsPageModel.reset(zzxsMapperPlus.SelectCount(), false);
        Zzxspage(1);

    }

    public void Showzzswdj() {
        outsideLabel = "猪只死亡登记";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(true);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        String[] things1 = new String[1];
        things1[0] = "死亡   ";
        jLabel02.setText("死亡日期：");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jDesktopPane1.removeAll();
        zzswPageModel.reset(zzswMapperPlus.SelectCount(), false);
        Zzswpage(1);
    }

    public void Showpzfql() {
        outsideLabel = "配种返情率";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jLabel02.setText("配种日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        pzfqlTJ.setVisible(true);
        pzfqlTJ.setTitle(outsideLabel);
        pzfqlTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(pzfqlTJ);
        try {
            pzfqlTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
        System.gc();
    }

    public void Showpzfml() {
        outsideLabel = "配种分娩率";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("配种日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        pzfmlTJ.setVisible(true);
        pzfmlTJ.setTitle(outsideLabel);
        pzfmlTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(pzfmlTJ);
        try {
            pzfmlTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showtjzczs() {
        outsideLabel = "胎均总产仔数";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("分娩日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        tjzczsTJ.setVisible(true);
        tjzczsTJ.setTitle(outsideLabel);
        tjzczsTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(tjzczsTJ);
        try {
            tjzczsTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showtjhzzs() {
        outsideLabel = "胎均活产仔数";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("分娩日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        tjhczsTJ.setVisible(true);
        tjhczsTJ.setTitle(outsideLabel);
        tjhczsTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(tjhczsTJ);
        try {
            tjhczsTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showcshtgz() {
        outsideLabel = "出生活体个重";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("分娩日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        cshtgzTJ.setVisible(true);
        cshtgzTJ.setTitle(outsideLabel);
        cshtgzTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(cshtgzTJ);
        try {
            cshtgzTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
    }

    public void Showcshtgs() {
        outsideLabel = "出生活体个数";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");

        jLabel02.setText("分娩日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        cshtgsTJ.setVisible(true);
        cshtgsTJ.setTitle(outsideLabel);
        cshtgsTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(cshtgsTJ);
        try {
            cshtgsTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showtjdnhzs() {
        outsideLabel = "胎均断奶活仔数";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("断奶日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        tjdnhzsTJ.setVisible(true);
        tjdnhzsTJ.setTitle(outsideLabel);
        tjdnhzsTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(tjdnhzsTJ);
        try {
            tjdnhzsTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showdngtz() {
        outsideLabel = "断奶个体重";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("断奶日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        dngtzTJ.setVisible(true);
        dngtzTJ.setTitle(outsideLabel);
        dngtzTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(dngtzTJ);
        try {
            dngtzTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showtjzschl() {
        outsideLabel = "断奶仔猪成活率";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("断奶日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        dnzzchlTJ.setVisible(true);
        dnzzchlTJ.setTitle(outsideLabel);
        dnzzchlTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(dnzzchlTJ);
        try {
            dnzzchlTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showbyqchl() {
        outsideLabel = "保育期成活率";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("转保育日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigBYCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("统计");//查询
        byqchlTJ.setVisible(true);
        byqchlTJ.setTitle(outsideLabel);
        byqchlTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(byqchlTJ);
        try {
            byqchlTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }//在父窗口中添加这个子窗口

    }

    public void Showyfqchl() {
        outsideLabel = "育肥期成活率";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("转育肥日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigYFCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("统计");//查询
        yfqchlTJ.setVisible(true);
        yfqchlTJ.setTitle(outsideLabel);
        yfqchlTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(yfqchlTJ);
        try {
            yfqchlTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }//在父窗口中添加这个子窗口

    }

    public void Showslrktj() {
        outsideLabel = "饲料入库统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("入库日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigslSLLBThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigslSLLBThingsShow));
        jButton1.setText("统计");//查询
        slrkTJ.setVisible(true);
        slrkTJ.setTitle(outsideLabel);
        slrkTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(slrkTJ);
        try {
            slrkTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
        //在父窗口中添加这个子窗口

    }

    public void Showyprktj() {
        outsideLabel = "药品入库统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("入库日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigYpThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("统计");//查询
        yprkTJ.setVisible(true);
        yprkTJ.setTitle(outsideLabel);
        yprkTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(yprkTJ);
        try {
            yprkTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showymrktj() {
        outsideLabel = "疫苗入库统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("入库日期");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigYmThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("统计");//查询
        ymrkTJ.setVisible(true);
        ymrkTJ.setTitle(outsideLabel);
        ymrkTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(ymrkTJ);
        try {
            ymrkTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showslcktj() {
        outsideLabel = "饲料出库统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("出库日期");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigslSLLBThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jButton1.setText("统计");//查询
        slckTJ.setVisible(true);
        slckTJ.setTitle(outsideLabel);
        slckTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(slckTJ);
        try {
            slckTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        } //在父窗口中添加这个子窗口

    }

    public void Showypcktj() {
        outsideLabel = "药品出库统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("出库日期");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigYpThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jButton1.setText("统计");//查询
        ypckTJ.setVisible(true);
        ypckTJ.setTitle(outsideLabel);
        ypckTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(ypckTJ);
        try {
            ypckTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showymcktj() {
        outsideLabel = "疫苗出库统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jLabel02.setText("出库日期");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigYmThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jButton1.setText("统计");//查询
        ymckTJ.setVisible(true);
        ymckTJ.setTitle(outsideLabel);
        ymckTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(ymckTJ);
        try {
            ymckTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showzzswtj() {
        outsideLabel = "猪只死亡统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(true);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(pigFenceThingsShow));
        jButton1.setText("统计");//查询
        zzswTJ.setVisible(true);
        zzswTJ.setTitle(outsideLabel);
        zzswTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(zzswTJ);
        try {
            zzswTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
    }

    public void Showzcxstj() {
        outsideLabel = "猪场销售统计";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(true);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsShowPlus));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("统计");//查询
        zzxsTJ.setVisible(true);
        zzxsTJ.setTitle(outsideLabel);
        zzxsTJ.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(zzxsTJ);
        try {
            zzxsTJ.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }

    }

    public void Showjdlrb() {
        outsideLabel = "简单料肉比";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(true);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jButton1.setText("统计");//查询
        jdlrbTj.setVisible(true);
        jdlrbTj.setTitle(outsideLabel);
        jdlrbTj.setData();
        jDesktopPane1.removeAll();
        jDesktopPane1.add(jdlrbTj);
        try {
            jdlrbTj.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
    }

    public void Showrsjytx() {
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();

        List<Breeding> breedingList;
        List<Selebith> selebithList = new ArrayList();
        int[] count;

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            RemindMapper mapper1 = sqlSession.getMapper(RemindMapper.class
            );
            breedingList = mapper1.breedingJytx(minusDate(NowTime(), 21));
            SelebithMapper mapper2 = sqlSession.getMapper(SelebithMapper.class
            );
            for (int i = 0; i < breedingList.size(); i++) {
                selebithList.add(mapper2.selectByTypeid(breedingList.get(i).getR_animal()));
            }
        }

        Object[][] tableModel = new Object[selebithList.size()][4];
        for (int j = 0; j < selebithList.size(); j++) {
            tableModel[j][0] = selebithList.get(j).getR_animal();
            tableModel[j][1] = selebithList.get(j).getR_fdate();
            tableModel[j][2] = swintypeIdtoNameSmap.get(selebithList.get(j).getR_curmark());
            tableModel[j][3] = fenceIdtoNameSmap.get(selebithList.get(j).getR_pcage());

        }

        String[] tableHead = new String[]{"个体编号", "出生日期", "当前状态", "所在栏舍"};
        String title1 = "妊娠检验提醒";
        closeList(tableModel, tableHead, title1);
    }

    public void Showymtx() {
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();

        List<Mysz> myszList;
        int[] count;

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            MyszMapper mapper1 = sqlSession.getMapper(MyszMapper.class
            );
            myszList = mapper1.selectAll();
            count = new int[myszList.size()];
            RemindMapper mapper2 = sqlSession.getMapper(RemindMapper.class
            );
            for (int i = 0; i < myszList.size(); i++) {
                count[i] = mapper2.selebithByR_fdateCount(minusDate(NowTime(), myszList.get(i).getRl())).getCount();

            }
        }
        Object[][] tableModel = new Object[myszList.size()][5];
        for (int j = 0; j < myszList.size(); j++) {
            tableModel[j][0] = myszList.get(j).getId();
            tableModel[j][1] = vaccineIdtoNameSmap.get(myszList.get(j).getMyname());
            tableModel[j][2] = count[j];
            tableModel[j][3] = String.valueOf(myszList.get(j).getRl());
            tableModel[j][4] = myszList.get(j).getBz();

        }

        String[] tableHead = new String[]{"免疫编号", "疫苗名称", "猪只个数", "日龄天数", "备   注"};
        String title1 = "疫苗提醒";
        closeList(tableModel, tableHead, title1);
    }

    public void Showzzymtx() {
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        //上排按钮可用否--查询
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(true);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jButtonPrint.setEnabled(false);//打印输出        
        jDesktopPane1.removeAll();

        List<Zzmysz> zzmyszList;
        int[] count;

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyszMapper mapper1 = sqlSession.getMapper(ZzmyszMapper.class
            );
            zzmyszList = mapper1.selectAll();
            count = new int[zzmyszList.size()];
            RemindMapper mapper2 = sqlSession.getMapper(RemindMapper.class
            );
            for (int i = 0; i < zzmyszList.size(); i++) {

                if (zzmyszList.get(i).getTypeid().equals("6")) {
                    count[i] = mapper2.breedingRshtxCount(minusDate(NowTime(), Integer.parseInt(zzmyszList.get(i).getSzrq()))).getCount();
                } else if (zzmyszList.get(i).getTypeid().equals("7")) {
                    count[i] = mapper2.childbirthFmhtxCount(minusDate(NowTime(), Integer.parseInt(zzmyszList.get(i).getSzrq()))).getCount();
                } else if (zzmyszList.get(i).getTypeid().equals("8")) {
                    count[i] = mapper2.childbirthDnhtxCount(minusDate(NowTime(), Integer.parseInt(zzmyszList.get(i).getSzrq()))).getCount();
                } else if (zzmyszList.get(i).getTypeid().equals("5")) {
                    count[i] = mapper2.hbmzhundredtesthtxCount(minusDate(NowTime(), Integer.parseInt(zzmyszList.get(i).getSzrq()))).getCount();
                } else if (zzmyszList.get(i).getTypeid().equals("9") && zzmyszList.get(i).getRqdw().equals("1")) {
                    count[i] = mapper2.zgzhundredtesthtxCount(minusDate(NowTime(), Integer.parseInt(zzmyszList.get(i).getSzrq()))).getCount();
                } else if (zzmyszList.get(i).getTypeid().equals("9") && zzmyszList.get(i).getRqdw().equals("0") && (NowTime().substring(5, 7).equals(zzmyszList.get(i).getSzrq()))) {
                    count[i] = mapper2.zgztxCount().getCount();
                }

                if (count[i] == 0) {
                    zzmyszList.remove(i);
                    i--;
                }
            }
        }
        Object[][] tableModel = new Object[zzmyszList.size()][7];
        for (int j = 0; j < zzmyszList.size(); j++) {

            tableModel[j][0] = zzmyszList.get(j).getId();
            tableModel[j][1] = swintypeIdtoNameSmap.get(zzmyszList.get(j).getTypeid());
            tableModel[j][2] = zzmyszList.get(j).getSzrq();
            if (zzmyszList.get(j).getRqdw().equals("1")) {
                tableModel[j][3] = "天";

            } else {
                tableModel[j][3] = "月";

            }
            tableModel[j][4] = vaccineIdtoNameSmap.get(zzmyszList.get(j).getMyname());
            tableModel[j][5] = count[j];
            tableModel[j][6] = zzmyszList.get(j).getBz();
        }

        String[] tableHead = new String[]{"流水编号", "猪只状态", "设置日期", "日期单位", "疫苗名称", "猪只个数", "备注"};
        String title1 = "种猪疫苗提醒";
        closeList(tableModel, tableHead, title1);
    }

    public void Showfmtx() {
        //上排按钮可用否--查询
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();

        List<Breeding> breedingList;
        List<Selebith> selebithList = new ArrayList();
        int[] count;

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            RemindMapper mapper1 = sqlSession.getMapper(RemindMapper.class
            );
            breedingList = mapper1.breedingFmtx(minusDate(NowTime(), 107));
            SelebithMapper mapper2 = sqlSession.getMapper(SelebithMapper.class
            );
            for (int i = 0; i < breedingList.size(); i++) {
                selebithList.add(mapper2.selectByTypeid(breedingList.get(i).getR_animal()));
            }
        }

        Object[][] tableModel = new Object[selebithList.size()][4];
        for (int j = 0; j < selebithList.size(); j++) {
            tableModel[j][0] = selebithList.get(j).getR_animal();
            tableModel[j][1] = selebithList.get(j).getR_fdate();
            tableModel[j][2] = swintypeIdtoNameSmap.get(selebithList.get(j).getR_curmark());
            tableModel[j][3] = fenceIdtoNameSmap.get(selebithList.get(j).getR_pcage());

        }

        String[] tableHead = new String[]{"个体编号", "出生日期", "当前状态", "所在栏舍"};
        String title1 = "分娩提醒";
        closeList(tableModel, tableHead, title1);
    }

    public void Showxpwj() {
        //上排按钮可用否--查询
        outsideLabel = "系谱数据";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();
        jLabel02.setText("出生日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("查询");//查询
        //搜索控件可用否
        List<String> StringList = new ArrayList<>();
        Object[][] tableModel = new Object[StringList.size()][3];
        for (int j = 0; j < StringList.size(); j++) {
            tableModel[j][0] = StringList.get(j);
            tableModel[j][1] = StringList.get(j);
            tableModel[j][2] = StringList.get(j);
        }

        String[] tableHead = new String[]{"个体编号", "父亲编号", "母亲编号"};
        String title1 = "系谱数据";
        closeList(tableModel, tableHead, title1);

    }

    public void Showyzgtxx() {
        //上排按钮可用否--查询
        outsideLabel = "育种个体信息";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();
        jLabel02.setText("出生日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("查询");//查询
        //搜索控件可用否
        List<String> StringList = new ArrayList<>();
        Object[][] tableModel = new Object[StringList.size()][9];
        for (int j = 0; j < StringList.size(); j++) {
            tableModel[j][0] = StringList.get(j);
            tableModel[j][1] = StringList.get(j);
            tableModel[j][2] = StringList.get(j);
            tableModel[j][3] = StringList.get(j);
            tableModel[j][4] = StringList.get(j);
            tableModel[j][5] = StringList.get(j);
            tableModel[j][6] = StringList.get(j);
            tableModel[j][7] = StringList.get(j);
            tableModel[j][8] = StringList.get(j);
        }

        String[] tableHead = new String[]{"个体编号", "品系", "出生日期", "性别", "当前状态", "所在栏舍", "出生胎次", "断奶重量", "采精次数", "当前胎次", "产仔总数"};
        String title1 = "育种个体信息";
        closeList(tableModel, tableHead, title1);

    }

    public void Showyztwotest() {
        //上排按钮可用否--查询
        outsideLabel = "后备2月性状";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();
        jLabel02.setText("测试日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("查询");//查询
        //搜索控件可用否
        List<String> StringList = new ArrayList<>();
        Object[][] tableModel = new Object[StringList.size()][5];
        for (int j = 0; j < StringList.size(); j++) {
            tableModel[j][0] = StringList.get(j);
            tableModel[j][1] = StringList.get(j);
            tableModel[j][2] = StringList.get(j);
            tableModel[j][3] = StringList.get(j);
            tableModel[j][4] = StringList.get(j);
        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性别", "体重", "所在猪舍"};
        String title1 = "后备2月性状";
        closeList(tableModel, tableHead, title1);
    }

    public void Showyzfourtest() {
        //上排按钮可用否--查询
        outsideLabel = "后备4月性状";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();
        jLabel02.setText("测试日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("查询");//查询
        //搜索控件可用否
        List<String> StringList = new ArrayList<>();
        Object[][] tableModel = new Object[StringList.size()][5];
        for (int j = 0; j < StringList.size(); j++) {
            tableModel[j][0] = StringList.get(j);
            tableModel[j][1] = StringList.get(j);
            tableModel[j][2] = StringList.get(j);
            tableModel[j][3] = StringList.get(j);
            tableModel[j][4] = StringList.get(j);
        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性别", "体重", "所在猪舍"};
        String title1 = "后备4月性状";
        closeList(tableModel, tableHead, title1);
    }

    public void Showyzsixtest() {
        //上排按钮可用否--查询
        outsideLabel = "后备6月性状";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();
        jLabel02.setText("测试日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("查询");//查询
        //搜索控件可用否
        List<String> StringList = new ArrayList<>();
        Object[][] tableModel = new Object[StringList.size()][5];
        for (int j = 0; j < StringList.size(); j++) {
            tableModel[j][0] = StringList.get(j);
            tableModel[j][1] = StringList.get(j);
            tableModel[j][2] = StringList.get(j);
            tableModel[j][3] = StringList.get(j);
            tableModel[j][4] = StringList.get(j);
        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性别", "体重", "所在猪舍"};
        String title1 = "后备6月性状";
        closeList(tableModel, tableHead, title1);
    }

    public void Showyzhundredtest() {
        //上排按钮可用否--查询
        outsideLabel = "100kg测定性状";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(true);//时间起始
        jTextField2.setEnabled(true);//时间起始框
        jButton9.setEnabled(true);//时间结束
        jTextField3.setEnabled(true);//时间起结束框
        jComboBox2.setEnabled(true);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("查看信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        jDesktopPane1.removeAll();
        jLabel02.setText("测试日期");
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(pigCategoryThingsShow));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));
        jButton1.setText("查询");//查询
        //搜索控件可用否
        List<String> StringList = new ArrayList<>();
        Object[][] tableModel = new Object[StringList.size()][5];
        for (int j = 0; j < StringList.size(); j++) {
            tableModel[j][0] = StringList.get(j);
            tableModel[j][1] = StringList.get(j);
            tableModel[j][2] = StringList.get(j);
            tableModel[j][3] = StringList.get(j);
            tableModel[j][4] = StringList.get(j);
        }

        String[] tableHead = new String[]{"个体编号", "测定日期", "性别", "体重", "所在猪舍", "体重日龄"};
        String title1 = "100kg测定性状";
        closeList(tableModel, tableHead, title1);

    }

    public void ShowYzfx() {
        outsideLabel = "育种分析";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(false);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(false);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(false);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jButton1.setText("统计");//查询
        yzfx.setData();
        yzfx.setVisible(true);
        yzfx.setTitle(outsideLabel);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(yzfx);
        try {
            yzfx.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
    }

    public void ShowXzxp() {
        outsideLabel = "选种选配";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(true);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(true);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出当前");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(true);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(true);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jButton1.setText("查询");//查询
        xzxp.setData();
        xzxp.setVisible(true);
        xzxp.setTitle(outsideLabel);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(xzxp);
        try {
            xzxp.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
    }

    public void ShowPlxz() {
        outsideLabel = "批量选种";
        jTextField01.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField01.setEnabled(false);//个体编号不可用
        jComboBox1.setEnabled(false);//猪只状态不可用
        jButton7.setEnabled(false);//时间起始
        jTextField2.setEnabled(false);//时间起始框
        jButton9.setEnabled(false);//时间结束
        jTextField3.setEnabled(false);//时间起结束框
        jComboBox2.setEnabled(false);//全部舍
        jComboBox3.setEnabled(false);//全部栏
        jButton1.setEnabled(false);//查询
        jButton5.setEnabled(false);//清空
        //下排按钮可用否
        jButton4.setText("更改信息");
        jButton1NowExcel.setText("导出全部");
        jButton3.setEnabled(false);//增加
        jButton2.setEnabled(false);//删除
        jButton4.setEnabled(false);//更改
        jButton6.setEnabled(true);//刷新
        jButton8.setEnabled(false);//详情
        jButton1NowExcel.setEnabled(true);//导出当前
        jButton1AllExcel.setEnabled(false);//导出全部
        jButtonPrint.setEnabled(true);//打印输出
        //搜索控件可用否
        //标签更改
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(kongString));//猪只状态不可用
        jButton1.setText("查询");//查询
        List<Selebith> MaleList = null;
        List<Selebith> FemaleList = null;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JqqyjyMapper mapper = sqlSession.getMapper(JqqyjyMapper.class);
            MaleList = mapper.selectAllMale1();
            FemaleList = mapper.selectAllFemale1();
        }

        plxz = new Plxz(MaleList, FemaleList);
        plxz.setData();
        plxz.setVisible(true);
        plxz.setTitle(outsideLabel);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(plxz);
        try {
            plxz.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
    }

    public void update() {
        jDesktopPane1.removeAll();
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton1AllExcel;
    private javax.swing.JButton jButton1NowExcel;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jButtonPrint;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private static javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel02;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JTextField jTextField01;
    public static javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
