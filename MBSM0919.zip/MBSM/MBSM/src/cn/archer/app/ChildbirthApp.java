package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.Childbirthpage;
import static cn.archer.app.MainApp.childbirthMapperPlus;
import static cn.archer.app.MainApp.childbirthPageModel;
import static cn.archer.app.MainApp.employeeIdtoNameSmap;
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeeSYYThingsShow;
import static cn.archer.app.MainApp.employeeSYYThingsmap;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.fenceNametoIdSmap;
import static cn.archer.app.MainApp.fenceThingsShow;
import static cn.archer.app.MainApp.fenceThingsmap;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.piggeryThingsShow;
import static cn.archer.app.MainApp.piggeryThingsmap;
import cn.archer.mapper.BreedingMapper;
import cn.archer.mapper.ChildbirthMapper;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.model.ChildbirthPageModel;
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Fence;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Selebith;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import static cn.archer.utils.MyStaticMethod.NowTime;
import cn.archer.utils.DateChooserJButtonJDialog;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author Administrator
 */
public class ChildbirthApp extends javax.swing.JDialog {

    private VarietiesDataPlus varietiesDataPlus;
    private String flagua;
    private String formid0;
    private List<Piggery> piggery;
    private java.awt.Frame parent;

    /**
     * Creates new form FormApp
     */
    public ChildbirthApp(VarietiesDataPlus varietiesDataPlus, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.parent = parent;

        flagua = "add";
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("母猪分娩情况登记");
        jLabel00.setText("母猪分娩情况登记");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        jTextField2.setText(NowTime());
        //分娩猪舍复选框
        PiggeryMapper mapper0 = sqlSession.getMapper(PiggeryMapper.class);
        piggery = mapper0.selectAll();

        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsShow));
        //分娩栏位复选框
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsShow));
        //负责人复选框
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsShow));
        //妊娠猪舍复选框
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsShow));
        //妊娠栏位复选框 
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsShow));

        jTextField17.setEnabled(false);
        jComboBox4.setEnabled(false);
        jComboBox5.setEnabled(false);
        jTextField6.setEnabled(false);
        jComboBox3.setEnabled(false);

        sqlSession.close();

    }

    public ChildbirthApp(VarietiesDataPlus varietiesDataPlus, String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "upp";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;

        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("母猪分娩情况修改");
        jLabel00.setText("母猪分娩情况修改");

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        ChildbirthMapper mapper = sqlSession.getMapper(ChildbirthMapper.class);
        Childbirth childbirth;
        childbirth = mapper.selectByid(farmid0);
        jCheckBox1.setSelected(false);
        jTextField1.setText(childbirth.getR_animal());
        jTextField2.setText(childbirth.getCzrq());
        String[] things = new String[2];
        if (childbirth.getZt().equals("1")) {
            things[0] = "分娩状态";
            things[1] = "断奶状态";
        }
        if (childbirth.getZt().equals("2")) {
            things[0] = "断奶状态";
            things[1] = "分娩状态";
        }

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getFenceid().substring(0, 5))));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getFenceid())));
        jTextField6.setText(String.valueOf(childbirth.getTc()));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsmap.get(childbirth.getFwemployeeid())));
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getFwfenceid().substring(0, 5))));
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getFwfenceid())));
        jTextField10.setText(String.valueOf(childbirth.getZczs()));
        jTextField11.setText(String.valueOf(childbirth.getCzhs()));
        jTextField12.setText(String.valueOf(childbirth.getCgzs()));
        jTextField13.setText(String.valueOf(childbirth.getCmzs()));
        jTextField14.setText(String.valueOf(childbirth.getJxs()));
        jTextField15.setText(String.valueOf(childbirth.getSds()));
        jTextField16.setText(String.valueOf(childbirth.getMny()));
        jTextField17.setText(String.valueOf(childbirth.getCswz()));
        jTextField18.setText(String.valueOf(childbirth.getJl()));
        jTextField19.setText(String.valueOf(childbirth.getJc()));

        jTextField1.setEnabled(false);
        jButton0002.setEnabled(false);
        jComboBox3.setEnabled(false);
        jTextField2.setEnabled(false);
        jComboBox4.setEnabled(false);
        jComboBox5.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField17.setEnabled(false);
        jCheckBox1.setText("如需修改小猪信息请到个体信息表");
        jCheckBox1.setEnabled(false);
        jTextField6.setEnabled(false);
        jButton2.setEnabled(false);
        sqlSession.close();
    }

    public ChildbirthApp(String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("母猪分娩情况详情");
        jLabel00.setText("母猪分娩情况详情");//录入，登记，更改,详情
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        ChildbirthMapper mapper = sqlSession.getMapper(ChildbirthMapper.class);
        Childbirth childbirth;
        childbirth = mapper.selectByid(farmid0);
        jCheckBox1.setSelected(false);
        jTextField1.setText(childbirth.getR_animal());
        jTextField2.setText(childbirth.getCzrq());
        String[] things = new String[3];
        if (childbirth.getZt().equals("1")) {
            things[0] = "分娩状态";
            things[1] = "断奶状态";
        }
        if (childbirth.getZt().equals("2")) {
            things[0] = "断奶状态";
            things[1] = "分娩状态";
        }

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getFenceid().substring(0, 5))));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getFenceid())));
        jTextField6.setText(String.valueOf(childbirth.getTc()));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsmap.get(childbirth.getFwemployeeid())));
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getFwfenceid().substring(0, 5))));
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getFwfenceid())));
        jTextField10.setText(String.valueOf(childbirth.getZczs()));
        jTextField11.setText(String.valueOf(childbirth.getCzhs()));
        jTextField12.setText(String.valueOf(childbirth.getCgzs()));
        jTextField13.setText(String.valueOf(childbirth.getCmzs()));
        jTextField14.setText(String.valueOf(childbirth.getJxs()));
        jTextField15.setText(String.valueOf(childbirth.getSds()));
        jTextField16.setText(String.valueOf(childbirth.getMny()));
        jTextField17.setText(String.valueOf(childbirth.getCswz()));
        jTextField18.setText(String.valueOf(childbirth.getJl()));
        jTextField19.setText(String.valueOf(childbirth.getJc()));

        jTextField1.setEnabled(false);
        jButton0002.setEnabled(false);
        jComboBox3.setEnabled(false);
        jTextField2.setEnabled(false);
        jComboBox4.setEnabled(false);
        jComboBox5.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jTextField11.setEnabled(false);
        jTextField12.setEnabled(false);
        jTextField13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jTextField16.setEnabled(false);
        jTextField17.setEnabled(false);
        jTextField18.setEnabled(false);
        jTextField19.setEnabled(false);

        jCheckBox1.setText("如需修改小猪信息请到个体信息表");
        jCheckBox1.setEnabled(false);
        jTextField6.setEnabled(false);
        jButton1.setEnabled(false);
        jButton2.setEnabled(false);
        sqlSession.close();
    }

    public ChildbirthApp(String farmid0, javax.swing.JDialog parent, boolean modal) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("母猪分娩情况详情");
        jLabel00.setText("母猪分娩情况详情");//录入，登记，更改,详情

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        ChildbirthMapper mapper = sqlSession.getMapper(ChildbirthMapper.class);
        Childbirth childbirth;
        childbirth = mapper.selectByid(farmid0);
        jCheckBox1.setSelected(false);
        jTextField1.setText(childbirth.getR_animal());
        jTextField2.setText(childbirth.getCzrq());
        String[] things = new String[2];
        if (childbirth.getZt().equals("1")) {
            things[0] = "分娩状态";
            things[1] = "断奶状态";
        }
        if (childbirth.getZt().equals("2")) {
            things[0] = "断奶状态";
            things[1] = "分娩状态";
        }
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getFenceid().substring(0, 5))));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getFenceid())));
        jTextField6.setText(String.valueOf(childbirth.getTc()));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsmap.get(childbirth.getFwemployeeid())));
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getFwfenceid().substring(0, 5))));
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getFwfenceid())));
        jTextField10.setText(String.valueOf(childbirth.getZczs()));
        jTextField11.setText(String.valueOf(childbirth.getCzhs()));
        jTextField12.setText(String.valueOf(childbirth.getCgzs()));
        jTextField13.setText(String.valueOf(childbirth.getCmzs()));
        jTextField14.setText(String.valueOf(childbirth.getJxs()));
        jTextField15.setText(String.valueOf(childbirth.getSds()));
        jTextField16.setText(String.valueOf(childbirth.getMny()));
        jTextField17.setText(String.valueOf(childbirth.getCswz()));
        jTextField18.setText(String.valueOf(childbirth.getJl()));
        jTextField19.setText(String.valueOf(childbirth.getJc()));

        jTextField1.setEnabled(false);
        jButton0002.setEnabled(false);
        jComboBox3.setEnabled(false);
        jTextField2.setEnabled(false);
        jComboBox4.setEnabled(false);
        jComboBox5.setEnabled(false);
        jComboBox7.setEnabled(false);
        jComboBox8.setEnabled(false);
        jComboBox9.setEnabled(false);
        jTextField10.setEnabled(false);
        jTextField11.setEnabled(false);
        jTextField12.setEnabled(false);
        jTextField13.setEnabled(false);
        jTextField14.setEnabled(false);
        jTextField15.setEnabled(false);
        jTextField16.setEnabled(false);
        jTextField17.setEnabled(false);
        jTextField18.setEnabled(false);
        jTextField19.setEnabled(false);

        jCheckBox1.setText("如需修改小猪信息请到个体信息表");
        jCheckBox1.setEnabled(false);
        jTextField6.setEnabled(false);
        jButton1.setEnabled(false);
        jButton2.setEnabled(false);
        sqlSession.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jComboBox7 = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jComboBox9 = new javax.swing.JComboBox<>();
        jComboBox8 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jCheckBox1 = new javax.swing.JCheckBox();
        jButton3 = new javax.swing.JButton();
        jLabel00 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton0002 =  new DateChooserJButtonJDialog (jTextField2);
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(305, 353));

        jLabel1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel1.setText("个体编号：");

        jLabel2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("*");

        jTextField1.setText("0");
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton1.setText("确认提交");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/refues.png"))); // NOI18N
        jButton2.setText("重新输入");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setText("分娩时间：");

        jLabel5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 0));
        jLabel5.setText("*");

        jLabel7.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 0, 0));
        jLabel7.setText("*");

        jLabel8.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 0));
        jLabel8.setText("*");

        jLabel9.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel9.setText("状    态：");

        jLabel10.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel10.setText("当前胎次：");

        jTextField6.setText("0");

        jLabel11.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel11.setText("负 责 人：");

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel12.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel12.setText("分娩猪舍：");

        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel13.setText("分娩栏位：");

        jComboBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox8ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel14.setText("妊娠猪舍：");

        jLabel15.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel15.setText("妊娠栏位：");

        jTextField10.setText("0");
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel16.setText("总产仔数：");

        jLabel17.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel17.setText("产仔活数：");

        jTextField11.setText("0");

        jLabel18.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel18.setText("产公仔数：");

        jTextField12.setText("0");

        jLabel19.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel19.setText("死 胎 数：");

        jLabel20.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel20.setText("畸 形 数：");

        jLabel21.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel21.setText("产母仔数：");

        jTextField13.setText("0");

        jTextField14.setText("0");

        jTextField15.setText("0");

        jLabel22.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel22.setText("木 乃 伊：");

        jTextField17.setText("0");

        jTextField16.setText("0");

        jLabel23.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel23.setText("出生窝重：");

        jTextField18.setText("0");

        jLabel24.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel24.setText("寄    入：");

        jLabel25.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel25.setText("寄    出：");

        jTextField19.setText("0");

        jCheckBox1.setSelected(true);
        jCheckBox1.setText("         是否添加新小猪信息");
        jCheckBox1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 0), new java.awt.Color(204, 255, 255)));
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton3.setText("退出输入");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel00.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel00.setText("分娩信息录入");

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "分娩状态", "已经断奶" }));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(204, 0, 0));
        jLabel26.setText("*");

        jLabel27.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(204, 0, 0));
        jLabel27.setText("*");

        jLabel28.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(204, 0, 0));
        jLabel28.setText("*");

        jButton0002.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton0002.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton0002ActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(204, 0, 0));
        jLabel29.setText("KG");

        jLabel30.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 0, 0));
        jLabel30.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息处理");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel28))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11)
                                            .addComponent(jLabel12))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel15)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel8))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(83, 83, 83)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel21)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField13))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel20)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField14))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel19)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField15))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel23)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(10, 10, 10)
                                            .addComponent(jLabel29)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel22)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel24)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel25)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel1)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField1))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jButton0002, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel7))
                                .addGap(83, 83, 83)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel16)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField10))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField11))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel18)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addComponent(jButton1)
                                .addGap(35, 35, 35)
                                .addComponent(jButton2)
                                .addGap(35, 35, 35)
                                .addComponent(jButton3))
                            .addComponent(jLabel30))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26)
                            .addComponent(jLabel27))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(236, 236, 236)
                .addComponent(jLabel00)
                .addGap(235, 235, 235))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel00)
                .addGap(30, 30, 30)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel17)
                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel26)
                                .addComponent(jLabel5))
                            .addComponent(jButton0002, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel18)
                                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(10, 10, 10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jLabel8)
                            .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel29)))
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(8, 8, 8)
                .addComponent(jCheckBox1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 585, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 498, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField6.setText("");
        jTextField10.setText("");
        jTextField11.setText("");
        jTextField12.setText("");
        jTextField13.setText("");
        jTextField14.setText("");
        jTextField15.setText("");
        jTextField16.setText("");
        jTextField17.setText("");
        jTextField18.setText("");
        jTextField19.setText("");

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (StringUtils.isBlank(jTextField1.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加个体编号!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (StringUtils.isBlank(jTextField2.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加分娩时间!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (jTextField11.getText().equals("0")) {
            JOptionPane.showMessageDialog(null,
                    "您添加的产仔活数不可以为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        BreedingMapper mapper1 = sqlSession.getMapper(BreedingMapper.class);
        String idM = jTextField1.getText();
        if (idM.length() != 15 && idM.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加母猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Selebith selebith = mapper0.selectById("%" + jTextField1.getText());

        if (selebith == null) {
            JOptionPane.showMessageDialog(null, "您添加种母猪个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在
        String pzfzr = mapper1.selectByidandtc(selebith.getR_animal(), String.valueOf(selebith.getR_fno()));

        //｝提取猪之编号
        ChildbirthMapper mapper = sqlSession.getMapper(ChildbirthMapper.class);
        Childbirth childbirth = new Childbirth();
        if (flagua.equals("add")) {
            //｛查询母猪个体编号是否存在
            int pdk = 0;
            if (selebith.getR_curmark().equals("6") && selebith.getR_select() == 0) {
                pdk = 1;
            } else {
                pdk = 0;
                JOptionPane.showMessageDialog(null, "您添加母猪不是妊娠母猪状态，也可能正处在配种检验状态!", "系统信息", JOptionPane.WARNING_MESSAGE);
                sqlSession.close();
                return;
            }
        }
        String jComboBox3String = null;
        //分娩状态, 已经断奶, 未知状态
        if (JComboBoxString(jComboBox3).equals("分娩状态")) {
            jComboBox3String = "1";
        }
        if (JComboBoxString(jComboBox3).equals("已经断奶")) {
            jComboBox3String = "2";
        }

        childbirth.setR_animal(selebith.getR_animal());
        childbirth.setCzrq(jTextField2.getText());
        childbirth.setZt(jComboBox3String);
        childbirth.setFwfenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox9)));
        childbirth.setTc(Integer.parseInt(jTextField6.getText()));
        childbirth.setFwemployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBox7)));
        childbirth.setFenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBox5)));
        childbirth.setZczs(Integer.parseInt(jTextField10.getText()));
        childbirth.setCzhs(Integer.parseInt(jTextField11.getText()));
        childbirth.setCgzs(Integer.parseInt(jTextField12.getText()));
        childbirth.setCmzs(Integer.parseInt(jTextField13.getText()));
        childbirth.setJxs(Integer.parseInt(jTextField14.getText()));
        childbirth.setSds(Integer.parseInt(jTextField15.getText()));
        childbirth.setMny(Integer.parseInt(jTextField16.getText()));
        childbirth.setJl(Integer.parseInt(jTextField18.getText()));
        childbirth.setJc(Integer.parseInt(jTextField19.getText()));

        JTable jTable1 = varietiesDataPlus.getjTable1();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        if (flagua.equals("add")) {

            childbirth.setPzemployeeid(pzfzr);
            childbirth.setCswz(0.0);
            selebith.setR_fno(selebith.getR_fno() + 1);
            selebith.setR_curmark("7");
            selebith.setCzzs(childbirth.getCzhs());
            mapper0.updateByTypeid(selebith);
            mapper.insert(childbirth);
            sqlSession.commit();
            sqlSession.close();
            JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);

            System.gc();
            dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));

            if (jCheckBox1.isSelected()) {
                if (childbirth.getCzhs() != 0) {
                    NewbithApp newbithApp = new NewbithApp(this.parent, childbirth, selebith.getDqpzgzid());
                    newbithApp.setVisible(true);
                }
            }
            //添加后更新数据格式
            childbirthPageModel = new ChildbirthPageModel(14, childbirthMapperPlus.SelectCount(), childbirthMapperPlus, false);
            Childbirthpage(childbirthPageModel.getTopPageNo());

        } else {
            mapper.updateByid(childbirth);
            sqlSession.commit();
            sqlSession.close();
            JOptionPane.showMessageDialog(null, "修改成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            jTextField2.setEditable(true);
            jButton2.setEnabled(true);
            //移除修改那行，然后在后面加上新的一行
            model.removeRow(jTable1.getSelectedRow());
            Object[] rowInsert = new Object[]{formid0, childbirth.getR_animal(), childbirth.getCzrq(), childbirth.getTc(), employeeIdtoNameSmap.get(childbirth.getFwemployeeid()), fenceIdtoNameSmap.get(childbirth.getFenceid()), fenceIdtoNameSmap.get(childbirth.getFwfenceid())};
            model.addRow(rowInsert);
            jTable1.setModel(model);
            varietiesDataPlus.validate();

            System.gc();
            dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox8ActionPerformed

        String id = piggeryNametoIdSmap.get(JComboBoxString(jComboBox8));
        List<Fence> fencelist;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
            fencelist = mapper6.selectAllById(id);
        }
        String[] things6 = new String[fencelist.size()];
        for (int i = 0; i < fencelist.size(); i++) {
            things6[i] = fencelist.get(i).getFencename();
        }
        jComboBox9.removeAll();
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel(things6));
        }//GEN-LAST:event_jComboBox8ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        String id = piggeryNametoIdSmap.get(JComboBoxString(jComboBox4));

        List<Fence> fencelist;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
            fencelist = mapper6.selectAllById(id);
        }
        String[] things6 = new String[fencelist.size()];
        for (int i = 0; i < fencelist.size(); i++) {
            things6[i] = fencelist.get(i).getFencename();
        }
        jComboBox5.removeAll();
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(things6));
        // TODO add your handling code here:

    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        if ("upp".equals(flagua)) {
            return;
        }
        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper mapper0 = sqlSession.getMapper(SelebithMapper.class);
        PiggeryMapper mapper1 = sqlSession.getMapper(PiggeryMapper.class);
        List<Piggery> piggerList = mapper1.selectAll();
        String number = jTextField1.getText();
        if (number.length() != 15 && number.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加母猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Selebith selebithM = mapper0.selectById("%" + jTextField1.getText());

        if (selebithM == null) {
            JOptionPane.showMessageDialog(null, "您添加种母猪个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }

        String shehao = selebithM.getR_pcage().substring(0, 5);
        String fzr = null;
        for (int i = 0; i < piggerList.size(); i++) {
            if (piggerList.get(i).getNumber().equals(shehao)) {
                fzr = piggerList.get(i).getFeeder();
                break;
            }
        }

        //｝提取猪之编号,并查询种公猪个体编号是否存在
        jTextField6.setText(String.valueOf(selebithM.getR_fno() + 1));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(selebithM.getR_cage())));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(selebithM.getR_pcage())));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsmap.get(fzr)));
        sqlSession.close();
    }//GEN-LAST:event_jTextField1FocusLost

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton0002ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton0002ActionPerformed

    }//GEN-LAST:event_jButton0002ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton0002;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
