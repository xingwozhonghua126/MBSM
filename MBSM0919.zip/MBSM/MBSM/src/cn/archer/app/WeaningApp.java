package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.childbirthMapperPlus;
import static cn.archer.app.MainApp.childbirthPageModel;
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeeSYYThingsShow;
import static cn.archer.app.MainApp.employeeSYYThingsmap;
import static cn.archer.app.MainApp.employeeThingsShow;
import static cn.archer.app.MainApp.employeeThingsmap;
import static cn.archer.app.MainApp.fenceNametoIdSmap;
import static cn.archer.app.MainApp.fenceThingsmap;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.piggeryThingsmap;
import static cn.archer.app.MainApp.swintypeNametoIdSmap;
import static cn.archer.app.MainApp.swintypeThingsmap;
import static cn.archer.app.MainApp.weaningMapperPlus;
import static cn.archer.app.MainApp.weaningPageModel;
import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.mapper.WeaningMapper;
import cn.archer.model.ChildbirthPageModel;
import cn.archer.model.WeaningPageModel;
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Fence;
import cn.archer.pojo.Piggery;
import cn.archer.pojo.Selebith;
import static cn.archer.utils.MyStaticMethod.calInterval;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import static cn.archer.utils.MyStaticMethod.NowTime;
import cn.archer.utils.DateChooserJButtonJDialog;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JOptionPane;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author Administrator
 */
public class WeaningApp extends javax.swing.JDialog {

    private VarietiesDataPlus varietiesDataPlus;
    private String flagua;
    private String formid0;
    private List<Piggery> piggery;

    /**
     * Creates new form FormApp
     */
    public WeaningApp(VarietiesDataPlus varietiesDataPlus, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "add";
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("断奶信息登记");
        jLabel3.setText("断奶信息登记");//录入，登记，更改,详情
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        jTextFieldMZ8.setText(NowTime());
        jTextFieldMZ3.setEnabled(false);
        jTextFieldMZ2.setEnabled(false);
        jTextFieldMZ4.setEnabled(false);
        jTextFieldMZ5.setEnabled(false);
        jComboBoxMZ9.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsShow));//负责人
        //｛母猪断奶后猪舍复选框
        PiggeryMapper mapper0 = sqlSession.getMapper(PiggeryMapper.class);
        piggery = mapper0.selectAll();
        String[] things0 = new String[piggery.size()];
        for (int i = 0; i < piggery.size(); i++) {
            things0[i] = piggery.get(i).getCategory();
        }
        jComboBoxMZ6.setModel(new javax.swing.DefaultComboBoxModel(things0));
        //｝母猪断奶后猪舍复选框
        //｛母猪断奶后栏位复选框
        FenceMapper mapper1 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper1.selectAll();
        String[] things1 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things1[i] = fence.get(i).getFencename();
        }
        jComboBoxMZ7.setModel(new javax.swing.DefaultComboBoxModel(things1));
        //｛母猪断奶后栏位复选框
        jComboBox001.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox002.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox012.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox014.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox015.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox022.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox024.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox025.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox032.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox034.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox035.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox042.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox044.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox045.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox052.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox054.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox055.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox062.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox064.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox065.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox072.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox074.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox075.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox082.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox084.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox085.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox092.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox094.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox095.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox102.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox104.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox105.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox112.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox114.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox115.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox122.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox124.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox125.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox132.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox134.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox135.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox142.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox144.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox145.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox152.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox154.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox155.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox162.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox164.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox165.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox172.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox174.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox175.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox182.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox184.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox185.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox192.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox194.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox195.setModel(new javax.swing.DefaultComboBoxModel(things1));
        jComboBox202.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get("2")));
        jComboBox204.setModel(new javax.swing.DefaultComboBoxModel(things0));
        jComboBox205.setModel(new javax.swing.DefaultComboBoxModel(things1));
        sqlSession.close();

    }

    public WeaningApp(String farmid0, javax.swing.JDialog parent, boolean modal) {
        super(parent, modal);
        flagua = "detail";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("断奶信息详情");
        jLabel3.setText("断奶信息详情");//录入，登记，更改,详情
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
        Childbirth childbirth = weaningMapper.selectByid(farmid0);
        List<Selebith> SelebithList = weaningMapper.selectAllZz(childbirth.getR_animal(), String.valueOf(childbirth.getTc()));
        jTextFieldMZ1.setText(childbirth.getR_animal());
        jTextFieldMZ2.setText(String.valueOf(childbirth.getTc()));
        jTextFieldMZ4.setText(String.valueOf(childbirth.getDnts()));
        jTextFieldMZ5.setText(String.valueOf(childbirth.getDnwz()));
        jComboBoxMZ6.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getOutfenceid().substring(0, 5))));
        jComboBoxMZ7.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getOutfenceid())));
        jTextFieldMZ8.setText(childbirth.getDnrq());
        jComboBoxMZ9.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsmap.get(childbirth.getEmployeeid())));
        jTextFieldMZ10.setText(childbirth.getBz());
        jTextFieldMZ1.setEnabled(false);
        jTextFieldMZ2.setEnabled(false);
        jTextFieldMZ3.setEnabled(false);
        jTextFieldMZ4.setEnabled(false);
        jTextFieldMZ5.setEnabled(false);
        jComboBoxMZ6.setEnabled(false);
        jComboBoxMZ7.setEnabled(false);
        jTextFieldMZ8.setEnabled(false);
        jComboBoxMZ9.setEnabled(false);
        jTextFieldMZ10.setEnabled(false);
        jComboBox001.setEnabled(false);
        jComboBox002.setEnabled(false);
        jButton3.setEnabled(false);
        jButton0004.setEnabled(false);
        childbirth.setDnts(childbirth.getCzhs());
        for (int i = 0; i < SelebithList.size(); i++) {
            switch (i) {
                case 0:
                    jTextField011.setText(SelebithList.get(i).getR_animal());
                    jComboBox012.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField013.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox014.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox015.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField011.setEnabled(false);
                    jComboBox012.setEnabled(false);
                    jTextField013.setEnabled(false);
                    jComboBox014.setEnabled(false);
                    jComboBox015.setEnabled(false);

                    break;
                case 1:
                    jTextField021.setText(SelebithList.get(i).getR_animal());
                    jComboBox022.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField023.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox024.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox025.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField021.setEnabled(false);
                    jComboBox022.setEnabled(false);
                    jTextField023.setEnabled(false);
                    jComboBox024.setEnabled(false);
                    jComboBox025.setEnabled(false);

                    break;
                case 2:
                    jTextField031.setText(SelebithList.get(i).getR_animal());
                    jComboBox032.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField033.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox034.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox035.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField031.setEnabled(false);
                    jComboBox032.setEnabled(false);
                    jTextField033.setEnabled(false);
                    jComboBox034.setEnabled(false);
                    jComboBox035.setEnabled(false);
                    break;
                case 3:
                    jTextField041.setText(SelebithList.get(i).getR_animal());
                    jComboBox042.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField043.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox044.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox045.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField041.setEnabled(false);
                    jComboBox042.setEnabled(false);
                    jTextField043.setEnabled(false);
                    jComboBox044.setEnabled(false);
                    jComboBox045.setEnabled(false);
                    break;
                case 4:
                    jTextField051.setText(SelebithList.get(i).getR_animal());
                    jComboBox052.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField053.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox054.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox055.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField051.setEnabled(false);
                    jComboBox052.setEnabled(false);
                    jTextField053.setEnabled(false);
                    jComboBox054.setEnabled(false);
                    jComboBox055.setEnabled(false);
                    break;
                case 5:
                    jTextField061.setText(SelebithList.get(i).getR_animal());
                    jComboBox062.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField063.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox064.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox065.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField061.setEnabled(false);
                    jComboBox062.setEnabled(false);
                    jTextField063.setEnabled(false);
                    jComboBox064.setEnabled(false);
                    jComboBox065.setEnabled(false);
                    break;
                case 6:
                    jTextField071.setText(SelebithList.get(i).getR_animal());
                    jComboBox072.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField073.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox074.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox075.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField071.setEnabled(false);
                    jComboBox072.setEnabled(false);
                    jTextField073.setEnabled(false);
                    jComboBox074.setEnabled(false);
                    jComboBox075.setEnabled(false);
                    break;
                case 7:
                    jTextField081.setText(SelebithList.get(i).getR_animal());
                    jComboBox082.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField083.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox084.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox085.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField081.setEnabled(false);
                    jComboBox082.setEnabled(false);
                    jTextField083.setEnabled(false);
                    jComboBox084.setEnabled(false);
                    jComboBox085.setEnabled(false);

                    break;
                case 8:
                    jTextField091.setText(SelebithList.get(i).getR_animal());
                    jComboBox092.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField093.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox094.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox095.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField091.setEnabled(false);
                    jComboBox092.setEnabled(false);
                    jTextField093.setEnabled(false);
                    jComboBox094.setEnabled(false);
                    jComboBox095.setEnabled(false);
                    break;
                case 9:
                    jTextField101.setText(SelebithList.get(i).getR_animal());
                    jComboBox102.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField103.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox104.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox105.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField101.setEnabled(false);
                    jComboBox102.setEnabled(false);
                    jTextField103.setEnabled(false);
                    jComboBox104.setEnabled(false);
                    jComboBox105.setEnabled(false);
                    break;
                case 10:
                    jTextField111.setText(SelebithList.get(i).getR_animal());
                    jComboBox112.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField113.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox114.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox115.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField111.setEnabled(false);
                    jComboBox112.setEnabled(false);
                    jTextField113.setEnabled(false);
                    jComboBox114.setEnabled(false);
                    jComboBox115.setEnabled(false);
                    break;
                case 11:
                    jTextField121.setText(SelebithList.get(i).getR_animal());
                    jComboBox122.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField123.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox124.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox125.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField121.setEnabled(false);
                    jComboBox122.setEnabled(false);
                    jTextField123.setEnabled(false);
                    jComboBox124.setEnabled(false);
                    jComboBox125.setEnabled(false);
                    break;
                case 12:
                    jTextField131.setText(SelebithList.get(i).getR_animal());
                    jComboBox132.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField133.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox134.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox135.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField131.setEnabled(false);
                    jComboBox132.setEnabled(false);
                    jTextField133.setEnabled(false);
                    jComboBox134.setEnabled(false);
                    jComboBox135.setEnabled(false);
                    break;
                case 13:
                    jTextField141.setText(SelebithList.get(i).getR_animal());
                    jComboBox142.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField143.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox144.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox145.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField141.setEnabled(false);
                    jComboBox142.setEnabled(false);
                    jTextField143.setEnabled(false);
                    jComboBox144.setEnabled(false);
                    jComboBox145.setEnabled(false);

                    break;
                case 14:
                    jTextField151.setText(SelebithList.get(i).getR_animal());
                    jComboBox152.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField153.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox154.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox155.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField151.setEnabled(false);
                    jComboBox152.setEnabled(false);
                    jTextField153.setEnabled(false);
                    jComboBox154.setEnabled(false);
                    jComboBox155.setEnabled(false);
                    childbirth.setDnts(childbirth.getDnts() - 1);

                case 15:
                    jTextField161.setText(SelebithList.get(i).getR_animal());
                    jComboBox162.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField163.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox164.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox165.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField161.setEnabled(false);
                    jComboBox162.setEnabled(false);
                    jTextField163.setEnabled(false);
                    jComboBox164.setEnabled(false);
                    jComboBox165.setEnabled(false);
                    break;
                case 16:
                    jTextField171.setText(SelebithList.get(i).getR_animal());
                    jComboBox172.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField173.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox174.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox175.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField171.setEnabled(false);
                    jComboBox172.setEnabled(false);
                    jTextField173.setEnabled(false);
                    jComboBox174.setEnabled(false);
                    jComboBox175.setEnabled(false);
                    break;
                case 17:
                    jTextField181.setText(SelebithList.get(i).getR_animal());
                    jComboBox182.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField183.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox184.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox185.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField181.setEnabled(false);
                    jComboBox182.setEnabled(false);
                    jTextField183.setEnabled(false);
                    jComboBox184.setEnabled(false);
                    jComboBox185.setEnabled(false);
                    break;
                case 18:
                    jTextField191.setText(SelebithList.get(i).getR_animal());
                    jComboBox192.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField193.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox194.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox195.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField191.setEnabled(false);
                    jComboBox192.setEnabled(false);
                    jTextField193.setEnabled(false);
                    jComboBox194.setEnabled(false);
                    jComboBox195.setEnabled(false);
                    break;
                case 19:
                    jTextField201.setText(SelebithList.get(i).getR_animal());
                    jComboBox202.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField203.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox204.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox205.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField201.setEnabled(false);
                    jComboBox202.setEnabled(false);
                    jTextField203.setEnabled(false);
                    jComboBox204.setEnabled(false);
                    jComboBox205.setEnabled(false);
                    break;
            }
            if ((i + 1) == SelebithList.size()) {
                switch (i) {

                    case 0:
                        jTextField021.setEnabled(false);
                        jComboBox022.setEnabled(false);
                        jTextField023.setEnabled(false);
                        jComboBox024.setEnabled(false);
                        jComboBox025.setEnabled(false);
                    case 1:
                        jTextField031.setEnabled(false);
                        jComboBox032.setEnabled(false);
                        jTextField033.setEnabled(false);
                        jComboBox034.setEnabled(false);
                        jComboBox035.setEnabled(false);
                    case 2:
                        jTextField041.setEnabled(false);
                        jComboBox042.setEnabled(false);
                        jTextField043.setEnabled(false);
                        jComboBox044.setEnabled(false);
                        jComboBox045.setEnabled(false);
                    case 3:
                        jTextField051.setEnabled(false);
                        jComboBox052.setEnabled(false);
                        jTextField053.setEnabled(false);
                        jComboBox054.setEnabled(false);
                        jComboBox055.setEnabled(false);
                    case 4:
                        jTextField061.setEnabled(false);
                        jComboBox062.setEnabled(false);
                        jTextField063.setEnabled(false);
                        jComboBox064.setEnabled(false);
                        jComboBox065.setEnabled(false);
                    case 5:
                        jTextField071.setEnabled(false);
                        jComboBox072.setEnabled(false);
                        jTextField073.setEnabled(false);
                        jComboBox074.setEnabled(false);
                        jComboBox075.setEnabled(false);
                    case 6:
                        jTextField081.setEnabled(false);
                        jComboBox082.setEnabled(false);
                        jTextField083.setEnabled(false);
                        jComboBox084.setEnabled(false);
                        jComboBox085.setEnabled(false);
                    case 7:
                        jTextField091.setEnabled(false);
                        jComboBox092.setEnabled(false);
                        jTextField093.setEnabled(false);
                        jComboBox094.setEnabled(false);
                        jComboBox095.setEnabled(false);
                    case 8:
                        jTextField101.setEnabled(false);
                        jComboBox102.setEnabled(false);
                        jTextField103.setEnabled(false);
                        jComboBox104.setEnabled(false);
                        jComboBox105.setEnabled(false);
                    case 9:
                        jTextField111.setEnabled(false);
                        jComboBox112.setEnabled(false);
                        jTextField113.setEnabled(false);
                        jComboBox114.setEnabled(false);
                        jComboBox115.setEnabled(false);
                    case 10:
                        jTextField121.setEnabled(false);
                        jComboBox122.setEnabled(false);
                        jTextField123.setEnabled(false);
                        jComboBox124.setEnabled(false);
                        jComboBox125.setEnabled(false);
                    case 11:
                        jTextField131.setEnabled(false);
                        jComboBox132.setEnabled(false);
                        jTextField133.setEnabled(false);
                        jComboBox134.setEnabled(false);
                        jComboBox135.setEnabled(false);
                    case 12:
                        jTextField141.setEnabled(false);
                        jComboBox142.setEnabled(false);
                        jTextField143.setEnabled(false);
                        jComboBox144.setEnabled(false);
                        jComboBox145.setEnabled(false);
                    case 13:
                        jTextField151.setEnabled(false);
                        jComboBox152.setEnabled(false);
                        jTextField153.setEnabled(false);
                        jComboBox154.setEnabled(false);
                        jComboBox155.setEnabled(false);
                    case 14:
                        jTextField161.setEnabled(false);
                        jComboBox162.setEnabled(false);
                        jTextField163.setEnabled(false);
                        jComboBox164.setEnabled(false);
                        jComboBox165.setEnabled(false);
                    case 15:
                        jTextField171.setEnabled(false);
                        jComboBox172.setEnabled(false);
                        jTextField173.setEnabled(false);
                        jComboBox174.setEnabled(false);
                        jComboBox175.setEnabled(false);
                    case 16:
                        jTextField181.setEnabled(false);
                        jComboBox182.setEnabled(false);
                        jTextField183.setEnabled(false);
                        jComboBox184.setEnabled(false);
                        jComboBox185.setEnabled(false);
                    case 17:
                        jTextField191.setEnabled(false);
                        jComboBox192.setEnabled(false);
                        jTextField193.setEnabled(false);
                        jComboBox194.setEnabled(false);
                        jComboBox195.setEnabled(false);
                    case 18:
                        jTextField201.setEnabled(false);
                        jComboBox202.setEnabled(false);
                        jTextField203.setEnabled(false);
                        jComboBox204.setEnabled(false);
                        jComboBox205.setEnabled(false);
                }
            }
        }

        sqlSession.close();
    }

    public WeaningApp(String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        flagua = "detail";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setTitle("断奶信息详情");
        jLabel3.setText("断奶信息详情");//录入，登记，更改,详情

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
        Childbirth childbirth = weaningMapper.selectByid(farmid0);
        List<Selebith> SelebithList = weaningMapper.selectAllZz(childbirth.getR_animal(), String.valueOf(childbirth.getTc()));
        jTextFieldMZ1.setText(childbirth.getR_animal());
        jTextFieldMZ2.setText(String.valueOf(childbirth.getTc()));
        jTextFieldMZ4.setText(String.valueOf(childbirth.getDnts()));
        jTextFieldMZ5.setText(String.valueOf(childbirth.getDnwz()));
        jComboBoxMZ6.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(childbirth.getOutfenceid().substring(0, 5))));
        jComboBoxMZ7.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(childbirth.getOutfenceid())));
        jTextFieldMZ8.setText(childbirth.getDnrq());
        jComboBoxMZ9.setModel(new javax.swing.DefaultComboBoxModel(employeeThingsmap.get(childbirth.getEmployeeid())));
        jTextFieldMZ10.setText(childbirth.getBz());

        jTextFieldMZ1.setEnabled(false);
        jTextFieldMZ2.setEnabled(false);
        jTextFieldMZ3.setEnabled(false);
        jTextFieldMZ4.setEnabled(false);
        jTextFieldMZ5.setEnabled(false);
        jComboBoxMZ6.setEnabled(false);
        jComboBoxMZ7.setEnabled(false);
        jTextFieldMZ8.setEnabled(false);
        jComboBoxMZ9.setEnabled(false);
        jTextFieldMZ10.setEnabled(false);
        jComboBox001.setEnabled(false);
        jComboBox002.setEnabled(false);
        jButton3.setEnabled(false);
        jButton0004.setEnabled(false);

        childbirth.setDnts(childbirth.getCzhs());
        for (int i = 0; i < SelebithList.size(); i++) {
            switch (i) {
                case 0:
                    jTextField011.setText(SelebithList.get(i).getR_animal());
                    jComboBox012.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField013.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox014.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox015.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField011.setEnabled(false);
                    jComboBox012.setEnabled(false);
                    jTextField013.setEnabled(false);
                    jComboBox014.setEnabled(false);
                    jComboBox015.setEnabled(false);

                    break;
                case 1:
                    jTextField021.setText(SelebithList.get(i).getR_animal());
                    jComboBox022.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField023.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox024.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox025.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField021.setEnabled(false);
                    jComboBox022.setEnabled(false);
                    jTextField023.setEnabled(false);
                    jComboBox024.setEnabled(false);
                    jComboBox025.setEnabled(false);

                    break;
                case 2:
                    jTextField031.setText(SelebithList.get(i).getR_animal());
                    jComboBox032.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField033.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox034.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox035.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField031.setEnabled(false);
                    jComboBox032.setEnabled(false);
                    jTextField033.setEnabled(false);
                    jComboBox034.setEnabled(false);
                    jComboBox035.setEnabled(false);
                    break;
                case 3:
                    jTextField041.setText(SelebithList.get(i).getR_animal());
                    jComboBox042.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField043.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox044.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox045.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField041.setEnabled(false);
                    jComboBox042.setEnabled(false);
                    jTextField043.setEnabled(false);
                    jComboBox044.setEnabled(false);
                    jComboBox045.setEnabled(false);
                    break;
                case 4:
                    jTextField051.setText(SelebithList.get(i).getR_animal());
                    jComboBox052.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField053.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox054.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox055.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField051.setEnabled(false);
                    jComboBox052.setEnabled(false);
                    jTextField053.setEnabled(false);
                    jComboBox054.setEnabled(false);
                    jComboBox055.setEnabled(false);
                    break;
                case 5:
                    jTextField061.setText(SelebithList.get(i).getR_animal());
                    jComboBox062.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField063.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox064.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox065.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField061.setEnabled(false);
                    jComboBox062.setEnabled(false);
                    jTextField063.setEnabled(false);
                    jComboBox064.setEnabled(false);
                    jComboBox065.setEnabled(false);
                    break;
                case 6:
                    jTextField071.setText(SelebithList.get(i).getR_animal());
                    jComboBox072.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField073.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox074.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox075.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField071.setEnabled(false);
                    jComboBox072.setEnabled(false);
                    jTextField073.setEnabled(false);
                    jComboBox074.setEnabled(false);
                    jComboBox075.setEnabled(false);
                    break;
                case 7:
                    jTextField081.setText(SelebithList.get(i).getR_animal());
                    jComboBox082.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField083.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox084.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox085.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField081.setEnabled(false);
                    jComboBox082.setEnabled(false);
                    jTextField083.setEnabled(false);
                    jComboBox084.setEnabled(false);
                    jComboBox085.setEnabled(false);

                    break;
                case 8:
                    jTextField091.setText(SelebithList.get(i).getR_animal());
                    jComboBox092.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField093.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox094.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox095.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField091.setEnabled(false);
                    jComboBox092.setEnabled(false);
                    jTextField093.setEnabled(false);
                    jComboBox094.setEnabled(false);
                    jComboBox095.setEnabled(false);
                    break;
                case 9:
                    jTextField101.setText(SelebithList.get(i).getR_animal());
                    jComboBox102.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField103.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox104.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox105.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField101.setEnabled(false);
                    jComboBox102.setEnabled(false);
                    jTextField103.setEnabled(false);
                    jComboBox104.setEnabled(false);
                    jComboBox105.setEnabled(false);
                    break;
                case 10:
                    jTextField111.setText(SelebithList.get(i).getR_animal());
                    jComboBox112.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField113.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox114.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox115.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField111.setEnabled(false);
                    jComboBox112.setEnabled(false);
                    jTextField113.setEnabled(false);
                    jComboBox114.setEnabled(false);
                    jComboBox115.setEnabled(false);
                    break;
                case 11:
                    jTextField121.setText(SelebithList.get(i).getR_animal());
                    jComboBox122.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField123.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox124.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox125.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField121.setEnabled(false);
                    jComboBox122.setEnabled(false);
                    jTextField123.setEnabled(false);
                    jComboBox124.setEnabled(false);
                    jComboBox125.setEnabled(false);
                    break;
                case 12:
                    jTextField131.setText(SelebithList.get(i).getR_animal());
                    jComboBox132.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField133.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox134.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox135.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField131.setEnabled(false);
                    jComboBox132.setEnabled(false);
                    jTextField133.setEnabled(false);
                    jComboBox134.setEnabled(false);
                    jComboBox135.setEnabled(false);
                    break;
                case 13:
                    jTextField141.setText(SelebithList.get(i).getR_animal());
                    jComboBox142.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField143.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox144.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox145.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField141.setEnabled(false);
                    jComboBox142.setEnabled(false);
                    jTextField143.setEnabled(false);
                    jComboBox144.setEnabled(false);
                    jComboBox145.setEnabled(false);

                    break;
                case 14:
                    jTextField151.setText(SelebithList.get(i).getR_animal());
                    jComboBox152.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField153.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox154.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox155.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField151.setEnabled(false);
                    jComboBox152.setEnabled(false);
                    jTextField153.setEnabled(false);
                    jComboBox154.setEnabled(false);
                    jComboBox155.setEnabled(false);
                    childbirth.setDnts(childbirth.getDnts() - 1);

                case 15:
                    jTextField161.setText(SelebithList.get(i).getR_animal());
                    jComboBox162.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField163.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox164.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox165.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField161.setEnabled(false);
                    jComboBox162.setEnabled(false);
                    jTextField163.setEnabled(false);
                    jComboBox164.setEnabled(false);
                    jComboBox165.setEnabled(false);
                    break;
                case 16:
                    jTextField171.setText(SelebithList.get(i).getR_animal());
                    jComboBox172.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField173.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox174.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox175.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField171.setEnabled(false);
                    jComboBox172.setEnabled(false);
                    jTextField173.setEnabled(false);
                    jComboBox174.setEnabled(false);
                    jComboBox175.setEnabled(false);
                    break;
                case 17:
                    jTextField181.setText(SelebithList.get(i).getR_animal());
                    jComboBox182.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField183.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox184.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox185.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField181.setEnabled(false);
                    jComboBox182.setEnabled(false);
                    jTextField183.setEnabled(false);
                    jComboBox184.setEnabled(false);
                    jComboBox185.setEnabled(false);
                    break;
                case 18:
                    jTextField191.setText(SelebithList.get(i).getR_animal());
                    jComboBox192.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField193.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox194.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox195.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField191.setEnabled(false);
                    jComboBox192.setEnabled(false);
                    jTextField193.setEnabled(false);
                    jComboBox194.setEnabled(false);
                    jComboBox195.setEnabled(false);
                    break;
                case 19:
                    jTextField201.setText(SelebithList.get(i).getR_animal());
                    jComboBox202.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                    jTextField203.setText(SelebithList.get(i).getR_weanwt());
                    jComboBox204.setModel(new javax.swing.DefaultComboBoxModel(piggeryThingsmap.get(SelebithList.get(i).getZbafenceid().substring(0, 5))));
                    jComboBox205.setModel(new javax.swing.DefaultComboBoxModel(fenceThingsmap.get(SelebithList.get(i).getZbafenceid())));

                    jTextField201.setEnabled(false);
                    jComboBox202.setEnabled(false);
                    jTextField203.setEnabled(false);
                    jComboBox204.setEnabled(false);
                    jComboBox205.setEnabled(false);
                    break;
            }
            if ((i + 1) == SelebithList.size()) {
                switch (i) {

                    case 0:
                        jTextField021.setEnabled(false);
                        jComboBox022.setEnabled(false);
                        jTextField023.setEnabled(false);
                        jComboBox024.setEnabled(false);
                        jComboBox025.setEnabled(false);
                    case 1:
                        jTextField031.setEnabled(false);
                        jComboBox032.setEnabled(false);
                        jTextField033.setEnabled(false);
                        jComboBox034.setEnabled(false);
                        jComboBox035.setEnabled(false);
                    case 2:
                        jTextField041.setEnabled(false);
                        jComboBox042.setEnabled(false);
                        jTextField043.setEnabled(false);
                        jComboBox044.setEnabled(false);
                        jComboBox045.setEnabled(false);
                    case 3:
                        jTextField051.setEnabled(false);
                        jComboBox052.setEnabled(false);
                        jTextField053.setEnabled(false);
                        jComboBox054.setEnabled(false);
                        jComboBox055.setEnabled(false);
                    case 4:
                        jTextField061.setEnabled(false);
                        jComboBox062.setEnabled(false);
                        jTextField063.setEnabled(false);
                        jComboBox064.setEnabled(false);
                        jComboBox065.setEnabled(false);
                    case 5:
                        jTextField071.setEnabled(false);
                        jComboBox072.setEnabled(false);
                        jTextField073.setEnabled(false);
                        jComboBox074.setEnabled(false);
                        jComboBox075.setEnabled(false);
                    case 6:
                        jTextField081.setEnabled(false);
                        jComboBox082.setEnabled(false);
                        jTextField083.setEnabled(false);
                        jComboBox084.setEnabled(false);
                        jComboBox085.setEnabled(false);
                    case 7:
                        jTextField091.setEnabled(false);
                        jComboBox092.setEnabled(false);
                        jTextField093.setEnabled(false);
                        jComboBox094.setEnabled(false);
                        jComboBox095.setEnabled(false);
                    case 8:
                        jTextField101.setEnabled(false);
                        jComboBox102.setEnabled(false);
                        jTextField103.setEnabled(false);
                        jComboBox104.setEnabled(false);
                        jComboBox105.setEnabled(false);
                    case 9:
                        jTextField111.setEnabled(false);
                        jComboBox112.setEnabled(false);
                        jTextField113.setEnabled(false);
                        jComboBox114.setEnabled(false);
                        jComboBox115.setEnabled(false);
                    case 10:
                        jTextField121.setEnabled(false);
                        jComboBox122.setEnabled(false);
                        jTextField123.setEnabled(false);
                        jComboBox124.setEnabled(false);
                        jComboBox125.setEnabled(false);
                    case 11:
                        jTextField131.setEnabled(false);
                        jComboBox132.setEnabled(false);
                        jTextField133.setEnabled(false);
                        jComboBox134.setEnabled(false);
                        jComboBox135.setEnabled(false);
                    case 12:
                        jTextField141.setEnabled(false);
                        jComboBox142.setEnabled(false);
                        jTextField143.setEnabled(false);
                        jComboBox144.setEnabled(false);
                        jComboBox145.setEnabled(false);
                    case 13:
                        jTextField151.setEnabled(false);
                        jComboBox152.setEnabled(false);
                        jTextField153.setEnabled(false);
                        jComboBox154.setEnabled(false);
                        jComboBox155.setEnabled(false);
                    case 14:
                        jTextField161.setEnabled(false);
                        jComboBox162.setEnabled(false);
                        jTextField163.setEnabled(false);
                        jComboBox164.setEnabled(false);
                        jComboBox165.setEnabled(false);
                    case 15:
                        jTextField171.setEnabled(false);
                        jComboBox172.setEnabled(false);
                        jTextField173.setEnabled(false);
                        jComboBox174.setEnabled(false);
                        jComboBox175.setEnabled(false);
                    case 16:
                        jTextField181.setEnabled(false);
                        jComboBox182.setEnabled(false);
                        jTextField183.setEnabled(false);
                        jComboBox184.setEnabled(false);
                        jComboBox185.setEnabled(false);
                    case 17:
                        jTextField191.setEnabled(false);
                        jComboBox192.setEnabled(false);
                        jTextField193.setEnabled(false);
                        jComboBox194.setEnabled(false);
                        jComboBox195.setEnabled(false);
                    case 18:
                        jTextField201.setEnabled(false);
                        jComboBox202.setEnabled(false);
                        jTextField203.setEnabled(false);
                        jComboBox204.setEnabled(false);
                        jComboBox205.setEnabled(false);
                }
            }
        }

        sqlSession.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox001 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jComboBox002 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jTextFieldMZ1 = new javax.swing.JTextField();
        jTextFieldMZ2 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextFieldMZ4 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jTextFieldMZ5 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jTextFieldMZ3 = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jTextFieldMZ10 = new javax.swing.JTextField();
        jComboBoxMZ6 = new javax.swing.JComboBox<>();
        jComboBoxMZ7 = new javax.swing.JComboBox<>();
        jComboBoxMZ9 = new javax.swing.JComboBox<>();
        jTextFieldMZ8 = new javax.swing.JTextField();
        jButton0004 =  new DateChooserJButtonJDialog (jTextFieldMZ8);
        jLabel64 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jComboBox015 = new javax.swing.JComboBox<>();
        jComboBox014 = new javax.swing.JComboBox<>();
        jTextField013 = new javax.swing.JTextField();
        jTextField011 = new javax.swing.JTextField();
        jTextField031 = new javax.swing.JTextField();
        jPanel30 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jComboBox035 = new javax.swing.JComboBox<>();
        jComboBox034 = new javax.swing.JComboBox<>();
        jTextField033 = new javax.swing.JTextField();
        jTextField053 = new javax.swing.JTextField();
        jComboBox054 = new javax.swing.JComboBox<>();
        jComboBox055 = new javax.swing.JComboBox<>();
        jComboBox075 = new javax.swing.JComboBox<>();
        jComboBox074 = new javax.swing.JComboBox<>();
        jComboBox094 = new javax.swing.JComboBox<>();
        jComboBox095 = new javax.swing.JComboBox<>();
        jComboBox115 = new javax.swing.JComboBox<>();
        jComboBox114 = new javax.swing.JComboBox<>();
        jComboBox134 = new javax.swing.JComboBox<>();
        jComboBox135 = new javax.swing.JComboBox<>();
        jComboBox155 = new javax.swing.JComboBox<>();
        jComboBox154 = new javax.swing.JComboBox<>();
        jComboBox174 = new javax.swing.JComboBox<>();
        jComboBox175 = new javax.swing.JComboBox<>();
        jComboBox195 = new javax.swing.JComboBox<>();
        jComboBox194 = new javax.swing.JComboBox<>();
        jTextField193 = new javax.swing.JTextField();
        jTextField173 = new javax.swing.JTextField();
        jTextField153 = new javax.swing.JTextField();
        jTextField133 = new javax.swing.JTextField();
        jTextField113 = new javax.swing.JTextField();
        jTextField093 = new javax.swing.JTextField();
        jTextField073 = new javax.swing.JTextField();
        jTextField191 = new javax.swing.JTextField();
        jTextField171 = new javax.swing.JTextField();
        jTextField151 = new javax.swing.JTextField();
        jTextField131 = new javax.swing.JTextField();
        jTextField111 = new javax.swing.JTextField();
        jTextField091 = new javax.swing.JTextField();
        jTextField071 = new javax.swing.JTextField();
        jTextField051 = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jComboBox012 = new javax.swing.JComboBox<>();
        jComboBox032 = new javax.swing.JComboBox<>();
        jComboBox052 = new javax.swing.JComboBox<>();
        jComboBox072 = new javax.swing.JComboBox<>();
        jComboBox092 = new javax.swing.JComboBox<>();
        jComboBox112 = new javax.swing.JComboBox<>();
        jComboBox132 = new javax.swing.JComboBox<>();
        jComboBox152 = new javax.swing.JComboBox<>();
        jComboBox172 = new javax.swing.JComboBox<>();
        jComboBox192 = new javax.swing.JComboBox<>();
        jPanel31 = new javax.swing.JPanel();
        jComboBox025 = new javax.swing.JComboBox<>();
        jComboBox024 = new javax.swing.JComboBox<>();
        jTextField023 = new javax.swing.JTextField();
        jTextField021 = new javax.swing.JTextField();
        jTextField041 = new javax.swing.JTextField();
        jPanel32 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jComboBox045 = new javax.swing.JComboBox<>();
        jComboBox044 = new javax.swing.JComboBox<>();
        jTextField043 = new javax.swing.JTextField();
        jTextField063 = new javax.swing.JTextField();
        jComboBox064 = new javax.swing.JComboBox<>();
        jComboBox065 = new javax.swing.JComboBox<>();
        jComboBox085 = new javax.swing.JComboBox<>();
        jComboBox084 = new javax.swing.JComboBox<>();
        jComboBox104 = new javax.swing.JComboBox<>();
        jComboBox105 = new javax.swing.JComboBox<>();
        jComboBox125 = new javax.swing.JComboBox<>();
        jComboBox124 = new javax.swing.JComboBox<>();
        jComboBox144 = new javax.swing.JComboBox<>();
        jComboBox145 = new javax.swing.JComboBox<>();
        jComboBox165 = new javax.swing.JComboBox<>();
        jComboBox164 = new javax.swing.JComboBox<>();
        jComboBox184 = new javax.swing.JComboBox<>();
        jComboBox185 = new javax.swing.JComboBox<>();
        jComboBox205 = new javax.swing.JComboBox<>();
        jComboBox204 = new javax.swing.JComboBox<>();
        jTextField203 = new javax.swing.JTextField();
        jTextField183 = new javax.swing.JTextField();
        jTextField163 = new javax.swing.JTextField();
        jTextField143 = new javax.swing.JTextField();
        jTextField123 = new javax.swing.JTextField();
        jTextField103 = new javax.swing.JTextField();
        jTextField083 = new javax.swing.JTextField();
        jTextField201 = new javax.swing.JTextField();
        jTextField181 = new javax.swing.JTextField();
        jTextField161 = new javax.swing.JTextField();
        jTextField141 = new javax.swing.JTextField();
        jTextField121 = new javax.swing.JTextField();
        jTextField101 = new javax.swing.JTextField();
        jTextField081 = new javax.swing.JTextField();
        jTextField061 = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jComboBox182 = new javax.swing.JComboBox<>();
        jComboBox102 = new javax.swing.JComboBox<>();
        jComboBox062 = new javax.swing.JComboBox<>();
        jComboBox162 = new javax.swing.JComboBox<>();
        jComboBox202 = new javax.swing.JComboBox<>();
        jComboBox042 = new javax.swing.JComboBox<>();
        jComboBox022 = new javax.swing.JComboBox<>();
        jComboBox142 = new javax.swing.JComboBox<>();
        jComboBox082 = new javax.swing.JComboBox<>();
        jComboBox122 = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel2.setText("母猪断奶信息：");

        jLabel1.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel1.setText("小猪断奶信息：");

        jLabel6.setForeground(new java.awt.Color(0, 51, 153));
        jLabel6.setText("断奶后所去猪舍");

        jComboBox001.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox001.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox001ActionPerformed(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(0, 51, 153));
        jLabel7.setText("所去栏位");

        jComboBox002.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));
        jComboBox002.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox002ActionPerformed(evt);
            }
        });

        jLabel14.setText("个体编号：");

        jTextFieldMZ1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldMZ1FocusLost(evt);
            }
        });

        jLabel15.setText("当前胎次：");

        jLabel16.setText("断奶时间：");

        jLabel18.setText("断奶头数：");

        jTextFieldMZ5.setText("0");

        jLabel19.setText("断奶窝重：");

        jLabel20.setText("断奶后舍：");

        jLabel21.setText("断奶后栏：");

        jLabel36.setText("状    态：");

        jTextFieldMZ3.setText("断奶状态");

        jLabel37.setText("负 责 人：");

        jLabel38.setText("备    注：");

        jComboBoxMZ6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBoxMZ6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxMZ6ActionPerformed(evt);
            }
        });

        jComboBoxMZ7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBoxMZ9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "张三" }));

        jButton0004.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton0004.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton0004ActionPerformed(evt);
            }
        });

        jLabel64.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(204, 0, 0));
        jLabel64.setText("KG");

        jLabel23.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 0, 0));
        jLabel23.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息处理");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox001, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox002, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(jComboBoxMZ6, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextFieldMZ1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(jComboBoxMZ7, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(11, 11, 11)
                                        .addComponent(jTextFieldMZ8, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton0004, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBoxMZ9, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextFieldMZ10, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(jTextFieldMZ2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextFieldMZ3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextFieldMZ4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextFieldMZ5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel64))))
                            .addComponent(jLabel23))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton0004, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(jTextFieldMZ1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18)
                            .addComponent(jTextFieldMZ4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19)
                            .addComponent(jTextFieldMZ5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldMZ3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel36)
                            .addComponent(jTextFieldMZ2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15)
                            .addComponent(jLabel64))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel37)
                            .addComponent(jLabel38)
                            .addComponent(jTextFieldMZ10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxMZ6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxMZ7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxMZ9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16)
                            .addComponent(jTextFieldMZ8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox001, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox002, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        jComboBox015.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox014.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox014.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox014ActionPerformed(evt);
            }
        });

        jTextField013.setText("0");
        jTextField013.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField013ActionPerformed(evt);
            }
        });

        jTextField011.setText("不存在");
        jTextField011.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField011ActionPerformed(evt);
            }
        });

        jTextField031.setText("不存在");
        jTextField031.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField031ActionPerformed(evt);
            }
        });

        jPanel30.setPreferredSize(new java.awt.Dimension(305, 353));

        jLabel22.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(204, 0, 204));
        jLabel22.setText("个体编号");

        jLabel88.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(204, 0, 204));
        jLabel88.setText("断后状态");

        jLabel89.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(204, 0, 204));
        jLabel89.setText("断奶重量（KG）");

        jLabel90.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(204, 0, 204));
        jLabel90.setText("所去猪舍");

        jLabel91.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel91.setForeground(new java.awt.Color(204, 0, 204));
        jLabel91.setText("所去栏位");

        jLabel4.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 0, 204));
        jLabel4.setText("序号");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel4)
                .addGap(2, 2, 2)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel88)
                .addGap(18, 18, 18)
                .addComponent(jLabel89)
                .addGap(26, 26, 26)
                .addComponent(jLabel90)
                .addGap(26, 26, 26)
                .addComponent(jLabel91)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(jLabel88)
                    .addComponent(jLabel89)
                    .addComponent(jLabel90)
                    .addComponent(jLabel91)
                    .addComponent(jLabel4)))
        );

        jComboBox035.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox034.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox034.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox034ActionPerformed(evt);
            }
        });

        jTextField033.setText("0");
        jTextField033.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField033ActionPerformed(evt);
            }
        });

        jTextField053.setText("0");
        jTextField053.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField053ActionPerformed(evt);
            }
        });

        jComboBox054.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox054.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox054ActionPerformed(evt);
            }
        });

        jComboBox055.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox075.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox074.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox074.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox074ActionPerformed(evt);
            }
        });

        jComboBox094.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox094.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox094ActionPerformed(evt);
            }
        });

        jComboBox095.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox115.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox114.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox114.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox114ActionPerformed(evt);
            }
        });

        jComboBox134.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox134.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox134ActionPerformed(evt);
            }
        });

        jComboBox135.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox155.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox154.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox154.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox154ActionPerformed(evt);
            }
        });

        jComboBox174.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox174.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox174ActionPerformed(evt);
            }
        });

        jComboBox175.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox195.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox194.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox194.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox194ActionPerformed(evt);
            }
        });

        jTextField193.setText("0");
        jTextField193.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField193ActionPerformed(evt);
            }
        });

        jTextField173.setText("0");
        jTextField173.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField173ActionPerformed(evt);
            }
        });

        jTextField153.setText("0");
        jTextField153.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField153ActionPerformed(evt);
            }
        });

        jTextField133.setText("0");
        jTextField133.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField133ActionPerformed(evt);
            }
        });

        jTextField113.setText("0");
        jTextField113.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField113ActionPerformed(evt);
            }
        });

        jTextField093.setText("0");
        jTextField093.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField093ActionPerformed(evt);
            }
        });

        jTextField073.setText("0");
        jTextField073.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField073ActionPerformed(evt);
            }
        });

        jTextField191.setText("不存在");
        jTextField191.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField191ActionPerformed(evt);
            }
        });

        jTextField171.setText("不存在");
        jTextField171.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField171ActionPerformed(evt);
            }
        });

        jTextField151.setText("不存在");
        jTextField151.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField151ActionPerformed(evt);
            }
        });

        jTextField131.setText("不存在");
        jTextField131.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField131ActionPerformed(evt);
            }
        });

        jTextField111.setText("不存在");
        jTextField111.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField111ActionPerformed(evt);
            }
        });

        jTextField091.setText("不存在");
        jTextField091.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField091ActionPerformed(evt);
            }
        });

        jTextField071.setText("不存在");
        jTextField071.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField071ActionPerformed(evt);
            }
        });

        jTextField051.setText("不存在");
        jTextField051.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField051ActionPerformed(evt);
            }
        });

        jLabel44.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 0, 0));
        jLabel44.setText("19");

        jLabel45.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 0, 0));
        jLabel45.setText("17");

        jLabel46.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 0, 0));
        jLabel46.setText("15");

        jLabel47.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 0, 0));
        jLabel47.setText("07");

        jLabel48.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 0, 0));
        jLabel48.setText("09");

        jLabel49.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 0, 0));
        jLabel49.setText("11");

        jLabel50.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 0, 0));
        jLabel50.setText("13");

        jLabel51.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 0, 0));
        jLabel51.setText("01");

        jLabel52.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 0, 0));
        jLabel52.setText("03");

        jLabel53.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 0, 0));
        jLabel53.setText("05");

        jComboBox012.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox012.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox012ActionPerformed(evt);
            }
        });

        jComboBox032.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox032.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox032ActionPerformed(evt);
            }
        });

        jComboBox052.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox052.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox052ActionPerformed(evt);
            }
        });

        jComboBox072.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox072.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox072ActionPerformed(evt);
            }
        });

        jComboBox092.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox092.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox092ActionPerformed(evt);
            }
        });

        jComboBox112.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox112.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox112ActionPerformed(evt);
            }
        });

        jComboBox132.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox132.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox132ActionPerformed(evt);
            }
        });

        jComboBox152.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox152.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox152ActionPerformed(evt);
            }
        });

        jComboBox172.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox172.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox172ActionPerformed(evt);
            }
        });

        jComboBox192.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox192.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox192ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel47)
                                    .addComponent(jLabel48, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel51)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel53)
                                            .addComponent(jLabel52))))
                                .addComponent(jLabel49))
                            .addComponent(jLabel44)
                            .addComponent(jLabel45))
                        .addComponent(jLabel46))
                    .addComponent(jLabel50))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel29Layout.createSequentialGroup()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField091, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField191, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField131, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField111, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField151, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField171, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jComboBox092, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox192, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jComboBox132, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox112, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox152, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox172, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField193, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                            .addComponent(jTextField173, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField153, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField133, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField113, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField093, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox174, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox154, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox134, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox114, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox094, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox194, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jComboBox135, 0, 110, Short.MAX_VALUE)
                                .addComponent(jComboBox155, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBox195, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jComboBox175, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextField053, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel29Layout.createSequentialGroup()
                                            .addComponent(jTextField031, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jComboBox032, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField033))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel29Layout.createSequentialGroup()
                                            .addComponent(jTextField011, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jComboBox012, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTextField013, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jTextField073, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel29Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jComboBox034, 0, 110, Short.MAX_VALUE)
                                            .addComponent(jComboBox014, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jComboBox054, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox074, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addComponent(jTextField051, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox052, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addComponent(jTextField071, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox072, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox115, 0, 110, Short.MAX_VALUE)
                            .addComponent(jComboBox095, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox015, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox035, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox055, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox075, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(27, 27, 27))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                .addComponent(jPanel30, javax.swing.GroupLayout.DEFAULT_SIZE, 486, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel51)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField011, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField013, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox014, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox015, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox012, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField031, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField033, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox034, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox035, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel52)
                            .addComponent(jComboBox032, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField051, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField053, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox054, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox055, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel53)
                            .addComponent(jComboBox052, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField071, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField073, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox074, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox075, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel47)
                            .addComponent(jComboBox072, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addComponent(jTextField091, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel49))
                            .addComponent(jLabel48)
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox092, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField093, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox094, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox095, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox112, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField113, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox114, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox115, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField111, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox132, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField133, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox134, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox135, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField131, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel50))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox152, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField153, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox154, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox155, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField151, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel46))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox172, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField173, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox174, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox175, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField171, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel45))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jComboBox192, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextField193, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextField191, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel44))
                                    .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jComboBox194, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jComboBox195, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jComboBox025.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox024.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox024.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox024ActionPerformed(evt);
            }
        });

        jTextField023.setText("0");
        jTextField023.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField023ActionPerformed(evt);
            }
        });

        jTextField021.setText("不存在");
        jTextField021.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField021ActionPerformed(evt);
            }
        });

        jTextField041.setText("不存在");
        jTextField041.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField041ActionPerformed(evt);
            }
        });

        jPanel32.setPreferredSize(new java.awt.Dimension(305, 353));

        jLabel35.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(204, 0, 204));
        jLabel35.setText("个体编号");

        jLabel92.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel92.setForeground(new java.awt.Color(204, 0, 204));
        jLabel92.setText("断后状态");

        jLabel93.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel93.setForeground(new java.awt.Color(204, 0, 204));
        jLabel93.setText("断奶重量（KG）");

        jLabel94.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel94.setForeground(new java.awt.Color(204, 0, 204));
        jLabel94.setText("所去猪舍");

        jLabel95.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel95.setForeground(new java.awt.Color(204, 0, 204));
        jLabel95.setText("所去栏位");

        jLabel5.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 204));
        jLabel5.setText("序号");

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel92)
                .addGap(18, 18, 18)
                .addComponent(jLabel93)
                .addGap(35, 35, 35)
                .addComponent(jLabel94)
                .addGap(31, 31, 31)
                .addComponent(jLabel95)
                .addGap(111, 111, 111))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel92)
                    .addComponent(jLabel93)
                    .addComponent(jLabel94)
                    .addComponent(jLabel95)
                    .addComponent(jLabel5)))
        );

        jComboBox045.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox044.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox044.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox044ActionPerformed(evt);
            }
        });

        jTextField043.setText("0");
        jTextField043.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField043ActionPerformed(evt);
            }
        });

        jTextField063.setText("0");
        jTextField063.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField063ActionPerformed(evt);
            }
        });

        jComboBox064.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox064.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox064ActionPerformed(evt);
            }
        });

        jComboBox065.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox085.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox084.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox084.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox084ActionPerformed(evt);
            }
        });

        jComboBox104.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox104.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox104ActionPerformed(evt);
            }
        });

        jComboBox105.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox125.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox124.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox124.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox124ActionPerformed(evt);
            }
        });

        jComboBox144.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox144.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox144ActionPerformed(evt);
            }
        });

        jComboBox145.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox165.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox164.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox164.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox164ActionPerformed(evt);
            }
        });

        jComboBox184.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox184.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox184ActionPerformed(evt);
            }
        });

        jComboBox185.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox205.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪栏" }));

        jComboBox204.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "猪舍" }));
        jComboBox204.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox204ActionPerformed(evt);
            }
        });

        jTextField203.setText("0");
        jTextField203.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField203ActionPerformed(evt);
            }
        });

        jTextField183.setText("0");
        jTextField183.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField183ActionPerformed(evt);
            }
        });

        jTextField163.setText("0");
        jTextField163.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField163ActionPerformed(evt);
            }
        });

        jTextField143.setText("0");
        jTextField143.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField143ActionPerformed(evt);
            }
        });

        jTextField123.setText("0");
        jTextField123.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField123ActionPerformed(evt);
            }
        });

        jTextField103.setText("0");
        jTextField103.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField103ActionPerformed(evt);
            }
        });

        jTextField083.setText("0");
        jTextField083.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField083ActionPerformed(evt);
            }
        });

        jTextField201.setText("不存在");
        jTextField201.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField201ActionPerformed(evt);
            }
        });

        jTextField181.setText("不存在");
        jTextField181.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField181ActionPerformed(evt);
            }
        });

        jTextField161.setText("不存在");
        jTextField161.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField161ActionPerformed(evt);
            }
        });

        jTextField141.setText("不存在");
        jTextField141.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField141ActionPerformed(evt);
            }
        });

        jTextField121.setText("不存在");
        jTextField121.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField121ActionPerformed(evt);
            }
        });

        jTextField101.setText("不存在");
        jTextField101.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField101ActionPerformed(evt);
            }
        });

        jTextField081.setText("不存在");
        jTextField081.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField081ActionPerformed(evt);
            }
        });

        jTextField061.setText("不存在");
        jTextField061.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField061ActionPerformed(evt);
            }
        });

        jLabel54.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(255, 0, 0));
        jLabel54.setText("20");

        jLabel55.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 0, 0));
        jLabel55.setText("18");

        jLabel56.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 0, 0));
        jLabel56.setText("16");

        jLabel57.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 0, 0));
        jLabel57.setText("08");

        jLabel58.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 0, 0));
        jLabel58.setText("10");

        jLabel59.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(255, 0, 0));
        jLabel59.setText("12");

        jLabel60.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 0, 0));
        jLabel60.setText("14");

        jLabel61.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(255, 0, 0));
        jLabel61.setText("02");

        jLabel62.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(255, 0, 0));
        jLabel62.setText("04");

        jLabel63.setFont(new java.awt.Font("宋体", 1, 12)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(255, 0, 0));
        jLabel63.setText("06");

        jComboBox182.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox182.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox182ActionPerformed(evt);
            }
        });

        jComboBox102.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox102.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox102ActionPerformed(evt);
            }
        });

        jComboBox062.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox062.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox062ActionPerformed(evt);
            }
        });

        jComboBox162.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox162.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox162ActionPerformed(evt);
            }
        });

        jComboBox202.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox202.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox202ActionPerformed(evt);
            }
        });

        jComboBox042.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox042.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox042ActionPerformed(evt);
            }
        });

        jComboBox022.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox022.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox022ActionPerformed(evt);
            }
        });

        jComboBox142.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox142.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox142ActionPerformed(evt);
            }
        });

        jComboBox082.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox082.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox082ActionPerformed(evt);
            }
        });

        jComboBox122.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "哺乳仔猪" }));
        jComboBox122.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox122ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, 493, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel57)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel59)
                                    .addComponent(jLabel58))
                                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel61)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel63)
                                        .addComponent(jLabel62))))
                            .addComponent(jLabel56)
                            .addComponent(jLabel55)
                            .addComponent(jLabel54)
                            .addComponent(jLabel60))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField101, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField041, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField021, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField061, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField081, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField201, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jTextField141, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField121, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField161, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField181, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jComboBox042, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox022, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox082, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox062, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jComboBox102, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox202, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBox142, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox122, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox162, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox182, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField203, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                            .addComponent(jTextField183, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField163, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField143, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField123, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField103, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField083, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField063, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField043, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField023, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox204, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox184, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox164, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox144, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox124, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox104, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox084, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox064, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox044, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox024, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jComboBox185, 0, 110, Short.MAX_VALUE)
                            .addComponent(jComboBox165, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox145, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox125, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox105, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox085, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox045, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox065, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox205, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox025, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(14, 14, 14))))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField021, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField023, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox024, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox025, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField041, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField043, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox044, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox045, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel62))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField061, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField063, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox064, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox065, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel63))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField081, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField083, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox084, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox085, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel57))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField101, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField103, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox104, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox105, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel58))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField121, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField123, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox124, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox125, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel59))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField141, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField143, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox144, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox145, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel60))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField161, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField163, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox164, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox165, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel56))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField181, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField183, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox184, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox185, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel55))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField201, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField203, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox204, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox205, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel54)))
                    .addComponent(jLabel61)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jComboBox022, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox042, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox062, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox082, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox102, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox122, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox142, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox162, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox182, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox202, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.white, new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 287, Short.MAX_VALUE)
        );

        jLabel3.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel3.setText("断奶信息登记");

        jButton3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton3.setText("确定提交");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton5.setText("退出输入");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(478, 478, 478)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGap(288, 288, 288)
                                    .addComponent(jButton3)
                                    .addGap(181, 181, 181)
                                    .addComponent(jButton5))))
                        .addGap(20, 20, 20))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(468, 468, 468)
                .addComponent(jLabel3)
                .addGap(468, 468, 468))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel3)
                .addGap(5, 5, 5)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5)
                    .addComponent(jButton3))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField061ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField061ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField061ActionPerformed

    private void jTextField081ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField081ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField081ActionPerformed

    private void jTextField101ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField101ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField101ActionPerformed

    private void jTextField121ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField121ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField121ActionPerformed

    private void jTextField141ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField141ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField141ActionPerformed

    private void jTextField161ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField161ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField161ActionPerformed

    private void jTextField181ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField181ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField181ActionPerformed

    private void jTextField201ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField201ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField201ActionPerformed

    private void jTextField083ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField083ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField083ActionPerformed

    private void jTextField103ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField103ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField103ActionPerformed

    private void jTextField123ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField123ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField123ActionPerformed

    private void jTextField143ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField143ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField143ActionPerformed

    private void jTextField163ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField163ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField163ActionPerformed

    private void jTextField183ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField183ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField183ActionPerformed

    private void jTextField203ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField203ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField203ActionPerformed

    private void jTextField063ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField063ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField063ActionPerformed

    private void jTextField043ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField043ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField043ActionPerformed

    private void jTextField041ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField041ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField041ActionPerformed

    private void jTextField021ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField021ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField021ActionPerformed

    private void jTextField023ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField023ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField023ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        WeaningMapper mapper0 = sqlSession.getMapper(WeaningMapper.class);
        PiggeryMapper mapper2 = sqlSession.getMapper(PiggeryMapper.class);
        List<Piggery> piggerList = mapper2.selectAll();
        String fzr = null;

        String number = jTextFieldMZ1.getText();
        if (number.length() != 15 && number.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加母猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        Childbirth childbirth = mapper0.selectByIdAndFm2("%" + number);

        if (childbirth == null) {
            JOptionPane.showMessageDialog(null, "您添加种母猪个体编号不存在或者不是母猪不是哺乳状态!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在
        SelebithMapper mapper1 = sqlSession.getMapper(SelebithMapper.class);
        List<Selebith> SelebithList = mapper0.selectAllZz(childbirth.getR_animal(), String.valueOf(childbirth.getTc()));

        Selebith selebithMZ = mapper1.selectById("%" + number);

        childbirth.setDnwz(0.0);

        for (int i = 0; i < SelebithList.size(); i++) {
            switch (i) {
                case 0:
                    if (jTextField013.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号01 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox014)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }
                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox012)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField013.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox014)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox015)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));
                    break;
                case 1:
                    if (jTextField023.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号02 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox024)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox022)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField023.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox024)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox025)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 2:
                    if (jTextField033.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号03 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox034)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox032)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField033.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox034)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox035)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 3:
                    if (jTextField043.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号04 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox044)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox042)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField043.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox044)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox045)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 4:
                    if (jTextField053.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号05 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox054)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox052)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField053.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox054)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox055)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 5:
                    if (jTextField063.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号06 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox064)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox062)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField063.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox064)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox065)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 6:
                    if (jTextField073.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号07 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox074)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox072)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField073.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox074)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox075)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 7:
                    if (jTextField083.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号08 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox084)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox082)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField083.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox084)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox085)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 8:
                    if (jTextField093.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号09 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox094)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox092)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField093.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox094)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox095)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 9:
                    if (jTextField103.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号10 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox104)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox102)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField103.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox104)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox105)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 10:
                    if (jTextField113.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号11 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox114)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox112)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField113.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox114)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox115)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 11:
                    if (jTextField123.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号12 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox124)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox122)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField123.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox124)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox125)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 12:
                    if (jTextField133.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号13 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox134)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox132)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField133.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox134)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox135)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 13:
                    if (jTextField143.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号14 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox144)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox142)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField143.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox144)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox145)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 14:
                    if (jTextField153.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号15 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox154)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox152)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField153.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox154)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox155)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 15:
                    if (jTextField163.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号16 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox164)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox162)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField163.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox164)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox165)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 16:
                    if (jTextField173.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号17 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox174)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox172)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField173.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox174)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox175)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 17:
                    if (jTextField183.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号18 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox184)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox182)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField183.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox184)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox185)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 18:
                    if (jTextField193.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号19 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox194)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox192)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField193.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox194)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox195)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
                case 19:
                    if (jTextField203.getText().equals("0") && !SelebithList.get(i).getR_curmark().equals("10") && !SelebithList.get(i).getR_curmark().equals("11")) {
                        JOptionPane.showMessageDialog(null, "序号20 仔猪断奶重不能为0!", "系统信息", JOptionPane.WARNING_MESSAGE);
                        sqlSession.close();
                        return;
                    }
                    for (int j = 0; j < piggerList.size(); j++) {
                        if (piggerList.get(j).getNumber().equals(piggeryNametoIdSmap.get(JComboBoxString(jComboBox204)))) {
                            fzr = piggerList.get(j).getFeeder();
                            break;
                        }
                    }

                    SelebithList.get(i).setR_curmark(swintypeNametoIdSmap.get(JComboBoxString(jComboBox202)));//当前状态
                    SelebithList.get(i).setR_weandate(jTextFieldMZ8.getText());//断奶时间
                    SelebithList.get(i).setR_weanday(String.valueOf(calInterval(SelebithList.get(i).getR_fdate(), SelebithList.get(i).getR_weandate())));//断奶日龄
                    SelebithList.get(i).setR_weanwt(jTextField203.getText());//断奶重
                    SelebithList.get(i).setNifzb("1");
                    SelebithList.get(i).setZbffenceid(SelebithList.get(i).getR_pcage());//转前栏位
                    SelebithList.get(i).setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBox204)));//当前舍
                    SelebithList.get(i).setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBox205)));//当前栏
                    SelebithList.get(i).setZbafenceid(SelebithList.get(i).getR_pcage());//转后栏位
                    SelebithList.get(i).setZbfzr(fzr);//负责人
                    childbirth.setDnwz(childbirth.getDnwz() + Double.parseDouble(SelebithList.get(i).getR_weanwt()));

                    break;
            }
        }
        childbirth.setOutfenceid(fenceNametoIdSmap.get(JComboBoxString(jComboBoxMZ7)));
        childbirth.setDnrq(jTextFieldMZ8.getText());
        childbirth.setDnrl(calInterval(childbirth.getCzrq(), childbirth.getDnrq()));
        childbirth.setDnts(SelebithList.size());
        childbirth.setEmployeeid(employeeNametoIdSmap.get(JComboBoxString(jComboBoxMZ9)));
        childbirth.setZt("2");

        selebithMZ.setR_cage(piggeryNametoIdSmap.get(JComboBoxString(jComboBoxMZ6)));
        selebithMZ.setR_pcage(fenceNametoIdSmap.get(JComboBoxString(jComboBoxMZ7)));
        selebithMZ.setR_curmark("8");

        mapper0.updateByid(childbirth);
        mapper1.updateByTypeid(selebithMZ);//母猪
        for (int i = 0; i < SelebithList.size(); i++) {
            mapper1.updateByTypeid(SelebithList.get(i));//小猪
        }
        sqlSession.commit();
        JOptionPane.showMessageDialog(null, "添加成功!", "系统信息", JOptionPane.WARNING_MESSAGE);
        sqlSession.close();

        //添加后更新数据格式
        MainApp.weaningPageModel = new WeaningPageModel(14, weaningMapperPlus.SelectCount(), weaningMapperPlus, false);
        MainApp.Weaningpage(weaningPageModel.getTopPageNo());

        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton0004ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton0004ActionPerformed

    }//GEN-LAST:event_jButton0004ActionPerformed

    private void jTextFieldMZ1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldMZ1FocusLost
        if (flagua == "upp") {
            return;
        }
        //｛提取猪之编号
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
        String number = jTextFieldMZ1.getText();
        if (number.length() != 15 && number.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加母猪编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Childbirth childbirth = weaningMapper.selectByIdAndFm2("%" + number);

        if (childbirth == null) {
            JOptionPane.showMessageDialog(null, "您添加种母猪个体编号不存在或者不是母猪不是哺乳状态!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在

        List<Selebith> SelebithList = weaningMapper.selectAllZz(childbirth.getR_animal(), String.valueOf(childbirth.getTc()));
        jTextFieldMZ2.setText(String.valueOf(childbirth.getTc()));
        childbirth.setDnts(childbirth.getCzhs());
        for (int i = 0; i < SelebithList.size(); i++) {
            switch (i) {
                case 0:
                    jTextField011.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox012.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField011.setEnabled(false);
                        jComboBox012.setEnabled(false);
                        jTextField013.setEnabled(false);
                        jComboBox014.setEnabled(false);
                        jComboBox015.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);
                    }
                    break;
                case 1:
                    jTextField021.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox022.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField021.setEnabled(false);
                        jComboBox022.setEnabled(false);
                        jTextField023.setEnabled(false);
                        jComboBox024.setEnabled(false);
                        jComboBox025.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 2:
                    jTextField031.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox032.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField031.setEnabled(false);
                        jComboBox032.setEnabled(false);
                        jTextField033.setEnabled(false);
                        jComboBox034.setEnabled(false);
                        jComboBox035.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 3:
                    jTextField041.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox042.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField041.setEnabled(false);
                        jComboBox042.setEnabled(false);
                        jTextField043.setEnabled(false);
                        jComboBox044.setEnabled(false);
                        jComboBox045.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 4:
                    jTextField051.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox052.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField051.setEnabled(false);
                        jComboBox052.setEnabled(false);
                        jTextField053.setEnabled(false);
                        jComboBox054.setEnabled(false);
                        jComboBox055.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 5:
                    jTextField061.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox062.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField061.setEnabled(false);
                        jComboBox062.setEnabled(false);
                        jTextField063.setEnabled(false);
                        jComboBox064.setEnabled(false);
                        jComboBox065.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 6:
                    jTextField071.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox072.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField071.setEnabled(false);
                        jComboBox072.setEnabled(false);
                        jTextField073.setEnabled(false);
                        jComboBox074.setEnabled(false);
                        jComboBox075.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 7:
                    jTextField081.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox082.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField081.setEnabled(false);
                        jComboBox082.setEnabled(false);
                        jTextField083.setEnabled(false);
                        jComboBox084.setEnabled(false);
                        jComboBox085.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 8:
                    jTextField091.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox092.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField091.setEnabled(false);
                        jComboBox092.setEnabled(false);
                        jTextField093.setEnabled(false);
                        jComboBox094.setEnabled(false);
                        jComboBox095.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 9:
                    jTextField101.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox102.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField101.setEnabled(false);
                        jComboBox102.setEnabled(false);
                        jTextField103.setEnabled(false);
                        jComboBox104.setEnabled(false);
                        jComboBox105.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 10:
                    jTextField111.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox112.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField111.setEnabled(false);
                        jComboBox112.setEnabled(false);
                        jTextField113.setEnabled(false);
                        jComboBox114.setEnabled(false);
                        jComboBox115.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 11:
                    jTextField121.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox122.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField121.setEnabled(false);
                        jComboBox122.setEnabled(false);
                        jTextField123.setEnabled(false);
                        jComboBox124.setEnabled(false);
                        jComboBox125.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 12:
                    jTextField131.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox132.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField131.setEnabled(false);
                        jComboBox132.setEnabled(false);
                        jTextField133.setEnabled(false);
                        jComboBox134.setEnabled(false);
                        jComboBox135.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 13:
                    jTextField141.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox142.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField141.setEnabled(false);
                        jComboBox142.setEnabled(false);
                        jTextField143.setEnabled(false);
                        jComboBox144.setEnabled(false);
                        jComboBox145.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 14:
                    jTextField151.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox152.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField151.setEnabled(false);
                        jComboBox152.setEnabled(false);
                        jTextField153.setEnabled(false);
                        jComboBox154.setEnabled(false);
                        jComboBox155.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 15:
                    jTextField161.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox162.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField161.setEnabled(false);
                        jComboBox162.setEnabled(false);
                        jTextField163.setEnabled(false);
                        jComboBox164.setEnabled(false);
                        jComboBox165.setEnabled(false);
                    }
                    break;
                case 16:
                    jTextField171.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox172.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField171.setEnabled(false);
                        jComboBox172.setEnabled(false);
                        jTextField173.setEnabled(false);
                        jComboBox174.setEnabled(false);
                        jComboBox175.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 17:
                    jTextField181.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox182.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField181.setEnabled(false);
                        jComboBox182.setEnabled(false);
                        jTextField183.setEnabled(false);
                        jComboBox184.setEnabled(false);
                        jComboBox185.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 18:
                    jTextField191.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox192.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField191.setEnabled(false);
                        jComboBox192.setEnabled(false);
                        jTextField193.setEnabled(false);
                        jComboBox194.setEnabled(false);
                        jComboBox195.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);

                    }
                    break;
                case 19:
                    jTextField201.setText(SelebithList.get(i).getR_animal());
                    if (SelebithList.get(i).getR_curmark().equals("10") || SelebithList.get(i).getR_curmark().equals("11")) {
                        jComboBox202.setModel(new javax.swing.DefaultComboBoxModel(swintypeThingsmap.get(SelebithList.get(i).getR_curmark())));//销售或死亡
                        jTextField201.setEnabled(false);
                        jComboBox202.setEnabled(false);
                        jTextField203.setEnabled(false);
                        jComboBox204.setEnabled(false);
                        jComboBox205.setEnabled(false);
                        childbirth.setDnts(childbirth.getDnts() - 1);
                    }
                    break;
            }
            if ((i + 1) == SelebithList.size()) {
                switch (i) {

                    case 0:
                        jTextField021.setEnabled(false);
                        jComboBox022.setEnabled(false);
                        jTextField023.setEnabled(false);
                        jComboBox024.setEnabled(false);
                        jComboBox025.setEnabled(false);
                    case 1:
                        jTextField031.setEnabled(false);
                        jComboBox032.setEnabled(false);
                        jTextField033.setEnabled(false);
                        jComboBox034.setEnabled(false);
                        jComboBox035.setEnabled(false);
                    case 2:
                        jTextField041.setEnabled(false);
                        jComboBox042.setEnabled(false);
                        jTextField043.setEnabled(false);
                        jComboBox044.setEnabled(false);
                        jComboBox045.setEnabled(false);
                    case 3:
                        jTextField051.setEnabled(false);
                        jComboBox052.setEnabled(false);
                        jTextField053.setEnabled(false);
                        jComboBox054.setEnabled(false);
                        jComboBox055.setEnabled(false);
                    case 4:
                        jTextField061.setEnabled(false);
                        jComboBox062.setEnabled(false);
                        jTextField063.setEnabled(false);
                        jComboBox064.setEnabled(false);
                        jComboBox065.setEnabled(false);
                    case 5:
                        jTextField071.setEnabled(false);
                        jComboBox072.setEnabled(false);
                        jTextField073.setEnabled(false);
                        jComboBox074.setEnabled(false);
                        jComboBox075.setEnabled(false);
                    case 6:
                        jTextField081.setEnabled(false);
                        jComboBox082.setEnabled(false);
                        jTextField083.setEnabled(false);
                        jComboBox084.setEnabled(false);
                        jComboBox085.setEnabled(false);
                    case 7:
                        jTextField091.setEnabled(false);
                        jComboBox092.setEnabled(false);
                        jTextField093.setEnabled(false);
                        jComboBox094.setEnabled(false);
                        jComboBox095.setEnabled(false);
                    case 8:
                        jTextField101.setEnabled(false);
                        jComboBox102.setEnabled(false);
                        jTextField103.setEnabled(false);
                        jComboBox104.setEnabled(false);
                        jComboBox105.setEnabled(false);
                    case 9:
                        jTextField111.setEnabled(false);
                        jComboBox112.setEnabled(false);
                        jTextField113.setEnabled(false);
                        jComboBox114.setEnabled(false);
                        jComboBox115.setEnabled(false);
                    case 10:
                        jTextField121.setEnabled(false);
                        jComboBox122.setEnabled(false);
                        jTextField123.setEnabled(false);
                        jComboBox124.setEnabled(false);
                        jComboBox125.setEnabled(false);
                    case 11:
                        jTextField131.setEnabled(false);
                        jComboBox132.setEnabled(false);
                        jTextField133.setEnabled(false);
                        jComboBox134.setEnabled(false);
                        jComboBox135.setEnabled(false);
                    case 12:
                        jTextField141.setEnabled(false);
                        jComboBox142.setEnabled(false);
                        jTextField143.setEnabled(false);
                        jComboBox144.setEnabled(false);
                        jComboBox145.setEnabled(false);
                    case 13:
                        jTextField151.setEnabled(false);
                        jComboBox152.setEnabled(false);
                        jTextField153.setEnabled(false);
                        jComboBox154.setEnabled(false);
                        jComboBox155.setEnabled(false);
                    case 14:
                        jTextField161.setEnabled(false);
                        jComboBox162.setEnabled(false);
                        jTextField163.setEnabled(false);
                        jComboBox164.setEnabled(false);
                        jComboBox165.setEnabled(false);
                    case 15:
                        jTextField171.setEnabled(false);
                        jComboBox172.setEnabled(false);
                        jTextField173.setEnabled(false);
                        jComboBox174.setEnabled(false);
                        jComboBox175.setEnabled(false);
                    case 16:
                        jTextField181.setEnabled(false);
                        jComboBox182.setEnabled(false);
                        jTextField183.setEnabled(false);
                        jComboBox184.setEnabled(false);
                        jComboBox185.setEnabled(false);
                    case 17:
                        jTextField191.setEnabled(false);
                        jComboBox192.setEnabled(false);
                        jTextField193.setEnabled(false);
                        jComboBox194.setEnabled(false);
                        jComboBox195.setEnabled(false);
                    case 18:
                        jTextField201.setEnabled(false);
                        jComboBox202.setEnabled(false);
                        jTextField203.setEnabled(false);
                        jComboBox204.setEnabled(false);
                        jComboBox205.setEnabled(false);
                }
            }
        }

        jTextFieldMZ4.setText(String.valueOf(childbirth.getDnts()));

        sqlSession.close();
    }//GEN-LAST:event_jTextFieldMZ1FocusLost

    private void jComboBoxMZ6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxMZ6ActionPerformed
        String name = JComboBoxString(jComboBoxMZ6);

        String id = null;
        String fzr = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
                fzr = piggery.get(i).getFeeder();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBoxMZ7.removeAll();
        jComboBoxMZ7.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBoxMZ9.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsmap.get(fzr)));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxMZ6ActionPerformed

    private void jComboBox001ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox001ActionPerformed
        String name = JComboBoxString(jComboBox001);
        String[] things5 = new String[20];
        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            things5[i] = piggery.get(i).getCategory();
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
                String temp = things5[0];
                things5[0] = things5[i];
                things5[i] = temp;
            }
        }
        jComboBox014.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox024.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox034.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox044.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox054.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox064.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox074.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox084.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox094.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox104.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox114.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox124.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox134.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox144.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox154.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox164.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox174.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox184.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox194.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox204.setModel(new javax.swing.DefaultComboBoxModel(things5));

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox002.removeAll();
        jComboBox002.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox015.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox025.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox035.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox045.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox055.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox065.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox075.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox085.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox095.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox105.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox115.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox125.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox135.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox145.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox155.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox165.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox175.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox185.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox195.setModel(new javax.swing.DefaultComboBoxModel(things6));
        jComboBox205.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox001ActionPerformed

    private void jComboBox024ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox024ActionPerformed
        String name = JComboBoxString(jComboBox024);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox025.removeAll();
        jComboBox025.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox024ActionPerformed

    private void jComboBox044ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox044ActionPerformed
        String name = JComboBoxString(jComboBox044);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox045.removeAll();
        jComboBox045.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox044ActionPerformed

    private void jComboBox064ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox064ActionPerformed
        String name = JComboBoxString(jComboBox064);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox065.removeAll();
        jComboBox065.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox064ActionPerformed

    private void jComboBox084ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox084ActionPerformed
        String name = JComboBoxString(jComboBox084);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox085.removeAll();
        jComboBox085.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox084ActionPerformed

    private void jComboBox104ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox104ActionPerformed
        String name = JComboBoxString(jComboBox104);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox105.removeAll();
        jComboBox105.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox104ActionPerformed

    private void jComboBox124ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox124ActionPerformed
        String name = JComboBoxString(jComboBox124);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox125.removeAll();
        jComboBox125.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox124ActionPerformed

    private void jComboBox144ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox144ActionPerformed
        String name = JComboBoxString(jComboBox144);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox145.removeAll();
        jComboBox145.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox144ActionPerformed

    private void jComboBox164ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox164ActionPerformed
        String name = JComboBoxString(jComboBox164);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox165.removeAll();
        jComboBox165.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox164ActionPerformed

    private void jComboBox184ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox184ActionPerformed
        String name = JComboBoxString(jComboBox184);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox185.removeAll();
        jComboBox185.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox184ActionPerformed

    private void jComboBox204ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox204ActionPerformed
        String name = JComboBoxString(jComboBox204);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox205.removeAll();
        jComboBox205.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox204ActionPerformed

    private void jComboBox002ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox002ActionPerformed

        String[] things5 = fenceThingsmap.get(JComboBoxString(jComboBox002));

        jComboBox015.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox025.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox035.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox045.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox055.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox065.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox075.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox085.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox095.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox105.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox115.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox125.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox135.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox145.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox155.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox165.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox175.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox185.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox195.setModel(new javax.swing.DefaultComboBoxModel(things5));
        jComboBox205.setModel(new javax.swing.DefaultComboBoxModel(things5));

        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox002ActionPerformed

    private void jComboBox192ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox192ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox192ActionPerformed

    private void jComboBox172ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox172ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox172ActionPerformed

    private void jComboBox152ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox152ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox152ActionPerformed

    private void jComboBox132ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox132ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox132ActionPerformed

    private void jComboBox112ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox112ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox112ActionPerformed

    private void jComboBox092ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox092ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox092ActionPerformed

    private void jComboBox072ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox072ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox072ActionPerformed

    private void jComboBox052ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox052ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox052ActionPerformed

    private void jComboBox032ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox032ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox032ActionPerformed

    private void jComboBox012ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox012ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox012ActionPerformed

    private void jTextField051ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField051ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField051ActionPerformed

    private void jTextField071ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField071ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField071ActionPerformed

    private void jTextField091ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField091ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField091ActionPerformed

    private void jTextField111ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField111ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField111ActionPerformed

    private void jTextField131ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField131ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField131ActionPerformed

    private void jTextField151ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField151ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField151ActionPerformed

    private void jTextField171ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField171ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField171ActionPerformed

    private void jTextField191ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField191ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField191ActionPerformed

    private void jTextField073ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField073ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField073ActionPerformed

    private void jTextField093ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField093ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField093ActionPerformed

    private void jTextField113ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField113ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField113ActionPerformed

    private void jTextField133ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField133ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField133ActionPerformed

    private void jTextField153ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField153ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField153ActionPerformed

    private void jTextField173ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField173ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField173ActionPerformed

    private void jTextField193ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField193ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField193ActionPerformed

    private void jComboBox194ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox194ActionPerformed
        String name = JComboBoxString(jComboBox194);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox195.removeAll();
        jComboBox195.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox194ActionPerformed

    private void jComboBox174ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox174ActionPerformed
        String name = JComboBoxString(jComboBox174);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox175.removeAll();
        jComboBox175.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox174ActionPerformed

    private void jComboBox154ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox154ActionPerformed
        String name = JComboBoxString(jComboBox154);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox155.removeAll();
        jComboBox155.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox154ActionPerformed

    private void jComboBox134ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox134ActionPerformed
        String name = JComboBoxString(jComboBox134);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox135.removeAll();
        jComboBox135.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox134ActionPerformed

    private void jComboBox114ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox114ActionPerformed
        String name = JComboBoxString(jComboBox114);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox115.removeAll();
        jComboBox115.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox114ActionPerformed

    private void jComboBox094ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox094ActionPerformed
        String name = JComboBoxString(jComboBox094);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox095.removeAll();
        jComboBox095.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox094ActionPerformed

    private void jComboBox074ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox074ActionPerformed
        String name = JComboBoxString(jComboBox074);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox075.removeAll();
        jComboBox075.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox074ActionPerformed

    private void jComboBox054ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox054ActionPerformed
        String name = JComboBoxString(jComboBox054);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox055.removeAll();
        jComboBox055.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox054ActionPerformed

    private void jTextField053ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField053ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField053ActionPerformed

    private void jTextField033ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField033ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField033ActionPerformed

    private void jComboBox034ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox034ActionPerformed
        String name = JComboBoxString(jComboBox034);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox035.removeAll();
        jComboBox035.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox034ActionPerformed

    private void jTextField031ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField031ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField031ActionPerformed

    private void jTextField011ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField011ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField011ActionPerformed

    private void jTextField013ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField013ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField013ActionPerformed

    private void jComboBox014ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox014ActionPerformed
        String name = JComboBoxString(jComboBox014);

        String id = null;
        for (int i = 0; i < piggery.size(); i++) {
            if (name.equals(piggery.get(i).getCategory())) {
                id = piggery.get(i).getNumber();
            }
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
        List<Fence> fence = mapper6.selectAllById(id);
        String[] things6 = new String[fence.size()];
        for (int i = 0; i < fence.size(); i++) {
            things6[i] = fence.get(i).getFencename();
        }
        jComboBox015.removeAll();
        jComboBox015.setModel(new javax.swing.DefaultComboBoxModel(things6));
        sqlSession.close();         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox014ActionPerformed

    private void jComboBox022ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox022ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox022ActionPerformed

    private void jComboBox042ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox042ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox042ActionPerformed

    private void jComboBox062ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox062ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox062ActionPerformed

    private void jComboBox082ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox082ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox082ActionPerformed

    private void jComboBox102ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox102ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox102ActionPerformed

    private void jComboBox122ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox122ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox122ActionPerformed

    private void jComboBox142ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox142ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox142ActionPerformed

    private void jComboBox162ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox162ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox162ActionPerformed

    private void jComboBox182ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox182ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox182ActionPerformed

    private void jComboBox202ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox202ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox202ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton0004;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox001;
    private javax.swing.JComboBox<String> jComboBox002;
    private javax.swing.JComboBox<String> jComboBox012;
    private javax.swing.JComboBox<String> jComboBox014;
    private javax.swing.JComboBox<String> jComboBox015;
    private javax.swing.JComboBox<String> jComboBox022;
    private javax.swing.JComboBox<String> jComboBox024;
    private javax.swing.JComboBox<String> jComboBox025;
    private javax.swing.JComboBox<String> jComboBox032;
    private javax.swing.JComboBox<String> jComboBox034;
    private javax.swing.JComboBox<String> jComboBox035;
    private javax.swing.JComboBox<String> jComboBox042;
    private javax.swing.JComboBox<String> jComboBox044;
    private javax.swing.JComboBox<String> jComboBox045;
    private javax.swing.JComboBox<String> jComboBox052;
    private javax.swing.JComboBox<String> jComboBox054;
    private javax.swing.JComboBox<String> jComboBox055;
    private javax.swing.JComboBox<String> jComboBox062;
    private javax.swing.JComboBox<String> jComboBox064;
    private javax.swing.JComboBox<String> jComboBox065;
    private javax.swing.JComboBox<String> jComboBox072;
    private javax.swing.JComboBox<String> jComboBox074;
    private javax.swing.JComboBox<String> jComboBox075;
    private javax.swing.JComboBox<String> jComboBox082;
    private javax.swing.JComboBox<String> jComboBox084;
    private javax.swing.JComboBox<String> jComboBox085;
    private javax.swing.JComboBox<String> jComboBox092;
    private javax.swing.JComboBox<String> jComboBox094;
    private javax.swing.JComboBox<String> jComboBox095;
    private javax.swing.JComboBox<String> jComboBox102;
    private javax.swing.JComboBox<String> jComboBox104;
    private javax.swing.JComboBox<String> jComboBox105;
    private javax.swing.JComboBox<String> jComboBox112;
    private javax.swing.JComboBox<String> jComboBox114;
    private javax.swing.JComboBox<String> jComboBox115;
    private javax.swing.JComboBox<String> jComboBox122;
    private javax.swing.JComboBox<String> jComboBox124;
    private javax.swing.JComboBox<String> jComboBox125;
    private javax.swing.JComboBox<String> jComboBox132;
    private javax.swing.JComboBox<String> jComboBox134;
    private javax.swing.JComboBox<String> jComboBox135;
    private javax.swing.JComboBox<String> jComboBox142;
    private javax.swing.JComboBox<String> jComboBox144;
    private javax.swing.JComboBox<String> jComboBox145;
    private javax.swing.JComboBox<String> jComboBox152;
    private javax.swing.JComboBox<String> jComboBox154;
    private javax.swing.JComboBox<String> jComboBox155;
    private javax.swing.JComboBox<String> jComboBox162;
    private javax.swing.JComboBox<String> jComboBox164;
    private javax.swing.JComboBox<String> jComboBox165;
    private javax.swing.JComboBox<String> jComboBox172;
    private javax.swing.JComboBox<String> jComboBox174;
    private javax.swing.JComboBox<String> jComboBox175;
    private javax.swing.JComboBox<String> jComboBox182;
    private javax.swing.JComboBox<String> jComboBox184;
    private javax.swing.JComboBox<String> jComboBox185;
    private javax.swing.JComboBox<String> jComboBox192;
    private javax.swing.JComboBox<String> jComboBox194;
    private javax.swing.JComboBox<String> jComboBox195;
    private javax.swing.JComboBox<String> jComboBox202;
    private javax.swing.JComboBox<String> jComboBox204;
    private javax.swing.JComboBox<String> jComboBox205;
    private javax.swing.JComboBox<String> jComboBoxMZ6;
    private javax.swing.JComboBox<String> jComboBoxMZ7;
    private javax.swing.JComboBox<String> jComboBoxMZ9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JTextField jTextField011;
    private javax.swing.JTextField jTextField013;
    private javax.swing.JTextField jTextField021;
    private javax.swing.JTextField jTextField023;
    private javax.swing.JTextField jTextField031;
    private javax.swing.JTextField jTextField033;
    private javax.swing.JTextField jTextField041;
    private javax.swing.JTextField jTextField043;
    private javax.swing.JTextField jTextField051;
    private javax.swing.JTextField jTextField053;
    private javax.swing.JTextField jTextField061;
    private javax.swing.JTextField jTextField063;
    private javax.swing.JTextField jTextField071;
    private javax.swing.JTextField jTextField073;
    private javax.swing.JTextField jTextField081;
    private javax.swing.JTextField jTextField083;
    private javax.swing.JTextField jTextField091;
    private javax.swing.JTextField jTextField093;
    private javax.swing.JTextField jTextField101;
    private javax.swing.JTextField jTextField103;
    private javax.swing.JTextField jTextField111;
    private javax.swing.JTextField jTextField113;
    private javax.swing.JTextField jTextField121;
    private javax.swing.JTextField jTextField123;
    private javax.swing.JTextField jTextField131;
    private javax.swing.JTextField jTextField133;
    private javax.swing.JTextField jTextField141;
    private javax.swing.JTextField jTextField143;
    private javax.swing.JTextField jTextField151;
    private javax.swing.JTextField jTextField153;
    private javax.swing.JTextField jTextField161;
    private javax.swing.JTextField jTextField163;
    private javax.swing.JTextField jTextField171;
    private javax.swing.JTextField jTextField173;
    private javax.swing.JTextField jTextField181;
    private javax.swing.JTextField jTextField183;
    private javax.swing.JTextField jTextField191;
    private javax.swing.JTextField jTextField193;
    private javax.swing.JTextField jTextField201;
    private javax.swing.JTextField jTextField203;
    private javax.swing.JTextField jTextFieldMZ1;
    private javax.swing.JTextField jTextFieldMZ10;
    private javax.swing.JTextField jTextFieldMZ2;
    private javax.swing.JTextField jTextFieldMZ3;
    private javax.swing.JTextField jTextFieldMZ4;
    private javax.swing.JTextField jTextFieldMZ5;
    private javax.swing.JTextField jTextFieldMZ8;
    // End of variables declaration//GEN-END:variables
}
