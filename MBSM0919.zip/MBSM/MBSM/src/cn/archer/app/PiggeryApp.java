/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.app;

import static cn.archer.app.MainApp.BRZZPiggeryList;
import static cn.archer.app.MainApp.BYPiggeryList;
import static cn.archer.app.MainApp.HBPiggeryList;
import static cn.archer.app.MainApp.YFPiggeryList;
import static cn.archer.app.MainApp.employeeIdtoNameSmap;
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeeSYYThingsShow;
import static cn.archer.app.MainApp.employeeSYYThingsmap;
import static cn.archer.app.MainApp.pigBYCategoryThingsShow;
import static cn.archer.app.MainApp.pigCategoryThingsShow;
import static cn.archer.app.MainApp.pigHBCategoryThingsShow;
import static cn.archer.app.MainApp.pigYFCategoryThingsShow;
import static cn.archer.app.MainApp.piggeryIdtoNameSmap;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.piggeryThingsShow;
import static cn.archer.app.MainApp.piggeryThingsmap;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.pojo.FenceTemp;
import cn.archer.pojo.Piggery;
import static cn.archer.utils.MyStaticMethod.ToStringNum4;
import cn.archer.utils.MybatisUtil;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import cn.archer.mapper.FenceTempMapper;
import cn.archer.mapper.ZslbMapper;
import cn.archer.pojo.Zslb;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class PiggeryApp extends javax.swing.JDialog {

    private VarietiesData varietiesData;
    private String flagua;
    private String formid0;

    /**
     * Creates new form FormApp
     */
    public PiggeryApp(VarietiesData varietiesData, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.setTitle("场内圈舍");
        flagua = "add";
        this.varietiesData = varietiesData;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceTempMapper mapper0 = sqlSession.getMapper(FenceTempMapper.class);
        FenceTemp fencetemp = mapper0.selectByTypeid(1);
        jTextField1.setText("S" + String.valueOf(fencetemp.getCategoryid()));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsShow));
        ZslbMapper mapper1 = sqlSession.getMapper(ZslbMapper.class);
        List<Zslb> zslblist;
        zslblist = mapper1.selectAll();

        String[] zslbThingsShow = new String[zslblist.size()];
        for (int i = 0; i < zslblist.size(); i++) {
            zslbThingsShow[i] = zslblist.get(i).getTypename();
        }
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(zslbThingsShow));

        sqlSession.close();
        jTextField1.setEditable(false);

    }

    public PiggeryApp(VarietiesData varietiesData, String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.setTitle("场内圈舍");
        flagua = "upp";
        this.formid0 = farmid0;
        this.varietiesData = varietiesData;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        PiggeryMapper mapper = sqlSession.getMapper(PiggeryMapper.class);
        Piggery piggery = mapper.selectByPiggeryid(farmid0);
        jTextField1.setText(piggery.getNumber());
        jTextField2.setText(piggery.getCategory());
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeeSYYThingsmap.get(piggery.getFeeder())));
        jTextField4.setText(piggery.getStatue());
        jTextField5.setText(piggery.getVariety());
        ZslbMapper mapper1 = sqlSession.getMapper(ZslbMapper.class);
        List<Zslb> zslblist;
        zslblist = mapper1.selectAll();
        String[] zslbThingsShow = new String[zslblist.size()];
        for (int i = 0; i < zslblist.size(); i++) {
            if (zslblist.get(i).getTypeid().equals(piggery.getZslb())) {
                String temp = zslbThingsShow[0];
                zslbThingsShow[i] = zslbThingsShow[0];
                zslbThingsShow[0] = zslblist.get(i).getTypename();
            } else {
                zslbThingsShow[i] = zslblist.get(i).getTypename();
            }
        }
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(zslbThingsShow));

        jTextField1.setEnabled(false);
        jButton2.setEnabled(false);
        sqlSession.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox<>();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel1.setText("猪舍编号：");

        jLabel2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("*");

        jButton1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton1.setText("确认提交");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/refues.png"))); // NOI18N
        jButton2.setText("重新输入");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setText("猪舍名称：");

        jLabel5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel5.setText("饲 养 员：");

        jLabel6.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel6.setText("使用状态：");
        jLabel6.setToolTipText("");

        jLabel7.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel7.setText("饲养品种：");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel4.setText("猪舍类别：");

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox1, 0, 164, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField2))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField4))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField5))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox6, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(17, 17, 17)))
                .addGap(25, 25, 25))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (StringUtils.isBlank(jTextField1.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加场内猪舍!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        FenceTempMapper mapper0 = sqlSession.getMapper(FenceTempMapper.class);
        FenceTemp fencetemp = mapper0.selectByTypeid(1);
        PiggeryMapper mapper = sqlSession.getMapper(PiggeryMapper.class);
        ZslbMapper mapper1 = sqlSession.getMapper(ZslbMapper.class);
        List<Zslb> zslblist;
        zslblist = mapper1.selectAll();
        Piggery piggery = new Piggery();
        piggery.setNumber(jTextField1.getText());
        piggery.setCategory(jTextField2.getText());
        String employeeName = employeeNametoIdSmap.get(JComboBoxString(jComboBox1));
        piggery.setFeeder(employeeName);
        employeeName = employeeIdtoNameSmap.get(employeeName);

        piggery.setStatue(jTextField4.getText());
        piggery.setVariety(jTextField5.getText());
        zslblist = mapper1.selectAll();
        for (int i = 0; i < zslblist.size(); i++) {
            if (zslblist.get(i).getTypename().equals(JComboBoxString(jComboBox6))) {
                piggery.setZslb(zslblist.get(i).getTypeid());
            }
        }

        JTable jTable1 = varietiesData.getjTable1();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        if (flagua.equals("add")) {

            //{查询是否存在相同主键
            List<Piggery> piggerylist = mapper.selectAll();
            for (int i = 0; i < piggerylist.size(); i++) {
                if (piggerylist.get(i).getNumber().equals(piggery.getNumber())) {
                    JOptionPane.showMessageDialog(null, "添加失败！已存在相同主键", "系统信息", JOptionPane.INFORMATION_MESSAGE);
                    sqlSession.close();
                    return;
                }
            }
            //}查询是否存在相同主键

            mapper.insert(piggery);
            fencetemp.setCategoryid(ToStringNum4(Integer.parseInt(fencetemp.getCategoryid()) + 1));
            mapper0.updateByTypeid(fencetemp);
            sqlSession.commit();
            JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
        } else {
            mapper.updateByPiggeryid(piggery);
            sqlSession.commit();
            JOptionPane.showMessageDialog(null, "修改成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            jTextField1.setEditable(true);
            jButton2.setEnabled(true);
            //移除修改那行，然后在后面加上新的一行
            model.removeRow(jTable1.getSelectedRow());
        }

        Object[] rowInsert = new Object[]{jTextField1.getText(), jTextField2.getText(), employeeName, jTextField4.getText(), jTextField5.getText(), JComboBoxString(jComboBox6)};
        model.addRow(rowInsert);
        jTable1.setModel(model);
        varietiesData.validate();

        List<Piggery> piggeryList = mapper.selectAll();

        for (int i = 0; i < piggeryList.size(); i++) {
            piggeryThingsShow = new String[piggeryList.size()];
            piggeryIdtoNameSmap.put(piggeryList.get(i).getNumber(), piggeryList.get(i).getCategory());
            piggeryNametoIdSmap.put(piggeryList.get(i).getCategory(), piggeryList.get(i).getNumber());
            for (int j = 0; j < piggeryList.size(); j++) {
                piggeryThingsShow[j] = piggeryList.get(j).getCategory();
                if (piggeryList.get(i).getNumber().equals(piggeryList.get(j).getNumber())) {
                    String thingstemp = piggeryThingsShow[0];
                    piggeryThingsShow[0] = piggeryThingsShow[j];
                    piggeryThingsShow[j] = thingstemp;
                }
            }
            piggeryThingsmap.put(piggeryList.get(i).getNumber(), piggeryThingsShow);
        }
        BYPiggeryList = new ArrayList<>();
        YFPiggeryList = new ArrayList<>();
        HBPiggeryList = new ArrayList<>();
        BRZZPiggeryList = new ArrayList<>();
        pigCategoryThingsShow = new String[piggeryList.size() + 1];
        for (int i = 0; i < piggeryList.size() + 1; i++) {
            if (i == 0) {
                pigCategoryThingsShow[i] = "全部舍";
            } else {
                pigCategoryThingsShow[i] = piggeryList.get(i - 1).getCategory();
            }
            if (i == 0) {
                BYPiggeryList.add("全部保育舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("3")) {
                BYPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }
            if (i == 0) {
                YFPiggeryList.add("全部育肥舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("1")) {
                YFPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }
            if (i == 0) {
                HBPiggeryList.add("全部后备舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("4")) {
                HBPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }
            if (i == 0) {
                BRZZPiggeryList.add("全部哺乳仔猪舍");
            } else if (piggeryList.get(i - 1).getZslb().equals("2")) {
                BRZZPiggeryList.add(piggeryList.get(i - 1).getCategory());
            }
        }
        pigBYCategoryThingsShow = new String[BYPiggeryList.size()];
        for (int i = 0; i < BYPiggeryList.size(); i++) {
            pigBYCategoryThingsShow[i] = BYPiggeryList.get(i);
        }
        pigYFCategoryThingsShow = new String[YFPiggeryList.size()];

        for (int i = 0; i < YFPiggeryList.size(); i++) {
            pigYFCategoryThingsShow[i] = YFPiggeryList.get(i);
        }
        pigHBCategoryThingsShow = new String[HBPiggeryList.size()];

        for (int i = 0; i < HBPiggeryList.size(); i++) {
            pigHBCategoryThingsShow[i] = HBPiggeryList.get(i);
        }

        sqlSession.close();
        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
