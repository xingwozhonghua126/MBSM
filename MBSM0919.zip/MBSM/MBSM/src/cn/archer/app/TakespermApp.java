package cn.archer.app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static cn.archer.app.MainApp.employeeNametoIdSmap;
import static cn.archer.app.MainApp.employeePZYThingsShow;
import static cn.archer.app.MainApp.employeePZYThingsmap;
import static cn.archer.app.MainApp.employeeThingsShow;
import static cn.archer.app.MainApp.employeeThingsmap;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.piggeryIdtoNameSmap;
import static cn.archer.app.MainApp.takespermMapperPlus;
import static cn.archer.app.MainApp.takespermPageModel;
import cn.archer.mapper.SelebithMapper;
import cn.archer.mapper.TakespermMapper;
import cn.archer.model.TakespermPageModel;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.Takesperm;
import static cn.archer.utils.MyStaticMethod.NowTime;
import cn.archer.utils.DateChooserJButtonJDialog;
import cn.archer.utils.MybatisUtil;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import cn.archer.mapper.SelethTempMapper;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;

/**
 *
 * @author Administrator
 */
public class TakespermApp extends javax.swing.JDialog {

    private VarietiesDataPlus varietiesDataPlus;
    private String flagua;
    private String formid0;
    private Selebith selebith;

    /**
     * Creates new form FormApp
     */
    public TakespermApp(VarietiesDataPlus varietiesDataPlus, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "add";
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("公猪采精登记");
        jLabel00.setText("公猪采精登记");//录入，登记，更改,详情
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelethTempMapper mapper0 = sqlSession.getMapper(SelethTempMapper.class);
        //雇员复选框
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsShow));

        jTextField2.setText(NowTime());
        sqlSession.close();

    }

    public TakespermApp(VarietiesDataPlus varietiesDataPlus, String farmid0, java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        flagua = "upp";
        this.formid0 = farmid0;
        this.varietiesDataPlus = varietiesDataPlus;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("公猪采精更改");
        jLabel00.setText("公猪采精更改");
        jButton1.setText("确定提交");
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        TakespermMapper mapper = sqlSession.getMapper(TakespermMapper.class);
        Takesperm takesperm = mapper.selectByid(formid0);
        //雇员复选框
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsmap.get(takesperm.getEmployeeid())));
        jTextField1.setText(takesperm.getR_animal());
        jTextField2.setText(takesperm.getCjrq());
        jTextField3.setText(String.valueOf(takesperm.getCjcs()));
        jTextField4.setText(String.valueOf(takesperm.getCjsl()));
        jTextField5.setText(String.valueOf(takesperm.getCjmd()));
        jTextField6.setText(String.valueOf(takesperm.getCjhl()));
        jTextField7.setText(String.valueOf(takesperm.getCjjl()));
        jTextArea1.setText(takesperm.getBz());

        jTextField1.setEnabled(false);
        jButton2.setEnabled(false);
        sqlSession.close();
    }

    public TakespermApp(String farmid0, java.awt.Frame parent, boolean modal, int j) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("公猪采精详情");
        jLabel00.setText("公猪采精详情");

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        TakespermMapper mapper = sqlSession.getMapper(TakespermMapper.class);
        Takesperm takesperm;
        takesperm = mapper.selectByid(formid0);
        //雇员复选框
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsmap.get(takesperm.getEmployeeid())));

        jTextField1.setText(takesperm.getR_animal());
        jTextField2.setText(takesperm.getCjrq());
        jTextField3.setText(String.valueOf(takesperm.getCjcs()));
        jTextField4.setText(String.valueOf(takesperm.getCjsl()));
        jTextField5.setText(String.valueOf(takesperm.getCjmd()));
        jTextField6.setText(String.valueOf(takesperm.getCjhl()));
        jTextField7.setText(String.valueOf(takesperm.getCjjl()));
        jTextArea1.setText(takesperm.getBz());

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jTextField3.setEnabled(false);
        jTextField4.setEnabled(false);
        jTextField5.setEnabled(false);
        jTextField6.setEnabled(false);
        jTextField7.setEnabled(false);
        jTextArea1.setEnabled(false);
        jComboBox1.setEnabled(false);
        jButton3.setEnabled(false);
        jButton2.setEnabled(false);
        jButton1.setEnabled(false);
        sqlSession.close();
    }

    public TakespermApp(String farmid0, javax.swing.JDialog parent, boolean modal) {
        super(parent, modal);

        flagua = "detail";
        this.formid0 = farmid0;
        initComponents();
        setLocationRelativeTo(parent);
        this.setResizable(false);
        this.setTitle("公猪采精详情");
        jLabel00.setText("公猪采精详情");

        SqlSession sqlSession = MybatisUtil.getSqlSession();
        TakespermMapper mapper = sqlSession.getMapper(TakespermMapper.class);
        Takesperm takesperm;
        takesperm = mapper.selectByid(formid0);
        //雇员复选框
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(employeePZYThingsmap.get(takesperm.getEmployeeid())));

        jTextField1.setText(takesperm.getR_animal());
        jTextField2.setText(takesperm.getCjrq());
        jTextField3.setText(String.valueOf(takesperm.getCjcs()));
        jTextField4.setText(String.valueOf(takesperm.getCjsl()));
        jTextField5.setText(String.valueOf(takesperm.getCjmd()));
        jTextField6.setText(String.valueOf(takesperm.getCjhl()));
        jTextField7.setText(String.valueOf(takesperm.getCjjl()));
        jTextArea1.setText(takesperm.getBz());

        jTextField1.setEnabled(false);
        jTextField2.setEnabled(false);
        jTextField3.setEnabled(false);
        jTextField4.setEnabled(false);
        jTextField5.setEnabled(false);
        jTextField6.setEnabled(false);
        jTextField7.setEnabled(false);
        jTextArea1.setEnabled(false);
        jComboBox1.setEnabled(false);
        jButton3.setEnabled(false);
        jButton2.setEnabled(false);
        jButton1.setEnabled(false);
        sqlSession.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField2 = new javax.swing.JTextField();
        jButton3 =  new DateChooserJButtonJDialog(jTextField2);
        jButton5 = new javax.swing.JButton();
        jLabel00 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jDialog1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jDialog1.setTitle("品种资料添加");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(397, 557));

        jButton1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/sure.png"))); // NOI18N
        jButton1.setText("连续提交");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/refues.png"))); // NOI18N
        jButton2.setText("重新输入");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setText("0");
        jScrollPane1.setViewportView(jTextArea1);

        jLabel8.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel8.setText("备    注：");

        jLabel5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel5.setText("采 精 量：");

        jTextField4.setText("0");

        jTextField3.setText("0");

        jLabel4.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel4.setText("采精次数：");

        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setText("采精日期：");

        jTextField1.setText("0");
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel1.setText("猪只编号：");

        jLabel6.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel6.setText("精子密度：");

        jTextField5.setText("0");

        jLabel7.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel7.setText("采精活力：");

        jTextField6.setText("0");

        jLabel10.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel10.setText("负 责 人：");

        jTextField7.setText("0");

        jLabel9.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel9.setText("畸 形 率：");

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTextField2.setText("0");

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/down.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/exit.png"))); // NOI18N
        jButton5.setText("退出输入");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel00.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel00.setText("采精信息登记");

        jLabel2.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("可输入完整猪只编号或者年份+耳缺号,如16000001,进行信息处理");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(7, 7, 7)
                .addComponent(jButton2)
                .addGap(7, 7, 7)
                .addComponent(jButton5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addComponent(jLabel00)
                .addGap(141, 141, 141))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTextField4))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTextField3))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTextField6))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTextField5))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTextField2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel9)
                                .addComponent(jLabel10))
                            .addGap(10, 10, 10)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField7)
                                .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel8)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel00)
                .addGap(30, 30, 30)
                .addComponent(jLabel2)
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton5))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 569, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        System.gc();
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost

        String id = jTextField1.getText();
        if (id.length() != 15 && id.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            selebith = takespermMapper.selecByZzid("%" + jTextField1.getText());
        }

        if (selebith == null) {
            JOptionPane.showMessageDialog(null, "您添加种公猪个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        jTextField3.setText(String.valueOf(selebith.getGzcjcs() + 1));

    }//GEN-LAST:event_jTextField1FocusLost

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextArea1.setText("");

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (StringUtils.isBlank(jTextField1.getText())) {
            JOptionPane.showMessageDialog(null,
                    "您没有添加个体编号!", "系统信息", JOptionPane.WARNING_MESSAGE);
            return;
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        //｛提取猪之编号,并查询种公猪个体编号是否存在
        String id = jTextField1.getText();
        if (id.length() != 15 && id.length() != 8) {
            JOptionPane.showMessageDialog(null, "您添加编号位数不是15位，或8位!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }

        TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);//SelebithMapper
        SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);//
        selebith = takespermMapper.selecByZzid("%" + jTextField1.getText());

        if (selebith == null) {
            JOptionPane.showMessageDialog(null, "您添加种公猪个体编号不存在!", "系统信息", JOptionPane.WARNING_MESSAGE);
            sqlSession.close();
            return;
        }
        //｝提取猪之编号,并查询种公猪个体编号是否存在
        TakespermMapper mapper = sqlSession.getMapper(TakespermMapper.class);
        Takesperm takesperm = new Takesperm();

        //复选框-关联雇员表{
        String jComboBox1String = employeeNametoIdSmap.get(JComboBoxString(jComboBox1));
        takesperm.setR_animal(selebith.getR_animal());
        takesperm.setCjrq(jTextField2.getText());
        takesperm.setCjcs(Integer.parseInt(jTextField3.getText()));
        takesperm.setCjsl(Integer.parseInt(jTextField4.getText()));
        takesperm.setCjmd(Integer.parseInt(jTextField5.getText()));
        takesperm.setCjhl(Integer.parseInt(jTextField6.getText()));
        takesperm.setCjjl(Integer.parseInt(jTextField7.getText()));
        takesperm.setEmployeeid(jComboBox1String);
        takesperm.setBz(jTextArea1.getText());

        JTable jTable1 = varietiesDataPlus.getjTable1();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        if (flagua.equals("add")) {
            selebith.setGzcjcs(selebith.getGzcjcs() + 1);
            selebithMapper.updateByTypeid(selebith);
            mapper.insert(takesperm);
            sqlSession.commit();
            sqlSession.close();
            jTextField3.setText(String.valueOf(Integer.parseInt(jTextField3.getText()) + 1));
            JOptionPane.showMessageDialog(null, "添加成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            takespermPageModel = new TakespermPageModel(14, takespermMapperPlus.SelectCount(), takespermMapperPlus, false);
            MainApp.Takespermpage(takespermPageModel.getTopPageNo());

        } else {
            takesperm.setId(formid0);
            mapper.updateByid(takesperm);
            sqlSession.commit();
            JOptionPane.showMessageDialog(null, "修改成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
            jTextField1.setEditable(true);
            jButton2.setEnabled(true);
            //移除修改那行，然后在后面加上新的一行
            model.removeRow(jTable1.getSelectedRow());
            Object[] rowInsert = new Object[]{takesperm.getId(), takesperm.getR_animal(), jTextField2.getText(), piggeryIdtoNameSmap.get(selebith.getR_cage()), fenceIdtoNameSmap.get(selebith.getR_pcage()), JComboBoxString(jComboBox1)};
            model.addRow(rowInsert);
            jTable1.setModel(model);
            varietiesDataPlus.validate();
            sqlSession.close();
            System.gc();
            dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
