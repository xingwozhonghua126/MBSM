package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Count;
import cn.archer.pojo.TwoTest;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface TwoTestMapper {

    public int insert(TwoTest twoTest);

    public List<TwoTest> selectAll();

    public void deleteByid(String id);

    public void updateByid(TwoTest twoTest);

    public TwoTest selectByid(String id);

    public List<TwoTest> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<TwoTest> selectByDate(String startDate, String endDate);

}
