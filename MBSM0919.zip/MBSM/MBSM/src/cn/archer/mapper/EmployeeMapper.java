package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Employee;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface EmployeeMapper {

    public void insert(Employee employee);

    public List<Employee> selectAll();

    public void deleteByid(String employeeid);

    public void updateByid(Employee employee);

    public Employee selectByid(String employeeid);

}
