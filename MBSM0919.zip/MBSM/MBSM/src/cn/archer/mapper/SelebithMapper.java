package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.ShengZYF;

import java.util.List;

/**
 *
 * @author Administrator
 */
public interface SelebithMapper {

    public void insert(Selebith selebith);

    public List<Selebith> selectAll();

    public void deleteByTypeid(String r_animal);

    public void updateByTypeid(Selebith selebith);

    public Selebith selectByTypeid(String r_animal);

    public Selebith selectById(String id);

    public List<Selebith> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Selebith> selectByDate(String startDate, String endDate);

    public void updateTwo(String r_animal);

    public void updateZT(String zt, String r_animal, String xs);

    public void updateZTT(String zt, String r_animal, String tt);

    public void updateT(ShengZYF sZYF);

    public void updateFour(String r_animal);

    public void updateSix(String r_animal);

    public void updateF(ShengZYF sZYF);//更改四月 生长育肥猪

    public void updateS(ShengZYF sZYF);//更改六月 生长育肥猪

    public void updateH(ShengZYF sZYF);//更改100kg 生长育肥猪

    public void updateHundred(ShengZYF sZYF);//更改100kg 后背母猪 种公猪
}
