package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Jyjc;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface JyjcMapper {

    public void insert(Jyjc jyjc);

    public List<Jyjc> selectAll();

    public void deleteByid(String id);

    public void updateByid(Jyjc jyjc);

    public Jyjc selectByid(String id);

    public List<Jyjc> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Jyjc> selectByDate(String startDate, String endDate);

}
