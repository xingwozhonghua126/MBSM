/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Breeding;
import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import java.util.List;

/**
 *
 * @author WB
 */
public interface RemindMapper {

    //按出生日期查找个体信息
    public List<Selebith> selebithByR_fdate(String r_fdate);

    //按出生日期查找个体信息数量
    public Count selebithByR_fdateCount(String r_fdate);

    //按配种日期和配种状态为检验查找信息用于母猪妊娠检验提醒
    public List<Breeding> breedingJytx(String pzrq);
    //按配种日期和配种状态为检验查找信息的数量
//    public Count breedingJytxCount(String pzrq);    

    //按配种日期和配种状态为分娩查找信息用于母猪妊娠检验提醒
    public List<Breeding> breedingFmtx(String pzrq);
    //按配种日期和配种状态为分娩查找信息的数量
//    public Count breedingFmtxCount(String pzrq);

    //按配种日期查找信息用于母猪妊娠后疫苗提醒
    public List<String> breedingRshtx(String pzrq);

    //按配种日期查找信息用于母猪妊娠后疫苗的数量
    public Count breedingRshtxCount(String pzrq);

    //按分娩日期查找信息用于母猪分娩后疫苗提醒
    public List<String> childbirthFmhtx(String czrq);

    //按分娩日期查找信息用于母猪分娩后疫苗的数量
    public Count childbirthFmhtxCount(String czrq);

    //按断奶日期查找信息用于母猪断奶后疫苗提醒
    public List<String> childbirthDnhtx(String dnrq);

    //按断奶日期查找信息用于母猪断奶后疫苗的数量
    public Count childbirthDnhtxCount(String dnrq);

    //按测定日期查找信息用于后备母猪100kg后疫苗提醒
    public List<String> hbmzhundredtesthtx(String cdrq);

    //按测定日期查找信息用于后备母猪100kg后疫苗的数量
    public Count hbmzhundredtesthtxCount(String cdrq);

    //按测定日期查找信息用于种公猪100kg后疫苗提醒
    public List<String> zgzhundredtesthtx(String cdrq);

    //按测定日期查找信息用于种公猪100kg后疫苗的数量
    public Count zgzhundredtesthtxCount(String cdrq);

    //查询所有种公猪
    public List<Selebith> zgztx();

    //查询所有种公猪的数量
    public Count zgztxCount();

    //通过个体编号查找猪只信息
    public Selebith zzxx(String r_animal);

}
