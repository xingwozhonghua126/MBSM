/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Lineherd;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface LineherdMapper {

    public void insert(Lineherd lineherd);

    public List<Lineherd> selectAll();

    public void deleteByTypeid(String herdid);

    public void updateByTypeid(Lineherd lineherd);

    public Lineherd selectByTypeid(String herdid);

    public List<Lineherd> selectAllById(String herdid);

}
