package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Zzmy;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ZzmyMapper {

    public void insert(Zzmy zzmy);

    public List<Zzmy> selectAll();

    public void deleteByid(String r_animal);

    public void updateByid(Zzmy zzmy);

    public Zzmy selectByid(String id);

    public List<Zzmy> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Zzmy> selectByDate(String startDate, String endDate);

}
