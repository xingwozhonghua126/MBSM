package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Pigjb;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface PigjbMapper {

    public void insert(Pigjb pigjb);

    public List<Pigjb> selectAll();

    public void deleteByid(String id);

    public void updateByid(Pigjb pigjb);

    public Pigjb selectByid(String id);
}
