package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface TjMapper {

    public String selectById(String id);//求个体编号

    public Count selectFqcs(String startTime, String endTime, String pignum, String fence, String employe);//返情次数

    public List<Count> selectFqcsday(String startTime, String endTime, String pignum, String fence, String employe);//返情次数天

    public List<Count> selectFqcsmonth(String startTime, String endTime, String pignum, String fence, String employe);//返情次数月

    public List<Count> selectFqcsyear(String startTime, String endTime, String pignum, String fence, String employe);//返情次数年

    public Count selectPzcs(String startTime, String endTime, String pignum, String fence, String employe);//配种次数

    public List<Count> selectPzcsday(String startTime, String endTime, String pignum, String fence, String employe);//配种次数天

    public List<Count> selectPzcsmonth(String startTime, String endTime, String pignum, String fence, String employe);//配种次数月

    public List<Count> selectPzcsyear(String startTime, String endTime, String pignum, String fence, String employe);//配种次数年

    public Count selectPzcs2(String startTime, String endTime, String pignum, String fence, String employe);//配种次数

    public List<Count> selectPzcs2day(String startTime, String endTime, String pignum, String fence, String employe);//配种次数天

    public List<Count> selectPzcs2month(String startTime, String endTime, String pignum, String fence, String employe);//配种次数月

    public List<Count> selectPzcs2year(String startTime, String endTime, String pignum, String fence, String employe);//配种次数年

    public Count selectRscs(String startTime, String endTime, String pignum, String fence, String employe);//妊娠次数

    public List<Count> selectRscsday(String startTime, String endTime, String pignum, String fence, String employe);//妊娠次数天

    public List<Count> selectRscsmonth(String startTime, String endTime, String pignum, String fence, String employe);//妊娠次数月

    public List<Count> selectRscsyear(String startTime, String endTime, String pignum, String fence, String employe);//妊娠次数年

    public Count selectFmcs(String startTime, String endTime, String pignum, String fence, String employe,String startTime1, String endTime1);//分娩次数

    public List<Count> selectFmcsday(String startTime, String endTime, String pignum, String fence, String employe,String startTime1, String endTime1);//分娩次数

    public List<Count> selectFmcsmonth(String startTime, String endTime, String pignum, String fence, String employe,String startTime1, String endTime1);//分娩次数

    public List<Count> selectFmcsyear(String startTime, String endTime, String pignum, String fence, String employe,String startTime1, String endTime1);//分娩次数

    public Count selectFmts(String startTime, String endTime, String pignum, String fence, String employe);//分娩次数带负责人

    public List<Count> selectFmtsday(String startTime, String endTime, String pignum, String fence, String employe);//分娩次数带负责人

    public List<Count> selectFmtsmonth(String startTime, String endTime, String pignum, String fence, String employe);//分娩次数带负责人

    public List<Count> selectFmtsyear(String startTime, String endTime, String pignum, String fence, String employe);//分娩次数带负责人

    public Count selectFmzzs(String startTime, String endTime, String pignum, String fence, String employe);//分娩总产仔数

    public List<Count> selectFmzzsday(String startTime, String endTime, String pignum, String fence, String employe);//分娩总产仔数

    public List<Count> selectFmzzsmonth(String startTime, String endTime, String pignum, String fence, String employe);//分娩总产仔数

    public List<Count> selectFmzzsyear(String startTime, String endTime, String pignum, String fence, String employe);//分娩总产仔数

    public Count selectFmhzs(String startTime, String endTime, String pignum, String fence, String employe);//分娩产仔活数

    public List<Count> selectFmhzsday(String startTime, String endTime, String pignum, String fence, String employe);//分娩产仔活数

    public List<Count> selectFmhzsmonth(String startTime, String endTime, String pignum, String fence, String employe);//分娩产仔活数

    public List<Count> selectFmhzsyear(String startTime, String endTime, String pignum, String fence, String employe);//分娩产仔活数

    public Count selectCswzz(String startTime, String endTime, String pignum, String fence, String employe);//出生窝总重

    public List<Count> selectCswzzday(String startTime, String endTime, String pignum, String fence, String employe);//出生窝总重

    public List<Count> selectCswzzmonth(String startTime, String endTime, String pignum, String fence, String employe);//出生窝总重

    public List<Count> selectCswzzyear(String startTime, String endTime, String pignum, String fence, String employe);//出生窝总重

    public Count selectDnts(String startTime, String endTime, String fence, String employe);//断奶总个数

    public List<Count> selectDntsday(String startTime, String endTime, String fence, String employe);//断奶总个数

    public List<Count> selectDntsmonth(String startTime, String endTime, String fence, String employe);//断奶总个数

    public List<Count> selectDntsyear(String startTime, String endTime, String fence, String employe);//断奶总个数

    public Count selectDnzgs(String startTime, String endTime, String fence, String employe);//断奶总个数

    public List<Count> selectDnzgsday(String startTime, String endTime, String fence, String employe);//断奶总个数

    public List<Count> selectDnzgsmonth(String startTime, String endTime, String fence, String employe);//断奶总个数

    public List<Count> selectDnzgsyear(String startTime, String endTime, String fence, String employe);//断奶总个数

    public Count selectDnzwwz(String startTime, String endTime, String fence, String employe);//断奶总窝窝重

    public List<Count> selectDnzwwzday(String startTime, String endTime, String fence, String employe);//断奶总窝窝重

    public List<Count> selectDnzwwzmonth(String startTime, String endTime, String fence, String employe);//断奶总窝窝重

    public List<Count> selectDnzwwzyear(String startTime, String endTime, String fence, String employe);//断奶总窝窝重

    public Count selectByszs(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectByszsday(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectByszsmonth(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectByszsyear(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public Count selectBysswzs(String startTime, String endTime, String fence, String employe);//保育舍死亡猪数

    public List<Count> selectBysswzsday(String startTime, String endTime, String fence, String employe);//保育舍死亡猪数

    public List<Count> selectBysswzsmonth(String startTime, String endTime, String fence, String employe);//保育舍死亡猪数

    public List<Count> selectBysswzsyear(String startTime, String endTime, String fence, String employe);//保育舍死亡猪数

    public Count selectYfszs(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectYfszsday(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectYfszsmonth(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectYfszsyear(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public Count selectYfsswzs(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectYfsswzsday(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectYfsswzsmonth(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public List<Count> selectYfsswzsyear(String startTime, String endTime, String fence, String employe);//保育舍猪数

    public Count selectSlrk(String startTime, String endTime, String slmc, String employe);//饲料出库

    public List<Count> selectSlrkday(String startTime, String endTime, String slmc, String employe);//饲料出库

    public List<Count> selectSlrkmonth(String startTime, String endTime, String slmc, String employe);//饲料出库

    public List<Count> selectSlrkyear(String startTime, String endTime, String slmc, String employe);//饲料出库

    public Count selectYprk(String startTime, String endTime, String slmc, String employe);//饲料出库

    public List<Count> selectYprkday(String startTime, String endTime, String ypmc, String employe);//饲料出库

    public List<Count> selectYprkmonth(String startTime, String endTime, String ypmc, String employe);//饲料出库

    public List<Count> selectYprkyear(String startTime, String endTime, String ypmc, String employe);//饲料出库

    public Count selectYmrk(String startTime, String endTime, String ymmc, String employe);//饲料出库

    public List<Count> selectYmrkday(String startTime, String endTime, String ymmc, String employe);//饲料出库

    public List<Count> selectYmrkmonth(String startTime, String endTime, String ymmc, String employe);//饲料出库

    public List<Count> selectYmrkyear(String startTime, String endTime, String ymmc, String employe);//饲料出库

    public Count selectSlck(String startTime, String endTime, String slmc, String employe, String number);//饲料出库

    public List<Count> selectSlckday(String startTime, String endTime, String slmc, String employe, String number);//饲料出库

    public List<Count> selectSlckmonth(String startTime, String endTime, String slmc, String employe, String number);//饲料出库

    public List<Count> selectSlckyear(String startTime, String endTime, String slmc, String employe, String number);//饲料出库

    public Count selectYpck(String startTime, String endTime, String ypmc, String employe, String number);//饲料出库

    public List<Count> selectYpckday(String startTime, String endTime, String ypmc, String employe, String number);//饲料出库

    public List<Count> selectYpckmonth(String startTime, String endTime, String ypmc, String employe, String number);//饲料出库

    public List<Count> selectYpckyear(String startTime, String endTime, String ypmc, String employe, String number);//饲料出库

    public Count selectYmck(String startTime, String endTime, String ymmc, String employe, String number);//饲料出库

    public List<Count> selectYmckday(String startTime, String endTime, String ymmc, String employe, String number);//饲料出库

    public List<Count> selectYmckmonth(String startTime, String endTime, String ymmc, String employe, String number);//饲料出库

    public List<Count> selectYmckyear(String startTime, String endTime, String ymmc, String employe, String number);//饲料出库

    public Count selectZzsw(String startTime, String endTime, String fence, String employe);//猪只死亡

    public List<Count> selectZzswday(String startTime, String endTime, String fence, String employe);//饲料出库

    public List<Count> selectZzswmonth(String startTime, String endTime, String fence, String employe);//饲料出库

    public List<Count> selectZzswyear(String startTime, String endTime, String fence, String employe);//饲料出库    

    public Count selectZzxs(String startTime, String endTime, String employe);//猪只销售

    public List<Count> selectZzxsday(String startTime, String endTime, String employe);//饲料出库

    public List<Count> selectZzxsmonth(String startTime, String endTime, String employe);//饲料出库

    public List<Count> selectZzxsyear(String startTime, String endTime, String employe);//饲料出库

    public Count selectLrbZzxs(String startTime, String endTime);//猪只销售

    public List<Count> selectLrbZzxsday(String startTime, String endTime);//饲料出库

    public List<Count> selectLrbZzxsmonth(String startTime, String endTime);//饲料出库

    public List<Count> selectLrbZzxsyear(String startTime, String endTime);//饲料出库

    public Count selectLrbSlck(String startTime, String endTime, String number);//猪只销售

    public List<Count> selectLrbSlckday(String startTime, String endTime, String typeid);//饲料出库

    public List<Count> selectLrbSlckmonth(String startTime, String endTime, String typeid);//饲料出库

    public List<Count> selectLrbSlckyear(String startTime, String endTime, String typeid);//饲料出库

}
