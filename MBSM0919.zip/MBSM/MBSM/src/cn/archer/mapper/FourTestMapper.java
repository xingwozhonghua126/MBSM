package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.mapper.*;
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Count;
import cn.archer.pojo.FourTest;
import cn.archer.pojo.Takesperm;
import cn.archer.pojo.TwoTest;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface FourTestMapper {

    public int insert(FourTest fourTest);

    public List<FourTest> selectAll();

    public void deleteByid(String id);

    public void updateByid(FourTest fourTest);

    public FourTest selectByid(String id);

    public List<FourTest> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<FourTest> selectByDate(String startDate, String endDate);

}
