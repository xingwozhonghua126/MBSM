package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Selebith;

import java.util.List;

/**
 *
 * @author Administrator
 */
//近亲亲缘检验
public interface JqqyjyMapper {

    //输入母亲的编号求所有儿子
    public List<String> selectMzAll(String r_animal);
    
    //输入母亲的编号求所有女儿
    public List<String> selectMnAll(String r_animal);

    //输入父亲的编号求所有儿子
    public List<String> selectFzAll(String r_animal);

    //输入父亲的编号求所有女儿
    public List<String> selectFnAll(String r_animal);

    //求所有公猪编号
    public List<String> selectAllMale();

    //求所有母猪编号
    public List<String> selectAllFemale();
    
    //求所有公猪编号
    public List<Selebith> selectAllMale1();

    //求所有母猪编号
    public List<Selebith> selectAllFemale1();

    //输入母亲的编号求所有子女
    public List<Selebith> selectMZnAll(String r_animal);

    //输入父亲的编号求所有子女
    public List<Selebith> selectFZnAll(String r_animal);

    public Selebith selectById(String r_animal);
    
    //求最近采精日期
    public String selectByCjrq(String r_animal);
}
