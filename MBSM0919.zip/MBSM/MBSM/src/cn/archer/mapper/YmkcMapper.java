package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.pojo.Ymkc;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface YmkcMapper {

    public void insert(Ymkc ymkc);

    public List<Ymkc> selectAll();

    public void deleteByid(String id);

    public void updateByid(Ymkc ymkc);

    public Ymkc selectByid(String id);

}
