package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.pojo.Ymck;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface YmckMapper {

    public void insert(Ymck ymck);

    public List<Ymck> selectAll();

    public void deleteByid(String id);

    public void updateByid(Ymck ymck);

    public Ymck selectByid(String id);

    public List<Ymck> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Ymck> selectByDate(String startDate, String endDate);

}
