package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Pigsl;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface PigslMapper {

    public void insert(Pigsl pigsl);

    public List<Pigsl> selectAll();

    public void deleteByid(String id);

    public void updateByid(Pigsl pigsl);

    public Pigsl selectByid(String id);

}
