package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.pojo.Count;
import cn.archer.pojo.FourTest;
import cn.archer.pojo.HundredTest;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.SixTest;
import cn.archer.pojo.TwoTest;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface YzMapper {

    public List<Selebith> selectAllyzgtxx(String start, String end,  String fenceid);
    public List<Selebith> selectAllyzgtxxBypage(String start, String end,  String fenceid, String size, String jump);
    public Count selectAllyzgtxxBycount(String start, String end,  String fenceid);

    public List<TwoTest> selectAlltwotest(String start, String end,  String fenceid);
    public List<TwoTest> selectAlltwotestBypage(String start, String end,  String fenceid, String size, String jump);
    public Count selectAlltwotestBycount(String start, String end,  String fenceid);

    public List<FourTest> selectAllfourtest(String start, String end,  String fenceid);
    public List<FourTest> selectAllfourtestBypage(String start, String end,  String fenceid, String size, String jump);
    public Count selectAllfourtestBycount(String start, String end,  String fenceid);

    public List<SixTest> selectAllsixtest(String start, String end,  String fenceid);
    public List<SixTest> selectAllsixtestBypage(String start, String end,  String fenceid, String size, String jump);
    public Count selectAllsixtestBycount(String start, String end,  String fenceid);

    public List<HundredTest> selectAllhundredtest(String start, String end, String fenceid);
    public List<HundredTest> selectAllhundredtestBypage(String start, String end, String fenceid, String size, String jump);
    public Count selectAllhundredtestBycount(String start, String end, String fenceid);

    public List<String> selectzzbh();
    public List<String> selectzzbhhd();

}
