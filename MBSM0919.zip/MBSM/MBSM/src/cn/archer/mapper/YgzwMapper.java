package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.Takesperm;
import cn.archer.pojo.Ygzw;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface YgzwMapper {

    public void insert(Ygzw zwid);

    public List<Ygzw> selectAll();

    public void deleteByid(String zwid);

    public void updateByid(Ygzw ygzw);

    public Ygzw selectByid(String zwid);

}
