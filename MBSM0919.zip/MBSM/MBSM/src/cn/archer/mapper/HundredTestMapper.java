package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Count;
import cn.archer.pojo.HundredTest;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface HundredTestMapper {

    public int insert(HundredTest hundredTest);

    public List<HundredTest> selectAll();

    public void deleteByid(String id);

    public void updateByid(HundredTest hundredTest);

    public HundredTest selectByid(String id);

    public List<HundredTest> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<HundredTest> selectByDate(String startDate, String endDate);

}
