package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.pojo.Ypkc;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface YpkcMapper {

    public void insert(Ypkc ypkc);

    public List<Ypkc> selectAll();

    public void deleteByid(String id);

    public void updateByid(Ypkc ypkc);

    public Ypkc selectByid(String id);

}
