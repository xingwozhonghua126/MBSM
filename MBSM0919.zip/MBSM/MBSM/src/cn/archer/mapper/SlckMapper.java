package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Slck;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface SlckMapper {

    public void insert(Slck slck);

    public List<Slck> selectAll();

    public void deleteByid(String id);

    public void updateByid(Slck slck);

    public Slck selectByid(String id);

    public List<Slck> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Slck> selectByDate(String startDate, String endDate);

}
