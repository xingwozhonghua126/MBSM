package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Sllb;
import java.util.List;

/**
 *
 * @author hp
 */
public interface SllbMapper {

    public void insert(Sllb typeid);

    public List<Sllb> selectAll();

    public void deleteByid(String typeid);

    public void updateByid(Sllb typeid);

    public Sllb selectByid(String typeid);

}
