package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Jbzl;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface JbzlMapper {

    public void insert(Jbzl jbzl);

    public List<Jbzl> selectAll();

    public void deleteByid(String id);

    public void updateByid(Jbzl jbzl);

    public Jbzl selectByid(String id);

    public List<Jbzl> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Jbzl> selectByDate(String startDate, String endDate);

}
