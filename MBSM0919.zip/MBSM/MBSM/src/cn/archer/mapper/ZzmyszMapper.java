package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Zzmysz;
import java.util.List;

/**
 *
 * @author hp
 */
public interface ZzmyszMapper {

    public void insert(Zzmysz zzmysz);

    public List<Zzmysz> selectAll();

    public void deleteByid(String id);

    public void updateByid(Zzmysz zzmysz);

    public Zzmysz selectByid(String id);

}
