package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Yprk;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface YprkMapper {

    public void insert(Yprk yprk);

    public List<Yprk> selectAll();

    public void deleteByid(String id);

    public void updateByid(Yprk yprk);

    public Yprk selectByid(String id);

    public List<Yprk> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Yprk> selectByDate(String startDate, String endDate);

}
