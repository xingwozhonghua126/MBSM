package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.pojo.Slkc;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface SlkcMapper {

    public void insert(Slkc slkc);

    public List<Slkc> selectAll();

    public void deleteByid(String id);

    public void updateByid(Slkc slkc);

    public Slkc selectByid(String id);

}
