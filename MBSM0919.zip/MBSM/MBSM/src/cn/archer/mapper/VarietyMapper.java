/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Variety;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface VarietyMapper {

    public void insert(Variety variety);

    public List<Variety> selectAll();

    public void deleteByNumber(String number);
}
