package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.mapper.*;
import cn.archer.pojo.Ymrk;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface YmrkMapper {

    public void insert(Ymrk ymrk);

    public List<Ymrk> selectAll();

    public void deleteByid(String id);

    public void updateByid(Ymrk ymrk);

    public Ymrk selectByid(String id);

    public List<Ymrk> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Ymrk> selectByDate(String startDate, String endDate);

}
