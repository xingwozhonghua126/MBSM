package cn.archer.mapper;

import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.Takesperm;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface TakespermMapper {

    public void insert(Takesperm takesperm);

    public List<Takesperm> selectAll();

    public Selebith selecByZzid(String id);//查询种猪编号

    public void deleteByid(String id);

    public void updateByid(Takesperm takesperm);

    public Takesperm selectByid(String id);

    public List<Takesperm> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Takesperm> selectByDate(String startDate, String endDate);

}
