package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface BreedingMapper {

    public void insert(Breeding breeding);

    public List<Breeding> selectAll();

    public void deleteByid(String id);

    public void updateByid(Breeding breeding);

    public Breeding selectByid(String id);

    public String selectByidandtc(String id, String tc);

    public List<Breeding> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Breeding> selectByDate(String startDate, String endDate);

}
