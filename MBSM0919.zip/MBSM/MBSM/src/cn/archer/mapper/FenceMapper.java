package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Fence;
import java.util.List;

/**
 *
 * @author hp
 */
public interface FenceMapper {

    public void insert(Fence fenceid);

    public List<Fence> selectAll();

    public void deleteByFenceid(String fenceid);

    public void updateByFenceid(Fence fenceid);

    public Fence selectByFenceid(String fenceid);

    public List<Fence> selectAllById(String number);
}
