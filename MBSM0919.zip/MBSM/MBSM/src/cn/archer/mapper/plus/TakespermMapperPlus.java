package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.TakespermMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Takesperm;
import cn.archer.utils.MybatisUtil;

public class TakespermMapperPlus {

    private String num;
    private String startDate;
    private String endDate;

    public TakespermMapperPlus() {
        num = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Takesperm takesperm) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            takespermMapper.insert(takesperm);
        }
    }

    public List<Takesperm> SelectByDate(String data1, String data2) {

        List<Takesperm> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            selectByDate = takespermMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Takesperm> SelectByIdPage(int size, int jump) {
        List<Takesperm> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            selectByIdPage = takespermMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Takesperm> SelectAll() {
        List<Takesperm> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            selectByDate = takespermMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            count = takespermMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Takesperm takesperm) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            takespermMapper.updateByid(takesperm);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TakespermMapper takespermMapper = sqlSession.getMapper(TakespermMapper.class);
            takespermMapper.deleteByid(id);
            sqlSession.commit();
            sqlSession.close();
        }

    }

    public List<Takesperm> TakespermSelectSearchByPage(int size, int jump) {
        List<Takesperm> takespermList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            takespermList = searchMapper.TakespermSelectSearchByPage(num, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return takespermList;
    }

    public int TakespermSelectSearchByCount(String num, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.TakespermSelectSearchByCount(this.num, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
