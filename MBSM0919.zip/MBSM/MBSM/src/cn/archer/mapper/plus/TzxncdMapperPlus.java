package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.TzxncdMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Tzxncd;
import cn.archer.utils.MybatisUtil;

public class TzxncdMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;

    public TzxncdMapperPlus() {
        num = null;
        fenceid = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Tzxncd tzxncd) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class);
            tzxncdMapper.insert(tzxncd);
        }
    }

    public List<Tzxncd> SelectByDate(String data1, String data2) {

        List<Tzxncd> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class);
            selectByDate = tzxncdMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Tzxncd> SelectByIdPage(int size, int jump) {
        List<Tzxncd> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class);
            selectByIdPage = tzxncdMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Tzxncd> SelectAll() {
        List<Tzxncd> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class);
            selectByDate = tzxncdMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class);
            count = tzxncdMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Tzxncd tzxncd) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class);
            tzxncdMapper.updateByid(tzxncd);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TzxncdMapper tzxncdMapper = sqlSession.getMapper(TzxncdMapper.class);
            tzxncdMapper.deleteByid(id);
        }

    }

    public List<Tzxncd> TzxncdSelectSearchByPage(int size, int jump) {
        List<Tzxncd> tzxncdList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            tzxncdList = searchMapper.TzxncdSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return tzxncdList;
    }

    public int TzxncdSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.TzxncdSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
