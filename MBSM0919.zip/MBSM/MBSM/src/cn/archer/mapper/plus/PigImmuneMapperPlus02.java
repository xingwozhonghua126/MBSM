package cn.archer.mapper.plus;

import cn.archer.mapper.PigImmuneMapper02;
import cn.archer.mapper.SearchMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;

public class PigImmuneMapperPlus02 {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String pzzt;
    private PigImmuneMapper02 pigImmuneMapper02;

    public PigImmuneMapperPlus02() {
        num = null;
        startDate = null;
        endDate = null;
        pzzt = null;
    }

    public List<Selebith> SelectByDate02(String data1, String data2) {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            pigImmuneMapper02 = sqlSession.getMapper(PigImmuneMapper02.class);
            selectByDate = pigImmuneMapper02.selectByDate02(data1, data2);
        }
        return selectByDate;
    }

    public List<Selebith> SelectByIdPage02(int size, int jump) {
        List<Selebith> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            pigImmuneMapper02 = sqlSession.getMapper(PigImmuneMapper02.class);
            selectByIdPage = pigImmuneMapper02.selectByIdPage02(size, jump);
        }
        return selectByIdPage;
    }

    public List<Selebith> SelectAll02() {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            pigImmuneMapper02 = sqlSession.getMapper(PigImmuneMapper02.class);
            selectByDate = pigImmuneMapper02.selectAll02();
        }
        return selectByDate;
    }

    public int SelectCount02() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            pigImmuneMapper02 = sqlSession.getMapper(PigImmuneMapper02.class);
            count = pigImmuneMapper02.selectCount02().getCount();
        }
        return count;
    }

    public void updateById02(Selebith takesperm) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            pigImmuneMapper02 = sqlSession.getMapper(PigImmuneMapper02.class);
            pigImmuneMapper02.updateById02(takesperm);
        }
    }

    public List<Selebith> pigImmuneSelectSearchByPage02(int size, int jump) {
        List<Selebith> breedingList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            breedingList = sarchMapper.pigImmuneSelectSearchByPage02(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump), pzzt);
        }
        return breedingList;
    }

    public int pigImmuneSelectSearchByCount02(String num, String fenceid, String startDate, String endDate, String pzzt) {
        Count count;
        this.num = "%" + num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pzzt = pzzt;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.pigImmuneSelectSearchByCount02(this.num, this.fenceid, this.startDate, this.endDate, this.pzzt);
        }
        return count.getCount();
    }

}
