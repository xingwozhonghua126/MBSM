package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Zzsw;
import cn.archer.utils.MybatisUtil;
import cn.archer.mapper.ZzswMapper;

public class ZzswMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;

    public ZzswMapperPlus() {
        num = null;
        fenceid = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Zzsw zztt) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzswMapper zzttMapper = sqlSession.getMapper(ZzswMapper.class);
            zzttMapper.insert(zztt);
        }
    }

    public List<Zzsw> SelectByDate(String data1, String data2) {

        List<Zzsw> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzswMapper zzttMapper = sqlSession.getMapper(ZzswMapper.class);
            selectByDate = zzttMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Zzsw> SelectByIdPage(int size, int jump) {
        List<Zzsw> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzswMapper zzttMapper = sqlSession.getMapper(ZzswMapper.class);
            selectByIdPage = zzttMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Zzsw> SelectAll() {
        List<Zzsw> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzswMapper zzttMapper = sqlSession.getMapper(ZzswMapper.class);
            selectByDate = zzttMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzswMapper zzttMapper = sqlSession.getMapper(ZzswMapper.class);
            count = zzttMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Zzsw zztt) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzswMapper zzttMapper = sqlSession.getMapper(ZzswMapper.class);
            zzttMapper.updateByid(zztt);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzswMapper zzttMapper = sqlSession.getMapper(ZzswMapper.class);
            zzttMapper.deleteByid(id);
        }

    }

    public List<Zzsw> ZzswSelectSearchByPage(int size, int jump) {
        List<Zzsw> zzswList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            zzswList = searchMapper.ZzswSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return zzswList;
    }

    public int ZzswSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.ZzswSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
