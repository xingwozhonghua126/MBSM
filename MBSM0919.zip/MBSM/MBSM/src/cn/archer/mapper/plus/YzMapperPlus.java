package cn.archer.mapper.plus;

import cn.archer.mapper.YzMapper;
import cn.archer.pojo.Count;
import cn.archer.pojo.FourTest;
import cn.archer.pojo.HundredTest;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.SixTest;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.TwoTest;
import cn.archer.utils.MybatisUtil;
import java.util.ArrayList;

public class YzMapperPlus {

    private String piggery;
    private String startDate;
    private String endDate;

    public YzMapperPlus() {
        piggery = null;
        startDate = null;
        endDate = null;
    }

    public List<Selebith> selectAllyzgtxx() {
        List<Selebith> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            selebithList = yzMapper.selectAllyzgtxx(startDate, endDate, piggery);
        }
        return selebithList;
    }

    public List<Selebith> selectAllyzgtxxBypage(int size, int jump) {
        List<Selebith> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            selebithList = yzMapper.selectAllyzgtxxBypage(startDate, endDate, piggery, String.valueOf(size), String.valueOf(jump));
        }
        return selebithList;
    }

    public int selectAllyzgtxxBycount(String startDate, String endDate, String piggery) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            count = yzMapper.selectAllyzgtxxBycount(this.startDate, this.endDate, this.piggery);
        }
        return count.getCount();
    }

    public List<TwoTest> selectAlltwotest() {
        List<TwoTest> TwoTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            TwoTestList = yzMapper.selectAlltwotest(startDate, endDate, piggery);
        }
        return TwoTestList;
    }

    public List<TwoTest> selectAlltwotestBypage(int size, int jump) {
        List<TwoTest> TwoTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            TwoTestList = yzMapper.selectAlltwotestBypage(startDate, endDate, piggery, String.valueOf(size), String.valueOf(jump));
        }
        return TwoTestList;
    }

    public int selectAlltwotestBycount(String startDate, String endDate, String piggery) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            count = yzMapper.selectAlltwotestBycount(this.startDate, this.endDate, this.piggery);
        }
        return count.getCount();
    }

    public List<FourTest> selectAllfourtest() {
        List<FourTest> slckList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            slckList = yzMapper.selectAllfourtest(startDate, endDate, piggery);
        }
        return slckList;
    }

    public List<FourTest> selectAllfourtestBypage(int size, int jump) {
        List<FourTest> slckList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            slckList = yzMapper.selectAllfourtestBypage(startDate, endDate, piggery, String.valueOf(size), String.valueOf(jump));
        }
        return slckList;
    }

    public int selectAllfourtestBycount(String startDate, String endDate, String piggery) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            count = yzMapper.selectAllfourtestBycount(this.startDate, this.endDate, this.piggery);
        }
        return count.getCount();
    }

    public List<SixTest> selectAllsixtest() {
        List<SixTest> SixTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            SixTestList = yzMapper.selectAllsixtest(startDate, endDate, piggery);
        }
        return SixTestList;
    }

    public List<SixTest> selectAllsixtestBypage(int size, int jump) {
        List<SixTest> SixTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            SixTestList = yzMapper.selectAllsixtestBypage(startDate, endDate, piggery, String.valueOf(size), String.valueOf(jump));
        }
        return SixTestList;
    }

    public int selectAllsixtestBycount(String startDate, String endDate, String piggery) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            count = yzMapper.selectAllsixtestBycount(this.startDate, this.endDate, this.piggery);
        }
        return count.getCount();
    }

    public List<HundredTest> selectAllhundredtest() {
        List<HundredTest> HundredTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            HundredTestList = yzMapper.selectAllhundredtest(startDate, endDate, piggery);
        }
        return HundredTestList;
    }

    public List<HundredTest> selectAllhundredtestBypage(int size, int jump) {
        List<HundredTest> HundredTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            HundredTestList = yzMapper.selectAllhundredtestBypage(startDate, endDate, piggery, String.valueOf(size), String.valueOf(jump));
        }
        return HundredTestList;
    }

    public int selectAllhundredtestBycount(String startDate, String endDate, String piggery) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YzMapper yzMapper = sqlSession.getMapper(YzMapper.class);
            count = yzMapper.selectAllhundredtestBycount(this.startDate, this.endDate, this.piggery);
        }
        return count.getCount();
    }

}
