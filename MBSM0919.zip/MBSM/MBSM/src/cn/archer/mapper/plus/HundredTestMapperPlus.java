package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.pojo.Count;
import cn.archer.pojo.HundredTest;
import cn.archer.pojo.SixTest;
import java.util.List;
import org.apache.ibatis.session.SqlSession;

import cn.archer.utils.MybatisUtil;
import cn.archer.mapper.HundredTestMapper;

public class HundredTestMapperPlus {

    private String num;
    private String zzzt;
    private String startDate;
    private String endDate;
    private String fenceid;

    public HundredTestMapperPlus() {
        num = null;
        startDate = null;
        endDate = null;
        fenceid = null;
        zzzt = null;
    }

    public void insert(HundredTest hundredtest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            hundredtestMapper.insert(hundredtest);
        }
    }

    public List<HundredTest> SelectByDate(String data1, String data2) {

        List<HundredTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            selectByDate = hundredtestMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<HundredTest> SelectByIdPage(int size, int jump) {
        List<HundredTest> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            selectByIdPage = hundredtestMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<HundredTest> SelectAll() {
        List<HundredTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            selectByDate = hundredtestMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            count = hundredtestMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(HundredTest hundredtest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            hundredtestMapper.updateByid(hundredtest);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            HundredTestMapper hundredtestMapper = sqlSession.getMapper(HundredTestMapper.class);
            hundredtestMapper.deleteByid(id);
        }

    }

    public List<HundredTest> HundredTestSelectSearchByPage(int size, int jump) {
        List<HundredTest> hundredtestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            hundredtestList = searchMapper.HundredTestSelectSearchByPage(num, zzzt, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return hundredtestList;
    }

    public int HundredTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.zzzt = zzzt;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.HundredTestSelectSearchByCount(this.num, this.zzzt, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
