package cn.archer.mapper.plus;

import cn.archer.mapper.JbzlMapper;
import cn.archer.mapper.SearchMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Jbzl;
import cn.archer.utils.MybatisUtil;

public class JbzlMapperPlus {

    private String num;
    private String zzzt;
    private String startDate;
    private String endDate;

    public JbzlMapperPlus() {
        num = null;
        zzzt = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Jbzl jbzl) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class);
            jbzlMapper.insert(jbzl);
        }
    }

    public List<Jbzl> SelectByDate(String data1, String data2) {

        List<Jbzl> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class);
            selectByDate = jbzlMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Jbzl> SelectByIdPage(int size, int jump) {
        List<Jbzl> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class);
            selectByIdPage = jbzlMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Jbzl> SelectAll() {
        List<Jbzl> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class);
            selectByDate = jbzlMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class);
            count = jbzlMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Jbzl jbzl) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class);
            jbzlMapper.updateByid(jbzl);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JbzlMapper jbzlMapper = sqlSession.getMapper(JbzlMapper.class);
            jbzlMapper.deleteByid(id);
        }

    }

    public List<Jbzl> JbzlSelectSearchByPage(int size, int jump) {
        List<Jbzl> jbzlList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            jbzlList = sarchMapper.JbzlSelectSearchByPage(num, zzzt, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return jbzlList;
    }

    public int JbzlSelectSearchByCount(String num, String zzzt, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.zzzt = zzzt;
        this.startDate = startDate;
        this.endDate = endDate;
        System.out.println("编号" + this.num + "状态" + this.zzzt + "开始时间" + this.startDate + "结束时间" + this.endDate);

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.JbzlSelectSearchByCount(this.num, this.zzzt, this.startDate, this.endDate);
        }
        return count.getCount();
    }
}
