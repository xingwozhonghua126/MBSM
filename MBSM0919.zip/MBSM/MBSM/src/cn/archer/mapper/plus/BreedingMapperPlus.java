package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.BreedingMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Breeding;
import cn.archer.utils.MybatisUtil;

public class BreedingMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String pzzt;

    public BreedingMapperPlus() {
        num = null;
        startDate = null;
        endDate = null;
        pzzt = null;
    }

    public void insert(Breeding breeding) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BreedingMapper BreedingMapper = sqlSession.getMapper(BreedingMapper.class);
            BreedingMapper.insert(breeding);
        }
    }

    public List<Breeding> SelectByDate(String data1, String data2) {

        List<Breeding> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BreedingMapper breedingMapper = sqlSession.getMapper(BreedingMapper.class);
            selectByDate = breedingMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Breeding> SelectByIdPage(int size, int jump) {
        List<Breeding> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BreedingMapper breedingMapper = sqlSession.getMapper(BreedingMapper.class);
            selectByIdPage = breedingMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Breeding> SelectAll() {
        List<Breeding> selectAll;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BreedingMapper breedingMapper = sqlSession.getMapper(BreedingMapper.class);
            selectAll = breedingMapper.selectAll();
        }
        return selectAll;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BreedingMapper breedingMapper = sqlSession.getMapper(BreedingMapper.class);
            count = breedingMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Breeding takesperm) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BreedingMapper breedingMapper = sqlSession.getMapper(BreedingMapper.class);
            breedingMapper.updateByid(takesperm);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BreedingMapper breedingMapper = sqlSession.getMapper(BreedingMapper.class);
            breedingMapper.deleteByid(id);
            sqlSession.commit();
            sqlSession.close();
        }

    }

    public List<Breeding> BreedingSelectSearchByPage(int size, int jump) {
        List<Breeding> breedingList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            breedingList = sarchMapper.BreedingSelectSearchByPage(num, fenceid, pzzt, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return breedingList;
    }

    public int BreedingSelectSearchByCount(String num, String fenceid, String pzzt, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pzzt = pzzt;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.BreedingSelectSearchByCount(this.num, this.fenceid, this.pzzt, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
