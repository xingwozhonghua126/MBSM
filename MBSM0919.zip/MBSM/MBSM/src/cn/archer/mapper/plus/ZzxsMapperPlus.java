package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.ZzxsMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Zzxs;
import cn.archer.utils.MybatisUtil;

public class ZzxsMapperPlus {

    private String startDate;
    private String endDate;

    public ZzxsMapperPlus() {
        startDate = null;
        endDate = null;
    }

    public void insert(Zzxs zzxs) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            zzxsMapper.insert(zzxs);
        }
    }

    public List<Zzxs> SelectByDate(String data1, String data2) {

        List<Zzxs> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            selectByDate = zzxsMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Zzxs> SelectByIdPage(int size, int jump) {
        List<Zzxs> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            selectByIdPage = zzxsMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Zzxs> SelectAll() {
        List<Zzxs> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            selectByDate = zzxsMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            count = zzxsMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Zzxs zzxs) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            zzxsMapper.updateByid(zzxs);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzxsMapper zzxsMapper = sqlSession.getMapper(ZzxsMapper.class);
            zzxsMapper.deleteByid(id);
        }

    }

    public List<Zzxs> ZzxsSelectSearchByPage(int size, int jump) {
        List<Zzxs> zzxsList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            zzxsList = searchMapper.ZzxsSelectSearchByPage(startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return zzxsList;
    }

    public int ZzxsSelectSearchByCount(String startDate, String endDate) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.ZzxsSelectSearchByCount(this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
