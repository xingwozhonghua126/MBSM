package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.YmckMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Ymck;
import cn.archer.utils.MybatisUtil;

public class YmckMapperPlus {

    private String piggery;
    private String startDate;
    private String endDate;

    public YmckMapperPlus() {
        piggery = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Ymck ymck) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class);
            ymckMapper.insert(ymck);
        }
    }

    public List<Ymck> SelectByDate(String data1, String data2) {

        List<Ymck> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class);
            selectByDate = ymckMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Ymck> SelectByIdPage(int size, int jump) {
        List<Ymck> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class);
            selectByIdPage = ymckMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Ymck> SelectAll() {
        List<Ymck> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class);
            selectByDate = ymckMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class);
            count = ymckMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Ymck ymck) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class);
            ymckMapper.updateByid(ymck);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmckMapper ymckMapper = sqlSession.getMapper(YmckMapper.class);
            ymckMapper.deleteByid(id);
        }

    }

    public List<Ymck> YmckSelectSearchByPage(int size, int jump) {
        List<Ymck> ymckList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            ymckList = searchMapper.YmckSelectSearchByPage(piggery, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return ymckList;
    }

    public int YmckSelectSearchByCount(String piggery, String startDate, String endDate) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.YmckSelectSearchByCount(this.piggery, this.startDate, this.endDate);
        }
        return count.getCount();
    }

    public int YmckSelectSearchByCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
