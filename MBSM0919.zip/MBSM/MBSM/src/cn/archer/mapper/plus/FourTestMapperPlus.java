package cn.archer.mapper.plus;

import cn.archer.mapper.FourTestMapper;
import cn.archer.mapper.SearchMapper;
import cn.archer.pojo.Count;
import cn.archer.pojo.FourTest;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.utils.MybatisUtil;

public class FourTestMapperPlus {

    private String num;
    private String zzzt;
    private String startDate;
    private String endDate;
    private String fenceid;

    public FourTestMapperPlus() {
        num = null;
        startDate = null;
        endDate = null;
        fenceid = null;
    }

    public void insert(FourTest fourTest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            fourTestMapper.insert(fourTest);
        }
    }

    public List<FourTest> SelectByDate(String data1, String data2) {

        List<FourTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            selectByDate = fourTestMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<FourTest> SelectByIdPage(int size, int jump) {
        List<FourTest> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            selectByIdPage = fourTestMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<FourTest> SelectAll() {
        List<FourTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            selectByDate = fourTestMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            count = fourTestMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(FourTest fourTest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            fourTestMapper.updateByid(fourTest);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FourTestMapper fourTestMapper = sqlSession.getMapper(FourTestMapper.class);
            fourTestMapper.deleteByid(id);
        }

    }

    public List<FourTest> FourTestSelectSearchByPage(int size, int jump) {
        List<FourTest> fourTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            fourTestList = searchMapper.FourTestSelectSearchByPage(num, zzzt, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return fourTestList;
    }

    public int FourTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.zzzt = zzzt;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.FourTestSelectSearchByCount(this.num, this.zzzt, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
