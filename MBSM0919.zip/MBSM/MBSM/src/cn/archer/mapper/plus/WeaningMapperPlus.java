package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.WeaningMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Childbirth;
import cn.archer.utils.MybatisUtil;

public class WeaningMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;

    public WeaningMapperPlus() {

    }

    public List<Childbirth> SelectByDate(String data1, String data2) {

        List<Childbirth> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
            selectByDate = weaningMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Childbirth> SelectByIdPage(int size, int jump) {
        List<Childbirth> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
            selectByIdPage = weaningMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Childbirth> SelectAll() {
        List<Childbirth> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
            selectByDate = weaningMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
            count = weaningMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Childbirth childbirth) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            WeaningMapper weaningMapper = sqlSession.getMapper(WeaningMapper.class);
            weaningMapper.updateByid(childbirth);
        }
    }

    public List<Childbirth> WeaningSelectSearchByPage(int size, int jump) {
        List<Childbirth> childbirthList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            childbirthList = sarchMapper.WeaningSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return childbirthList;
    }

    public int WeaningSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        Count count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.WeaningSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
