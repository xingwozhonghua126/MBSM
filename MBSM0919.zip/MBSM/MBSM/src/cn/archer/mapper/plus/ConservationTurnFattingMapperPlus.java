package cn.archer.mapper.plus;

import cn.archer.mapper.ConservationTurnFatteningPigMapper;
import cn.archer.mapper.SearchMapper;
;

import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;



public class ConservationTurnFattingMapperPlus {

    private String num;
    private String sex;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String pzzt;

    public ConservationTurnFattingMapperPlus() {
        num = null;
        sex = null;
        startDate = null;
        endDate = null;
        pzzt = null;
    }

    public void insert(Selebith selebith) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class);
            conservationTurnFatteningPigMapper.insert(selebith);
        }
    }

    public List<Selebith> SelectByDate(String data1, String data2) {

        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class);
            selectByDate = conservationTurnFatteningPigMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Selebith> SelectByIdPage(int size, int jump) {
        List<Selebith> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class);
            selectByIdPage = conservationTurnFatteningPigMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Selebith> SelectAll() {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class);
            selectByDate = conservationTurnFatteningPigMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class);
            count = conservationTurnFatteningPigMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Selebith takesperm) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class);
            conservationTurnFatteningPigMapper.updateByid(takesperm);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnFatteningPigMapper conservationTurnFatteningPigMapper = sqlSession.getMapper(ConservationTurnFatteningPigMapper.class);
            conservationTurnFatteningPigMapper.deleteByid(id);
            sqlSession.commit();
            sqlSession.close();
        }

    }

    public List<Selebith> ConservationTurnFattingSelectSearchByPage(int size, int jump) {
        List<Selebith> breedingList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            breedingList = sarchMapper.ConservationTurnFattingSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return breedingList;
    }

    public int ConservationTurnFattingSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.ConservationTurnFattingSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
