package cn.archer.mapper.plus;

import cn.archer.mapper.JyjcMapper;
import cn.archer.mapper.SearchMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Jyjc;
import cn.archer.utils.MybatisUtil;

public class JyjcMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;

    public JyjcMapperPlus() {
        num = null;
        fenceid = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Jyjc jyjc) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class);
            jyjcMapper.insert(jyjc);
        }
    }

    public List<Jyjc> SelectByDate(String data1, String data2) {

        List<Jyjc> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class);
            selectByDate = jyjcMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Jyjc> SelectByIdPage(int size, int jump) {
        List<Jyjc> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class);
            selectByIdPage = jyjcMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Jyjc> SelectAll() {
        List<Jyjc> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class);
            selectByDate = jyjcMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class);
            count = jyjcMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Jyjc jyjc) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class);
            jyjcMapper.updateByid(jyjc);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JyjcMapper jyjcMapper = sqlSession.getMapper(JyjcMapper.class);
            jyjcMapper.deleteByid(id);
        }

    }

    public List<Jyjc> JyjcSelectSearchByPage(int size, int jump) {
        List<Jyjc> jyjcList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            jyjcList = searchMapper.JyjcSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return jyjcList;
    }

    public int JyjcSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.JyjcSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
