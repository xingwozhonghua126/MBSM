package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.SlckMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Slck;
import cn.archer.utils.MybatisUtil;

public class SlckMapperPlus {

    private String piggery;
    private String startDate;
    private String endDate;

    public SlckMapperPlus() {
        piggery = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Slck slck) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class);
            slckMapper.insert(slck);
        }
    }

    public List<Slck> SelectByDate(String data1, String data2) {

        List<Slck> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class);
            selectByDate = slckMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Slck> SelectByIdPage(int size, int jump) {
        List<Slck> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class);
            selectByIdPage = slckMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Slck> SelectAll() {
        List<Slck> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class);
            selectByDate = slckMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class);
            count = slckMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Slck slck) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class);
            slckMapper.updateByid(slck);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlckMapper slckMapper = sqlSession.getMapper(SlckMapper.class);
            slckMapper.deleteByid(id);
        }

    }

    public List<Slck> SlckSelectSearchByPage(int size, int jump) {
        List<Slck> slckList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            slckList = searchMapper.SlckSelectSearchByPage(piggery, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return slckList;
    }

    public int SlckSelectSearchByCount(String piggery, String startDate, String endDate) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.SlckSelectSearchByCount(this.piggery, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
