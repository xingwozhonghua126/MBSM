package cn.archer.mapper.plus;

import cn.archer.mapper.ConservationTurnBackPigMapper;
import cn.archer.mapper.ConservationTurnFatteningPigMapper;
import cn.archer.mapper.SearchMapper;
;

import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;



public class ConservationTurnBackMapperPlus {

    private String num;
    private String sex;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String pzzt;
    private ConservationTurnBackPigMapper conservationTurnBackPigMapper;

    public ConservationTurnBackMapperPlus() {
        num = null;
        sex = null;
        startDate = null;
        endDate = null;
        pzzt = null;
    }

    public List<Selebith> SelectByDate(String data1, String data2) {

        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            conservationTurnBackPigMapper = sqlSession.getMapper(ConservationTurnBackPigMapper.class);
            selectByDate = conservationTurnBackPigMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Selebith> SelectByIdPage(int size, int jump) {
        List<Selebith> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            conservationTurnBackPigMapper = sqlSession.getMapper(ConservationTurnBackPigMapper.class);
            selectByIdPage = conservationTurnBackPigMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Selebith> SelectAll() {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            conservationTurnBackPigMapper = sqlSession.getMapper(ConservationTurnBackPigMapper.class);
            selectByDate = conservationTurnBackPigMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            conservationTurnBackPigMapper = sqlSession.getMapper(ConservationTurnBackPigMapper.class);
            count = conservationTurnBackPigMapper.selectCount().getCount();
        }
        return count;
    }

    public List<Selebith> ConservationTurnBackSelectSearchByPage(int size, int jump) {
        List<Selebith> breedingList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            breedingList = sarchMapper.ConservationTurnBackSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return breedingList;
    }

    public int ConservationTurnBackSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.ConservationTurnBackSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
