package cn.archer.mapper.plus;

import cn.archer.mapper.BoarMapper;
import cn.archer.mapper.SearchMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;

public class MaleBoarMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;

    public MaleBoarMapperPlus() {
        num = null;
        fenceid = null;
        startDate = null;
        endDate = null;
    }

    public List<Selebith> selectAllMalePage(int size, int jump) {
        List<Selebith> selectAllMalePage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            selectAllMalePage = boarMapper.selectAllMalePage(size, jump);
        }
        return selectAllMalePage;
    }

    public List<Selebith> selectAllMale() {
        List<Selebith> selectAllMale;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            selectAllMale = boarMapper.selectAllMale();
        }
        return selectAllMale;
    }

    public int selectAllMaleCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            count = boarMapper.selectAllMaleCount().getCount();
        }
        return count;
    }

    public List<Selebith> MaleBoarSelectSearchByPage(int size, int jump) {
        List<Selebith> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            selebithList = searchMapper.MaleBoarSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return selebithList;
    }

    public int MaleBoarSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.MaleBoarSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }
}
