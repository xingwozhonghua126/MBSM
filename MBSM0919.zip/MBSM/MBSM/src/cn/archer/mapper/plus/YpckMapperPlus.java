package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.YpckMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Ypck;
import cn.archer.utils.MybatisUtil;

public class YpckMapperPlus {

    private String piggery;
    private String startDate;
    private String endDate;

    public YpckMapperPlus() {
        piggery = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Ypck ypck) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class);
            ypckMapper.insert(ypck);
        }
    }

    public List<Ypck> SelectByDate(String data1, String data2) {

        List<Ypck> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class);
            selectByDate = ypckMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Ypck> SelectByIdPage(int size, int jump) {
        List<Ypck> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class);
            selectByIdPage = ypckMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Ypck> SelectAll() {
        List<Ypck> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class);
            selectByDate = ypckMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class);
            count = ypckMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Ypck ypck) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class);
            ypckMapper.updateByid(ypck);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YpckMapper ypckMapper = sqlSession.getMapper(YpckMapper.class);
            ypckMapper.deleteByid(id);
        }

    }

    public List<Ypck> YpckSelectSearchByPage(int size, int jump) {
        List<Ypck> ypckList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            ypckList = sarchMapper.YpckSelectSearchByPage(piggery, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return ypckList;
    }

    public int YpckSelectSearchByCount(String piggery, String startDate, String endDate) {
        Count count;
        this.piggery = piggery;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.YpckSelectSearchByCount(this.piggery, this.startDate, this.endDate);
        }
        return count.getCount();
    }

    public int YpckSelectSearchByCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
