package cn.archer.mapper.plus;

import cn.archer.mapper.ConservationTurnBackPigMapper;
import cn.archer.mapper.FeedingTurnConservationPigMapper;
import cn.archer.mapper.SearchMapper;
;

import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;



public class FeedingTurnConservationMapperPlus {

    private String num;
    private String sex;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String pzzt;
    private FeedingTurnConservationPigMapper feedingTurnConservationPigMapper;

    public FeedingTurnConservationMapperPlus() {
        num = null;
        sex = null;
        startDate = null;
        endDate = null;
        pzzt = null;
    }

    public List<Selebith> SelectByDate(String data1, String data2) {

        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            feedingTurnConservationPigMapper = sqlSession.getMapper(FeedingTurnConservationPigMapper.class);
            selectByDate = feedingTurnConservationPigMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Selebith> SelectByIdPage(int size, int jump) {
        List<Selebith> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            feedingTurnConservationPigMapper = sqlSession.getMapper(FeedingTurnConservationPigMapper.class);
            selectByIdPage = feedingTurnConservationPigMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Selebith> SelectAll() {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            feedingTurnConservationPigMapper = sqlSession.getMapper(FeedingTurnConservationPigMapper.class);
            selectByDate = feedingTurnConservationPigMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            feedingTurnConservationPigMapper = sqlSession.getMapper(FeedingTurnConservationPigMapper.class);
            count = feedingTurnConservationPigMapper.selectCount().getCount();
        }
        return count;
    }

    public List<Selebith> FeedingTurnConservationSelectSearchByPage(int size, int jump) {
        List<Selebith> breedingList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            breedingList = searchMapper.FeedingTurnConservationSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return breedingList;
    }

    public int FeedingTurnConservationSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.FeedingTurnConservationSelectSearchByCount(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
