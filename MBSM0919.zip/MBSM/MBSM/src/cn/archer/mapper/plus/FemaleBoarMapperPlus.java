package cn.archer.mapper.plus;

import cn.archer.mapper.BoarMapper;
import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.BreedingMapper;
import cn.archer.mapper.ChildbirthMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;

public class FemaleBoarMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String zzzt;

    public FemaleBoarMapperPlus() {
        num = null;
        fenceid = null;
        startDate = null;
        endDate = null;
        zzzt = null;
    }

    public List<Selebith> selectAllFemalePage(int size, int jump) {
        List<Selebith> selectAllFemalePage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            selectAllFemalePage = boarMapper.selectAllFemalePage(size, jump);
        }
        return selectAllFemalePage;
    }

    public List<Selebith> selectAllFemale() {
        List<Selebith> selectAllFemale;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            selectAllFemale = boarMapper.selectAllFemale();
        }
        return selectAllFemale;
    }

    public int selectAllFemaleCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            count = boarMapper.selectAllFemaleCount().getCount();
        }
        return count;
    }

    public List<Breeding> selectAllPZ(String r_animal) {
        List<Breeding> selectAllPZ;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            selectAllPZ = boarMapper.selectAllPZ(r_animal);
        }
        return selectAllPZ;
    }

    public List<Childbirth> selectAllFM(String r_animal) {
        List<Childbirth> selectAllFM;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            selectAllFM = boarMapper.selectAllFM(r_animal);
        }
        return selectAllFM;
    }

    public List<Childbirth> selectAllDM(String r_animal) {
        List<Childbirth> selectAllDM;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            BoarMapper boarMapper = sqlSession.getMapper(BoarMapper.class);
            selectAllDM = boarMapper.selectAllDM(r_animal);
        }
        return selectAllDM;
    }

    public List<Selebith> FemaleBoarSelectSearchByPage(int size, int jump) {
//        if (zzzt.equals("%")) {
//            return selectAllFemalePage(size, jump);
//        }
        List<Selebith> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            selebithList = searchMapper.FemaleBoarSelectSearchByPage(num, fenceid, zzzt, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return selebithList;
    }

    public List<Selebith> FemaleBoarSelectSearchByPage02(int size, int jump) {
//        if (zzzt.equals("%")) {
//            return selectAllFemalePage(size, jump);
//        }
        List<Selebith> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            selebithList = searchMapper.FemaleBoarSelectSearchByPage02(num, zzzt, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return selebithList;
    }

    public int FemaleBoarSelectSearchByCount(String num, String fenceid, String zzzt, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        this.zzzt = zzzt;
        if (this.zzzt.equals("%")) {
            return FemaleBoarSelectSearchByCount02(this.num, this.fenceid, this.startDate, this.endDate);
        }
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.FemaleBoarSelectSearchByCount(this.num, this.fenceid, this.zzzt, this.startDate, this.endDate);
        }
        return count.getCount();
    }

    public int FemaleBoarSelectSearchByCount02(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num + "%";
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;

        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.FemaleBoarSelectSearchByCount02(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
