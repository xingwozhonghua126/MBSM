package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.SlrkMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Slrk;
import cn.archer.utils.MybatisUtil;

public class SlrkMapperPlus {

    private String startDate;
    private String endDate;

    public SlrkMapperPlus() {
        startDate = null;
        endDate = null;
    }

    public void insert(Slrk slrk) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class);
            slrkMapper.insert(slrk);
        }
    }

    public List<Slrk> SelectByDate(String data1, String data2) {

        List<Slrk> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class);
            selectByDate = slrkMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Slrk> SelectByIdPage(int size, int jump) {
        List<Slrk> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class);
            selectByIdPage = slrkMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Slrk> SelectAll() {
        List<Slrk> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class);
            selectByDate = slrkMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class);
            count = slrkMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Slrk slrk) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class);
            slrkMapper.updateByid(slrk);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SlrkMapper slrkMapper = sqlSession.getMapper(SlrkMapper.class);
            slrkMapper.deleteByid(id);
        }

    }

    public List<Slrk> SlrkSelectSearchByPage(int size, int jump) {
        List<Slrk> slrkList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            slrkList = searchMapper.SlrkSelectSearchByPage(startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return slrkList;
    }

    public int SlrkSelectSearchByCount(String startDate, String endDate) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.SlrkSelectSearchByCount(this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
