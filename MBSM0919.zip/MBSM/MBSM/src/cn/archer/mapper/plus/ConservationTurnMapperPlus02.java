package cn.archer.mapper.plus;

import cn.archer.mapper.ConservationTurnPigMapper02;
import cn.archer.mapper.SearchMapper;

import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;

public class ConservationTurnMapperPlus02 {

    private String num;
    private String sex;
    private String fenceid;
    private String startDate;
    private String endDate;
    private String pzzt;

    public ConservationTurnMapperPlus02() {
        num = null;
        sex = null;
        startDate = null;
        endDate = null;
        pzzt = null;
    }

    public List<Selebith> SelectByDate02FatteningPig(String data1, String data2) {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            selectByDate = conservationTurnPigMapper.selectByDate02FatteningPig(data1, data2);
        }
        return selectByDate;
    }

    public List<Selebith> SelectByDate02BackPig(String data1, String data2) {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            selectByDate = conservationTurnPigMapper.selectByDate02BackPig(data1, data2);
        }
        return selectByDate;
    }

    public List<Selebith> SelectByIdPage02FatteningPig(int size, int jump) {
        List<Selebith> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            selectByIdPage = conservationTurnPigMapper.selectByIdPage02FatteningPig(size, jump);
        }
        return selectByIdPage;
    }

    public List<Selebith> SelectByIdPage02BackPig(int size, int jump) {
        List<Selebith> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            selectByIdPage = conservationTurnPigMapper.selectByIdPage02BackPig(size, jump);
        }
        return selectByIdPage;
    }

    public List<Selebith> SelectAll02FatteningPig() {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            selectByDate = conservationTurnPigMapper.selectAll02FatteningPig();
        }
        return selectByDate;
    }

    public List<Selebith> SelectAll02BackPig() {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            selectByDate = conservationTurnPigMapper.selectAll02BackPig();
        }
        return selectByDate;
    }

    public int SelectCount02FatteningPig() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            count = conservationTurnPigMapper.selectCount02FatteningPig().getCount();
        }
        return count;
    }

    public int SelectCount02BackPig() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            count = conservationTurnPigMapper.selectCount02BackPig().getCount();
        }
        return count;
    }

    public void updateById02BackPig(Selebith takesperm) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper02 = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            conservationTurnPigMapper02.updateById02BackPig(takesperm);
        }
    }

    public void updateById02FatteningPig(Selebith takesperm) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ConservationTurnPigMapper02 conservationTurnPigMapper02 = sqlSession.getMapper(ConservationTurnPigMapper02.class);
            conservationTurnPigMapper02.updateById02FatteningPig(takesperm);
        }
    }

    public List<Selebith> ConservationTurnFatteningSelectSearchByPage02(int size, int jump) {
        List<Selebith> breedingList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            breedingList = sarchMapper.ConservationTurnFatteningSelectSearchByPage02(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return breedingList;
    }

    public int ConservationTurnFatteningSelectSearchByCount02(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = "%" + num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.ConservationTurnFatteningSelectSearchByCount02(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

    public List<Selebith> ConservationTurnBackSelectSearchByPage02(int size, int jump) {
        List<Selebith> breedingList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            breedingList = sarchMapper.ConservationTurnBackSelectSearchByPage02(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return breedingList;
    }

    public int ConservationTurnBackSelectSearchByCount02(String num, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = "%" + num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.ConservationTurnBackSelectSearchByCount02(this.num, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
