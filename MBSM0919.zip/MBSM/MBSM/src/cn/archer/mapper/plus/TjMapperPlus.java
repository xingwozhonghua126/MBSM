package cn.archer.mapper.plus;

import static cn.archer.app.MainApp.pigBYCategoryThingsShow;
import static cn.archer.app.MainApp.pigYFCategoryThingsShow;
import static cn.archer.app.MainApp.pigYmThingsShow;
import static cn.archer.app.MainApp.pigYpThingsShow;
import static cn.archer.app.MainApp.piggeryNametoIdSmap;
import static cn.archer.app.MainApp.pigslBRMZThingsShow;
import static cn.archer.app.MainApp.pigslBRZZThingsShow;
import static cn.archer.app.MainApp.pigslBYZThingsShow;
import static cn.archer.app.MainApp.pigslHBMZThingsShow;
import static cn.archer.app.MainApp.pigslHBZThingsShow;
import static cn.archer.app.MainApp.pigslKHMZThingsShow;
import static cn.archer.app.MainApp.pigslNametoIdSmap;
import static cn.archer.app.MainApp.pigslRSMZThingsShow;
import static cn.archer.app.MainApp.pigslSZYFZThingsShow;
import static cn.archer.app.MainApp.pigslThingsShow;
import static cn.archer.app.MainApp.pigslZGZThingsShow;
import static cn.archer.app.MainApp.pigypNametoIdSmap;
import static cn.archer.app.MainApp.vaccineNametoIdSmap;
import cn.archer.mapper.TjMapper;
import cn.archer.pojo.Count;
import static cn.archer.utils.MyStaticMethod.addDate;
import org.apache.ibatis.session.SqlSession;
import cn.archer.utils.MybatisUtil;
import java.util.ArrayList;
import java.util.List;

public class TjMapperPlus {

    private String startDate;
    private String endDate;
    private String pignum;
    private String fenceid;
    private String employe;
    private String number;

    public TjMapperPlus() {
        startDate = null;
        endDate = null;
        pignum = null;
        fenceid = null;
        employe = null;
        number = null;
    }

    public String selectById(String id) {
        String temp;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            temp = tjMapper.selectById(this.pignum);
        }
        if (temp == null) {
            return "输入编号不存在";
        }

        return temp;
    }

    public int selectFqcs(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectFqcs(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectFqcsday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFqcsday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFqcsmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFqcsmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFqcsyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFqcsyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public int selectPzcs(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectPzcs(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectPzcsday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectPzcsday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectPzcsmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectPzcsmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectPzcsyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectPzcsyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public int selectPzcs2(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectPzcs2(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectPzcs2day(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectPzcs2day(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectPzcs2month(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectPzcs2month(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectPzcs2year(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectPzcs2year(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public int selectRscs(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectRscs(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectRscsday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectRscsday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectRscsmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectRscsmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectRscsyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectRscsyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public int selectFmcs(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectFmcs(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe,addDate(this.startDate,107), addDate(this.endDate,120));
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectFmcsday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmcsday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe,addDate(this.startDate,107), addDate(this.endDate,120));
        }

        return countList;
    }

    public List<Count> selectFmcsmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmcsmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe,addDate(this.startDate,107), addDate(this.endDate,120));
        }

        return countList;
    }

    public List<Count> selectFmcsyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmcsyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe,addDate(this.startDate,107), addDate(this.endDate,120));
        }
        return countList;
    }

    public int selectFmts(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectFmts(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectFmtsday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmtsday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFmtsmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmtsmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFmtsyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmtsyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public int selectFmzzs(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectFmzzs(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectFmzzsday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmzzsday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFmzzsmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmzzsmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFmzzsyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmzzsyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        return countList;
    }

    public int selectFmhzs(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectFmhzs(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectFmhzsday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmhzsday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFmhzsmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmhzsmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectFmhzsyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectFmhzsyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }

        return countList;
    }

    public int selectCswzz(String startDate, String endDate, String pignum, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectCswzz(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectCswzzyear(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectCswzzyear(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectCswzzmonth(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectCswzzmonth(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectCswzzday(String startDate, String endDate, String pignum, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.pignum = pignum;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectCswzzday(this.startDate, this.endDate, this.pignum, this.fenceid, this.employe);
        }
        return countList;
    }

    public int selectDnzgs(String startDate, String endDate, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectDnzgs(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectDnzgsday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDnzgsday(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectDnzgsmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDnzgsmonth(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectDnzgsyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDnzgsyear(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public int selectDnts(String startDate, String endDate, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectDnts(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectDntsday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDntsday(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectDntsmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDntsmonth(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectDntsyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDntsyear(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public int selectDnzwwz(String startDate, String endDate, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectDnzwwz(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectDnzwwzday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDnzwwzday(this.startDate, this.endDate, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectDnzwwzmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDnzwwzmonth(this.startDate, this.endDate, this.fenceid, this.employe);
        }

        return countList;
    }

    public List<Count> selectDnzwwzyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectDnzwwzyear(this.startDate, this.endDate, this.fenceid, this.employe);
        }

        return countList;
    }

    public int selectByszs(String startDate, String endDate, String fenceid, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigBYCategoryThingsShow.length; i++) {
                    temp = tjMapper.selectByszs(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigBYCategoryThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setCount(count.getCount() + temp.getCount());
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectByszs(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectByszsday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigBYCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectByszsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigBYCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectByszsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public List<Count> selectByszsmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigBYCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectByszsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigBYCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectByszsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public List<Count> selectByszsyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigBYCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectByszsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigBYCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectByszsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public int selectBysswzs(String startDate, String endDate, String fenceid, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigBYCategoryThingsShow.length; i++) {
                    temp = tjMapper.selectBysswzs(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigBYCategoryThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setCount(count.getCount() + temp.getCount());
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectBysswzs(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectBysswzsday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectBysswzsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                tempList = tjMapper.selectBysswzsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        }
        return countList;
    }

    public List<Count> selectBysswzsmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectBysswzsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectBysswzsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public List<Count> selectBysswzsyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部保育舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectBysswzsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectBysswzsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public int selectYfszs(String startDate, String endDate, String fenceid, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    temp = tjMapper.selectYfszs(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setCount(count.getCount() + temp.getCount());
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectByszs(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectYfszsday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectYfszsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYfszsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public List<Count> selectYfszsmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        Count count = new Count();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectYfszsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYfszsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public List<Count> selectYfszsyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectYfszsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYfszsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public int selectYfsswzs(String startDate, String endDate, String typeid, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = typeid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    temp = tjMapper.selectYfsswzs(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setCount(count.getCount() + temp.getCount());
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectYfsswzs(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        if (count == null) {
            return 0;
        }
        return count.getCount();
    }

    public List<Count> selectYfsswzsday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectYfsswzsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYfsswzsday(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public List<Count> selectYfsswzsmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectYfsswzsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYfsswzsmonth(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public List<Count> selectYfsswzsyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部育肥舍")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYFCategoryThingsShow.length; i++) {
                    tempList = tjMapper.selectYfsswzsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(pigYFCategoryThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYfsswzsyear(this.startDate, this.endDate, piggeryNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public Count selectSlrk(String startDate, String endDate, String fenceid, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                temp = tjMapper.selectSlrk(this.startDate, this.endDate, "%", this.employe);
                if (temp != null) {
                    count.setNum(count.getNum() + temp.getNum());
                    count.setMoney(count.getMoney() + temp.getMoney());
                }
            }
        } else if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslThingsShow.length; i++) {
                    temp = tjMapper.selectSlrk(this.startDate, this.endDate, "%", this.employe);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                        count.setMoney(count.getMoney() + temp.getMoney());
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectSlrk(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        if (count == null) {
            count = new Count();
            count.setNum(0);
            count.setMoney(0);
        }
        return count;
    }

    public List<Count> selectSlrkday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        System.out.println("day：startDate" + startDate + "endDate" + endDate + "fenceid" + fenceid + "employe" + employe);
        if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                tempList = tjMapper.selectSlrkday(this.startDate, this.endDate, "%", this.employe);
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectSlrkday(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public List<Count> selectSlrkmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        System.out.println("month：startDate" + startDate + "endDate" + endDate + "fenceid" + fenceid + "employe" + employe);
        if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                tempList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, "%", this.employe);
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectSlrkmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public List<Count> selectSlrkyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                tempList = tjMapper.selectSlrkyear(this.startDate, this.endDate, "%", this.employe);
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectSlrkyear(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public Count selectYprk(String startDate, String endDate, String fenceid, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                temp = tjMapper.selectYprk(this.startDate, this.endDate, "%", this.employe);
                if (temp != null) {
                    count.setNum(count.getNum() + temp.getNum());
                    count.setMoney(count.getMoney() + temp.getMoney());
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectYprk(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        if (count == null) {
            count = new Count();
            count.setNum(0);
            count.setMoney(0);
        }
        return count;
    }

    public List<Count> selectYprkday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYpThingsShow.length; i++) {
                    tempList = tjMapper.selectYprkday(this.startDate, this.endDate, pigypNametoIdSmap.get(pigYpThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYprkday(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public List<Count> selectYprkmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYpThingsShow.length; i++) {
                    tempList = tjMapper.selectYprkmonth(this.startDate, this.endDate, pigypNametoIdSmap.get(pigYpThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYprkmonth(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public List<Count> selectYprkyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYpThingsShow.length; i++) {
                    tempList = tjMapper.selectYprkyear(this.startDate, this.endDate, pigypNametoIdSmap.get(pigYpThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYprkyear(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        return countList;
    }

    public Count selectYmrk(String startDate, String endDate, String fenceid, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                temp = tjMapper.selectYmrk(this.startDate, this.endDate, "%", this.employe);
                if (temp != null) {
                    count.setNum(count.getNum() + temp.getNum());
                    count.setMoney(count.getMoney() + temp.getMoney());
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectYmrk(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }
        if (count == null) {
            count = new Count();
            count.setNum(0);
            count.setMoney(0);
        }
        return count;
    }

    public List<Count> selectYmrkday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYmThingsShow.length; i++) {
                    tempList = tjMapper.selectYmrkday(this.startDate, this.endDate, vaccineNametoIdSmap.get(pigYmThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYmrkday(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public List<Count> selectYmrkmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYmThingsShow.length; i++) {
                    tempList = tjMapper.selectYmrkmonth(this.startDate, this.endDate, vaccineNametoIdSmap.get(pigYmThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYmrkmonth(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public List<Count> selectYmrkyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYmThingsShow.length; i++) {
                    tempList = tjMapper.selectYmrkyear(this.startDate, this.endDate, vaccineNametoIdSmap.get(pigYmThingsShow[i]) + "%", this.employe);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYmrkyear(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe);
            }
        }

        return countList;
    }

    public Count selectSlck(String startDate, String endDate, String fenceid, String employe, String number) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                temp = tjMapper.selectSlck(this.startDate, this.endDate, "%", this.employe, this.number);
                if (temp != null) {
                    count.setNum(count.getNum() + temp.getNum());
                }
            }
        } else if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslThingsShow.length; i++) {
                    temp = tjMapper.selectSlck(this.startDate, this.endDate, "%", this.employe, this.number);
                    if (temp != null) {
                        count.setNum(count.getNum() + temp.getNum());
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        if (count == null) {
            count = new Count();
            count.setNum(0);
        }
        return count;
    }

    public List<Count> selectSlckday(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                tempList = tjMapper.selectSlckday(this.startDate, this.endDate, "%", this.employe, this.number);
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }

        return countList;
    }

    public List<Count> selectSlckmonth(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                tempList = tjMapper.selectSlckmonth(this.startDate, this.endDate, "%", this.employe, this.number);
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }

        return countList;
    }

    public List<Count> selectSlckyear(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部哺乳仔猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部保育猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部生长育肥猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部后备母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslHBMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslHBMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部妊娠母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslRSMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslRSMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部哺乳母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslBRMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("空怀母猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslKHMZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslKHMZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部种公猪类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigslZGZThingsShow.length; i++) {
                    tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslZGZThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else if (this.fenceid.equals("全部饲料类型")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                tempList = tjMapper.selectSlckyear(this.startDate, this.endDate, "%", this.employe, this.number);
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }

        return countList;
    }

    public Count selectYpck(String startDate, String endDate, String fenceid, String employe, String number) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                temp = tjMapper.selectYpck(this.startDate, this.endDate, "%", this.employe, this.number);
                if (temp != null) {
                    count.setNum(count.getNum() + temp.getNum());
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectYpck(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        if (count == null) {
            count = new Count();
            count.setNum(0);
        }
        return count;
    }

    public List<Count> selectYpckday(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYpThingsShow.length; i++) {
                    tempList = tjMapper.selectYpckday(this.startDate, this.endDate, pigypNametoIdSmap.get(pigYpThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYpckday(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        return countList;
    }

    public List<Count> selectYpckmonth(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYpThingsShow.length; i++) {
                    tempList = tjMapper.selectYpckmonth(this.startDate, this.endDate, pigypNametoIdSmap.get(pigYpThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYpckmonth(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        return countList;
    }

    public List<Count> selectYpckyear(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部药品")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYpThingsShow.length; i++) {
                    tempList = tjMapper.selectYpckyear(this.startDate, this.endDate, pigypNametoIdSmap.get(pigYpThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYpckyear(this.startDate, this.endDate, pigypNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        return countList;
    }

    public Count selectYmck(String startDate, String endDate, String fenceid, String employe, String number) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;

        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                temp = tjMapper.selectYmck(this.startDate, this.endDate, "%", this.employe, this.number);
                if (temp != null) {
                    count.setNum(count.getNum() + temp.getNum());
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                count = tjMapper.selectYmck(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        if (count == null) {
            count = new Count();
            count.setNum(0);
        }
        return count;
    }

    public List<Count> selectYmckday(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYmThingsShow.length; i++) {
                    tempList = tjMapper.selectYmckday(this.startDate, this.endDate, vaccineNametoIdSmap.get(pigYmThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYmckday(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        return countList;
    }

    public List<Count> selectYmckmonth(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYmThingsShow.length; i++) {
                    tempList = tjMapper.selectYmckmonth(this.startDate, this.endDate, vaccineNametoIdSmap.get(pigYmThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYmckmonth(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        return countList;
    }

    public List<Count> selectYmckyear(String startDate, String endDate, String fenceid, String employe, String number) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        this.number = number;
        if (this.fenceid.equals("全部疫苗")) {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                for (int i = 0; i < pigYmThingsShow.length; i++) {
                    tempList = tjMapper.selectYmckyear(this.startDate, this.endDate, vaccineNametoIdSmap.get(pigYmThingsShow[i]) + "%", this.employe, this.number);
                    if (tempList != null) {
                        countList.addAll(tempList);
                    }
                }
            }
        } else {
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
                countList = tjMapper.selectYmckyear(this.startDate, this.endDate, vaccineNametoIdSmap.get(this.fenceid) + "%", this.employe, this.number);
            }
        }
        return countList;
    }

    public int selectZzsw(String startDate, String endDate, String fenceid, String employe) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectZzsw(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectZzswday(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectZzswday(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectZzswmonth(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectZzswmonth(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public List<Count> selectZzswyear(String startDate, String endDate, String fenceid, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fenceid = fenceid;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectZzswyear(this.startDate, this.endDate, this.fenceid, this.employe);
        }
        return countList;
    }

    public Count selectZzxs(String startDate, String endDate, String employe) {
        Count count = new Count();
        Count temp = null;
        this.startDate = startDate;
        this.endDate = endDate;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectZzxs(this.startDate, this.endDate, this.employe);
        }
        if (count == null) {
            count = new Count();
            count.setNum(0);
        }
        return count;
    }

    public List<Count> selectZzxsday(String startDate, String endDate, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectZzxsday(this.startDate, this.endDate, this.employe);
        }
        return countList;
    }

    public List<Count> selectZzxsmonth(String startDate, String endDate, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectZzxsmonth(this.startDate, this.endDate, this.employe);
        }
        return countList;
    }

    public List<Count> selectZzxsyear(String startDate, String endDate, String employe) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        this.employe = employe;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectZzxsyear(this.startDate, this.endDate, this.employe);
        }
        return countList;
    }

    public int selectLrbZzxs(String startDate, String endDate) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            count = tjMapper.selectLrbZzxs(this.startDate, this.endDate);
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectLrbZzxsday(String startDate, String endDate) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectLrbZzxsday(this.startDate, this.endDate);
        }
        return countList;
    }

    public List<Count> selectLrbZzxsmonth(String startDate, String endDate) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectLrbZzxsmonth(this.startDate, this.endDate);
        }
        return countList;
    }

    public List<Count> selectLrbZzxsyear(String startDate, String endDate) {
        List<Count> countList;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            countList = tjMapper.selectLrbZzxsyear(this.startDate, this.endDate);
        }
        return countList;
    }

    public int selectLrbSlck(String startDate, String endDate) {
        Count count = new Count();
        Count temp;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                temp = tjMapper.selectLrbSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]));
                if (temp != null) {
                    count.setCount(count.getCount() + temp.getCount());
                }
            }
            for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                temp = tjMapper.selectLrbSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]));
                if (temp != null) {
                    count.setCount(count.getCount() + temp.getCount());
                }
            }
            for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                temp = tjMapper.selectLrbSlck(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]));
                if (temp != null) {
                    count.setCount(count.getCount() + temp.getCount());
                }
            }
        }
        if (count == null) {
            return 0;
        }

        return count.getCount();
    }

    public List<Count> selectLrbSlckday(String startDate, String endDate) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList = null;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
            for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
            for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckday(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        }
        return countList;
    }

    public List<Count> selectLrbSlckmonth(String startDate, String endDate) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
            for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
            for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckmonth(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
            return countList;
        }
    }

    public List<Count> selectLrbSlckyear(String startDate, String endDate) {
        List<Count> countList = new ArrayList<>();
        List<Count> tempList;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TjMapper tjMapper = sqlSession.getMapper(TjMapper.class);
            for (int i = 0; i < pigslBRZZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBRZZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
            for (int i = 0; i < pigslBYZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslBYZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
            for (int i = 0; i < pigslSZYFZThingsShow.length; i++) {
                tempList = tjMapper.selectLrbSlckyear(this.startDate, this.endDate, pigslNametoIdSmap.get(pigslSZYFZThingsShow[i]));
                if (tempList != null) {
                    countList.addAll(tempList);
                }
            }
        }
        return countList;
    }

}
