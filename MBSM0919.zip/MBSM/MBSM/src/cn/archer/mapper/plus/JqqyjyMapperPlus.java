package cn.archer.mapper.plus;

import cn.archer.mapper.JqqyjyMapper;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;
import java.util.ArrayList;

public class JqqyjyMapperPlus {

    public JqqyjyMapperPlus() {

    }

    private static List<String> selectAllMale() {
        List<String> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JqqyjyMapper jqqyjyMapper = sqlSession.getMapper(JqqyjyMapper.class);
            selebithList = jqqyjyMapper.selectAllMale();
        }
        return selebithList;
    }

    private static List<String> selectMzAll(String Id) {
        List<String> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JqqyjyMapper jqqyjyMapper = sqlSession.getMapper(JqqyjyMapper.class);
            selebithList = jqqyjyMapper.selectMzAll(Id);
        }
        return selebithList;
    }

    private static List<String> selectFzAll(String Id) {
        List<String> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JqqyjyMapper jqqyjyMapper = sqlSession.getMapper(JqqyjyMapper.class);
            selebithList = jqqyjyMapper.selectFzAll(Id);
        }
        return selebithList;
    }

    private static List<Selebith> selectZnAll(String Id) {
        List<Selebith> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JqqyjyMapper jqqyjyMapper = sqlSession.getMapper(JqqyjyMapper.class);
            selebithList = jqqyjyMapper.selectMZnAll(Id);
        }
        return selebithList;
    }

    private static Selebith selectById(String Id) {
        Selebith selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JqqyjyMapper jqqyjyMapper = sqlSession.getMapper(JqqyjyMapper.class);
            selebithList = jqqyjyMapper.selectById(Id);
        }
        return selebithList;
    }

    public static String selectByCjrq(String Id) {
        String selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            JqqyjyMapper jqqyjyMapper = sqlSession.getMapper(JqqyjyMapper.class);
            selebithList = jqqyjyMapper.selectByCjrq(Id);
        }
        return selebithList;
    }

    public List<Selebith> Jqjy(String Id) {
        List<Selebith> SelebithAllList = new ArrayList<>();
        List<String> StringSumList = new ArrayList<>();
        List<String> StringAllList = selectAllMale();

        Selebith selebith = selectById(Id);
        if (selebith == null) {
            return null;
        }
        Selebith selebithFQ = selectById(selebith.getR_sire());
        Selebith selebithMQ = selectById(selebith.getR_dam());
        //自己的儿子
        List<String> StringList1 = selectMzAll(selebith.getR_animal());
        //母亲的儿子
        List<String> StringList2 = selectMzAll(selebith.getR_dam());
        List<String> StringList3 = null;
        List<String> StringList4 = null;
        if (selebithMQ != null) {
            //母亲的母亲的儿子
            StringList3 = selectMzAll(selebithMQ.getR_dam());
            //母亲的父亲的儿子
            StringList4 = selectFzAll(selebithMQ.getR_sire());
        }
        //父亲的儿子
        List<String> StringList5 = selectFzAll(selebith.getR_sire());
        List<String> StringList6 = null;
        List<String> StringList7 = null;
        if (selebithFQ != null) {
            //父亲的母亲的儿子
            StringList6 = selectMzAll(selebithFQ.getR_dam());
            //父亲的父亲的儿子
            StringList7 = selectFzAll(selebithFQ.getR_sire());
        }
        //子女的儿子
        List<Selebith> selebithZNList = selectZnAll(Id);
        List<String> StringList8 = null;
        List<String> StringList9 = null;
        for (int i = 0; i < selebithZNList.size(); i++) {
            StringList8 = selectMzAll(selebithZNList.get(i).getR_animal());
            StringList9 = selectFzAll(selebithZNList.get(i).getR_animal());
        }
        if (StringList1 != null) {
            StringSumList.addAll(StringList1);

        }
        if (StringList2 != null) {
            StringSumList.addAll(StringList2);

        }
        if (StringList3 != null) {
            StringSumList.addAll(StringList3);

        }
        if (StringList4 != null) {
            StringSumList.addAll(StringList4);

        }
        if (StringList5 != null) {
            StringSumList.addAll(StringList5);

        }
        if (StringList6 != null) {
            StringSumList.addAll(StringList6);

        }
        if (StringList7 != null) {
            StringSumList.addAll(StringList7);

        }
        if (StringList8 != null) {
            StringSumList.addAll(StringList8);

        }
        if (StringList9 != null) {
            StringSumList.addAll(StringList9);

        }
        if (selebithFQ != null) {
            StringSumList.add(selebithFQ.getR_sire());
        }
        if (selebithMQ != null) {
            StringSumList.add(selebithMQ.getR_sire());
        }

        if (StringAllList != null) {
            StringAllList.removeAll(StringSumList);
        }
        for (int i = 0; i < StringAllList.size(); i++) {

            SelebithAllList.add(selectById(StringAllList.get(i)));
        }
        return SelebithAllList;
    }

}
