package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.YmrkMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Ymrk;
import cn.archer.utils.MybatisUtil;

public class YmrkMapperPlus {

    private String startDate;
    private String endDate;

    public YmrkMapperPlus() {
        startDate = null;
        endDate = null;
    }

    public void insert(Ymrk ymrk) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class);
            ymrkMapper.insert(ymrk);
        }
    }

    public List<Ymrk> SelectByDate(String data1, String data2) {

        List<Ymrk> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class);
            selectByDate = ymrkMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Ymrk> SelectByIdPage(int size, int jump) {
        List<Ymrk> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class);
            selectByIdPage = ymrkMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Ymrk> SelectAll() {
        List<Ymrk> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class);
            selectByDate = ymrkMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class);
            count = ymrkMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Ymrk ymrk) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class);
            ymrkMapper.updateByid(ymrk);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YmrkMapper ymrkMapper = sqlSession.getMapper(YmrkMapper.class);
            ymrkMapper.deleteByid(id);
        }

    }

    public List<Ymrk> YmrkSelectSearchByPage(int size, int jump) {
        List<Ymrk> ymrkList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            ymrkList = sarchMapper.YmrkSelectSearchByPage(startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return ymrkList;
    }

    public int YmrkSelectSearchByCount(String startDate, String endDate) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.YmrkSelectSearchByCount(this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
