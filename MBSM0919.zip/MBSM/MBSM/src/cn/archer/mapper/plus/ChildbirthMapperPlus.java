package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.ChildbirthMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Childbirth;
import cn.archer.utils.MybatisUtil;

public class ChildbirthMapperPlus {

    private String num;
    private String fenceid;
    private String startDate;
    private String endDate;

    public ChildbirthMapperPlus() {

    }

    public void insert(Childbirth childbirth) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class);
            childbirthMapper.insert(childbirth);
        }
    }

    public List<Childbirth> SelectByDate(String data1, String data2) {

        List<Childbirth> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class);
            selectByDate = childbirthMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Childbirth> SelectByIdPage(int size, int jump) {
        List<Childbirth> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class);
            selectByIdPage = childbirthMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Childbirth> SelectAll() {
        List<Childbirth> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class);
            selectByDate = childbirthMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class);
            count = childbirthMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Childbirth childbirth) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class);
            childbirthMapper.updateByid(childbirth);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ChildbirthMapper childbirthMapper = sqlSession.getMapper(ChildbirthMapper.class);
            childbirthMapper.deleteByid(id);
        }

    }

    public List<Childbirth> ChildbirthSelectSearchByPage(int size, int jump) {
        List<Childbirth> childbirthList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            childbirthList = sarchMapper.ChildbirthSelectSearchByPage(num, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return childbirthList;
    }

    public int ChildbirthSelectSearchByCount(String num, String fenceid, String startDate, String endDate) {
        this.num = num;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        Count count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.ChildbirthSelectSearchByCount(this.num, fenceid, startDate, endDate);
        }
        return count.getCount();
    }

}
