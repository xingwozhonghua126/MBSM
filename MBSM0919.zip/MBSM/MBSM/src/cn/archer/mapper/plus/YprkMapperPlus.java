package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.YprkMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Yprk;
import cn.archer.utils.MybatisUtil;

public class YprkMapperPlus {

    private String startDate;
    private String endDate;

    public YprkMapperPlus() {
        startDate = null;
        endDate = null;
    }

    public void insert(Yprk yprk) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class);
            yprkMapper.insert(yprk);
        }
    }

    public List<Yprk> SelectByDate(String data1, String data2) {

        List<Yprk> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class);
            selectByDate = yprkMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Yprk> SelectByIdPage(int size, int jump) {
        List<Yprk> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class);
            selectByIdPage = yprkMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Yprk> SelectAll() {
        List<Yprk> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class);
            selectByDate = yprkMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class);
            count = yprkMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Yprk yprk) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class);
            yprkMapper.updateByid(yprk);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            YprkMapper yprkMapper = sqlSession.getMapper(YprkMapper.class);
            yprkMapper.deleteByid(id);
        }

    }

    public List<Yprk> YprkSelectSearchByPage(int size, int jump) {
        List<Yprk> yprkList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            yprkList = sarchMapper.YprkSelectSearchByPage(startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return yprkList;
    }

    public int YprkSelectSearchByCount(String startDate, String endDate) {
        Count count;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.YprkSelectSearchByCount(this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
