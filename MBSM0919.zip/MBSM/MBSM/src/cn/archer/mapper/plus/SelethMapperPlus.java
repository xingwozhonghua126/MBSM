package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.SelebithMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Selebith;
import cn.archer.utils.MybatisUtil;

public class SelethMapperPlus {

    private String num;
    private String fenceid;
    private String curmark;
    private String startDate;
    private String endDate;

    public SelethMapperPlus() {
        this.num = null;
        this.curmark = null;
        this.startDate = null;
        this.endDate = null;
    }

    public void InsertTable(Selebith selebith) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selebithMapper.insert(selebith);
        }
    }

    public List<Selebith> SelectByDate(String data1, String data2) {

        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selectByDate = selebithMapper.selectByDate(data1, data2);
        }
        return selectByDate;

    }

    public List<Selebith> SelectByIdPage(int size, int jump) {
        List<Selebith> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selectByIdPage = selebithMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Selebith> SelectAll() {
        List<Selebith> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selectByDate = selebithMapper.selectAll();
        }
        return selectByDate;
    }

    public Selebith SelectByTypeid(String Id) {
        Selebith selectByTypeid;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selectByTypeid = selebithMapper.selectByTypeid(Id);
        }
        return selectByTypeid;
    }

    public Selebith SelectById(String Id) {
        Selebith selectById;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selectById = selebithMapper.selectById(Id);
        }
        return selectById;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            count = selebithMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Selebith selebith) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selebithMapper.updateByTypeid(selebith);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
            selebithMapper.deleteByTypeid(id);
            sqlSession.commit();
            sqlSession.close();
        }

    }

    public List<Selebith> SelebithSelectSearchByPage(String size, String jump) {
        List<Selebith> selebithList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            selebithList = searchMapper.SelebithSelectSearchByPage(num, fenceid, curmark, startDate, endDate, size, jump);
        }
        return selebithList;
    }

    public int SelebithSelectSearchByCount(String num, String fenceid, String curmark, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.curmark = curmark;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.SelebithSelectSearchByCount(this.num, this.fenceid, this.curmark, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
