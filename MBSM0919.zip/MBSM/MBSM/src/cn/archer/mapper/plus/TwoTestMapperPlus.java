package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.TwoTestMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.TwoTest;
import cn.archer.utils.MybatisUtil;

public class TwoTestMapperPlus {

    private String num;
    private String zzzt;
    private String startDate;
    private String endDate;
    private String fenceid;

    public TwoTestMapperPlus() {
        num = null;
        startDate = null;
        endDate = null;
        fenceid = null;
    }

    public void insert(TwoTest twoTest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class);
            twoTestMapper.insert(twoTest);
        }
    }

    public List<TwoTest> SelectByDate(String data1, String data2) {

        List<TwoTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class);
            selectByDate = twoTestMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<TwoTest> SelectByIdPage(int size, int jump) {
        List<TwoTest> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class);
            selectByIdPage = twoTestMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<TwoTest> SelectAll() {
        List<TwoTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class);
            selectByDate = twoTestMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class);
            count = twoTestMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(TwoTest twoTest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class);
            twoTestMapper.updateByid(twoTest);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            TwoTestMapper twoTestMapper = sqlSession.getMapper(TwoTestMapper.class);
            twoTestMapper.deleteByid(id);
        }

    }

    public List<TwoTest> TwoTestSelectSearchByPage(int size, int jump) {
        List<TwoTest> twoTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            twoTestList = sarchMapper.TwoTestSelectSearchByPage(num, zzzt, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return twoTestList;
    }

    public int TwoTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.zzzt = zzzt;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.TwoTestSelectSearchByCount(this.num, this.zzzt, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
