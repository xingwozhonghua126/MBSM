package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.ZzmyMapper;
import cn.archer.pojo.Count;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.pojo.Zzmy;
import cn.archer.utils.MybatisUtil;

public class ZzmyMapperPlus {

    private String num;
    private String zzzt;
    private String startDate;
    private String endDate;

    public ZzmyMapperPlus() {
        num = null;
        startDate = null;
        endDate = null;
    }

    public void insert(Zzmy zzmy) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            zzmyMapper.insert(zzmy);
        }
    }

    public List<Zzmy> SelectByDate(String data1, String data2) {

        List<Zzmy> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            selectByDate = zzmyMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<Zzmy> SelectByIdPage(int size, int jump) {
        List<Zzmy> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            selectByIdPage = zzmyMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<Zzmy> SelectAll() {
        List<Zzmy> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            selectByDate = zzmyMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            count = zzmyMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(Zzmy zzmy) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            zzmyMapper.updateByid(zzmy);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            ZzmyMapper zzmyMapper = sqlSession.getMapper(ZzmyMapper.class);
            zzmyMapper.deleteByid(id);
        }

    }

    public List<Zzmy> ZzmySelectSearchByPage(int size, int jump) {
        List<Zzmy> zzmyList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            zzmyList = searchMapper.ZzmySelectSearchByPage(num, zzzt, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return zzmyList;
    }

    public int ZzmySelectSearchByCount(String num, String zzzt, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.startDate = startDate;
        this.endDate = endDate;
        this.zzzt = zzzt;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            count = searchMapper.ZzmySelectSearchByCount(this.num, this.zzzt, this.startDate, this.endDate);
        }
        return count.getCount();
    }
}
