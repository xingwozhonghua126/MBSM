package cn.archer.mapper.plus;

import cn.archer.mapper.SearchMapper;
import cn.archer.mapper.SixTestMapper;
import cn.archer.pojo.Count;
import cn.archer.pojo.SixTest;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import cn.archer.utils.MybatisUtil;

public class SixTestMapperPlus {

    private String num;
    private String zzzt;
    private String startDate;
    private String endDate;
    private String fenceid;

    public SixTestMapperPlus() {
        num = null;
        startDate = null;
        endDate = null;
        fenceid = null;
    }

    public void insert(SixTest sixTest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class);
            sixTestMapper.insert(sixTest);
        }
    }

    public List<SixTest> SelectByDate(String data1, String data2) {

        List<SixTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class);
            selectByDate = sixTestMapper.selectByDate(data1, data2);
        }
        return selectByDate;
    }

    public List<SixTest> SelectByIdPage(int size, int jump) {
        List<SixTest> selectByIdPage;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class);
            selectByIdPage = sixTestMapper.selectByIdPage(size, jump);
        }
        return selectByIdPage;
    }

    public List<SixTest> SelectAll() {
        List<SixTest> selectByDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class);
            selectByDate = sixTestMapper.selectAll();
        }
        return selectByDate;
    }

    public int SelectCount() {
        int count;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class);
            count = sixTestMapper.selectCount().getCount();
        }
        return count;
    }

    public void UpdateById(SixTest sixTest) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class);
            sixTestMapper.updateByid(sixTest);
        }
    }

    public void DeleteById(String id) {
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SixTestMapper sixTestMapper = sqlSession.getMapper(SixTestMapper.class);
            sixTestMapper.deleteByid(id);
        }

    }

    public List<SixTest> SixTestSelectSearchByPage(int size, int jump) {
        List<SixTest> sixTestList;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper searchMapper = sqlSession.getMapper(SearchMapper.class);
            sixTestList = searchMapper.SixTestSelectSearchByPage(num, zzzt, fenceid, startDate, endDate, String.valueOf(size), String.valueOf(jump));
        }
        return sixTestList;
    }

    public int SixTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate) {
        Count count;
        this.num = num;
        this.zzzt = zzzt;
        this.fenceid = fenceid;
        this.startDate = startDate;
        this.endDate = endDate;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            SearchMapper sarchMapper = sqlSession.getMapper(SearchMapper.class);
            count = sarchMapper.SixTestSelectSearchByCount(this.num, this.zzzt, this.fenceid, this.startDate, this.endDate);
        }
        return count.getCount();
    }

}
