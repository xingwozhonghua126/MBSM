package cn.archer.mapper;

import cn.archer.pojo.Breeding;
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Count;
import cn.archer.pojo.FourTest;
import cn.archer.pojo.HundredTest;
import cn.archer.pojo.Jbzl;
import cn.archer.pojo.Jyjc;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.SixTest;
import cn.archer.pojo.Slck;
import cn.archer.pojo.Slrk;
import cn.archer.pojo.Takesperm;
import cn.archer.pojo.TwoTest;
import cn.archer.pojo.Tzxncd;
import cn.archer.pojo.Ymck;
import cn.archer.pojo.Ymrk;
import cn.archer.pojo.Ypck;
import cn.archer.pojo.Yprk;
import cn.archer.pojo.Zzmy;
import cn.archer.pojo.Zzsw;
import cn.archer.pojo.Zzxs;
import java.util.List;

public interface SearchMapper {

    public List<Takesperm> TakespermSelectSearch(String num, String startDate, String endDate);

    public List<Takesperm> TakespermSelectSearchByPage(String num, String startDate, String endDate, String size, String jump);

    public Count TakespermSelectSearchByCount(String num, String startDate, String endDate);

    public List<Selebith> SelebithSelectSearch(String num, String fenceid, String curmark, String startDate, String endDate);

    public List<Selebith> SelebithSelectSearchByPage(String num, String fenceid, String curmark, String startDate, String endDate, String size, String jump);

    public Count SelebithSelectSearchByCount(String num, String fenceid, String curmark, String startDate, String endDate);

    public List<Breeding> BreedingSelectSearch(String num, String fenceid, String pzzt, String startDate, String endDate);

    public List<Breeding> BreedingSelectSearchByPage(String num, String fenceid, String pzzt, String startDate, String endDate, String size, String jump);

    public Count BreedingSelectSearchByCount(String num, String fenceid, String pzzt, String startDate, String endDate);

    public List<Childbirth> ChildbirthSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Childbirth> ChildbirthSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count ChildbirthSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<Childbirth> WeaningSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Childbirth> WeaningSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count WeaningSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<TwoTest> TwoTestSelectSearch(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<TwoTest> TwoTestSelectSearchByPage(String num, String zzzt, String fenceid, String startDate, String endDate, String size, String jump);

    public Count TwoTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<FourTest> FourTestSelectSearch(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<FourTest> FourTestSelectSearchByPage(String num, String zzzt, String fenceid, String startDate, String endDate, String size, String jump);

    public Count FourTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<SixTest> SixTestSelectSearch(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<SixTest> SixTestSelectSearchByPage(String num, String zzzt, String fenceid, String startDate, String endDate, String size, String jump);

    public Count SixTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<HundredTest> HundredTestSelectSearch(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<HundredTest> HundredTestSelectSearchByPage(String num, String zzzt, String fenceid, String startDate, String endDate, String size, String jump);

    public Count HundredTestSelectSearchByCount(String num, String zzzt, String fenceid, String startDate, String endDate);

    public List<Selebith> FemaleBoarSelectSearchByPage(String num, String fenceid, String zzzt, String startDate, String endDate, String size, String jump);

    public Count FemaleBoarSelectSearchByCount(String num, String fenceid, String zzzt, String startDate, String endDate);

    public List<Selebith> FemaleBoarSelectSearch(String num, String fenceid, String zzzt, String startDate, String endDate);

    public List<Selebith> FemaleBoarSelectSearch02(String num, String zzzt, String startDate, String endDate);

    public List<Selebith> FemaleBoarSelectSearchByPage02(String num, String zzzt, String startDate, String endDate, String size, String jump);

    public Count FemaleBoarSelectSearchByCount02(String num, String zzzt, String startDate, String endDate);

    public List<Selebith> MaleBoarSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> MaleBoarSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count MaleBoarSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    //zhou 
    public List<Selebith> ConservationTurnFattingSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count ConservationTurnFattingSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> ConservationTurnFattingSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> ConservationTurnFatteningSelectSearchByPage02(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count ConservationTurnFatteningSelectSearchByCount02(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> ConservationTurnBackSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count ConservationTurnBackSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> ConservationTurnBackSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> ConservationTurnBackSelectSearchByPage02(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count ConservationTurnBackSelectSearchByCount02(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> FeedingTurnConservationSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count FeedingTurnConservationSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<Selebith> FeedingTurnConservationSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Zzmy> ZzmySelectSearch(String num, String zzzt, String startDate, String endDate);

    public List<Zzmy> ZzmySelectSearchByPage(String num, String zzzt, String startDate, String endDate, String size, String jump);

    public Count ZzmySelectSearchByCount(String num, String zzzt, String startDate, String endDate);

    public List<Selebith> pigImmuneSelectSearchByPage02(String num, String fenceid, String startDate, String endDate, String size, String jump, String pzzt);

    public Count pigImmuneSelectSearchByCount02(String num, String fenceid, String startDate, String endDate, String pzzt);

    public List<Jbzl> JbzlSelectSearch(String num, String zzzt, String startDate, String endDate);

    public List<Jbzl> JbzlSelectSearchByPage(String num, String zzzt, String startDate, String endDate, String size, String jump);

    public Count JbzlSelectSearchByCount(String num, String zzzt, String startDate, String endDate);

    public List<Jyjc> JyjcSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Jyjc> JyjcSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count JyjcSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<Tzxncd> TzxncdSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Tzxncd> TzxncdSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count TzxncdSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<Zzxs> ZzxsSelectSearch(String startDate, String endDate);

    public List<Zzxs> ZzxsSelectSearchByPage(String startDate, String endDate, String size, String jump);

    public Count ZzxsSelectSearchByCount(String startDate, String endDate);

    public List<Zzsw> ZzswSelectSearch(String num, String fenceid, String startDate, String endDate);

    public List<Zzsw> ZzswSelectSearchByPage(String num, String fenceid, String startDate, String endDate, String size, String jump);

    public Count ZzswSelectSearchByCount(String num, String fenceid, String startDate, String endDate);

    public List<Slrk> SlrkSelectSearch(String startDate, String endDate);

    public List<Slrk> SlrkSelectSearchByPage(String startDate, String endDate, String size, String jump);

    public Count SlrkSelectSearchByCount(String startDate, String endDate);

    public List<Slck> SlckSelectSearch(String fenceid, String startDate, String endDate);

    public List<Slck> SlckSelectSearchByPage(String fenceid, String startDate, String endDate, String size, String jump);

    public Count SlckSelectSearchByCount(String fenceid, String startDate, String endDate);

    public List<Yprk> YprkSelectSearch(String startDate, String endDate);

    public List<Yprk> YprkSelectSearchByPage(String startDate, String endDate, String size, String jump);

    public Count YprkSelectSearchByCount(String startDate, String endDate);

    public List<Ypck> YpckSelectSearch(String fenceid, String startDate, String endDate);

    public List<Ypck> YpckSelectSearchByPage(String fenceid, String startDate, String endDate, String size, String jump);

    public Count YpckSelectSearchByCount(String fenceid, String startDate, String endDate);

    public List<Ymrk> YmrkSelectSearch(String startDate, String endDate);

    public List<Ymrk> YmrkSelectSearchByPage(String startDate, String endDate, String size, String jump);

    public Count YmrkSelectSearchByCount(String startDate, String endDate);

    public List<Ymck> YmckSelectSearch(String fenceid, String startDate, String endDate);

    public List<Ymck> YmckSelectSearchByPage(String fenceid, String startDate, String endDate, String size, String jump);

    public Count YmckSelectSearchByCount(String fenceid, String startDate, String endDate);

}
