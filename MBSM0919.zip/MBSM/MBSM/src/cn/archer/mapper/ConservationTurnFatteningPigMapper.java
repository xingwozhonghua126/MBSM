/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ConservationTurnFatteningPigMapper {

    public void insert(Selebith selebith);

    public List<Selebith> selectAll();

    public void deleteByid(String id);

    public void updateByid(Selebith selebith);

    public Selebith selectByid(String id);

    public List<Selebith> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Selebith> selectByDate(String startDate, String endDate);

}
