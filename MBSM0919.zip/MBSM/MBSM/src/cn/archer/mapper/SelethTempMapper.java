package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.SelethTemp;

/**
 *
 * @author Administrator
 */
public interface SelethTempMapper {

    public void updateByTypeid(SelethTemp selethtemp);

    public SelethTemp selectByTypeid(String pKey);

}
