package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Tzxncd;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface TzxncdMapper {

    public void insert(Tzxncd tzxncd);

    public List<Tzxncd> selectAll();

    public void deleteByid(String id);

    public void updateByid(Tzxncd tzxncd);

    public Tzxncd selectByid(String id);

    public List<Tzxncd> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Tzxncd> selectByDate(String startDate, String endDate);

}
