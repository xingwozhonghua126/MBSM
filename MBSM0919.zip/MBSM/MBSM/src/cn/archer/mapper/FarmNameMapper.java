/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.FarmName;
import java.util.List;

/**
 *
 * @author hp
 */
public interface FarmNameMapper {

    public void insert(FarmName farmName);

    public List<FarmName> selectAll();

    public void deleteByFarmid(String farmid);

    public void updateByFarmid(FarmName farmName);

    public FarmName selectByFarmid(String farmid);

}
