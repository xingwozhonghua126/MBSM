package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface WeaningMapper {

    public List<Childbirth> selectAll();

    public void updateByid(Childbirth childbirth);

    public Childbirth selectByid(String id);

    public List<Childbirth> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Childbirth> selectByDate(String startDate, String endDate);

    public Childbirth selectByIdAndFm(String r_animal);//添加时候用到在Children表中并且是分娩状态

    public Childbirth selectByIdAndFm2(String r_animal);//添加时候用到在Children表中并且是分娩状态

    public List<Selebith> selectAllZz(String mzr_animal, String tc);//查找小猪仔

}
