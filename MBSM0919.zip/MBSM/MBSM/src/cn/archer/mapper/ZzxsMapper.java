package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Zzxs;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ZzxsMapper {

    public void insert(Zzxs zzxs);

    public List<Zzxs> selectAll();

    public void deleteByid(String id);

    public void updateByid(Zzxs zzxs);

    public Zzxs selectByid(String id);

    public List<Zzxs> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Zzxs> selectByDate(String startDate, String endDate);

}
