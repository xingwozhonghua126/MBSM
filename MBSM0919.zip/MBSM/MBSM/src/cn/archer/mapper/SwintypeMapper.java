/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Swintype;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface SwintypeMapper {

    public void insert(Swintype swintype);

    public List<Swintype> selectAll();

    public void deleteByTypeid(String typeid);

    public void updateByTypeid(Swintype swintype);

    public Swintype selectByTypeid(String typeid);

    public List<Swintype> selectZzAll();

}
