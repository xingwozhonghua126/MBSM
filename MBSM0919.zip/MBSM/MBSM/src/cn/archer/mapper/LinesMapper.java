/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Lines;
import java.util.List;

/**
 *
 * @author hp
 */
public interface LinesMapper {

    public void insert(Lines lines);

    public List<Lines> selectAll();

    public void deleteByLineid(String lineid);

    public void updateByLineid(Lines lines);

    public Lines selectByLineid(String lineid);
}
