/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.Zzmy;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface PigImmuneMapper02 {

    public List<Selebith> selectAll02();

    public void updateById02(Selebith selebith);

    public Selebith selectById02(String id);

    public List<Selebith> selectByIdPage02(int startNum, int endNum);

    public Count selectCount02();

    public List<Selebith> selectByDate02(String startDate, String endDate);

    public void insertMY(Zzmy zzmy);

}
