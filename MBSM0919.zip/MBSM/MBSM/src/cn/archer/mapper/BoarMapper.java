package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Breeding;
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import cn.archer.pojo.Takesperm;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface BoarMapper {

    public List<Selebith> selectAllFemale();

    public List<Selebith> selectAllMale();

    public List<Selebith> selectAllFemalePage(int startNum, int endNum);

    public List<Selebith> selectAllMalePage(int startNum, int endNum);

    public Count selectAllFemaleCount();

    public Count selectAllMaleCount();

    public List<Breeding> selectAllPZ(String r_animal);//母猪配种

    public List<Childbirth> selectAllFM(String r_animal);//母猪分娩

    public List<Childbirth> selectAllDM(String r_animal);//母猪断奶

    public List<Takesperm> selectAllCJ(String r_animal);//公猪采精

    public List<Breeding> selectAllGPZ(String r_animal);//一配公猪

}
