package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.FenceTemp;

/**
 *
 * @author Administrator
 */
public interface FenceTempMapper {

    public void updateByTypeid(FenceTemp fencetemp);

    public FenceTemp selectByTypeid(int id);
}
