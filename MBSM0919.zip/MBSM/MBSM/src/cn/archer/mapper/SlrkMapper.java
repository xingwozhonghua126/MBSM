package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Slrk;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface SlrkMapper {

    public void insert(Slrk slrk);

    public List<Slrk> selectAll();

    public void deleteByid(String id);

    public void updateByid(Slrk slrk);

    public Slrk selectByid(String id);

    public List<Slrk> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Slrk> selectByDate(String startDate, String endDate);

}
