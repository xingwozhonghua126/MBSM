package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Zzsw;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ZzswMapper {

    public void insert(Zzsw zzsw);

    public List<Zzsw> selectAll();

    public void deleteByid(String id);

    public void updateByid(Zzsw zzsw);

    public Zzsw selectByid(String id);

    public List<Zzsw> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Zzsw> selectByDate(String startDate, String endDate);

}
