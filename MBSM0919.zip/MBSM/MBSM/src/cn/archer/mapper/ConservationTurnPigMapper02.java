/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.mapper;

import cn.archer.pojo.Count;
import cn.archer.pojo.Selebith;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ConservationTurnPigMapper02 {

    public List<Selebith> selectAll02BackPig();

    public List<Selebith> selectAll02FatteningPig();

    public void updateById02BackPig(Selebith selebith);

    public void updateById02FatteningPig(Selebith selebith);

    public Selebith selectById02BackPig(String id);

    public Selebith selectById02FatteningPig(String id);

    public List<Selebith> selectByIdPage02BackPig(int startNum, int endNum);

    public List<Selebith> selectByIdPage02FatteningPig(int startNum, int endNum);

    public Count selectCount02BackPig();

    public Count selectCount02FatteningPig();

    public List<Selebith> selectByDate02BackPig(String startDate, String endDate);

    public List<Selebith> selectByDate02FatteningPig(String startDate, String endDate);

}
