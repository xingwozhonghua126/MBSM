package cn.archer.mapper;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.Childbirth;
import cn.archer.pojo.Count;
import java.util.List;

/**
 *
 * @author Administrator
 */
public interface ChildbirthMapper {

    public void insert(Childbirth childbirth);

    public List<Childbirth> selectAll();

    public void deleteByid(String id);

    public void updateByid(Childbirth childbirth);

    public Childbirth selectByid(String id);

    public List<Childbirth> selectByIdPage(int startNum, int endNum);

    public Count selectCount();

    public List<Childbirth> selectByDate(String startDate, String endDate);

}
