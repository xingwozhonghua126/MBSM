/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 *
 * @author Administrator
 */
public class MybatisUtil {
    // 每一个MyBatis的应用程序都以一个SqlSessionFactory对象的实例为核心
    // 使用SqlSessionFactory的最佳实践是在应用运行期间不要重复创建多次,最佳范围是应用范围

    private static SqlSession sqlSession = null;
    private final static SqlSessionFactory sqlSessionFactory;

    static {
        String resource = "cn/archer/config/SqlMapConfig.xml";
        Reader reader = null;
        try {
            reader = Resources.getResourceAsReader(resource);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        // SqlSessionFactory对象的实例可以通过SqlSessionFactoryBuilder对象来获得
        // SqlSessionFactoryBuilder实例的最佳范围是方法范围（也就是本地方法变量）。
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
    }

    public static SqlSession getSqlSession() {
        sqlSession = sqlSessionFactory.openSession();
        return sqlSession;
    }

}
