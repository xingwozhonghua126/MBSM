/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.utils;

import cn.archer.mapper.FenceMapper;
import cn.archer.mapper.PiggeryMapper;
import cn.archer.pojo.Fence;
import cn.archer.pojo.Piggery;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import org.apache.ibatis.session.SqlSession;
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.RandomAccessFile;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.table.JTableHeader;

/**
 *
 * @author 24161
 */
public class MyStaticMethod {

    //将数字转化成字符串	
    public static String ToStringNum6(int num) {
        String stringNum = null;
        if (String.valueOf(num).length() == 1) {
            stringNum = "00000" + String.valueOf(num);
            return stringNum;
        }
        if (String.valueOf(num).length() == 2) {
            stringNum = "0000" + String.valueOf(num);
            return stringNum;

        }
        if (String.valueOf(num).length() == 3) {
            stringNum = "000" + String.valueOf(num);
            return stringNum;

        }
        if (String.valueOf(num).length() == 4) {
            stringNum = "00" + String.valueOf(num);
            return stringNum;

        }
        if (String.valueOf(num).length() == 5) {
            stringNum = "0" + String.valueOf(num);
            return stringNum;

        }
        if (String.valueOf(num).length() == 6) {
            stringNum = String.valueOf(num);
            return stringNum;

        }
        System.out.println("转化数字出错");
        return null;
    }

    //将数字转化成字符串	
    public static String ToStringNum4(int num) {
        String stringNum = null;
        if (String.valueOf(num).length() == 1) {
            stringNum = "000" + String.valueOf(num);
            return stringNum;
        }
        if (String.valueOf(num).length() == 2) {
            stringNum = "00" + String.valueOf(num);
            return stringNum;

        }
        if (String.valueOf(num).length() == 3) {
            stringNum = "0" + String.valueOf(num);
            return stringNum;

        }
        if (String.valueOf(num).length() == 4) {
            stringNum = String.valueOf(num);
            return stringNum;

        }

        System.out.println("转化数字出错");
        return null;
    }

    //将数字转化成字符串	
    public static String ToStringNum2(int num) {
        String stringNum = null;
        if (String.valueOf(num).length() == 1) {
            stringNum = "0" + String.valueOf(num);
            return stringNum;
        }
        if (String.valueOf(num).length() == 2) {
            stringNum = String.valueOf(num);
            return stringNum;

        }

        System.out.println("转化数字出错");
        return null;
    }

    //返回当前日期
    public static String NowTime() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");// 设置日期格式
        String strDate = df.format(new Date());
        return strDate;// new Date()为获取当前系统时间
    }

    //搜索栏位
    public static String SsFence(String fenceid, JComboBox jComboBox) {
        if (fenceid.equals("全部栏")) {
            fenceid = JComboBoxString(jComboBox);
            if (fenceid.equals("全部舍")) {
                fenceid = "%";
            }

            List<Piggery> piggeryList;
            try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
                PiggeryMapper mapper = sqlSession.getMapper(PiggeryMapper.class);
                piggeryList = mapper.selectAll();
            }
            for (int i = 0; i < piggeryList.size(); i++) {
                if (fenceid.equals(piggeryList.get(i).getCategory())) {
                    fenceid = piggeryList.get(i).getNumber() + "%";
                }
            }
        }
        List<Fence> fencelist;
        try (SqlSession sqlSession = MybatisUtil.getSqlSession()) {
            FenceMapper mapper6 = sqlSession.getMapper(FenceMapper.class);
            fencelist = mapper6.selectAll();
        }
        for (int i = 0; i < fencelist.size(); i++) {
            if (fencelist.get(i).getFencename().equals(fenceid)) {
                fenceid = fencelist.get(i).getFenceid();
            }
        }
        return fenceid;
    }

    //自动表格列大小
    public static void setJTableRow(JTable jTable1) {
        //返回包含此表所有列信息的 TableColumnModel。
        TableColumnModel columnModel = jTable1.getColumnModel();
        for (int col = 0; col < jTable1.getColumnCount(); col++) {
            int maxwidth = 0;
            for (int row = 0; row < jTable1.getRowCount(); row++) {
                //返回适于由行和列所指定单元格的渲染器。
                TableCellRenderer rend
                        = jTable1.getCellRenderer(row, col);
                Object value = jTable1.getValueAt(row, col);
                //返回用于绘制单元格的组件。此方法用于在绘制前适当地配置渲染器。
                Component comp
                        = rend.getTableCellRendererComponent(jTable1,
                                value,
                                false,
                                false,
                                row,
                                col);
                maxwidth = Math.max(comp.getPreferredSize().width, maxwidth);
            } // for row
            //TableColumn column = columnModel.getColumn (col); 
            //column.setPreferredWidth (maxwidth);
            TableColumn column = columnModel.getColumn(col);
            TableCellRenderer headerRenderer = column.getHeaderRenderer();
            if (headerRenderer == null) {
                JTableHeader tableHeader = jTable1.getTableHeader();
                tableHeader.setFont(new Font("楷体", 0, 17));
                tableHeader.setForeground(new Color(0, 51, 102));
                headerRenderer = tableHeader.getDefaultRenderer();
            }
            Object headerValue = column.getHeaderValue();
            Component headerComp
                    = headerRenderer.getTableCellRendererComponent(jTable1,
                            headerValue,
                            false,
                            false,
                            0,
                            col);
            maxwidth = Math.max(maxwidth,
                    headerComp.getPreferredSize().width);
            column.setPreferredWidth(maxwidth);
            //         jTable1.getColumn("品种名称").setMinWidth(10);//设置列宽最小值
            //  column.setMaxWidth(maxwidth);//设置列宽最大值

        }
        jTable1.getTableHeader().setReorderingAllowed(true); //不允许改变列的顺序
    }

    // 判断年份是否为闰年
    private static boolean isPrime(int year) {
        boolean leadyear;
        if (year % 4 == 0 && year % 100 != 0) {
            leadyear = true;
        } else if (year % 400 == 0) {
            leadyear = true;
        } else {
            leadyear = false;
        }
        return leadyear;
    }

    // 计算间隔天数
    public static int calInterval(String sDate, String eDate) {
        // 时间间隔，初始为0
        int interval = 0;
        boolean flag = true;
        int[] primeMonth = new int[]{31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int[] notPrimeMonth = new int[]{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        /* 将两个日期赋给日历实例，并获取年、月、日相关字段值 */
        int sYears = Integer.parseInt(sDate.substring(0, 4));// 2016-10-01
        int sMonths = Integer.parseInt(sDate.substring(5, 7));
        int sDays = Integer.parseInt(sDate.substring(8, 10));

        int eYears = Integer.parseInt(eDate.substring(0, 4));// 2016-10-01
        int eMonths = Integer.parseInt(eDate.substring(5, 7));
        int eDays = Integer.parseInt(eDate.substring(8, 10));
        // 从sYears开始累加到eYears
        for (int i = sYears; i < eYears; i++) {
            interval += isPrime(i) ? 366 : 365;
        }
        // 如果eYears是闰年,则flag=true,后面调用primeMonth[12]
        flag = isPrime(eYears);
        // 加上eMonths到1月的天数
        for (int i = 1; i < eMonths; i++) {
            if (flag) {
                interval += primeMonth[i - 1];
            } else {
                interval += notPrimeMonth[i - 1];
            }
        }
        // 如果sYears是闰年,则flag=true,后面调用primeMonth[12]

        flag = isPrime(sYears);
        // 减去sMonths到1月的天数
        for (int i = 1; i < sMonths; i++) {
            if (flag) {
                interval -= primeMonth[i - 1];
            } else {
                interval -= notPrimeMonth[i - 1];
            }
        }
        interval = interval + eDays - sDays;
        return interval;
    }

    public static String addDate(String initDate, int diffDays) {
        // 时间间隔，初始为0
        int interval = 0;
        boolean flag = true;
        int[] normalMonthDays = new int[]{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        /* 将两个日期赋给日历实例，并获取年、月、日相关字段值 */
        int initDateYears = Integer.parseInt(initDate.substring(0, 4));
        int initDateMonths = Integer.parseInt(initDate.substring(5, 7));
        int initDateDays = Integer.parseInt(initDate.substring(8, 10));

        int reDateYears = initDateYears;
        int reDateMonths = initDateMonths;
        int reDateDays = initDateDays;
        //1.get years (days >=366 or 365)  
        int daysAyear = 365;
        if (isPrime(reDateYears) && (reDateMonths < 3)) {//if leap year 
            daysAyear = 366;
        }
        while ((diffDays / daysAyear) != 0) {
            diffDays = diffDays - daysAyear;
            reDateYears++;
            if (isPrime(reDateYears)) {
                daysAyear = 366;
            } else {
                daysAyear = 365;
            }
        }
        //2.get months (days < 366 or 365) 
        if (isPrime(reDateYears)) {//if leap year 
            normalMonthDays[2] = 29;
        } else {
            normalMonthDays[2] = 28;
        }
        while ((diffDays / normalMonthDays[reDateMonths]) != 0) {
            diffDays = diffDays - normalMonthDays[reDateMonths];
            reDateMonths++;
            if (reDateMonths >= 13) {
                reDateYears++;
                if (isPrime(reDateYears)) {
                    normalMonthDays[2] = 29;
                } else {
                    normalMonthDays[2] = 28;
                }
                reDateMonths = reDateMonths % 12;
            }
        }
        //3.get days 
        if (isPrime(reDateYears)) {
            normalMonthDays[2] = 29;
        } else {
            normalMonthDays[2] = 28;
        }
        if (diffDays + reDateDays <= normalMonthDays[reDateMonths]) {
            reDateDays = diffDays + reDateDays;
        } else {
            reDateDays = diffDays + reDateDays - normalMonthDays[reDateMonths];
            reDateMonths++;
            if (reDateMonths > 12) {
                reDateYears++;
                reDateMonths = reDateMonths % 12;
            }
        }
        String reDate = String.valueOf(reDateYears) + "-" + ToStringNum2(reDateMonths) + "-" + ToStringNum2(reDateDays);
        return reDate;
    }

    public static String minusDate(String initDate, int diffDays) {
        // 时间间隔，初始为0
        int interval = 0;
        boolean flag = true;
        int[] normalMonthDays = new int[]{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        /* 将两个日期赋给日历实例，并获取年、月、日相关字段值 */
        int initDateYears = Integer.parseInt(initDate.substring(0, 4));
        int initDateMonths = Integer.parseInt(initDate.substring(5, 7));
        int initDateDays = Integer.parseInt(initDate.substring(8, 10));

        int reDateYears = initDateYears;
        int reDateMonths = initDateMonths;
        int reDateDays = initDateDays;

        if (reDateDays > diffDays) {
            reDateDays -= diffDays;

        } else if (reDateDays == diffDays) {
            reDateMonths--;
            if (reDateMonths < 1) {
                reDateYears--;
                reDateMonths = 12;
            }
            if (isPrime(reDateYears)) {
                normalMonthDays[2] = 29;
            } else {
                normalMonthDays[2] = 28;
            }
            reDateDays = normalMonthDays[reDateMonths];

        } else {
            diffDays = diffDays - reDateDays;

            reDateMonths--;
            if (reDateMonths < 1) {
                reDateYears--;
                reDateMonths = 12;
            }
            if (isPrime(reDateYears)) {
                normalMonthDays[2] = 29;
            } else {
                normalMonthDays[2] = 28;
            }
            reDateDays = normalMonthDays[reDateMonths];
            ///////////////////////////////////////////;
            int daysAyear = 365;
            if (isPrime(reDateYears) && (reDateMonths > 2)) {//if leap year 
                daysAyear = 366;
            } else if ((reDateMonths == 2) && (reDateDays == 29)) {
                daysAyear = 366;
                System.out.println("xxx");
            }
            while ((diffDays / daysAyear) != 0) {
                diffDays = diffDays - daysAyear;
                reDateYears--;
                if (isPrime(reDateYears)) {
                    daysAyear = 366;
                } else {
                    daysAyear = 365;
                }
            }
            //2.get months (days < 366 or 365) 
            if (isPrime(reDateYears)) {//if leap year 
                normalMonthDays[2] = 29;
            } else {
                normalMonthDays[2] = 28;
            }
            while ((diffDays / normalMonthDays[reDateMonths]) != 0) {
                diffDays = diffDays - normalMonthDays[reDateMonths];
                reDateMonths--;
                if (reDateMonths < 1) {
                    reDateYears--;
                    if (isPrime(reDateYears)) {
                        normalMonthDays[2] = 29;
                    } else {
                        normalMonthDays[2] = 28;
                    }
                    reDateMonths = 12;
                }
            }
            //3.get days 
            if (isPrime(reDateYears)) {
                normalMonthDays[2] = 29;
            } else {
                normalMonthDays[2] = 28;
            }
            reDateDays = normalMonthDays[reDateMonths];
            reDateDays -= diffDays;

        }

        String reDate = String.valueOf(reDateYears) + "-" + ToStringNum2(reDateMonths) + "-" + ToStringNum2(reDateDays);
        return reDate;
    }

    public static void FileWrite_Overwrite(String _strFullFileName, ArrayList<String> StringList) throws Exception {
        File file = new File(_strFullFileName.concat(".txt"));
        if (!file.exists()) {
            file.createNewFile();
        }

        String strContent = "";
        for (int i = 0; i < StringList.size(); i++) {
            strContent += StringList.get(i) + "\r\n";
            System.out.println(strContent);
        }
        strContent = new String(strContent.getBytes(), "utf-8"); // 多了这一句

        RandomAccessFile mm = new RandomAccessFile(file, "rw");
        mm.write(strContent.getBytes("utf-8"));
        mm.close();
    }

    public static DecimalFormat df1 = new DecimalFormat("######0.00");
    public static DecimalFormat df2 = new DecimalFormat("######0.000");
//df.format(f);
}
