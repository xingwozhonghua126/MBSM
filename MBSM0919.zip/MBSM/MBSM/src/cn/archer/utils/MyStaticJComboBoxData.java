/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.utils;

import cn.archer.utils.MybatisUtil;
import java.util.List;
import javax.swing.JComboBox;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author 24161
 */
public class MyStaticJComboBoxData {

    //获取复选框文字    
    public static String JComboBoxString(JComboBox jComboBoxTemp) {
        String JComboBoxString = jComboBoxTemp.toString();
        JComboBoxString = JComboBoxString.substring(JComboBoxString.lastIndexOf("selectedItemReminder="));
        JComboBoxString = JComboBoxString.substring(21, JComboBoxString.length() - 1);
        return JComboBoxString;
    }

}
