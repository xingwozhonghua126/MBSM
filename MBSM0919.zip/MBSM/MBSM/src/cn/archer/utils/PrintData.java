package cn.archer.utils;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author 24161
 */
public class PrintData implements Printable {

    /**
     * *
     * @param Graphic指明打印的图形环境
     *
     * @param
     * PageFormat指明打印页格式（页面大小以点为计量单位，1点为1英才的1/72，1英寸为25.4毫米。A4纸大致为595×842点）
     *
     * @param pageIndex指明页号 *
     *
     */
    private static ArrayList<String> PrintDataStringList;
    private static int nowPage;
    private static String[] StringArray;

    public int print(Graphics gra, PageFormat pf, int pageIndex) throws PrinterException {
//        pageIndex = nowPage;

        Component c = null;

        //print string  
        String str = "中华民族是勤劳、勇敢和富有智慧的伟大民族。";

        //转换成Graphics2D  
        Graphics2D g2 = (Graphics2D) gra;

        //设置打印颜色为黑色  
        g2.setColor(Color.black);

        Paper paper = pf.getPaper();//得到页面格式的纸张  

        paper.setSize(595, 842);//纸张大小  

        paper.setImageableArea(0, 0, 595, 842); //设置打印区域的大小  

        pf.setPaper(paper);//将该纸张作为格式 
        //打印起点坐标  
        double x = pf.getImageableX();
        double y = pf.getImageableY();
        if (pageIndex == 0) {
            //设置打印字体（字体名称、样式和点大小）（字体名称可以是物理或者逻辑名称）  
            //Java平台所定义的五种字体系列：Serif、SansSerif、Monospaced、Dialog 和 DialogInput  
            Font font = new Font("新宋体", Font.PLAIN, 9);

            g2.setFont(font);//设置字体  
            //BasicStroke   bs_3=new   BasicStroke(0.5f);    
            float[] dash1 = {4.0f};

            g2.setStroke(new BasicStroke(0.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 4.0f, dash1, 0.0f));

            float heigth = font.getSize2D();//字体高度  
            //使用抗锯齿模式完成文本呈现  
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            // -1- 用Graphics2D直接输出  
            //首字符的基线(右下部)位于用户空间中的 (x, y) 位置处  
            g2.drawLine(80, 80, 515, 80);

            g2.drawLine(80, 760, 515, 760);
            for (int i = 0; i < StringArray.length; i++) {
                if (StringArray[i] == null) {
                    break;
                }
                g2.drawString(StringArray[i], (float) 100, (float) (100 + i * 10));
            }
            g2.drawString("当前页数为：" + String.valueOf(nowPage+1) + "页", (float) 100, (float) (770));

            return PAGE_EXISTS;
        }
        return NO_SUCH_PAGE;

    }

    public static void PrintData() {

        StringArray = new String[65];

        //获取打印服务对象  
        PrinterJob job = PrinterJob.getPrinterJob();

        PageFormat pageFormat = job.defaultPage();//得到默认页格式    

        job.setPrintable(new PrintData());//设置打印类  

        nowPage = 0;
        try {
            for (int i = 0; i < PrintDataStringList.size(); i++) {
                if (((i % 65) == 0) && (i != 0)) {
                    job.print();
                    StringArray = new String[65];
                    nowPage++;
                }
                StringArray[i % 65] = PrintDataStringList.get(i);
            }
            job.print();
        } catch (PrinterException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<String> getPrintDataStringList() {
        return PrintDataStringList;
    }

    public static void setPrintDataStringList(ArrayList<String> PrintDataStringList) {
        PrintData.PrintDataStringList = PrintDataStringList;
    }
}
