package cn.archer.utils;

import cn.archer.mapper.SelebithMapper;
import cn.archer.pojo.Selebith;
import static cn.archer.utils.MyStaticMethod.FileWrite_Overwrite;
import static cn.archer.utils.MyStaticMethod.df2;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author 24161
 */
public class ReadText {

    private static int lieshu;
    private static int hangshu;
    private static String filePath;
    private static String[][] Data;

    private static double[][] selectLie;

    public ReadText(String filePath) {

        selectLie = new double[2][8];
        this.filePath = filePath;
    }

    public static void readTxt() {
        lieshu = 0;
        hangshu = 0;
        try {
            File file = new File(filePath);
            if (file.isFile() && file.exists()) { //判断文件是否存在 
                int length = (int) file.length();
                FileChannel fc = new RandomAccessFile(filePath, "rw").getChannel();
                MappedByteBuffer out = fc.map(FileChannel.MapMode.READ_WRITE, 0, length);
                for (int i = 0; i < length; i++) {
                    if (out.get(i) == '\t') {
                        lieshu++;
                    }
                    if (out.get(i) == '\n') {
                        lieshu++;
                        break;
                    }
                }
                for (int i = 0; i < length; i++) {
                    if (out.get(i) == '\n') {
                        hangshu++;
                    }
                }
                System.out.println("行数" + hangshu);
                Data = new String[hangshu][lieshu + 1];
            } else {
                System.out.println("找不到指定的文件");
            }
        } catch (Exception e) {
            System.out.println("读取文件内容出错");
            e.printStackTrace();
        }
    }

    public static void readTxtFile() {
        int temphang = 0;
        try {
            String encoding = "UTF-8";
            File file = new File(filePath);
            if (file.isFile() && file.exists()) { //判断文件是否存在
                InputStreamReader read = new InputStreamReader(
                        new FileInputStream(file), encoding);//考虑到编码格式
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;

                while ((lineTxt = bufferedReader.readLine()) != null) {
                    String[] temp = lineTxt.split("\t");
                    for (int i = 0; i < Data[temphang].length; i++) {
                        if (i == Data[temphang].length - 1) {
                            Data[temphang][Data[temphang].length - 1] = "0";
                        } else {
                            Data[temphang][i] = temp[i];
                        }
                    }
                    temphang++;
                }
                read.close();
            } else {
                System.out.println("找不到指定的文件");
            }
        } catch (Exception e) {
            System.out.println("读取文件内容出错");
            e.printStackTrace();
        }

    }

    public static String[] titleHead() {
        // TODO code application logic here
        //
        String[] titleHead;
        readTxt();
        readTxtFile();
        titleHead = new String[Data[0].length - 1];
        for (int i = 0; i < titleHead.length; i++) {
            if (i == 0) {
                titleHead[i] = "选择统计列";
            } else {
                titleHead[i] = Data[0][i];
            }

        }
        return titleHead;
    }

    public static void setNum(int num1, int num2, int num3, int num4, int num5, int num6, int num7, double bfb1, double bfb2, double bfb3, double bfb4, double bfb5, double bfb6, double bfb7) {
        System.out.println("num1:" + num1 + "num2:" + num2 + "num3:" + num3 + "num4:" + num4 + "num5:" + num5 + "num6:" + num6 + "num7:" + num7);
        System.out.println("bfb1:" + bfb1 + "bfb2:" + bfb2 + "bfb3:" + bfb3 + "bfb4:" + bfb4 + "bfb5:" + bfb5 + "bfb6:" + bfb6 + "bfb7:" + bfb7);
        selectLie[0][0] = num1;
        selectLie[0][1] = num2;
        selectLie[0][2] = num3;
        selectLie[0][3] = num4;
        selectLie[0][4] = num5;
        selectLie[0][5] = num6;
        selectLie[0][6] = num7;
        selectLie[1][0] = bfb1;
        selectLie[1][1] = bfb2;
        selectLie[1][2] = bfb3;
        selectLie[1][3] = bfb4;
        selectLie[1][4] = bfb5;
        selectLie[1][5] = bfb6;
        selectLie[1][6] = bfb7;

    }

    public static List<Selebith> dayincs(List<Selebith> selebithtemp) {
        if (selebithtemp == null) {
            return null;
        }
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        SelebithMapper selebithMapper = sqlSession.getMapper(SelebithMapper.class);
        List<Selebith> selebithList = new ArrayList<>();
        for (int i = 1; i < Data.length; i++) {
            for (int j = 0; j < Data[0].length - 2; j++) {
                Selebith temp = selebithMapper.selectById(Data[i][j]);
                temp.setR_farmid(Data[i][1]);
                selebithList.add(temp);
            }
        }
        List<Selebith> selebithtemp1 = new ArrayList<>();
        for (int i = 0; i < selebithList.size(); i++) {
            for (int j = 0; j < selebithtemp.size(); j++) {
                if (selebithtemp.get(j).getR_animal().equals(selebithList.get(i).getR_animal())) {
                    selebithtemp1.add(selebithList.get(i));
                }
            }
        }
        sqlSession.close();
        return selebithtemp1;
    }

    public static void jisuan() {
//        Data;
        for (int i = 0; i < Data.length; i++) {
            for (int j = 0; j < Data[0].length; j++) {
                System.out.printf("Data[" + i + "][" + j + "]=" + Data[i][j]);
            }
            System.out.println("");
        }

        for (int i = 1; i < Data.length; i++) {
            for (int j = 1; j < Data[0].length - 1; j++) {
                if (j == 1) {
                    Data[i][Data[0].length - 1] = "0";
                }
                if (Data[i][3].equals("NA")) {
                    if (j == selectLie[0][0]) {
                        Data[i][Data[0].length - 1] = df2.format(Double.valueOf(Data[i][Data[0].length - 1]) + Double.valueOf(Data[i][j]) * selectLie[1][0]);
                    }
                    if (j == selectLie[0][1]) {
                        Data[i][Data[0].length - 1] = df2.format(Double.valueOf(Data[i][Data[0].length - 1]) + Double.valueOf(Data[i][j]) * selectLie[1][1]);
                    }
                } else {
                    if (j == selectLie[0][3]) {
                        Data[i][Data[0].length - 1] = df2.format(Double.valueOf(Data[i][Data[0].length - 1]) + Double.valueOf(Data[i][j]) * selectLie[1][3]);
                    }
                    if (j == selectLie[0][4]) {
                        Data[i][Data[0].length - 1] = df2.format(Double.valueOf(Data[i][Data[0].length - 1]) + Double.valueOf(Data[i][j]) * selectLie[1][4]);
                    }
                    if (j == selectLie[0][5]) {
                        Data[i][Data[0].length - 1] = df2.format(Double.valueOf(Data[i][Data[0].length - 1]) + Double.valueOf(Data[i][j]) * selectLie[1][5]);
                    }
                }

            }
        }

        for (int i = 0; i < Data.length; i++) {
            for (int j = 0; j < Data[0].length; j++) {
                System.out.printf("Data[" + i + "][" + j + "]=" + Data[i][j]);
            }
            System.out.println("");
        }

    }

    public static void dayin(String output) throws Exception {
        ArrayList<String> Stringlist = new ArrayList<>();
        Stringlist.add("个体编号\t育种评分");
        for (int i = 1; i < Data.length; i++) {

            System.out.printf(Data[i][0] + "\t" + Data[i][Data[0].length - 1]);
            Stringlist.add(Data[i][0] + "\t" + Data[i][Data[0].length - 1]);

            FileWrite_Overwrite(output, Stringlist);
        }
    }

    public String[][] GetData() {
        return ReadText.Data;
    }
}
