package cn.archer.utils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 24161
 */
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;

/**
 *
 * @author outofmemory.cn
 */
public class TextOnClipboard {

    /**
     * Places text on the clipboard
     */
    public void placeTextOnClipboard(String temp) {

        Toolkit toolkit = Toolkit.getDefaultToolkit();

        Clipboard clipboard = toolkit.getSystemClipboard();

        StringSelection stringSel = new StringSelection(temp);

        clipboard.setContents(stringSel, null);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String temp = "Hello World";
        new TextOnClipboard().placeTextOnClipboard(temp);
    }

}
