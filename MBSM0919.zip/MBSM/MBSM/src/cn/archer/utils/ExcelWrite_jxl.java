package cn.archer.utils;

import cn.archer.pojo.Selebith;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import javax.swing.JTable;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class ExcelWrite_jxl {

    public static boolean writeExcel(String fileName, JTable jTable) throws WriteException, UnsupportedEncodingException {
        boolean flag = false;
        WritableWorkbook wwb = null;
        try {
            //首先要使用Workbook类的工厂方法创建一个可写入的工作薄(Workbook)对象    
            wwb = Workbook.createWorkbook(new File(fileName));

        } catch (IOException e) {
            e.printStackTrace();
        }
        if (wwb != null) {
            //创建一个可写入的工作表    
            //Workbook的createSheet方法有两个参数，第一个是工作表的名称，第二个是工作表在工作薄中的位置    
            WritableSheet ws = wwb.createSheet("工作表名称", 0);
            for (int i = 0; i < jTable.getColumnCount(); i++) {
                Label labelC = new Label(i, 0, jTable.getColumnName(i));
                ws.addCell(labelC);
            }
            //下面开始添加单元格   
            for (int i = 0; i < jTable.getRowCount(); i++) {
                for (int j = 0; j < jTable.getColumnCount(); j++) {
                    if ((String) jTable.getValueAt(i, 0) != null) {
                        String str = String.valueOf(jTable.getValueAt(i, j));
//                        byte[] temp=str.getBytes("utf-8");//这里写原编码方式
//                        String newStr=new String(temp,"utf-8");
                        //这里需要注意的是，在Excel中，第一个参数表示列，第二个表示行
                        Label labelC = new Label(j, i + 1, str);
                        //将生成的单元格添加到工作表中
                        ws.addCell(labelC);
                    }
                }
            }

            try {
                //从内存中写入文件中    
                wwb.write();
                //关闭资源，释放内存    
                wwb.close();
                flag = true;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (WriteException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

}
