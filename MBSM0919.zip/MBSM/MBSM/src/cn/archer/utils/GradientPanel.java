/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.utils;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import javax.swing.JPanel;

/**
 *
 * @author 24161
 */
public class GradientPanel extends JPanel {

    public GradientPanel(LayoutManager lm) {

        super(lm);

    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);

        if (!isOpaque()) {

            return;

        }

        int width = getWidth();

        int height = getHeight();

        Graphics2D g2 = (Graphics2D) g;

        GradientPaint gradientPaint = new GradientPaint(width / 2, 0, new Color(240, 240, 240, 0), width / 2, height, new Color(153, 255, 204), false);

        g2.setPaint(gradientPaint);

        g2.fillRect(0, 0, width, height);

    }
}
