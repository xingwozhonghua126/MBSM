package cn.archer.utils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Administrator
 */
public class MyTable extends javax.swing.table.AbstractTableModel {

    String[] head;
    Object[][] data;
    Class[] typeArray;

    public MyTable() {
    }

    public MyTable(Object[][] tableModel, String[] tableHeade) {
        super();
        this.head = tableHeade;
        this.data = tableModel;
        typeArray = new Class[tableHeade.length];
        typeArray[0] = Boolean.class;
        for (int j = 1; j < tableHeade.length; j++) {
            typeArray[j] = Object.class;
        }
    }
    // ��ñ�������

    public int getColumnCount() {
        return head.length;
    }

    // ��ñ�������
    public int getRowCount() {
        return data.length;
    }

    // ��ñ��������
    @Override
    public String getColumnName(int column) {
        return head[column];
    }

    // ��ñ��ĵ�Ԫ������
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }

    // ʹ�����пɱ༭��
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    // �滻��Ԫ���ֵ
    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        data[rowIndex][columnIndex] = aValue;
        fireTableCellUpdated(rowIndex, columnIndex);
    }
    //ʵ��boolean����ѡ���ת.

    @Override
    public Class getColumnClass(int columnIndex) {
        return typeArray[columnIndex];// ����ÿһ�е��������
    }
}
