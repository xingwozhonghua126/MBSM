package cn.archer.tj;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.app.*;
import static cn.archer.app.LoginApp.mainApp;
import static cn.archer.app.MainApp.fenceIdtoNameSmap;
import static cn.archer.app.MainApp.jqqyjyMapperPlus;
import static cn.archer.app.MainApp.piggeryIdtoNameSmap;
import cn.archer.mapper.plus.SelethMapperPlus;
import cn.archer.mapper.plus.XzxpMapperPlus;
import cn.archer.pojo.Selebith;
import static cn.archer.utils.MyStaticMethod.NowTime;
import static cn.archer.utils.MyStaticMethod.setJTableRow;
import cn.archer.utils.ReadText;
import java.awt.FileDialog;
import java.awt.Frame;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

/**
 *
 * @author Administrator
 */
public class Plxz extends javax.swing.JInternalFrame {

    private Object[][] tableModel;
    private String[] tableHead;
    private FileDialog loadDia;
    public static ReadText readText;
    private List<Selebith> selebithtemp;
    private List<Object[]> nowList;
    public VarietiesDataPlus2 varietiesDataPlus2;
    private Object[][] tableModel1;
    private Object[][] tableModel2;
    private Object[][] tableModel3;
    private DefaultTableModel model1;
    private DefaultTableModel model2;
    private DefaultTableModel model3;
    private boolean fopenboolean;

    public Plxz(List<Selebith> MaleList, List<Selebith> FemaleList) {
        initComponents();
        ((BasicInternalFrameUI) getUI()).setNorthPane(null);
        fopenboolean = false;
        tableModel1 = new Object[FemaleList.size()][3];
        for (int j = 0; j < FemaleList.size(); j++) {
            tableModel1[j][0] = FemaleList.get(j).getR_animal();
            tableModel1[j][1] = piggeryIdtoNameSmap.get(FemaleList.get(j).getR_cage());
            tableModel1[j][2] = fenceIdtoNameSmap.get(FemaleList.get(j).getR_pcage());
        }
        tableModel2 = new Object[MaleList.size()][5];
        for (int j = 0; j < MaleList.size(); j++) {
            tableModel2[j][0] = MaleList.get(j).getR_animal();
            tableModel2[j][2] = piggeryIdtoNameSmap.get(MaleList.get(j).getR_cage());
            tableModel2[j][3] = fenceIdtoNameSmap.get(MaleList.get(j).getR_pcage());
            tableModel2[j][4] = jqqyjyMapperPlus.selectByCjrq(MaleList.get(j).getR_animal());
        }
        tableModel3 = new Object[0][2];
        jTable1.setModel(new javax.swing.table.DefaultTableModel(tableModel1, new String[]{"母猪编号", "所在猪舍", "所在栏位"}));
        model1 = (DefaultTableModel) jTable1.getModel();
        setJTableRow(jTable1);
        jTable2.setModel(new javax.swing.table.DefaultTableModel(tableModel2, new String[]{"公猪编号", "育种评分", "所在猪舍", "所在栏位", "最近采精"}));
        setJTableRow(jTable2);
        model2 = (DefaultTableModel) jTable2.getModel();
        jTable3.setModel(new javax.swing.table.DefaultTableModel(tableModel3, new String[]{"母猪编号", "公猪编号"}));
        setJTableRow(jTable3);
        jTable3.setEnabled(false);
        model3 = (DefaultTableModel) jTable3.getModel();
        jButton3.setVisible(false);
    }

    public List<Selebith> getSelebithtemp() {
        return selebithtemp;
    }

    public void setSelebithtemp(List<Selebith> selebithtemp) {
        this.selebithtemp = readText.dayincs(selebithtemp);
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPaneDisplay3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jScrollPaneDisplay1 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jScrollPaneDisplay = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(233, 242, 252));
        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setTitle("选种选配");
        setToolTipText("");
        setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        setPreferredSize(new java.awt.Dimension(1010, 536));

        jPanel2.setBackground(new java.awt.Color(233, 242, 252));
        jPanel2.setPreferredSize(new java.awt.Dimension(1000, 520));

        jButton1.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 102));
        jButton1.setText("选择育种分析文件");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setText("文件目录：");

        jTable2.setFont(new java.awt.Font("楷体", 0, 12)); // NOI18N
        jTable2.setForeground(new java.awt.Color(0, 51, 102));
        jTable2.getTableHeader().setResizingAllowed(false);
        jScrollPaneDisplay3.setViewportView(jTable2);

        jButton2.setFont(new java.awt.Font("微软雅黑", 1, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 0, 102));
        jButton2.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        jButton2.setText("<html>预<br>配</html>");
        jButton2.setActionCommand("<html>这<br>个<br>也<br>可 <br>以</html>");
        jButton2.setPreferredSize(new java.awt.Dimension(56, 470));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable3.setFont(new java.awt.Font("楷体", 0, 12)); // NOI18N
        jTable3.setForeground(new java.awt.Color(0, 51, 102));
        jTable3.getTableHeader().setResizingAllowed(false);
        jScrollPaneDisplay1.setViewportView(jTable3);

        jTable1.setFont(new java.awt.Font("楷体", 0, 12)); // NOI18N
        jTable1.setForeground(new java.awt.Color(0, 51, 102));
        jTable1.getTableHeader().setResizingAllowed(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPaneDisplay.setViewportView(jTable1);

        jButton3.setFont(new java.awt.Font("宋体", 0, 8)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 102));
        jButton3.setText("当前综合育种值由大到小");
        jButton3.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
        jButton3.setPreferredSize(new java.awt.Dimension(37, 15));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("选配母猪");

        jLabel2.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("选种公猪");

        jLabel3.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("选种预配");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(445, 445, 445)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPaneDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(4, 4, 4)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(16, 16, 16)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(0, 0, 0)
                                        .addComponent(jScrollPaneDisplay3, javax.swing.GroupLayout.DEFAULT_SIZE, 423, Short.MAX_VALUE)
                                        .addGap(4, 4, 4)
                                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(4, 4, 4)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPaneDisplay1, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(108, 108, 108))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPaneDisplay1, javax.swing.GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE)
                    .addComponent(jScrollPaneDisplay3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPaneDisplay, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        loadDia = new FileDialog(new Frame(), "育种数据", FileDialog.LOAD);
        loadDia.setVisible(true);// TODO add your handling code here:
        String directory = loadDia.getDirectory();
        String file = loadDia.getFile();
        if (directory != null && file != null) {
            readText = new ReadText(directory + file);
            readText.readTxt();
            readText.readTxtFile();
            jLabel5.setText("文件目录：" + directory + file);
            setTableModel2(readText.GetData());
            jTable1.clearSelection();
            for (int i = 0; i < model2.getRowCount();) {
                model2.removeRow(i);
            }
            jTable2.setModel(model2);
            fopenboolean = true;
            jButton3.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "请先选择育种分析文件！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (jTable1.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "请选择预配种母猪！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (jTable2.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "请选择预配种公猪！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if ((jTable3.getRowCount() == 0) && (jLabel5.getText().equals("文件目录："))) {
            JOptionPane.showMessageDialog(null, "无参考育种分析文件！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
        }
        Object[] rowInsert = new Object[]{(String) model1.getValueAt(jTable1.getSelectedRow(), 0), (String) model2.getValueAt(jTable2.getSelectedRow(), 0)};
        for (int i = 0; i < model3.getRowCount(); i++) {
            if (model3.getValueAt(i, 0).equals(model1.getValueAt(jTable1.getSelectedRow(), 0))) {
                int flag = JOptionPane.showConfirmDialog(null, "是否从新预配编号为：" + (String) model1.getValueAt(jTable1.getSelectedRow(), 0) + "的配种母猪", "系统信息", JOptionPane.YES_NO_OPTION);
                if (flag == 0) {
                    model3.removeRow(i);
                } else {
                    return;
                }
            }
        }
        model3.addRow(rowInsert);
        jTable3.setModel(model3);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if (jTable1.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "请选择预配种母猪！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (fopenboolean) {
            XzxpMapperPlus xzxpMapperPlus = new XzxpMapperPlus();
            this.setSelebithtemp(xzxpMapperPlus.Jqjy((String) model1.getValueAt(jTable1.getSelectedRow(), 0)));
            tableModel2 = new Object[this.getSelebithtemp().size()][5];
            nowList = new ArrayList<>();
            for (int j = 0; j < this.getSelebithtemp().size(); j++) {
                tableModel2[j][0] = this.getSelebithtemp().get(j).getR_animal();
                tableModel2[j][1] = this.getSelebithtemp().get(j).getR_farmid();
                tableModel2[j][2] = piggeryIdtoNameSmap.get(this.getSelebithtemp().get(j).getR_cage());
                tableModel2[j][3] = fenceIdtoNameSmap.get(this.getSelebithtemp().get(j).getR_pcage());
                tableModel2[j][4] = jqqyjyMapperPlus.selectByCjrq(this.getSelebithtemp().get(j).getR_animal());
                nowList.add(tableModel2[j]);
            }
            Collections.reverse(nowList);
            for (int i = 0; i < model2.getRowCount();) {
                model2.removeRow(i);
            }
            for (int i = 0; i < nowList.size(); i++) {
                model2.addRow(nowList.get(i));
            }
            jTable2.setModel(model2);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (jButton3.getText().equals("当前综合育种值由大到小")) {
            jButton3.setText("当前综合育种值由小到大");
        } else {
            jButton3.setText("当前综合育种值由大到小");
        }
        Collections.reverse(nowList);
        for (int i = 0; i < model2.getRowCount();) {
            model2.removeRow(i);
        }
        for (int i = 0; i < nowList.size(); i++) {
            model2.addRow(nowList.get(i));
        }
        jTable2.setModel(model2);
    }//GEN-LAST:event_jButton3ActionPerformed

    public void setData() {
        jLabel5.setText("文件目录：");
        fopenboolean = false;
        jButton3.setVisible(false);
    }

    public ArrayList<String> ypxx(int dyf) {
        if (dyf == 0) {
            ArrayList<String> Stringlist = new ArrayList<>();
            Stringlist.add("母猪编号\t所在猪舍\t所在栏位\t公猪编号\t所在猪舍\t所在栏位");
            SelethMapperPlus selethMapperPlus = new SelethMapperPlus();
            for (int i = 0; i < model3.getRowCount(); i++) {
                Selebith selebithm = selethMapperPlus.SelectById((String) model3.getValueAt(i, 0));
                Selebith selebithg = selethMapperPlus.SelectById((String) model3.getValueAt(i, 1));
                Stringlist.add(selebithm.getR_animal() + "\t" + piggeryIdtoNameSmap.get(selebithm.getR_cage()) + "\t" + fenceIdtoNameSmap.get(selebithm.getR_pcage()) + "\t" + selebithg.getR_animal() + "\t" + piggeryIdtoNameSmap.get(selebithg.getR_cage()) + "\t" + fenceIdtoNameSmap.get(selebithg.getR_pcage()));
            }
            return Stringlist;
        } else {
            ArrayList<String> Stringlist = new ArrayList<>();
            Stringlist.add(mainApp.nowEmployee.getUser_name());
            Stringlist.add(NowTime());
            Stringlist.add("母猪编号   所在猪舍   所在栏位   公猪编号   所在猪舍   所在栏位");
            SelethMapperPlus selethMapperPlus = new SelethMapperPlus();
            for (int i = 0; i < model3.getRowCount(); i++) {
                Selebith selebithm = selethMapperPlus.SelectById((String) model3.getValueAt(i, 0));
                Selebith selebithg = selethMapperPlus.SelectById((String) model3.getValueAt(i, 1));
                Stringlist.add(selebithm.getR_animal() + "   " + piggeryIdtoNameSmap.get(selebithm.getR_cage()) + "   " + fenceIdtoNameSmap.get(selebithm.getR_pcage()) + "   " + selebithg.getR_animal() + "   " + piggeryIdtoNameSmap.get(selebithg.getR_cage()) + "   " + fenceIdtoNameSmap.get(selebithg.getR_pcage()));
            }
            return Stringlist;
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private static javax.swing.JScrollPane jScrollPaneDisplay;
    private static javax.swing.JScrollPane jScrollPaneDisplay1;
    private static javax.swing.JScrollPane jScrollPaneDisplay3;
    private static javax.swing.JTable jTable1;
    private static javax.swing.JTable jTable2;
    private static javax.swing.JTable jTable3;
    // End of variables declaration//GEN-END:variables
    public JTable getjTable1() {
        return jTable1;
    }

    public void setjTable1(JTable jTable1) {
        this.jTable1 = jTable1;
    }

    public void setTableModel1(Object[][] tableModel) {
        this.tableModel1 = tableModel;
    }

    public JTable getjTable2() {
        return jTable2;
    }

    public void setjTable2(JTable jTable2) {
        this.jTable2 = jTable2;
    }

    public void setTableModel2(Object[][] tableModel) {
        this.tableModel2 = tableModel;
    }

    public JTable getjTable3() {
        return jTable3;
    }

    public void setjTable3(JTable jTable2) {
        this.jTable3 = jTable2;
    }

    public void setTableModel3(Object[][] tableModel) {
        this.tableModel3 = tableModel;
    }

}
