package cn.archer.tj;

import cn.archer.tj.*;
import cn.archer.app.DetailedApp;
import cn.archer.app.MainApp;
import static cn.archer.app.MainApp.tjMapperPlus;
import cn.archer.pojo.Count;
import cn.archer.pojo.Data;
import cn.archer.pojo.Dataset;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import cn.archer.utils.ExcelWrite_jxl;
import cn.archer.utils.PrintData;
import static cn.archer.utils.PrintImage.printImage;
import java.awt.Dialog;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import jxl.write.WriteException;
import static cn.archer.app.MainApp.PrintList;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import static cn.archer.utils.MyStaticMethod.df1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Administrator
 */
public class PzfmlTJ extends javax.swing.JInternalFrame {

    private double pzcs2;
    private double fmcs;
    private FileDialog saveDia;
    private String ratio;
    private NumberFormat nFromat;
    private boolean sfkq;
    private Chart1 chart1 = null;
    private Chart2 chart2 = null;
    private List<Count> pzcs2dayList;
    private List<Count> pzcs2monthList;
    private List<Count> pzcs2yearList;
    private List<Count> fmcsdayList;
    private List<Count> fmcsmonthList;
    private List<Count> fmcsyearList;
    private List<Data> List;
    private List<Dataset> nowData;
    private PrintData printData;

    public PzfmlTJ() {
        ((BasicInternalFrameUI)getUI()).setNorthPane(null);
        nFromat = NumberFormat.getPercentInstance();
        this.setVisible(true);
        initComponents();
        printData = new PrintData();

    }

    public void setData() {
        sfkq = false;
        List = null;
        jTextField1.setText("");
        jTextField1.setEditable(false);
        jTextField2.setText("");
        jTextField2.setEditable(false);
        jTextField3.setText("");
        jTextField3.setEditable(false);
        jTextField4.setText("");
        jTextField4.setEditable(false);
        jTextField5.setText("");
        jTextField5.setEditable(false);
        jTextField6.setText("");
        jTextField6.setEditable(false);
        jTextField7.setText("");
        jTextField7.setEditable(false);
        jTextField8.setText("");
        jTextField8.setEditable(false);
        jTextField9.setText("");
        jTextField9.setEditable(false);
        jDesktopPane1.removeAll();
        jDesktopPane1.add(jLabel2);
        jDesktopPane1.repaint();
        String[] thungs = new String[]{"日期格式", "年", "月", "日"};
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(thungs));
    }

    public void setData(String startDate, String endDate, String pignum, String piggery, String fenceid, String employe, int pzcs2, int fmcs, List<Count> pzcs2dayList, List<Count> pzcs2monthList, List<Count> pzcs2yearList, List<Count> fmcsdayList, List<Count> fmcsmonthList, List<Count> fmcsyearList) {
        this.pzcs2dayList = pzcs2dayList;
        this.pzcs2monthList = pzcs2monthList;
        this.pzcs2yearList = pzcs2yearList;
        this.fmcsdayList = fmcsdayList;
        this.fmcsmonthList = fmcsmonthList;
        this.fmcsyearList = fmcsyearList;
        if (pzcs2dayList.size() != 0) {
            startDate = pzcs2dayList.get(0).getDays();
            endDate = pzcs2dayList.get(pzcs2dayList.size() - 1).getDays();
        }
        sfkq = true;
        this.pzcs2 = (double) pzcs2;
        this.fmcs = (double) fmcs;
        if (pzcs2 != 0) {
            ratio = nFromat.format(this.fmcs / this.pzcs2);
        } else {
            ratio = "0%";
        }

        if (pignum.equals("%")) {
            pignum = "全部个体";
        } else {
            pignum = tjMapperPlus.selectById(pignum);
        }

        jTextField1.setText(startDate);
        jTextField2.setText(endDate);
        jTextField3.setText(String.valueOf(pzcs2));
        jTextField4.setText(String.valueOf(fmcs));
        jTextField5.setText(ratio);
        jTextField6.setText(piggery);
        jTextField7.setText(fenceid);
        jTextField8.setText(employe);
        jTextField9.setText(pignum);

        jDesktopPane1.removeAll();
        jDesktopPane1.add(jLabel2);
        jDesktopPane1.repaint();
        String[] things = new String[]{"日期格式", "年", "月", "日"};
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(things));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel04 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();

        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setToolTipText("");
        setPreferredSize(new java.awt.Dimension(1010, 536));

        jPanel1.setBackground(new java.awt.Color(226, 237, 252));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 502));

        jTextField1.setForeground(new java.awt.Color(0, 0, 102));

        jLabel04.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel04.setForeground(new java.awt.Color(0, 0, 102));
        jLabel04.setText("配种日期：");

        jTextField2.setForeground(new java.awt.Color(0, 0, 102));

        jLabel5.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("妊娠次数：");

        jTextField3.setForeground(new java.awt.Color(0, 0, 102));

        jLabel6.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("分娩次数：");

        jTextField4.setForeground(new java.awt.Color(0, 0, 102));

        jLabel7.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("妊娠猪舍：");

        jLabel8.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("分娩比率：");

        jTextField9.setForeground(new java.awt.Color(0, 0, 102));

        jLabel9.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("个体编号：");

        jLabel10.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("负 责 人：");

        jLabel11.setFont(new java.awt.Font("宋体", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("配种栏位：");

        jLabel1.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("配种分娩率");

        jTextField6.setForeground(new java.awt.Color(0, 0, 102));

        jTextField7.setForeground(new java.awt.Color(0, 0, 102));

        jTextField8.setForeground(new java.awt.Color(0, 0, 102));

        jComboBox1.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jComboBox1.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "日期格式", "年", "月", "日" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jDesktopPane1.setBackground(new java.awt.Color(226, 237, 252));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/配种返情率统计.png"))); // NOI18N

        jDesktopPane1.setLayer(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel2)
                .addContainerGap(52, Short.MAX_VALUE))
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jButton2.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 102));
        jButton2.setText("导出图形");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 102));
        jButton3.setText("导出表格");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 0, 102));
        jButton4.setText("打印表格");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 0, 102));
        jButton5.setText("打印图形");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jComboBox2.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "条形图", "折线图" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel9)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel5))
                                .addGap(1, 1, 1))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel04, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                            .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField4, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField9)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel1)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 157, Short.MAX_VALUE)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton4)
                        .addGap(90, 90, 90))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jDesktopPane1))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel1)
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel04))
                        .addGap(18, 18, 18)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jDesktopPane1)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2)
                            .addComponent(jButton3)
                            .addComponent(jButton5)
                            .addComponent(jButton4)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        if (sfkq) {
            List = new ArrayList<>();
            List.add(new Data(jLabel04.getText(), jTextField1.getText(), jTextField2.getText(), "", "", "", "", "", ""));
            List.add(new Data(jLabel5.getText(), jTextField3.getText(), "", "", "", "", "", "", ""));
            List.add(new Data(jLabel6.getText(), jTextField4.getText(), "", "", "", "", "", "", ""));
            List.add(new Data(jLabel8.getText(), jTextField5.getText(), "", "", "", "", "", "", ""));
            List.add(new Data(jLabel7.getText(), jTextField6.getText(), "", "", "", "", "", "", ""));
            List.add(new Data(jLabel11.getText(), jTextField7.getText(), "", "", "", "", "", "", ""));
            List.add(new Data(jLabel10.getText(), jTextField8.getText(), "", "", "", "", "", "", ""));
            List.add(new Data(jLabel9.getText(), jTextField9.getText(), "", "", "", "", "", "", ""));
            List.add(new Data("", "", "", "", "", "", "", "", ""));
            List.add(new Data("配种时间", "妊娠数", "分娩次数", "分娩率", "负责人", "妊娠猪舍", "妊娠栏位", "个体编号", ""));
            String temp = JComboBoxString(jComboBox1);
            nowData = new ArrayList<>();
            double pzcs2temp = 0;
            double fmcstemp = 0;
            switch (temp) {
                case "年":
                    for (int i = 0; i < pzcs2yearList.size(); i++) {
                        pzcs2temp = (double) pzcs2yearList.get(i).getCount();
                        boolean pff = false;
                        for (int j = 0; j < fmcsyearList.size(); j++) {
                            if (pzcs2yearList.get(i).getYears().equals(fmcsyearList.get(j).getYears())) {
                                fmcstemp = (double) fmcsyearList.get(j).getCount();
                                pff = true;
                                break;
                            }
                        }
                        if (pff == false) {
                            fmcstemp = 0;
                        } else {
                            pff = false;
                        }

                        String result1 = df1.format((fmcstemp / pzcs2temp) * 100);
                        double result = Double.valueOf(result1);

                        nowData.add(new Dataset(result, "配种分娩率", pzcs2yearList.get(i).getYears()));
                        List.add(new Data(pzcs2yearList.get(i).getYears(), String.valueOf(pzcs2temp), String.valueOf(fmcstemp), result1, jTextField8.getText(), jTextField6.getText(), jTextField7.getText(), jTextField9.getText(), ""));
                    }
                    chart1 = new Chart1("配种分娩率", "配种分娩率", "年", "分娩率（%）", nowData);
                    chart2 = new Chart2("配种分娩率", "配种分娩率", "年", "分娩率（%）", nowData);

                    break;
                case "月":
                    for (int i = 0; i < pzcs2monthList.size(); i++) {
                        pzcs2temp = (double) pzcs2monthList.get(i).getCount();
                        boolean pff = false;
                        for (int j = 0; j < fmcsmonthList.size(); j++) {
                            if (pzcs2monthList.get(i).getMonths().equals(fmcsmonthList.get(j).getMonths())) {
                                fmcstemp = (double) fmcsmonthList.get(j).getCount();
                                pff = true;
                                break;
                            }
                        }
                        if (pff == false) {
                            fmcstemp = 0;
                        } else {
                            pff = false;
                        }
                        String result1 = df1.format((fmcstemp / pzcs2temp) * 100);
                        double result = Double.valueOf(result1);

                        nowData.add(new Dataset(result, "配种分娩率", pzcs2monthList.get(i).getMonths()));
                        List.add(new Data(pzcs2monthList.get(i).getMonths(), String.valueOf(pzcs2temp), String.valueOf(fmcstemp), result1, jTextField8.getText(), jTextField6.getText(), jTextField7.getText(), jTextField9.getText(), ""));

                    }
                    chart1 = new Chart1("配种分娩率", "配种分娩率", "月", "分娩率（%）", nowData);
                    chart2 = new Chart2("配种分娩率", "配种分娩率", "月", "分娩率（%）", nowData);

                    break;
                case "日":
                    for (int i = 0; i < pzcs2dayList.size(); i++) {
                        pzcs2temp = (double) pzcs2dayList.get(i).getCount();
                        boolean pff = false;
                        for (int j = 0; j < fmcsdayList.size(); j++) {
                            if (pzcs2dayList.get(i).getDays().equals(fmcsdayList.get(j).getDays())) {
                                fmcstemp = (double) fmcsdayList.get(j).getCount();
                                pff = true;
                                break;
                            }
                        }
                        if (pff == false) {
                            fmcstemp = 0;
                        } else {
                            pff = false;
                        }

                        String result1 = df1.format((fmcstemp / pzcs2temp) * 100);
                        double result = Double.valueOf(result1);

                        nowData.add(new Dataset(result, "配种分娩率", pzcs2dayList.get(i).getDays()));
                        List.add(new Data(pzcs2dayList.get(i).getDays(), String.valueOf(pzcs2temp), String.valueOf(fmcstemp), result1, jTextField8.getText(), jTextField6.getText(), jTextField7.getText(), jTextField9.getText(), ""));

                    }
                    chart1 = new Chart1("配种分娩率", "配种分娩率", "日", "分娩率（%）", nowData);
                    chart2 = new Chart2("配种分娩率", "配种分娩率", "日", "分娩率（%）", nowData);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "请先选择日期格式！", "系统信息", JOptionPane.ERROR_MESSAGE);
                    jDesktopPane1.removeAll();
                    return;
            }

            chart1.setVisible(true);
            chart2.setVisible(true);
            chart1.pack();
            chart2.pack();
            jDesktopPane1.removeAll();
            if ("条形图".equals(JComboBoxString(jComboBox2))) {
                jDesktopPane1.add(chart1); //在父窗口中添加这个子窗口
            } else if ("折线图".equals(JComboBoxString(jComboBox2))) {
                jDesktopPane1.add(chart2); //在父窗口中添加这个子窗口
            }

            PrintList((ArrayList<Data>) List);
        } else {
            JOptionPane.showMessageDialog(null, "请先统计数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
            String[] thungs = new String[]{"日期格式", "年", "月", "日"};
            jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(thungs));

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (sfkq) {
            if (chart1 == null) {
                JOptionPane.showMessageDialog(null, "请先选择年月日分类并生成表格！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (saveDia == null) {
                saveDia = new FileDialog(new Frame(), "我的保存", FileDialog.SAVE);
            }
            saveDia.setVisible(true);
            String dirPath = saveDia.getDirectory();
            String fileName = saveDia.getFile();
            boolean flag = false;
            if(dirPath!=null&&fileName!=null)
            {
                flag = true;
            }
            BufferedImage bi;
            Graphics2D g2d;
            if (JComboBoxString(jComboBox2).equals("条形图")) {
                bi = new BufferedImage(chart1.getWidth(), chart1.getHeight(), BufferedImage.TYPE_INT_ARGB);
                g2d = bi.createGraphics();
                chart1.paint(g2d);

            } else {
                bi = new BufferedImage(chart2.getWidth(), chart2.getHeight(), BufferedImage.TYPE_INT_ARGB);
                g2d = bi.createGraphics();
                chart2.paint(g2d);
            }

            try {
                ImageIO.write(bi, "PNG", new File(dirPath, fileName + ".png"));
            } catch (IOException ex) {
                Logger.getLogger(PzfmlTJ.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "数据导出成功", "提示", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "数据导出失败", "提示", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "请先统计数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }

// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (sfkq) {
            if (chart1 == null) {
                JOptionPane.showMessageDialog(null, "请先选择年月日分类并生成表格！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (saveDia == null) {
                saveDia = new FileDialog(new Frame(), "我的保存", FileDialog.SAVE);
            }
            saveDia.setVisible(true);
            String dirPath = saveDia.getDirectory();
            String fileName = saveDia.getFile();
            JTable jTable1Excel = null;
            boolean flag = false;
            if (dirPath != null || fileName != null) {
                File file = new File(dirPath, fileName);

                if (List != null) {
                    jTable1Excel = PrintList((ArrayList<Data>) List);
                }

                if (jTable1Excel.getRowCount() != 0) {

                    try {
                        flag = ExcelWrite_jxl.writeExcel(file.toString().concat(".xls"), jTable1Excel);
                    } catch (WriteException ex) {
                        Logger.getLogger(PzfmlTJ.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (UnsupportedEncodingException ex) {
                        Logger.getLogger(PzfmlTJ.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "数据导出成功", "提示", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "数据导出失败", "提示", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "请先统计数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
        } // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        if (!sfkq) {
            JOptionPane.showMessageDialog(null, "请先统计数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (JComboBoxString(jComboBox1).equals("日期格式")) {
            JOptionPane.showMessageDialog(null, "请先选择日期格式！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }

        jDesktopPane1.removeAll();
        if ("条形图".equals(JComboBoxString(jComboBox2))) {
            jDesktopPane1.add(chart1); //在父窗口中添加这个子窗口
        } else if ("折线图".equals(JComboBoxString(jComboBox2))) {
            jDesktopPane1.add(chart2); //在父窗口中添加这个子窗口
        }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (sfkq) {
            if (chart1 == null) {
                JOptionPane.showMessageDialog(null, "请先选择年月日分类并生成表格！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if ("条形图".equals(JComboBoxString(jComboBox2))) {
                BufferedImage bi = new BufferedImage(chart1.getWidth(), chart1.getHeight(), BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = bi.createGraphics();
                chart1.paint(g2d);
                try {
                    ImageIO.write(bi, "PNG", new File("D:\\pigdata\\temp.png"));
                    printImage("D:\\pigdata\\temp.png");// TODO add your handling code here:
                } catch (IOException ex) {
                }
            } else if ("折线图".equals(JComboBoxString(jComboBox2))) {
                BufferedImage bi = new BufferedImage(chart2.getWidth(), chart2.getHeight(), BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = bi.createGraphics();
                chart2.paint(g2d);
                try {
                    ImageIO.write(bi, "PNG", new File("D:\\pigdata\\temp.png"));
                    printImage("D:\\pigdata\\temp.png");// TODO add your handling code here:
                } catch (IOException ex) {
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "请先统计数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if (sfkq) {
            if (chart1 == null) {
                JOptionPane.showMessageDialog(null, "请先选择年月日分类并生成表格！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            printData.PrintData();

        } else {
            JOptionPane.showMessageDialog(null, "请先统计数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel04;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
