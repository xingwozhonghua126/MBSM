package cn.archer.tj;

import cn.archer.pojo.Dataset;
import java.awt.Font;
import java.util.List;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import javax.swing.JInternalFrame;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class Chart2 extends JInternalFrame {

    public Chart2(String applicationTitle, String chartTitle, String Abscissa, String Ratio, List<Dataset> Dlist) {
        super(applicationTitle);
        ((BasicInternalFrameUI)getUI()).setNorthPane(null);
        //创建主题样式
        StandardChartTheme standardChartTheme = new StandardChartTheme("CN");
        standardChartTheme.setExtraLargeFont(new Font("隶书", Font.BOLD, 20));
        standardChartTheme.setRegularFont(new Font("微软雅黑", Font.BOLD, 10));
        standardChartTheme.setLargeFont(new Font("宋书", Font.PLAIN, 15));
        ChartFactory.setChartTheme(standardChartTheme);
        JFreeChart lineChart = ChartFactory.createLineChart(
                chartTitle,
                Abscissa,
                Ratio,
                createDataset(Dlist),
                PlotOrientation.VERTICAL,
                true, true, false);

        ChartPanel chartPanel = new ChartPanel(lineChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(780, 400));
        setContentPane(chartPanel);
    }

    private CategoryDataset createDataset(List<Dataset> Dlist) {

        final DefaultCategoryDataset dataset
                = new DefaultCategoryDataset();

        for (int i = 0; i < Dlist.size(); i++) {
            dataset.addValue(Dlist.get(i).getRatio(), Dlist.get(i).getName(), Dlist.get(i).getAbscissag());
        }

        return dataset;
    }

}
