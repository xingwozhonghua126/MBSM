package cn.archer.tj;

import cn.archer.app.ShowPicture;
import static cn.archer.utils.MyStaticJComboBoxData.JComboBoxString;
import cn.archer.utils.ReadText;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.Image;
import static java.awt.Toolkit.getDefaultToolkit;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Administrator
 */
public class Yzfx extends javax.swing.JInternalFrame {

    private FileDialog loadDia;
    private double Sum1;
    private double Sum2;
    public static ReadText readText;
    public static String output;
    public static String outTuPianput;

    public Yzfx() {
        ((BasicInternalFrameUI) getUI()).setNorthPane(null);
        this.setVisible(true);
        initComponents();
        jComboBox4.setVisible(false);
        jComboBox8.setVisible(false);
        jTextField3.setVisible(false);
        jTextField7.setVisible(false);

    }
    public void setData() {

        jLabel1.setText("文件目录");
        jLabel2.setText("输出目录");
        output = null;
        outTuPianput =null;
        String things[] = new String[1];
        things[0] = "选择统计列";
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(things));
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(things));
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton6 = new javax.swing.JButton();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox5 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jComboBox6 = new javax.swing.JComboBox<>();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jComboBox7 = new javax.swing.JComboBox<>();
        jTextField7 = new javax.swing.JTextField();
        jComboBox8 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(226, 237, 252));
        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setToolTipText("");
        setPreferredSize(new java.awt.Dimension(1010, 536));

        jPanel1.setBackground(new java.awt.Color(226, 237, 252));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 502));

        jComboBox2.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "选择统计列" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 0, 102));
        jButton6.setText("选择图形文件");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jComboBox3.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jComboBox3.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "选择统计列" }));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jComboBox4.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jComboBox4.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "选择统计列" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        jComboBox5.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jComboBox5.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "选择统计列" }));
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });

        jTextField1.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 0, 102));
        jTextField1.setText("-0.7");
        jTextField1.setPreferredSize(new java.awt.Dimension(46, 23));

        jTextField2.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(0, 0, 102));
        jTextField2.setText("-0.3");
        jTextField2.setPreferredSize(new java.awt.Dimension(46, 23));

        jTextField3.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jTextField3.setText("0");
        jTextField3.setPreferredSize(new java.awt.Dimension(46, 23));
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jTextField4.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jTextField4.setText("-0.3");
        jTextField4.setPreferredSize(new java.awt.Dimension(46, 23));

        jButton2.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 102));
        jButton2.setText("生成育种综合文件");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/配种返情率统计.png"))); // NOI18N

        jButton3.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 102));
        jButton3.setText("显示图片");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jComboBox6.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jComboBox6.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "选择统计列" }));
        jComboBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox6ActionPerformed(evt);
            }
        });

        jTextField5.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jTextField5.setText("-0.1");
        jTextField5.setPreferredSize(new java.awt.Dimension(46, 23));

        jTextField6.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jTextField6.setText("0.6");
        jTextField6.setPreferredSize(new java.awt.Dimension(46, 23));

        jComboBox7.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jComboBox7.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "选择统计列" }));
        jComboBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox7ActionPerformed(evt);
            }
        });

        jTextField7.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jTextField7.setText("0");
        jTextField7.setPreferredSize(new java.awt.Dimension(46, 23));

        jComboBox8.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        jComboBox8.setForeground(new java.awt.Color(0, 0, 102));
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "选择统计列" }));
        jComboBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox8ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel1.setText("文件目录");

        jButton4.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 0, 102));
        jButton4.setText("选择数据文件");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("宋体", 0, 10)); // NOI18N
        jLabel2.setText("输出目录");

        jLabel3.setText("公猪");

        jLabel4.setText("母猪");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(33, 33, 33)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(33, 33, 33)
                                        .addComponent(jTextField5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(33, 33, 33)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jTextField4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(jTextField7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButton6)
                                    .addComponent(jButton4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton3)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(jButton6))
                        .addGap(7, 7, 7)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jButton2))
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed

    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        loadDia = new FileDialog(new Frame(), "育种图形", FileDialog.LOAD);
        loadDia.setVisible(true);// TODO add your handling code here:
        String directory = loadDia.getDirectory();
        String file = loadDia.getFile();
        if (directory != null && file != null) {
            outTuPianput = directory + file;
        } else {
            JOptionPane.showMessageDialog(null, "请先选择育种图形！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        ArrayList<String> txtList1 = new ArrayList<>();
        ArrayList<String> txtList2 = new ArrayList<>();
        String temp;
        Sum1 = 0;
        Sum2 = 0;

        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        int num4 = 0;
        int num5 = 0;
        int num6 = 0;
        int num7 = 0;
        double bfb1 = 0;
        double bfb2 = 0;
        double bfb3 = 0;
        double bfb4 = 0;
        double bfb5 = 0;
        double bfb6 = 0;
        double bfb7 = 0;
        if (!"选择统计列".equals(temp = JComboBoxString(jComboBox2))) {
            txtList1.add(temp);
            num1 = jComboBox2.getSelectedIndex();
            bfb1 = Double.valueOf(jTextField1.getText());
            Sum1 += java.lang.Math.abs(bfb1);
        }
        if (!"选择统计列".equals(temp = JComboBoxString(jComboBox3))) {
            txtList1.add(temp);
            num2 = jComboBox3.getSelectedIndex();
            bfb2 = Double.valueOf(jTextField2.getText());
            Sum1 += java.lang.Math.abs(bfb2);
        }

        if (!"选择统计列".equals(temp = JComboBoxString(jComboBox5))) {
            txtList2.add(temp);
            num4 = jComboBox5.getSelectedIndex();
            bfb4 = Double.valueOf(jTextField4.getText());
            Sum2 += java.lang.Math.abs(bfb4);
        }
        if (!"选择统计列".equals(temp = JComboBoxString(jComboBox6))) {
            txtList2.add(temp);
            num5 = jComboBox6.getSelectedIndex();
            bfb5 = Double.valueOf(jTextField5.getText());
            Sum2 += java.lang.Math.abs(bfb5);
        }
        if (!"选择统计列".equals(temp = JComboBoxString(jComboBox7))) {
            txtList2.add(temp);
            num6 = jComboBox7.getSelectedIndex();
            bfb6 = Double.valueOf(jTextField6.getText());
            Sum2 += java.lang.Math.abs(bfb6);
        }
        for (int i = 0; i < txtList1.size(); i++) {
            for (int j = i + 1; j < txtList1.size(); j++) {
                if (txtList1.get(i).equals(txtList1.get(j))) {
                    JOptionPane.showMessageDialog(null, "列标题重复,请重新选择！", "系统信息", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        }
        for (int i = 0; i < txtList2.size(); i++) {
            for (int j = i + 1; j < txtList2.size(); j++) {
                if (txtList2.get(i).equals(txtList2.get(j))) {
                    JOptionPane.showMessageDialog(null, "列标题重复,请重新选择！", "系统信息", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        }
        if (Sum1 != 1) {
            System.out.println("SUM1" + Sum1);
            JOptionPane.showMessageDialog(null, "公猪百分比之和不等于1！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (Sum2 != 1) {
            System.out.println("SUM2" + Sum2);
            JOptionPane.showMessageDialog(null, "母猪百分比之和不等于1！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        readText.setNum(num1, num2, num3, num4, num5, num6, num7, bfb1, bfb2, bfb3, bfb4, bfb5, bfb6, bfb7);
        readText.jisuan();
        
        loadDia = new FileDialog(new Frame(), "育种数据", FileDialog.SAVE);
        loadDia.setVisible(true);// TODO add your handling code here:
        String directory = loadDia.getDirectory();
        String file = loadDia.getFile();
        if (directory != null && file != null) {
            output = directory + file + ".txt";
            jLabel2.setText("输出目录：" + output);
        } else {
            JOptionPane.showMessageDialog(null, "生成数据文件失败！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }
        try {
            readText.dayin(directory + file);
            JOptionPane.showMessageDialog(null, "生成数据文件成功！", "系统信息", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        ShowPicture showPicture = new ShowPicture();
        Image image = null;
        try {
            if (outTuPianput == null) {
                JOptionPane.showMessageDialog(null, "请先选择育种图片！", "系统信息", JOptionPane.ERROR_MESSAGE);
                return;
            }
            image = ImageIO.read(new FileInputStream(outTuPianput));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "请先选择育种图片！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (image == null) {
            JOptionPane.showMessageDialog(null, "请先选择育种图片！", "系统信息", JOptionPane.ERROR_MESSAGE);
            return;
        }
        ImageIcon imageIcon = new ImageIcon(image);
        ShowPicture.jLabel11.setIcon(imageIcon);
        showPicture.setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox6ActionPerformed

    private void jComboBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox7ActionPerformed

    private void jComboBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox8ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        loadDia = new FileDialog(new Frame(), "育种数据", FileDialog.LOAD);
        loadDia.setVisible(true);// TODO add your handling code here:
        String directory = loadDia.getDirectory();
        String file = loadDia.getFile();
        if (directory != null && file != null) {
            readText = new ReadText(directory + file);
            jLabel1.setText("文件目录：" + directory + file);
            String[] titleheads = readText.titleHead();
            jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(titleheads));
            jComboBox2.setSelectedIndex(1);
            jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(titleheads));
            jComboBox3.setSelectedIndex(2);

            jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(titleheads));
            jComboBox5.setSelectedIndex(1);
            jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(titleheads));
            jComboBox6.setSelectedIndex(2);
            jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(titleheads));
            jComboBox7.setSelectedIndex(3);
        } else {
            JOptionPane.showMessageDialog(null, "请先选择育种数据！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }       // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
