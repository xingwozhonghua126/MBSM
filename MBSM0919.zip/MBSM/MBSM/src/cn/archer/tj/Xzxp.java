package cn.archer.tj;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.app.*;
import cn.archer.pojo.Selebith;
import cn.archer.utils.ReadText;
import java.awt.FileDialog;
import java.awt.Frame;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/**
 *
 * @author Administrator
 */
public class Xzxp extends javax.swing.JInternalFrame {

    private FileDialog loadDia;
    public static ReadText readText;
    private List<Selebith> selebithtemp;
    public VarietiesDataPlus2 varietiesDataPlus2;

    public Xzxp() {
        initComponents();
        ((BasicInternalFrameUI) getUI()).setNorthPane(null);

    }

    public List<Selebith> getSelebithtemp() {
        return selebithtemp;
    }

    public void setSelebithtemp(List<Selebith> selebithtemp) {
        this.selebithtemp = readText.dayincs(selebithtemp);
    }

    public void closeListplus2(Object[][] tableModel, String[] tableHead, String title) {
        varietiesDataPlus2 = new VarietiesDataPlus2(tableModel, tableHead);
        varietiesDataPlus2.setVisible(true);
        varietiesDataPlus2.setTitle(title);
        jDesktopPane2.removeAll();
        jDesktopPane2.add(varietiesDataPlus2); //在父窗口中添加这个子窗口
        try {
            varietiesDataPlus2.setSelected(true);
        } catch (java.beans.PropertyVetoException err) {
        }
        System.gc();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jDesktopPane2 = new javax.swing.JDesktopPane();
        jLabel6 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(233, 242, 252));
        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setTitle("选种选配");
        setToolTipText("");
        setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        setPreferredSize(new java.awt.Dimension(1010, 536));

        jPanel2.setBackground(new java.awt.Color(233, 242, 252));

        jButton1.setFont(new java.awt.Font("微软雅黑", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 102));
        jButton1.setText("选择育种分析文件");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setText("文件目录：");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 805, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabel5))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jDesktopPane2.setBackground(new java.awt.Color(233, 242, 252));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cn/archer/app/images/选种选配.png"))); // NOI18N

        jDesktopPane2.setLayer(jLabel6, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane2Layout = new javax.swing.GroupLayout(jDesktopPane2);
        jDesktopPane2.setLayout(jDesktopPane2Layout);
        jDesktopPane2Layout.setHorizontalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jDesktopPane2Layout.setVerticalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jDesktopPane2, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDesktopPane2))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        loadDia = new FileDialog(new Frame(), "育种数据", FileDialog.LOAD);
        loadDia.setVisible(true);// TODO add your handling code here:
        String directory = loadDia.getDirectory();
        String file = loadDia.getFile();
        if (directory != null && file != null) {
            readText = new ReadText(directory + file);
            readText.readTxt();
            readText.readTxtFile();
            jLabel5.setText("文件目录：" + directory + file);

        } else {
            JOptionPane.showMessageDialog(null, "请先选择育种分析文件！", "系统信息", JOptionPane.ERROR_MESSAGE);
        }       // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    public void setData() {
        jLabel5.setText("文件目录：");
        jDesktopPane2.removeAll();
        jDesktopPane2.add(jLabel6);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JDesktopPane jDesktopPane2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables

}
