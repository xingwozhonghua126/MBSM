/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Fence {

    private String fenceid;
    private String fencename;
    private String number;
    private String bz;

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public String getFencename() {
        return fencename;
    }

    public void setFencename(String fencename) {
        this.fencename = fencename;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }
}
