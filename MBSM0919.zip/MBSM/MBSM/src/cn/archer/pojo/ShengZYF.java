/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author WB
 */
public class ShengZYF {

    private String sfzz;
    private String r_animal;
    private String iftwo;
    private String r_curmark;
    private String r_pcage;
    private String nifhb;
    private String hyffenceid;
    private String hyafenceid;
    private String hysj;
    private String hyfzr;

    public String getSfzz() {
        return sfzz;
    }

    public void setSfzz(String sfzz) {
        this.sfzz = sfzz;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getIftwo() {
        return iftwo;
    }

    public void setIftwo(String iftwo) {
        this.iftwo = iftwo;
    }

    public String getR_curmark() {
        return r_curmark;
    }

    public void setR_curmark(String r_curmark) {
        this.r_curmark = r_curmark;
    }

    public String getR_pcage() {
        return r_pcage;
    }

    public void setR_pcage(String r_pcage) {
        this.r_pcage = r_pcage;
    }

    public String getNifhb() {
        return nifhb;
    }

    public void setNifhb(String nifhb) {
        this.nifhb = nifhb;
    }

    public String getHyffenceid() {
        return hyffenceid;
    }

    public void setHyffenceid(String hyffenceid) {
        this.hyffenceid = hyffenceid;
    }

    public String getHyafenceid() {
        return hyafenceid;
    }

    public void setHyafenceid(String hyafenceid) {
        this.hyafenceid = hyafenceid;
    }

    public String getHysj() {
        return hysj;
    }

    public void setHysj(String hysj) {
        this.hysj = hysj;
    }

    public String getHyfzr() {
        return hyfzr;
    }

    public void setHyfzr(String hyfzr) {
        this.hyfzr = hyfzr;
    }

    @Override
    public String toString() {
        return "ShengZYF{" + "r_animal=" + r_animal + ", iftwo=" + iftwo + ", r_curmark=" + r_curmark + ", r_pcage=" + r_pcage + ", nifhb=" + nifhb + ", hyffenceid=" + hyffenceid + ", hyafenceid=" + hyafenceid + ", hysj=" + hysj + ", hyfzr=" + hyfzr + '}';
    }

}
