/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Zzmy {

    private String id;
    private String r_animal;
    private String ztid;
    private String zsrq;
    private String ymid;
    private String employeeid;
    private String fenceid;
    private String zssm;
    private String bz;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getZtid() {
        return ztid;
    }

    public void setZtid(String ztid) {
        this.ztid = ztid;
    }

    public String getZsrq() {
        return zsrq;
    }

    public void setZsrq(String zsrq) {
        this.zsrq = zsrq;
    }

    public String getYmid() {
        return ymid;
    }

    public void setYmid(String ymid) {
        this.ymid = ymid;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public String getZssm() {
        return zssm;
    }

    public void setZssm(String zssm) {
        this.zssm = zssm;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
