package cn.archer.pojo;

/**
 *
 * @author Administrator
 */
public class Selebith {

    private int czzs;
    private int sfzz;
    private String r_lineid;
    private String r_herd;
    private String r_house;
    private String r_farmid;
    private String r_fdate;
    private String r_ear_no;
    private String r_animal;
    private String r_curmark;
    private String r_cage;
    private String r_pcage;
    private String r_sex;
    private Double r_bthwt;
    private int r_lsize;
    private String r_sire;
    private String r_dam;
    private int r_nipple1;
    private int r_nipple2;
    private String r_weanwt;
    private String r_date;
    private String r_ldate;
    private int r_ghatch;
    private int r_fno;
    private String r_note;
    //后添加的数据
    private String r_predate;
    private String whodo;
    private String nifbh;
    private String bhffenceid;
    private String bhafenceid;
    private int r_select;
    private String r_weandate;//
    private String nifzb;//
    private String zbffenceid;//
    private String zbafenceid;//
    private String zbfzr;//
    private String nifby;//
    private String byffenceid;
    private String bysj;
    private String byfzr;
    private String nifhb;
    private String hyffenceid;
    private String hyafenceid;
    private String hysj;
    private String hyfzr;
    private int gzcjcs;
    private String iftwo;
    private String iffour;
    private String ifsix;
    private String If100kg;
    private String xssj;
    private String ttsj;
    private String r_weanday;
    private String Byafenceid;
    private String dqpzgzid;

    public int getCzzs() {
        return czzs;
    }

    public void setCzzs(int czzs) {
        this.czzs = czzs;
    }

    public int getSfzz() {
        return sfzz;
    }

    public void setSfzz(int sfzz) {
        this.sfzz = sfzz;
    }

    public String getR_farmid() {
        return r_farmid;
    }

    public void setR_farmid(String r_farmid) {
        this.r_farmid = r_farmid;
    }

    public String getDqpzgzid() {
        return dqpzgzid;
    }

    public void setDqpzgzid(String dqpzgzid) {
        this.dqpzgzid = dqpzgzid;
    }

    public String getByafenceid() {
        return Byafenceid;
    }

    public void setByafenceid(String Byafenceid) {
        this.Byafenceid = Byafenceid;
    }

    public String getR_weanday() {
        return r_weanday;
    }

    public void setR_weanday(String r_weanday) {
        this.r_weanday = r_weanday;
    }

    public String getR_weandate() {
        return r_weandate;
    }

    public void setR_weandate(String r_weandate) {
        this.r_weandate = r_weandate;
    }

    public String getR_pcage() {
        return r_pcage;
    }

    public void setR_pcage(String r_pcage) {
        this.r_pcage = r_pcage;
    }

    public String getR_lineid() {
        return r_lineid;
    }

    public void setR_lineid(String r_lineid) {
        this.r_lineid = r_lineid;
    }

    public String getR_herd() {
        return r_herd;
    }

    public void setR_herd(String r_herd) {
        this.r_herd = r_herd;
    }

    public String getR_house() {
        return r_house;
    }

    public void setR_house(String r_house) {
        this.r_house = r_house;
    }

    public String getR_fdate() {
        return r_fdate;
    }

    public void setR_fdate(String r_fdate) {
        this.r_fdate = r_fdate;
    }

    public String getR_ear_no() {
        return r_ear_no;
    }

    public void setR_ear_no(String r_ear_no) {
        this.r_ear_no = r_ear_no;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getR_curmark() {
        return r_curmark;
    }

    public void setR_curmark(String r_curmark) {
        this.r_curmark = r_curmark;
    }

    public String getR_cage() {
        return r_cage;
    }

    public void setR_cage(String r_cage) {
        this.r_cage = r_cage;
    }

    public String getR_sex() {
        return r_sex;
    }

    public void setR_sex(String r_sex) {
        this.r_sex = r_sex;
    }

    public Double getR_bthwt() {
        return r_bthwt;
    }

    public void setR_bthwt(Double r_bthwt) {
        this.r_bthwt = r_bthwt;
    }

    public int getR_lsize() {
        return r_lsize;
    }

    public void setR_lsize(int r_lsize) {
        this.r_lsize = r_lsize;
    }

    public String getR_sire() {
        return r_sire;
    }

    public void setR_sire(String r_sire) {
        this.r_sire = r_sire;
    }

    public String getR_dam() {
        return r_dam;
    }

    public void setR_dam(String r_dam) {
        this.r_dam = r_dam;
    }

    public int getR_nipple1() {
        return r_nipple1;
    }

    public void setR_nipple1(int r_nipple1) {
        this.r_nipple1 = r_nipple1;
    }

    public int getR_nipple2() {
        return r_nipple2;
    }

    public void setR_nipple2(int r_nipple2) {
        this.r_nipple2 = r_nipple2;
    }

    public String getR_weanwt() {
        return r_weanwt;
    }

    public void setR_weanwt(String r_weanwt) {
        this.r_weanwt = r_weanwt;
    }

    public String getR_date() {
        return r_date;
    }

    public void setR_date(String r_date) {
        this.r_date = r_date;
    }

    public String getR_ldate() {
        return r_ldate;
    }

    public void setR_ldate(String r_ldate) {
        this.r_ldate = r_ldate;
    }

    public int getR_ghatch() {
        return r_ghatch;
    }

    public void setR_ghatch(int r_ghatch) {
        this.r_ghatch = r_ghatch;
    }

    public String getR_note() {
        return r_note;
    }

    public void setR_note(String r_note) {
        this.r_note = r_note;
    }

    public int getR_fno() {
        return r_fno;
    }

    public void setR_fno(int r_fno) {
        this.r_fno = r_fno;
    }

    public String getR_predate() {
        return r_predate;
    }

    public void setR_predate(String r_predate) {
        this.r_predate = r_predate;
    }

    public String getWhodo() {
        return whodo;
    }

    public void setWhodo(String whodo) {
        this.whodo = whodo;
    }

    public String getNifbh() {
        return nifbh;
    }

    public void setNifbh(String nifbh) {
        this.nifbh = nifbh;
    }

    public String getBhffenceid() {
        return bhffenceid;
    }

    public void setBhffenceid(String bhffenceid) {
        this.bhffenceid = bhffenceid;
    }

    public String getBhafenceid() {
        return bhafenceid;
    }

    public void setBhafenceid(String bhafenceid) {
        this.bhafenceid = bhafenceid;
    }

    public int getR_select() {
        return r_select;
    }

    public void setR_select(int r_select) {
        this.r_select = r_select;
    }

    public String getNifzb() {
        return nifzb;
    }

    public void setNifzb(String nifzb) {
        this.nifzb = nifzb;
    }

    public String getZbffenceid() {
        return zbffenceid;
    }

    public void setZbffenceid(String zbffenceid) {
        this.zbffenceid = zbffenceid;
    }

    public String getZbafenceid() {
        return zbafenceid;
    }

    public void setZbafenceid(String zbafenceid) {
        this.zbafenceid = zbafenceid;
    }

    public String getZbfzr() {
        return zbfzr;
    }

    public void setZbfzr(String zbfzr) {
        this.zbfzr = zbfzr;
    }

    public String getNifby() {
        return nifby;
    }

    public void setNifby(String nifby) {
        this.nifby = nifby;
    }

    public String getByffenceid() {
        return byffenceid;
    }

    public void setByffenceid(String byffenceid) {
        this.byffenceid = byffenceid;
    }

    public String getBysj() {
        return bysj;
    }

    public void setBysj(String bysj) {
        this.bysj = bysj;
    }

    public String getByfzr() {
        return byfzr;
    }

    public void setByfzr(String byfzr) {
        this.byfzr = byfzr;
    }

    public String getNifhb() {
        return nifhb;
    }

    public void setNifhb(String nifhb) {
        this.nifhb = nifhb;
    }

    public String getHyffenceid() {
        return hyffenceid;
    }

    public void setHyffenceid(String hyffenceid) {
        this.hyffenceid = hyffenceid;
    }

    public String getHyafenceid() {
        return hyafenceid;
    }

    public void setHyafenceid(String hyafenceid) {
        this.hyafenceid = hyafenceid;
    }

    public String getHysj() {
        return hysj;
    }

    public void setHysj(String hysj) {
        this.hysj = hysj;
    }

    public String getHyfzr() {
        return hyfzr;
    }

    public void setHyfzr(String hyfzr) {
        this.hyfzr = hyfzr;
    }

    public int getGzcjcs() {
        return gzcjcs;
    }

    public void setGzcjcs(int gzcjcs) {
        this.gzcjcs = gzcjcs;
    }

    public String getIftwo() {
        return iftwo;
    }

    public void setIftwo(String iftwo) {
        this.iftwo = iftwo;
    }

    public String getIffour() {
        return iffour;
    }

    public void setIffour(String iffour) {
        this.iffour = iffour;
    }

    public String getIfsix() {
        return ifsix;
    }

    public void setIfsix(String ifsix) {
        this.ifsix = ifsix;
    }

    public String getIf100kg() {
        return If100kg;
    }

    public void setIf100kg(String If100kg) {
        this.If100kg = If100kg;
    }

    public String getXssj() {
        return xssj;
    }

    public void setXssj(String xssj) {
        this.xssj = xssj;
    }

    public String getTtsj() {
        return ttsj;
    }

    public void setTtsj(String ttsj) {
        this.ttsj = ttsj;
    }

}
