/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Zzmysz {

    String id;
    String typeid;
    String szrq;
    String rqdw;
    String myname;
    String bz;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public String getSzrq() {
        return szrq;
    }

    public void setSzrq(String szrq) {
        this.szrq = szrq;
    }

    public String getRqdw() {
        return rqdw;
    }

    public void setRqdw(String rqdw) {
        this.rqdw = rqdw;
    }

    public String getMyname() {
        return myname;
    }

    public void setMyname(String myname) {
        this.myname = myname;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
