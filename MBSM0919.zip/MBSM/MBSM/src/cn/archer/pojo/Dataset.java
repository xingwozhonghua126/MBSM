/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Dataset {//double,Comparable,Comparable

    String abscissag;
    double ratio;
    String name;

    public Dataset(double ratio, String name, String abscissag) {
        this.ratio = ratio;
        this.name = name;
        this.abscissag = abscissag;

    }

    public String getAbscissag() {
        return abscissag;
    }

    public void setAbscissag(String abscissag) {
        this.abscissag = abscissag;
    }

    public double getRatio() {
        return ratio;
    }

    public void setRatio(int ratio) {
        this.ratio = ratio;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
