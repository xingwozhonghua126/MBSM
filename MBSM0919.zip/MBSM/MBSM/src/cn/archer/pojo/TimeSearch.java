package cn.archer.pojo;

import java.util.Date;

public class TimeSearch {

    private String id;
    private String name;
    private boolean isnot;
    private int number;
    private String date;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isIsnot() {
        return isnot;
    }

    public void setIsnot(boolean isnot) {
        this.isnot = isnot;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "TimeSearch [id=" + id + ", name=" + name + ", isnot=" + isnot + ", number=" + number + ", date=" + date
                + "]";
    }

}
