/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author WB
 */
public class HundredTest {

    private String r_animal;
    private String cdrq;
    private String zsex;
    private String fenceid;
    private Double weight;
    private String employeeid;
    private String cddd;
    private int rl;
    private String tc;
    private String tg;
    private String bg;
    private String xw;
    private String xs;
    private String fw;
    private String gw;
    private String ttw;
    private String htbbh;
    private String htyjmj;
    private String outfenceid;
    private String cdzt;
    private String bz;
    private String bz1;
    private String bz2;
    private String bz3;
    private String jg;

    public String getBz1() {
        return bz1;
    }

    public void setBz1(String bz1) {
        this.bz1 = bz1;
    }

    public String getBz2() {
        return bz2;
    }

    public void setBz2(String bz2) {
        this.bz2 = bz2;
    }

    public String getBz3() {
        return bz3;
    }

    public void setBz3(String bz3) {
        this.bz3 = bz3;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getCdrq() {
        return cdrq;
    }

    public void setCdrq(String cdrq) {
        this.cdrq = cdrq;
    }

    public String getZsex() {
        return zsex;
    }

    public void setZsex(String zsex) {
        this.zsex = zsex;
    }

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getCddd() {
        return cddd;
    }

    public void setCddd(String cddd) {
        this.cddd = cddd;
    }

    public int getRl() {
        return rl;
    }

    public void setRl(int rl) {
        this.rl = rl;
    }

    public String getTc() {
        return tc;
    }

    public void setTc(String tc) {
        this.tc = tc;
    }

    public String getTg() {
        return tg;
    }

    public void setTg(String tg) {
        this.tg = tg;
    }

    public String getBg() {
        return bg;
    }

    public void setBg(String bg) {
        this.bg = bg;
    }

    public String getXw() {
        return xw;
    }

    public void setXw(String xw) {
        this.xw = xw;
    }

    public String getXs() {
        return xs;
    }

    public void setXs(String xs) {
        this.xs = xs;
    }

    public String getFw() {
        return fw;
    }

    public void setFw(String fw) {
        this.fw = fw;
    }

    public String getGw() {
        return gw;
    }

    public void setGw(String gw) {
        this.gw = gw;
    }

    public String getTtw() {
        return ttw;
    }

    public void setTtw(String ttw) {
        this.ttw = ttw;
    }

    public String getHtbbh() {
        return htbbh;
    }

    public void setHtbbh(String htbbh) {
        this.htbbh = htbbh;
    }

    public String getHtyjmj() {
        return htyjmj;
    }

    public void setHtyjmj(String htyjmj) {
        this.htyjmj = htyjmj;
    }

    public String getOutfenceid() {
        return outfenceid;
    }

    public void setOutfenceid(String outfenceid) {
        this.outfenceid = outfenceid;
    }

    public String getCdzt() {
        return cdzt;
    }

    public void setCdzt(String cdzt) {
        this.cdzt = cdzt;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

    public String getJg() {
        return jg;
    }

    public void setJg(String jg) {
        this.jg = jg;
    }

}
