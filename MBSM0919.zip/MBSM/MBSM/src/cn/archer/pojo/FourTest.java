/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author WB
 */
public class FourTest {

    private String r_animal;
    private String cdrq;
    private String zsex;
    private String fenceid;
    private Double weight;
    private String employeeid;
    private String fxrts;
    private String fxqxrt;
    private int fxzhpf;
    private String ywss;
    private String sfgx;
    private int ygzhpf;
    private String ztzsfgx;
    private String ztfgjsfhl;
    private String ztszywssyz;
    private int ztzhpf;
    private String txqhqgc;
    private String txhtcqs;
    private String txlgxz;
    private int txzhpf;
    private String qjyl;
    private String jpz;
    private String qtyd;
    private String bltt;
    private String blbfb;
    private String bz;
    private String bz1;
    private String bz2;
    private String bz3;
    private String outfenceid;
    private String cdzt;
    private String jg;

    public String getBz1() {
        return bz1;
    }

    public void setBz1(String bz1) {
        this.bz1 = bz1;
    }

    public String getBz2() {
        return bz2;
    }

    public void setBz2(String bz2) {
        this.bz2 = bz2;
    }

    public String getBz3() {
        return bz3;
    }

    public void setBz3(String bz3) {
        this.bz3 = bz3;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getCdrq() {
        return cdrq;
    }

    public void setCdrq(String cdrq) {
        this.cdrq = cdrq;
    }

    public String getZsex() {
        return zsex;
    }

    public void setZsex(String zsex) {
        this.zsex = zsex;
    }

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getFxrts() {
        return fxrts;
    }

    public void setFxrts(String fxrts) {
        this.fxrts = fxrts;
    }

    public String getFxqxrt() {
        return fxqxrt;
    }

    public void setFxqxrt(String fxqxrt) {
        this.fxqxrt = fxqxrt;
    }

    public int getFxzhpf() {
        return fxzhpf;
    }

    public void setFxzhpf(int fxzhpf) {
        this.fxzhpf = fxzhpf;
    }

    public String getYwss() {
        return ywss;
    }

    public void setYwss(String ywss) {
        this.ywss = ywss;
    }

    public String getSfgx() {
        return sfgx;
    }

    public void setSfgx(String sfgx) {
        this.sfgx = sfgx;
    }

    public int getYgzhpf() {
        return ygzhpf;
    }

    public void setYgzhpf(int ygzhpf) {
        this.ygzhpf = ygzhpf;
    }

    public String getZtzsfgx() {
        return ztzsfgx;
    }

    public void setZtzsfgx(String ztzsfgx) {
        this.ztzsfgx = ztzsfgx;
    }

    public String getZtfgjsfhl() {
        return ztfgjsfhl;
    }

    public void setZtfgjsfhl(String ztfgjsfhl) {
        this.ztfgjsfhl = ztfgjsfhl;
    }

    public String getZtszywssyz() {
        return ztszywssyz;
    }

    public void setZtszywssyz(String ztszywssyz) {
        this.ztszywssyz = ztszywssyz;
    }

    public int getZtzhpf() {
        return ztzhpf;
    }

    public void setZtzhpf(int ztzhpf) {
        this.ztzhpf = ztzhpf;
    }

    public String getTxqhqgc() {
        return txqhqgc;
    }

    public void setTxqhqgc(String txqhqgc) {
        this.txqhqgc = txqhqgc;
    }

    public String getTxhtcqs() {
        return txhtcqs;
    }

    public void setTxhtcqs(String txhtcqs) {
        this.txhtcqs = txhtcqs;
    }

    public String getTxlgxz() {
        return txlgxz;
    }

    public void setTxlgxz(String txlgxz) {
        this.txlgxz = txlgxz;
    }

    public int getTxzhpf() {
        return txzhpf;
    }

    public void setTxzhpf(int txzhpf) {
        this.txzhpf = txzhpf;
    }

    public String getQjyl() {
        return qjyl;
    }

    public void setQjyl(String qjyl) {
        this.qjyl = qjyl;
    }

    public String getJpz() {
        return jpz;
    }

    public void setJpz(String jpz) {
        this.jpz = jpz;
    }

    public String getQtyd() {
        return qtyd;
    }

    public void setQtyd(String qtyd) {
        this.qtyd = qtyd;
    }

    public String getBltt() {
        return bltt;
    }

    public void setBltt(String bltt) {
        this.bltt = bltt;
    }

    public String getBlbfb() {
        return blbfb;
    }

    public void setBlbfb(String blbfb) {
        this.blbfb = blbfb;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

    public String getOutfenceid() {
        return outfenceid;
    }

    public void setOutfenceid(String outfenceid) {
        this.outfenceid = outfenceid;
    }

    public String getCdzt() {
        return cdzt;
    }

    public void setCdzt(String cdzt) {
        this.cdzt = cdzt;
    }

    public String getJg() {
        return jg;
    }

    public void setJg(String jg) {
        this.jg = jg;
    }

    @Override
    public String toString() {
        return "TwoTest{" + "r_animal=" + r_animal + ", cdrq=" + cdrq + ", zsex=" + zsex + ", fenceid=" + fenceid + ", weight=" + weight + ", employeeid=" + employeeid + ", fxrts=" + fxrts + ", fxqxrt=" + fxqxrt + ", fxzhpf=" + fxzhpf + ", ywss=" + ywss + ", sfgx=" + sfgx + ", ygzhpf=" + ygzhpf + ", ztzsfgx=" + ztzsfgx + ", ztfgjsfhl=" + ztfgjsfhl + ", ztszywssyz=" + ztszywssyz + ", ztzhpf=" + ztzhpf + ", txqhqgc=" + txqhqgc + ", txhtcqs=" + txhtcqs + ", txlgxz=" + txlgxz + ", txzhpf=" + txzhpf + ", qjyl=" + qjyl + ", jpz=" + jpz + ", qtyd=" + qtyd + ", bltt=" + bltt + ", blbfb=" + blbfb + ", bz=" + bz + ", outfenceid=" + outfenceid + ", cdzt=" + cdzt + '}';
    }

}
