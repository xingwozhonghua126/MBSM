package cn.archer.pojo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.*;
import cn.archer.pojo.*;

/**
 *
 * @author Administrator
 */
public class Breeding {

    private String id;
    private String r_animal;
    private int pztc;
    private String fqrq;
    private String pzrq;
    private String onetype;
    private String oner_animal;
    private String twotype;
    private String twor_animal;
    private String threetype;
    private String threer_animal;
    private String ycrq;
    private String employeeid;
    private String fenceid;
    private String outfenceid;
    private String pzzt;
    private String bz;

    public String getOutfenceid() {
        return outfenceid;
    }

    public void setOutfenceid(String outfenceid) {
        this.outfenceid = outfenceid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public int getPztc() {
        return pztc;
    }

    public void setPztc(int pztc) {
        this.pztc = pztc;
    }

    public String getFqrq() {
        return fqrq;
    }

    public void setFqrq(String fqrq) {
        this.fqrq = fqrq;
    }

    public String getPzrq() {
        return pzrq;
    }

    public void setPzrq(String pzrq) {
        this.pzrq = pzrq;
    }

    public String getOnetype() {
        return onetype;
    }

    public void setOnetype(String onetype) {
        this.onetype = onetype;
    }

    public String getOner_animal() {
        return oner_animal;
    }

    public void setOner_animal(String oner_animal) {
        this.oner_animal = oner_animal;
    }

    public String getTwotype() {
        return twotype;
    }

    public void setTwotype(String twotype) {
        this.twotype = twotype;
    }

    public String getTwor_animal() {
        return twor_animal;
    }

    public void setTwor_animal(String twor_animal) {
        this.twor_animal = twor_animal;
    }

    public String getThreetype() {
        return threetype;
    }

    public void setThreetype(String threetype) {
        this.threetype = threetype;
    }

    public String getThreer_animal() {
        return threer_animal;
    }

    public void setThreer_animal(String threer_animal) {
        this.threer_animal = threer_animal;
    }

    public String getYcrq() {
        return ycrq;
    }

    public void setYcrq(String ycrq) {
        this.ycrq = ycrq;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public String getPzzt() {
        return pzzt;
    }

    public void setPzzt(String pzzt) {
        this.pzzt = pzzt;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
