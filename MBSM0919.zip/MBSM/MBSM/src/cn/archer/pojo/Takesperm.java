package cn.archer.pojo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.*;

/**
 *
 * @author Administrator
 */
public class Takesperm {

    private String id;
    private String r_animal;
    private String cjrq;
    private int cjcs;
    private int cjsl;
    private int cjmd;
    private int cjhl;
    private int cjjl;
    private String employeeid;
    private String bz;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getCjrq() {
        return cjrq;
    }

    public void setCjrq(String cjrq) {
        this.cjrq = cjrq;
    }

    public int getCjcs() {
        return cjcs;
    }

    public void setCjcs(int cjcs) {
        this.cjcs = cjcs;
    }

    public int getCjsl() {
        return cjsl;
    }

    public void setCjsl(int cjsl) {
        this.cjsl = cjsl;
    }

    public int getCjmd() {
        return cjmd;
    }

    public void setCjmd(int cjmd) {
        this.cjmd = cjmd;
    }

    public int getCjhl() {
        return cjhl;
    }

    public void setCjhl(int cjhl) {
        this.cjhl = cjhl;
    }

    public int getCjjl() {
        return cjjl;
    }

    public void setCjjl(int cjjl) {
        this.cjjl = cjjl;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
