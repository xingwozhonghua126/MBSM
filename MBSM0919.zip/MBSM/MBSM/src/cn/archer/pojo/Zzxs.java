/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Zzxs {

    private String id;
    private String xsrq;
    private int xsgs;
    private Double zzzl;
    private Double xsje;
    private String employeeid;
    private String bz1;
    private String bz2;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getXsrq() {
        return xsrq;
    }

    public void setXsrq(String xsrq) {
        this.xsrq = xsrq;
    }

    public int getXsgs() {
        return xsgs;
    }

    public void setXsgs(int xsgs) {
        this.xsgs = xsgs;
    }

    public Double getZzzl() {
        return zzzl;
    }

    public void setZzzl(Double zzzl) {
        this.zzzl = zzzl;
    }

    public Double getXsje() {
        return xsje;
    }

    public void setXsje(Double xsje) {
        this.xsje = xsje;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getBz1() {
        return bz1;
    }

    public void setBz1(String bz) {
        this.bz1 = bz;
    }

    public String getBz2() {
        return bz2;
    }

    public void setBz2(String bz) {
        this.bz2 = bz;
    }

}
