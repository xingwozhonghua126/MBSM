/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author hp
 */
public class FarmName {
    private String id;
    private String farm_name;
    private String farm_id;
    private String farm_add;
    private String farm_code;
    private String farm_fzr;
    private String bz;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFarm_name() {
        return farm_name;
    }

    public void setFarm_name(String farm_name) {
        this.farm_name = farm_name;
    }

    public String getFarm_id() {
        return farm_id;
    }

    public void setFarm_id(String farm_id) {
        this.farm_id = farm_id;
    }

    public String getFarm_add() {
        return farm_add;
    }

    public void setFarm_add(String farm_add) {
        this.farm_add = farm_add;
    }

    public String getFarm_code() {
        return farm_code;
    }

    public void setFarm_code(String farm_code) {
        this.farm_code = farm_code;
    }

    public String getFarm_fzr() {
        return farm_fzr;
    }

    public void setFarm_fzr(String farm_fzr) {
        this.farm_fzr = farm_fzr;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
