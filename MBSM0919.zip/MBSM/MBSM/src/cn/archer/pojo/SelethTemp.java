/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class SelethTemp {

    private int czzs;
    private String r_lineid;
    private String r_herd;
    private String r_house;
    private String r_fdate;
    private String r_ear_no;
    private String r_animal;
    private String r_curmark;
    private String r_cage;
    private String r_pcage;
    private String r_sex;
    private Double r_bthwt;
    private String r_dam;
    private int pKey;
    private String r_sire;
    private int r_lsize;
    private int r_nipple1;
    private int r_nipple2;
    private int r_ghatch;
    private int r_fno;
    private String r_weanwt;
    private String r_date;
    private String r_ldate;
    private String r_note;

    public int getCzzs() {
        return czzs;
    }

    public void setCzzs(int czzs) {
        this.czzs = czzs;
    }

    public int getpKey() {
        return pKey;
    }

    public String getR_lineid() {
        return r_lineid;
    }

    public void setR_lineid(String r_lineid) {
        this.r_lineid = r_lineid;
    }

    public String getR_herd() {
        return r_herd;
    }

    public void setR_herd(String r_herd) {
        this.r_herd = r_herd;
    }

    public String getR_house() {
        return r_house;
    }

    public void setR_house(String r_house) {
        this.r_house = r_house;
    }

    public String getR_fdate() {
        return r_fdate;
    }

    public void setR_fdate(String r_fdate) {
        this.r_fdate = r_fdate;
    }

    public String getR_ear_no() {
        return r_ear_no;
    }

    public void setR_ear_no(String r_ear_no) {
        this.r_ear_no = r_ear_no;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getR_curmark() {
        return r_curmark;
    }

    public void setR_curmark(String r_curmark) {
        this.r_curmark = r_curmark;
    }

    public String getR_cage() {
        return r_cage;
    }

    public void setR_cage(String r_cage) {
        this.r_cage = r_cage;
    }

    public String getR_pcage() {
        return r_pcage;
    }

    public void setR_pcage(String r_pcage) {
        this.r_pcage = r_pcage;
    }

    public String getR_sex() {
        return r_sex;
    }

    public void setR_sex(String r_sex) {
        this.r_sex = r_sex;
    }

    public Double getR_bthwt() {
        return r_bthwt;
    }

    public void setR_bthwt(Double r_bthwt) {
        this.r_bthwt = r_bthwt;
    }

    public String getR_dam() {
        return r_dam;
    }

    public void setR_dam(String r_dam) {
        this.r_dam = r_dam;
    }

    public String getR_sire() {
        return r_sire;
    }

    public void setR_sire(String r_sire) {
        this.r_sire = r_sire;
    }

    public int getR_lsize() {
        return r_lsize;
    }

    public void setR_lsize(int r_lsize) {
        this.r_lsize = r_lsize;
    }

    public int getR_nipple1() {
        return r_nipple1;
    }

    public void setR_nipple1(int r_nipple1) {
        this.r_nipple1 = r_nipple1;
    }

    public int getR_nipple2() {
        return r_nipple2;
    }

    public void setR_nipple2(int r_nipple2) {
        this.r_nipple2 = r_nipple2;
    }

    public int getR_ghatch() {
        return r_ghatch;
    }

    public void setR_ghatch(int r_ghatch) {
        this.r_ghatch = r_ghatch;
    }

    public int getR_fno() {
        return r_fno;
    }

    public void setR_fno(int r_fno) {
        this.r_fno = r_fno;
    }

    public String getR_weanwt() {
        return r_weanwt;
    }

    public void setR_weanwt(String r_weanwt) {
        this.r_weanwt = r_weanwt;
    }

    public String getR_date() {
        return r_date;
    }

    public void setR_date(String r_date) {
        this.r_date = r_date;
    }

    public String getR_ldate() {
        return r_ldate;
    }

    public void setR_ldate(String r_ldate) {
        this.r_ldate = r_ldate;
    }

    public String getR_note() {
        return r_note;
    }

    public void setR_note(String r_note) {
        this.r_note = r_note;
    }

}
