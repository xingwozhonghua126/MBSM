/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Tzxncd {

    private String r_animal;
    private String fenceid;
    private String cdrq;
    private String zqhz;
    private String ttz;
    private String zttz;
    private String yttz;
    private String ttc;
    private String bbh1;
    private String bbh2;
    private String bbh3;
    private String pjbbh;
    private String yjmj;
    private String gz;
    private String pz;
    private String srz;
    private String frz;
    private String rspf;
    private String rsl;
    private String rsa;
    private String rsb;
    private String dlsw;
    private String jrzf;
    private String ph1;
    private String ph24;
    private String dsss;
    private String jrhsl;
    private String employeeid;
    private String bz;

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public String getCdrq() {
        return cdrq;
    }

    public void setCdrq(String cdrq) {
        this.cdrq = cdrq;
    }

    public String getZqhz() {
        return zqhz;
    }

    public void setZqhz(String zqhz) {
        this.zqhz = zqhz;
    }

    public String getTtz() {
        return ttz;
    }

    public void setTtz(String ttz) {
        this.ttz = ttz;
    }

    public String getZttz() {
        return zttz;
    }

    public void setZttz(String zttz) {
        this.zttz = zttz;
    }

    public String getYttz() {
        return yttz;
    }

    public void setYttz(String yttz) {
        this.yttz = yttz;
    }

    public String getTtc() {
        return ttc;
    }

    public void setTtc(String ttc) {
        this.ttc = ttc;
    }

    public String getBbh1() {
        return bbh1;
    }

    public void setBbh1(String bbh1) {
        this.bbh1 = bbh1;
    }

    public String getBbh2() {
        return bbh2;
    }

    public void setBbh2(String bbh2) {
        this.bbh2 = bbh2;
    }

    public String getBbh3() {
        return bbh3;
    }

    public void setBbh3(String bbh3) {
        this.bbh3 = bbh3;
    }

    public String getPjbbh() {
        return pjbbh;
    }

    public void setPjbbh(String pjbbh) {
        this.pjbbh = pjbbh;
    }

    public String getYjmj() {
        return yjmj;
    }

    public void setYjmj(String yjmj) {
        this.yjmj = yjmj;
    }

    public String getGz() {
        return gz;
    }

    public void setGz(String gz) {
        this.gz = gz;
    }

    public String getPz() {
        return pz;
    }

    public void setPz(String pz) {
        this.pz = pz;
    }

    public String getSrz() {
        return srz;
    }

    public void setSrz(String srz) {
        this.srz = srz;
    }

    public String getFrz() {
        return frz;
    }

    public void setFrz(String frz) {
        this.frz = frz;
    }

    public String getRspf() {
        return rspf;
    }

    public void setRspf(String rspf) {
        this.rspf = rspf;
    }

    public String getRsl() {
        return rsl;
    }

    public void setRsl(String rsl) {
        this.rsl = rsl;
    }

    public String getRsa() {
        return rsa;
    }

    public void setRsa(String rsa) {
        this.rsa = rsa;
    }

    public String getRsb() {
        return rsb;
    }

    public void setRsb(String rsb) {
        this.rsb = rsb;
    }

    public String getDlsw() {
        return dlsw;
    }

    public void setDlsw(String dlsw) {
        this.dlsw = dlsw;
    }

    public String getJrzf() {
        return jrzf;
    }

    public void setJrzf(String jrzf) {
        this.jrzf = jrzf;
    }

    public String getPh1() {
        return ph1;
    }

    public void setPh1(String ph1) {
        this.ph1 = ph1;
    }

    public String getPh24() {
        return ph24;
    }

    public void setPh24(String ph24) {
        this.ph24 = ph24;
    }

    public String getDsss() {
        return dsss;
    }

    public void setDsss(String dsss) {
        this.dsss = dsss;
    }

    public String getJrhsl() {
        return jrhsl;
    }

    public void setJrhsl(String jrhsl) {
        this.jrhsl = jrhsl;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
