/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

import cn.archer.pojo.*;

/**
 *
 * @author Administrator
 */
public class Lineherd {

    private String herdid;
    private String herdname;
    private String lineid;

    public String getHerdid() {
        return herdid;
    }

    public void setHerdid(String herdid) {
        this.herdid = herdid;
    }

    public String getHerdname() {
        return herdname;
    }

    public void setHerdname(String herdname) {
        this.herdname = herdname;
    }

    public String getLineid() {
        return lineid;
    }

    public void setLineid(String lineid) {
        this.lineid = lineid;
    }

}
