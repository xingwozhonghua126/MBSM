/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author Administrator
 */
public class Swintype {

    private String typeid;
    private String typename;
    private String totypeid;

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public String getTypename() {
        return typename;
    }

    public void setTypename(String typename) {
        this.typename = typename;
    }

    public String getTotypeid() {
        return totypeid;
    }

    public void setTotypeid(String totypeid) {
        this.totypeid = totypeid;
    }

}
