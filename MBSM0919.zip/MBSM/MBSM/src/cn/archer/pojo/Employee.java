package cn.archer.pojo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cn.archer.pojo.*;

/**
 *
 * @author Administrator
 */
public class Employee {

    private String employeeid;
    private String user_name;
    private String Password;
    private String superroot;
    private String isallfarm;
    private String money;
    private String rzsj;
    private String worksm;
    private String ygzw;
    private String bz;

    public String getYgzw() {
        return ygzw;
    }

    public void setYgzw(String ygzw) {
        this.ygzw = ygzw;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getSuperroot() {
        return superroot;
    }

    public void setSuperroot(String superroot) {
        this.superroot = superroot;
    }

    public String getIsallfarm() {
        return isallfarm;
    }

    public void setIsallfarm(String isallfarm) {
        this.isallfarm = isallfarm;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getRzsj() {
        return rzsj;
    }

    public void setRzsj(String rzsj) {
        this.rzsj = rzsj;
    }

    public String getWorksm() {
        return worksm;
    }

    public void setWorksm(String worksm) {
        this.worksm = worksm;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
