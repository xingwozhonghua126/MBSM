package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Childbirth {

    private String id;
    private String r_animal;
    private String farm_id;
    private String fenceid;
    private String fwfenceid;
    private String fwemployeeid;
    private String pzemployeeid;
    private int tc;
    private String czrq;
    private int zczs;
    private int czhs;
    private int cgzs;
    private int cmzs;
    private int jxs;
    private int sds;
    private int mny;
    private Double cswz;
    private int jl;
    private int jc;
    private String outfenceid;
    private String dnrq;
    private int dnrl;
    private int dnts;
    private Double dnwz;
    private String employeeid;
    private String zt;
    private String bz;

    public String getPzemployeeid() {
        return pzemployeeid;
    }

    public void setPzemployeeid(String pzemployeeid) {
        this.pzemployeeid = pzemployeeid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getFarm_id() {
        return farm_id;
    }

    public void setFarm_id(String farm_id) {
        this.farm_id = farm_id;
    }

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public String getFwfenceid() {
        return fwfenceid;
    }

    public void setFwfenceid(String fwfenceid) {
        this.fwfenceid = fwfenceid;
    }

    public String getFwemployeeid() {
        return fwemployeeid;
    }

    public void setFwemployeeid(String fwemployeeid) {
        this.fwemployeeid = fwemployeeid;
    }

    public int getTc() {
        return tc;
    }

    public void setTc(int tc) {
        this.tc = tc;
    }

    public String getCzrq() {
        return czrq;
    }

    public void setCzrq(String czrq) {
        this.czrq = czrq;
    }

    public int getZczs() {
        return zczs;
    }

    public void setZczs(int zczs) {
        this.zczs = zczs;
    }

    public int getCzhs() {
        return czhs;
    }

    public void setCzhs(int czhs) {
        this.czhs = czhs;
    }

    public int getCgzs() {
        return cgzs;
    }

    public void setCgzs(int cgzs) {
        this.cgzs = cgzs;
    }

    public int getCmzs() {
        return cmzs;
    }

    public void setCmzs(int cmzs) {
        this.cmzs = cmzs;
    }

    public int getJxs() {
        return jxs;
    }

    public void setJxs(int jxs) {
        this.jxs = jxs;
    }

    public int getSds() {
        return sds;
    }

    public void setSds(int sds) {
        this.sds = sds;
    }

    public int getMny() {
        return mny;
    }

    public void setMny(int mny) {
        this.mny = mny;
    }

    public Double getCswz() {
        return cswz;
    }

    public void setCswz(Double cswz) {
        this.cswz = cswz;
    }

    public int getJl() {
        return jl;
    }

    public void setJl(int jl) {
        this.jl = jl;
    }

    public int getJc() {
        return jc;
    }

    public void setJc(int jc) {
        this.jc = jc;
    }

    public String getOutfenceid() {
        return outfenceid;
    }

    public void setOutfenceid(String outfenceid) {
        this.outfenceid = outfenceid;
    }

    public String getDnrq() {
        return dnrq;
    }

    public void setDnrq(String dnrq) {
        this.dnrq = dnrq;
    }

    public int getDnrl() {
        return dnrl;
    }

    public void setDnrl(int dnrl) {
        this.dnrl = dnrl;
    }

    public int getDnts() {
        return dnts;
    }

    public void setDnts(int dnts) {
        this.dnts = dnts;
    }

    public Double getDnwz() {
        return dnwz;
    }

    public void setDnwz(Double dnwz) {
        this.dnwz = dnwz;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getZt() {
        return zt;
    }

    public void setZt(String zt) {
        this.zt = zt;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
