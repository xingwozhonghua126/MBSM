/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.archer.pojo;

/**
 *
 * @author 24161
 */
public class Zzsw {

    private String r_animal;
    private String swrq;
    private String fenceid;
    private String swyy;
    private String employeeid;
    private String bz;

    public String getR_animal() {
        return r_animal;
    }

    public void setR_animal(String r_animal) {
        this.r_animal = r_animal;
    }

    public String getSwrq() {
        return swrq;
    }

    public void setSwrq(String swrq) {
        this.swrq = swrq;
    }

    public String getFenceid() {
        return fenceid;
    }

    public void setFenceid(String fenceid) {
        this.fenceid = fenceid;
    }

    public String getSwyy() {
        return swyy;
    }

    public void setSwyy(String swyy) {
        this.swyy = swyy;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

}
